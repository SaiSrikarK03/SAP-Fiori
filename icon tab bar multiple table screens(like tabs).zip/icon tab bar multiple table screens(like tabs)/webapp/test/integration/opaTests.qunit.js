/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["zrdcandnrdcprint/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
