sap.ui.define([
	"zrdcandnrdcprint/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
