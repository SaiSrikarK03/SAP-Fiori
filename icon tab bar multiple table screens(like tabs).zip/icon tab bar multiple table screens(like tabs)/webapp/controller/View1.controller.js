sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "zrdcandnrdcprint/util/PDFLib"
], (Controller, exportLibrary, Spreadsheet) => {
    "use strict";

    return Controller.extend("zrdcandnrdcprint.controller.View1", {

        onInit() {

            // TransModel:
            var oModel1 = new sap.ui.model.json.JSONModel({
                Datas: []

            });
            this.getView().setModel(oModel1, "TransModel");

            // EditModel:
            var oModel2 = new sap.ui.model.json.JSONModel({
                editable1: true,
                editable2: true,
                PlantVisible: false
            });
            this.getView().setModel(oModel2, "EditModel");

            // TabModel:            
            var oModel = new sap.ui.model.json.JSONModel({
                items: []

            });
            this.getView().setModel(oModel, "TabModel");


            this.ReadFunction();
        },
        onAfterRendering: function () {
            var oUserRoleModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oUserRoleModel, "UserModel");

            var oModel = this.getView().getModel("ZCE_USER_BUSINESS_ROLE"); // OData V2 service
            var sUserId = sap.ushell.Container.getUser().getId(); // gets current logged-in user

            var filter1 = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId)
            var filter2 = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, "ZF_RDC_UPDATE_ROLE")

            var that = this;
            oModel.read("/ZCE_USERBUSINESSROLE", {
                filters: [filter1, filter2],
                success: function (oData) {
                    if (oData.results.length > 0) {
                        //   console.log("Tenant user found:", tenantUser);
                        that.AdminPanelAuth = new sap.ui.model.json.JSONModel({
                            Samples: { Role: true }
                        });
                        that.getView().setModel(that.AdminPanelAuth, "AdminPanelAuth");
                        console.log("that.AdminPanelAuth:", that.AdminPanelAuth);
                        sap.ui.core.BusyIndicator.hide();
                        //resolve(oData.results);

                        // You can handle the case where the tenant user is found here
                    } else {
                        console.log("Tenant user not found");
                        that.AdminPanelAuth = new sap.ui.model.json.JSONModel({
                            Samples: { Role: false }
                        });
                        that.getView().setModel(that.AdminPanelAuth, "AdminPanelAuth");
                        console.log("that.AdminPanelAuth:", that.AdminPanelAuth);
                        sap.ui.core.BusyIndicator.hide();
                        // resolve(oData.results);
                    }
                },
                error: function (oError) {
                    console.error("Failed to fetch roles", oError);
                    oUserRoleModel.setProperty("/roles", []);
                }
            });

        },
        ReadFunction: function () {

            sap.ui.core.BusyIndicator.show(0);

            // TABMODEL:

            var that = this;

            let Z_NRDC_Model = this.getOwnerComponent().getModel();

            Z_NRDC_Model.read("/ZASSET_RDC_NRDC", {
                urlParameters: {
                    "$orderby": "doc_no asc"
                },
                success: function (oData) {


                    sap.ui.core.BusyIndicator.hide();

                    if (oData.results && oData.results.length > 0) {

                        that.TabModel = new sap.ui.model.json.JSONModel({
                            items: oData.results

                        });
                        that.getView().setModel(that.TabModel, "TabModel");
                    } else {

                        that.TabModel = new sap.ui.model.json.JSONModel({
                            items: []

                        });
                        that.getView().setModel(that.TabModel, "TabModel");

                    }
                },
                error: function (oError) {

                    sap.ui.core.BusyIndicator.hide();

                    console.error("Error reading OData:", oError);
                    that.TabModel = new sap.ui.model.json.JSONModel({
                        items: []
                    });
                    that.getView().setModel(that.TabModel, "TabModel");
                }
            });


        },

        onAddPress: function () {

            sap.ui.core.BusyIndicator.show(0);

            if (this.byId("idComboBox").getSelectedKey() == "") {
                sap.m.MessageToast.show("Please select Document Type");
                this.byId("idComboBox").setValueState("Error");
                this.byId("idComboBox").setValueStateText("Please select");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            var oCombo = this.byId("idComboBox").getSelectedKey();
            if (oCombo === "RDC") {
                var oModel = this.getView().getModel("EditModel");
                oModel.setProperty("/editable1", true);
                oModel.setProperty("/editable2", true);
            } else {
                var oModel = this.getView().getModel("EditModel");
                oModel.setProperty("/editable1", false);
                oModel.setProperty("/editable2", false);
            }

            var oModel = this.getView().getModel("TransModel");
            var aItems = oModel.getProperty("/Datas");

            // Get details from first row
            var sSupplierCode = "";
            var sSupplierName = "";
            var sPlant = "";

            if (aItems.length > 0) {
                sSupplierCode = aItems[0].supplier_code;
                sSupplierName = aItems[0].supplier_name;
                sPlant = aItems[0].plant;
            }

            var sReceivingPlant = "";
            if (aItems.length > 0) {
                sReceivingPlant = aItems[0].receivingplant;
            }

            var sRefDoc = "";
            if (aItems.length > 0) {
                sRefDoc = aItems[0].reference_doc;
            }


            var sReqName = "";
            if (aItems.length > 0) {
                sReqName = aItems[0].requester_name;
            }

            var oModel = this.getView().getModel("TransModel");
            var aItems = oModel.getProperty("/Datas");
            aItems.push({
                asset_no: "",
                item_desc: "",
                plant: sPlant || "",
                plantEditable: aItems.length === 0 ? true : false,
                unit_price: "",
                quantity: "",
                uom: "",
                total_amount: "",
                showValueHelp: aItems.length === 0,
                editable: aItems.length === 0 ? true : false,
                supplier_code: sSupplierCode || "",
                supplier_name: sSupplierName || "",
                receivingplant: sReceivingPlant || "",
                receivingplantEditable: aItems.length === 0 ? true : false,
                doc_type: "",
                reference_doc: sRefDoc || "",
                return_flg: false,
                posting_date: "",
                requester_name: sReqName || "",
                editable3: aItems.length === 0 ? true : false,
                hsn_code: "",
                vehicleno: "",
                transpotername: "",
                transpoterid: "",
                handoverpersonname: "",
                termsofdelivery: "",
                remarks: ""
            });
            oModel.setProperty("/Datas", aItems);
            sap.ui.core.BusyIndicator.hide();

        },

        onDocumentTypeTChange: function () {
            var selectedDocType = this.byId("idComboBox").getSelectedKey();
            if (selectedDocType && selectedDocType === "NRDC") {
                this.getView().getModel("EditModel").setProperty("/ReceivingPlantVisible", true);
                this.getView().getModel("EditModel").setProperty("/SupplierCodeVisible", true);
                this.getView().getModel("EditModel").setProperty("/SupplierNameVisible", true);
                this.byId("idComboBox").setEnabled(false);
            } else {
                this.getView().getModel("EditModel").setProperty("/ReceivingPlantVisible", false);
                this.getView().getModel("EditModel").setProperty("/SupplierCodeVisible", false);
                this.getView().getModel("EditModel").setProperty("/SupplierNameVisible", false);
                this.byId("idComboBox").setEnabled(false);
            }
        },

        formatDate: function (Datess) {
            if (!Datess) {
                return null;
            }

            var oDate = new Date(Datess);

            var yyyy = oDate.getFullYear();
            var mm = String(oDate.getMonth() + 1).padStart(2, "0");
            var dd = String(oDate.getDate()).padStart(2, "0");

            // DateTime format
            return yyyy + "-" + mm + "-" + dd + "T00:00:00";
        },

        onResetPress: function () {
            var oModel = this.getView().getModel("TransModel");
            oModel.setProperty("/Datas", []);
            this.byId("idComboBox").setEnabled(true);
            this.byId("idComboBox").setSelectedKey("");
            this.byId("idComboBox").setValueState("None");
            this.byId("idComboBox").setValueStateText("");
        },

        onDeletePress: function () {

            var oTable = this.byId("idTable");
            var aSelectedIndices = oTable.getSelectedIndices();

            if (!aSelectedIndices.length) {
                sap.m.MessageToast.show("Select at least one row");
                return;
            }

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");

            aSelectedIndices.sort(function (a, b) {
                return b - a;
            });

            aSelectedIndices.forEach(function (iIndex) {
                aData.splice(iIndex, 1);
            });

            oModel.setProperty("/Datas", aData);
            oTable.clearSelection();
        },
        onGoPress: async function () {
            sap.ui.core.BusyIndicator.show(0);

            var oCombo = this.byId("idReportComboBox").getSelectedKey();

            var oDocNo = this.byId("doc_no_input_id").getValue();


            let aFilter = [];

            if (oCombo) {
                aFilter.push(
                    new sap.ui.model.Filter("doc_no", sap.ui.model.FilterOperator.StartsWith, oCombo)
                );
            }

            if (oDocNo) {
                aFilter.push(
                    new sap.ui.model.Filter("doc_no", sap.ui.model.FilterOperator.EQ, oDocNo)
                );
            }


            let oFilter = [];

            if (aFilter.length > 0) {
                oFilter.push(
                    new sap.ui.model.Filter({
                        filters: aFilter,
                        and: true // OR
                    })
                );
            }
            const oModel = this.getView().getModel();
            const that = this;
            that.getView().setBusy(true);

            let aAllItems = [];
            let iSkip = 0;
            const iTop = 200;

            // --- Recursive fetch  ---
            function fetchData() {
                oModel.read("/ZASSET_RDC_NRDC", {
                    filters: oFilter,
                    urlParameters: {
                        "$orderby": "doc_no asc",
                        "$skip": iSkip,
                        "$top": iTop
                    },
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            sap.ui.core.BusyIndicator.hide();
                            aAllItems = aAllItems.concat(oData.results);
                            iSkip += iTop;
                            fetchData(); // continue loading

                        } else {
                            that.getView().setBusy(false);
                            console.log("Total rows fetched:", aAllItems.length);

                            let aResults = aAllItems;

                            const oTabModel = new sap.ui.model.json.JSONModel({
                                items: aAllItems
                            });
                            that.getView().setModel(oTabModel, "TabModel");

                            //  Message if no results
                            if (aResults.length === 0) {
                                sap.m.MessageToast.show("No records found for the given filters.");
                                sap.ui.core.BusyIndicator.hide();
                            }
                        }
                    },
                    error: function (error) {
                        that.getView().setBusy(false);
                        sap.ui.core.BusyIndicator.hide();
                        console.error("Error fetching data:", error);
                        sap.m.MessageToast.show("Error fetching data.");
                    }
                });
            }

            // Start fetching
            fetchData();
        },
        // ========================================
        // Export funtion : =======================
        // ========================================
        onExportPress: function () {
            var that = this;
            sap.m.MessageBox.confirm("Do you want to download the data?", {
                onClose: function (oAction) {
                    if (oAction === sap.m.MessageBox.Action.OK) {
                        var oTable = that.getView().byId("idReportTable");
                        var oBinding = oTable.getBinding("rows");
                        var aCols = that._createColumns();

                        var oSettings = {
                            workbook: {
                                columns: aCols,
                                hierarchyLevel: "Level"
                            },
                            dataSource: oBinding,
                            fileName: "RDC & NRDC Data"
                        };

                        var oSheet = new Spreadsheet(oSettings);
                        oSheet.build().finally(function () {
                            oSheet.destroy();
                        });
                    }
                }
            });

        },
        _createColumns: function () {
            return [
                { label: "Document No", property: "doc_no" },
                { label: "Asset No", property: "asset_no" },
                { label: "Item Description", property: "item_desc" },
                { label: "Plant", property: "plant" },
                { label: "Unit Price", property: "unit_price" },
                { label: "Quantity", property: "quantity" },
                { label: "UOM", property: "uom" },
                { label: "Total Amount", property: "total_amount" },
                { label: "Receiving Plant", property: "receivingplant" },
                { label: "Supplier Code", property: "supplier_code" },
                { label: "Supplier Name", property: "supplier_name" },
                { label: "Reference Doc", property: "reference_doc" },
                { label: "Return Flag", property: "return_flg" },
                { label: "Posting Date", property: "posting_date", type: "date", format: "dd-MM-yyyy" },
                { label: "Requester Name", property: "requester_name" },
                { label: "HSN Code", property: "hsn_code" },
                { label: "Vehicle No", property: "vehicleno" },
                { label: "Transporter Name", property: "transpotername" },
                { label: "Transporter ID", property: "transpoterid" },
                { label: "Handover person Name", property: "handoverpersonname" },
                { label: "Terms of delivery", property: "termsofdelivery" },
                { label: "Remarks", property: "remarks" }
            ];
        },



        // onSavePress: function () {

        //     var that = this;
        //     var oModel = this.getView().getModel();
        //     var oTable = this.byId("idTable");
        //     var aSelectedIndices = oTable.getSelectedIndices();

        //     sap.ui.core.BusyIndicator.show(0);

        //     // No selection check
        //     if (aSelectedIndices.length === 0) {
        //         sap.ui.core.BusyIndicator.hide();
        //         sap.m.MessageBox.warning("Please select at least one row");
        //         return;
        //     }

        //     var bValidationFailed = false;
        //     var iInvalidRow = -1;

        //     // Mandatory validation
        //     aSelectedIndices.some(function (iIndex) {

        //         var oContext = oTable.getContextByIndex(iIndex);
        //         var oRowData = oContext.getObject();

        //         if (
        //             !oRowData.posting_date ||
        //             !oRowData.quantity ||
        //             !oRowData.uom ||
        //             !oRowData.unit_price ||
        //             !oRowData.item_desc
        //         ) {
        //             bValidationFailed = true;
        //             iInvalidRow = iIndex + 1;
        //             return true;
        //         }

        //         return false;
        //     });

        //     if (bValidationFailed) {
        //         sap.ui.core.BusyIndicator.hide();
        //         var msg = "Please enter Item Description, Unit Price, Quantity, UOM and Posting Date .";
        //         if ((this.getView().byId("idComboBox").getSelectedKey() === "NRDC")) {
        //             msg = "Please enter Item Description, Plant, Unit Price, Quantity, UOM and Posting Date .";
        //         }
        //         sap.m.MessageBox.warning(msg);
        //         return;
        //     }

        //     // NRDC validation - Either Receiving Plant or Material Code is mandatory
        //     if (this.byId("idComboBox").getSelectedKey() === "NRDC") {

        //         var bNRDCValidationFailed = false;

        //         aSelectedIndices.some(function (iIndex) {

        //             var oContext = oTable.getContextByIndex(iIndex);
        //             var oRowData = oContext.getObject();

        //             var bReceivingPlant = oRowData.receivingplant && oRowData.receivingplant.trim() !== "";
        //             var bSupplierCode = oRowData.supplier_code && oRowData.supplier_code.trim() !== "";

        //             if (!bReceivingPlant && !bSupplierCode) {
        //                 bNRDCValidationFailed = true;
        //                 iInvalidRow = iIndex + 1;
        //                 return true;
        //             }

        //             return false;
        //         });

        //         if (bNRDCValidationFailed) {
        //             sap.ui.core.BusyIndicator.hide();
        //             sap.m.MessageBox.warning(
        //                 "Row " + iInvalidRow + ": Either Receiving Plant or Supplier Code is mandatory for NRDC."
        //             );
        //             return;
        //         }
        //     }

        //     // RDC validation - Supplier Code is mandatory
        //     if (this.byId("idComboBox").getSelectedKey() === "RDC") {

        //         var bRDCValidationFailed = false;

        //         aSelectedIndices.some(function (iIndex) {

        //             var oContext = oTable.getContextByIndex(iIndex);
        //             var oRowData = oContext.getObject();

        //             var bSupplierCode = oRowData.supplier_code && oRowData.supplier_code.trim() !== "";

        //             if (!bSupplierCode) {
        //                 bRDCValidationFailed = true;
        //                 iInvalidRow = iIndex + 1;
        //                 return true;
        //             }

        //             return false;
        //         });

        //         if (bRDCValidationFailed) {
        //             sap.ui.core.BusyIndicator.hide();
        //             sap.m.MessageBox.warning(
        //                 "Row " + iInvalidRow + ": Supplier Code is mandatory for RDC."
        //             );
        //             return;
        //         }
        //     }

        //     // Return flag validation
        //     var bReturnValidationFailed = false;

        //     aSelectedIndices.some(function (iIndex) {

        //         var oContext = oTable.getContextByIndex(iIndex);
        //         var oRowData = oContext.getObject();

        //         var bReturnFlag = oRowData.return_flg === true;
        //         var bReferenceDoc = oRowData.reference_doc && oRowData.reference_doc.trim() !== "";
        //         var bRemarks = oRowData.remarks && oRowData.remarks.trim() !== "";

        //         if (bReturnFlag && (!bReferenceDoc || !bRemarks)) {
        //             bReturnValidationFailed = true;
        //             iInvalidRow = iIndex + 1;
        //             return true;
        //         }

        //         return false;
        //     });

        //     if (bReturnValidationFailed) {
        //         sap.ui.core.BusyIndicator.hide();
        //         sap.m.MessageBox.warning(
        //             "Row " + iInvalidRow + ": If Return Flag is selected, both Reference Document and Remarks should be mandatory to save."
        //         );
        //         return;
        //     }

        //     sap.ui.core.BusyIndicator.hide();

        //     // 🔥 Confirmation before save
        //     sap.m.MessageBox.confirm(
        //         "Do you want to save the selected records?",
        //         {
        //             title: "Confirmation",
        //             actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
        //             emphasizedAction: sap.m.MessageBox.Action.OK,

        //             onClose: function (sAction) {

        //                 if (sAction !== sap.m.MessageBox.Action.OK) {
        //                     return;
        //                 }

        //                 sap.ui.core.BusyIndicator.show(0);

        //                 var sDocType = that.byId("idComboBox").getSelectedKey();
        //                 var sYear = new Date().getFullYear().toString();
        //                 var sPrefix = sDocType + sYear;

        //                 oModel.read("/ZASSET_RDC_NRDC", {

        //                     success: function (oData) {
        //                         var iMax = 0;
        //                         oData.results.forEach(function (oItem) {
        //                             if (oItem.doc_no && oItem.doc_no.startsWith(sPrefix)) {
        //                                 var iRunningNo = parseInt(oItem.doc_no.substring(sPrefix.length), 10);
        //                                 if (iRunningNo > iMax) {
        //                                     iMax = iRunningNo;
        //                                 }
        //                             }
        //                         });
        //                         var iNextNo = iMax + 1;
        //                         var iSuccessCount = 0;
        //                         var iTotalRecords = aSelectedIndices.length;
        //                         aSelectedIndices.forEach(function (iIndex) {
        //                             var oContext = oTable.getContextByIndex(iIndex);
        //                             var oRowData = oContext.getObject();
        //                             function generateSapUID() {
        //                                 var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        //                                 var result = "";
        //                                 for (var i = 0; i < 15; i++) {
        //                                     result += chars.charAt(Math.floor(Math.random() * chars.length));
        //                                 }
        //                                 return result;
        //                             }

        //                             var sDocumentNo = sPrefix + String(iNextNo).padStart(3, "0");

        //                             var oPayload = {
        //                                 sapuid: generateSapUID(),
        //                                 doc_no: sDocumentNo,
        //                                 doc_type: sDocType,
        //                                 asset_no: oRowData.asset_no,
        //                                 item_desc: oRowData.item_desc,
        //                                 plant: oRowData.plant,
        //                                 unit_price: oRowData.unit_price,
        //                                 quantity: oRowData.quantity,
        //                                 uom: oRowData.uom,
        //                                 total_amount: oRowData.total_amount,
        //                                 receivingplant: oRowData.receivingplant,
        //                                 supplier_code: oRowData.supplier_code,
        //                                 supplier_name: oRowData.supplier_name,
        //                                 reference_doc: oRowData.reference_doc,
        //                                 return_flg: oRowData.return_flg,
        //                                 posting_date: that.formatDate(oRowData.posting_date),
        //                                 requester_name: oRowData.requester_name,
        //                                 hsn_code: oRowData.hsn_code,
        //                                 remarks: oRowData.remarks
        //                             };

        //                             oModel.create("/ZASSET_RDC_NRDC", oPayload, {

        //                                 success: function () {

        //                                     iSuccessCount++;

        //                                     if (iSuccessCount === iTotalRecords) {
        //                                         sap.ui.core.BusyIndicator.hide();
        //                                         oTable.clearSelection();

        //                                         sap.m.MessageBox.success(
        //                                             "Document No " + sDocumentNo + " generated successfully"
        //                                         );
        //                                         that.getView().getModel("TransModel").setProperty("/Datas", []);
        //                                     }
        //                                 },

        //                                 error: function () {
        //                                     sap.ui.core.BusyIndicator.hide();

        //                                     sap.m.MessageBox.error(
        //                                         "Error while creating document " + sDocumentNo
        //                                     );
        //                                 }
        //                             });

        //                             // iNextNo++;
        //                         });
        //                     },

        //                     error: function () {
        //                         sap.ui.core.BusyIndicator.hide();
        //                         sap.m.MessageBox.error("Error while generating document number");
        //                     }
        //                 });
        //             }
        //         }
        //     );
        // },


        onUnitPriceChange: function (oEvent) {
            var oUnitInput = oEvent.getSource();
            var oContext = oUnitInput.getBindingContext("TransModel");
            var oData = oContext.getObject();

            var oUnit = parseFloat(oData.unit_price);
            var oQuantity = parseFloat(oData.quantity) || 0;

            if (isNaN(oUnit)) {
                oUnit = 0;
                oContext.getModel("TransModel").setProperty(oContext.getPath() + "/unit_price", "0.00");
            } else {
                oContext.getModel("TransModel").setProperty(oContext.getPath() + "/unit_price", oUnit.toFixed(2));
            }

            oContext.getModel("TransModel").setProperty(oContext.getPath() + "/quantity", oQuantity.toFixed(0));

            let oTotal = oUnit * oQuantity;

            oContext.getModel("TransModel").setProperty(oContext.getPath() + "/total_amount", oTotal.toFixed(2));
        },

        onQuantityChange: function (oEvent) {
            var oInput = oEvent.getSource();

            var oContext = oInput.getBindingContext("TransModel");
            var oData = oContext.getObject();

            var oUnit = parseFloat(oData.unit_price);

            if (isNaN(oUnit)) {
                sap.m.MessageToast.show("Please enter unit price first");
                oContext.getModel("TransModel").setProperty(oContext.getPath() + "/quantity", "");
                return;
            }

            var oQuantity = parseFloat(oInput.getValue());

            if (isNaN(oQuantity)) {
                oQuantity = 0;
            }

            oContext.getModel("TransModel").setProperty(oContext.getPath() + "/quantity", oQuantity.toFixed(0));

            var oTotal = oUnit * oQuantity;

            oContext.getModel("TransModel").setProperty(oContext.getPath() + "/total_amount", oTotal.toFixed(2));
        },

        // ======================================================
        // Supplier Fragment : ==================================
        // ======================================================

        onSupplierValueHelpRequest: function (oEvent) {

            sap.ui.core.BusyIndicator.show();

            this.o_Supplier = oEvent.getSource();

            var oModel = this.getView().getModel();

            // Check if the model is valid
            if (!oModel) {
                console.error("OData model is not properly initialized.");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            //   var oFilters = [oFilters1];
            var that = this;
            var aAllItems = []; // Array to hold all retrieved items

            // Function to fetch data recursively
            function fetchData(skipCount) {

                oModel.read("/ZSUPPLIER", {
                    urlParameters: {
                        $top: 5000,  // Request a chunk of 5000 records
                        $skip: skipCount    // Start from the skipCount position

                    },
                    success: function (oData) {
                        var aItems = oData.results;
                        aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                        // Check if there are more records to fetch
                        if (oData.results.length >= 5000) {
                            // If there are more records, fetch next chunk
                            fetchData(skipCount + 5000);
                        } else {
                            // If no more records, all data is fetched
                            finishFetching();
                        }
                    },
                    error: function (oError) {
                        console.error("Error reading data: ", oError);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }

            function finishFetching() {


                // Once all data is fetched, proceed to display it
                that.oJSONModel = new sap.ui.model.json.JSONModel({
                    Datas: aAllItems
                });
                that.getView().setModel(that.oJSONModel, "oJSONModel");
                console.log("that.oJSONModel:", that.oJSONModel)

                // Load the value help dialog fragment
                that._oBasicSearchField = new sap.m.SearchField();
                that.loadFragment({
                    name: "zrdcandnrdcprint.fragment.supplier"
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();

                    var oColumnProductCode, oColumnSupplierName, oColumnCompanyCode;
                    that._oVHD = oDialog;
                    that.getView().addDependent(oDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oDialog.setRangeKeyFields([{
                        label: "Supplier.",
                        key: "Supplier",
                        type: "string",
                        typeInstance: new sap.ui.model.type.String({}, {
                            maxLength: 15
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(that._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    that._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {
                        oTable.setModel(that.oJSONModel);

                        // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                        if (oTable.bindRows) {
                            // Desktop/Table scenario (sap.ui.table.Table)
                            oTable.bindAggregation("rows", {
                                path: "oJSONModel>/Datas",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.ui.table.Table
                            oColumnProductCode = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: "Supplier." }),
                                template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>Supplier}" })
                            });
                            oColumnProductCode.data({
                                fieldName: "Supplier"
                            });
                            oTable.addColumn(oColumnProductCode);

                            oColumnSupplierName = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: "Supplier Name." }),
                                template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>SupplierName}" })
                            });
                            oColumnSupplierName.data({
                                fieldName: "SupplierName"
                            });



                            oTable.addColumn(oColumnSupplierName);


                        } else if (oTable.bindItems) {
                            // Mobile scenario (sap.m.Table)
                            oTable.bindAggregation("items", {
                                path: "oJSONModel>/Datas",
                                template: new sap.m.ColumnListItem({
                                    cells: [
                                        new sap.m.Text({ text: "{oJSONModel>Supplier}" }),
                                        new sap.m.Text({ text: "{oJSONModel>SupplierName}" })
                                    ]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.m.Table (if necessary)
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({ text: "Supplier." }),
                                header: new sap.m.Label({ text: "Supplier Name." })
                            }));

                        }

                        oDialog.update();
                        sap.ui.core.BusyIndicator.hide();
                    });

                    oDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                });
            }

            // Start fetching data from the beginning
            fetchData(0);

        },
        onValueHelpOkPress_Supplier: function (oEvent) {

            var aTokens = oEvent.getParameter("tokens");

            if (!aTokens || aTokens.length === 0) {
                return;
            }

            var sSelectedKey = aTokens[0].getKey();
            var sSelectedText = aTokens[0].getText();
            var sDescription = sSelectedText.split(" (")[0];

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");

            aData.forEach(function (oRow) {
                oRow.supplier_code = sSelectedKey;
                oRow.supplier_name = sDescription;
                oRow.receivingplantEditable = false;
            });

            oModel.setProperty("/Datas", aData);
            oModel.refresh(true);
            this._oVHD.close();
        },
        onValueHelpCancelPress_Supplier: function () {
            this._oVHD.close();
        },
        onValueHelpAfterClose_Supplier: function () {
            this._oVHD.destroy();
        },
        onFilterBarSearch_Supplier: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "Supplier", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
                    new sap.ui.model.Filter({ path: "SupplierName", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery })
                ],
                and: false
            }));

            this._filterTable_Supplier(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },
        _filterTable_Supplier: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },


        onDocumentTypeChange: function () {
            this.onGoPress();
        },


        // ======================================================
        // Doc No Fragment : ====================================
        // ======================================================

        onDocNoValueHelpRequest: function (oEvent) {

            sap.ui.core.BusyIndicator.show();

            this.o_Supplier = oEvent.getSource();

            var oModel = this.getView().getModel();

            // Check if the model is valid
            if (!oModel) {
                console.error("OData model is not properly initialized.");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            //   var oFilters = [oFilters1];
            var that = this;
            var aAllItems = []; // Array to hold all retrieved items

            // Function to fetch data recursively
            function fetchData(skipCount) {

                oModel.read("/ZASSET_RDC_NRDC", {
                    urlParameters: {
                        $top: 5000,  // Request a chunk of 5000 records
                        $skip: skipCount    // Start from the skipCount position

                    },
                    success: function (oData) {
                        var aItems = oData.results;
                        aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                        // Check if there are more records to fetch
                        if (oData.results.length >= 5000) {
                            // If there are more records, fetch next chunk
                            fetchData(skipCount + 5000);
                        } else {
                            // If no more records, all data is fetched
                            finishFetching();
                        }
                    },
                    error: function (oError) {
                        console.error("Error reading data: ", oError);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }

            function finishFetching() {

                // Once all data is fetched, proceed to display it
                that.oJSONModel = new sap.ui.model.json.JSONModel({
                    Datas: aAllItems
                });
                that.getView().setModel(that.oJSONModel, "oJSONModel");
                console.log("that.oJSONModel:", that.oJSONModel)

                // Load the value help dialog fragment
                that._oBasicSearchField = new sap.m.SearchField();
                that.loadFragment({
                    name: "zrdcandnrdcprint.fragment.docNo"
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();

                    var oColumnProductCode, oColumnSupplierName, oColumnCompanyCode;
                    that._oVHD = oDialog;
                    that.getView().addDependent(oDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oDialog.setRangeKeyFields([{
                        label: "Doc No",
                        key: "doc_no",
                        type: "string",
                        typeInstance: new sap.ui.model.type.String({}, {
                            maxLength: 15
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(that._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    that._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {
                        oTable.setModel(that.oJSONModel);

                        // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                        if (oTable.bindRows) {
                            // Desktop/Table scenario (sap.ui.table.Table)
                            oTable.bindAggregation("rows", {
                                path: "oJSONModel>/Datas",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.ui.table.Table
                            oColumnProductCode = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: "Doc No" }),
                                template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>doc_no}" })
                            });
                            oColumnProductCode.data({
                                fieldName: "doc_no"
                            });
                            oTable.addColumn(oColumnProductCode);


                        } else if (oTable.bindItems) {
                            // Mobile scenario (sap.m.Table)
                            oTable.bindAggregation("items", {
                                path: "oJSONModel>/Datas",
                                template: new sap.m.ColumnListItem({
                                    cells: [
                                        new sap.m.Text({ text: "{oJSONModel>doc_no}" })
                                    ]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.m.Table (if necessary)
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({ text: "Doc No" })
                            }));

                        }

                        oDialog.update();
                        sap.ui.core.BusyIndicator.hide();
                    });

                    oDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                });
            }

            // Start fetching data from the beginning
            fetchData(0);

        },
        onValueHelpOkPress_DocNo: function (oEvent) {

            var aTokens = oEvent.getParameter("tokens");

            console.log("aTokens:", aTokens);

            var sSelectedKey = aTokens[0].getKey(); // get the key of the first token

            this.byId("docNoInputId").setValue(sSelectedKey);
            this._oVHD.close();

        },
        onValueHelpCancelPress_DocNo: function () {
            this._oVHD.close();
        },
        onValueHelpAfterClose_DocNo: function () {
            this._oVHD.destroy();
        },
        onFilterBarSearch_DocNo: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "doc_no", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery })

                ],
                and: false
            }));

            this._filterTable_DocNo(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },
        _filterTable_DocNo: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },

        onPrintResetPress: function () {
            this.byId("docNoInputId").setValue("");
            sap.m.MessageToast.show("Document number reset successfully");
        },

        // ======================================================
        // Print Function : =====================================
        // ======================================================
        onPrintPress: async function () {

            sap.ui.core.BusyIndicator.show();

            var oValue = this.byId("docNoInputId").getValue();
            if (!oValue) {
                sap.ui.core.BusyIndicator.hide();
                sap.m.MessageToast.show("Please enter a document number");
                return;
            }

            try {
                var sServiceUrl = `/sap/bc/http/sap/Z_RDC_NRDC_ASSET?doc_no=${oValue}`;
                console.log("Service URL:", sServiceUrl);

                // Fetch PDF data
                const pdfData = await this.fetchPDFData(sServiceUrl);
                const pdfContentArray = [pdfData];

                // Display the PDF
                this.displayPDFs(pdfContentArray);

                sap.m.MessageToast.show("PDF displayed successfully!");
            } catch (error) {
                console.error("Error generating PDF:", error);
                sap.m.MessageToast.show("Failed to generate PDF. Please try again.");
            } finally {
                sap.ui.core.BusyIndicator.hide();
            }
        },
        fetchPDFData: function (sServiceUrl) {
            return new Promise((resolve, reject) => {
                jQuery.ajax({
                    url: sServiceUrl,
                    method: "GET",
                    success: function (data, textStatus, jqXHR) {
                        resolve(data); // Resolve with PDF data
                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        console.error("Error fetching data. Status:", textStatus, "Error:", errorThrown);
                        sap.m.MessageToast.show("HTTP Service Error...!");
                        reject(errorThrown);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            });
        },
        displayPDFs: async function (pdfDataArray) {
            const base64ToArrayBuffer = (base64) => {
                const binaryString = atob(base64);
                const binaryLen = binaryString.length;
                const bytes = new Uint8Array(binaryLen);
                for (let i = 0; i < binaryLen; i++) {
                    bytes[i] = binaryString.charCodeAt(i);
                }
                return bytes.buffer;
            };

            const mergedPdf = await PDFLib.PDFDocument.create();
            for (let document of pdfDataArray) {
                const pdfBytes = base64ToArrayBuffer(document);
                const pdfDoc = await PDFLib.PDFDocument.load(pdfBytes);
                const copiedPages = await mergedPdf.copyPages(pdfDoc, pdfDoc.getPageIndices());
                copiedPages.forEach((page) => mergedPdf.addPage(page));
            }

            const pdfBytes = await mergedPdf.save();
            const pdfBlob = new Blob([pdfBytes], { type: 'application/pdf' });
            const _pdfurl = URL.createObjectURL(pdfBlob);

            if (!this._pdfViewer) {
                this._pdfViewer = new sap.m.PDFViewer({
                    width: "auto",
                    source: _pdfurl
                });
                jQuery.sap.addUrlWhitelist("blob");
            } else {
                this._pdfViewer.setSource(_pdfurl);
            }

            this._pdfViewer.setTitle("RDC Print Form");
            this._pdfViewer.open();
        },

        onReportDeletePress: function () {
            var oTable = this.byId("idReportTable");
            var aSelectedIndices = oTable.getSelectedIndices();

            if (aSelectedIndices.length === 0) {
                sap.m.MessageToast.show("Please select at least one row to delete.");
                return;
            }

            var that = this;
            var oModel = this.getView().getModel();

            sap.ui.core.BusyIndicator.show(0);

            sap.m.MessageBox.confirm("Are you sure you want to delete the selected records?", {
                title: "Confirm Deletion",
                onClose: function (sAction) {
                    if (sAction === sap.m.MessageBox.Action.OK) {
                        aSelectedIndices.forEach(function (iIndex) {
                            var oContext = oTable.getContextByIndex(iIndex);
                            var oRowData = oContext.getObject();
                            var sDocNo = oRowData.doc_no;
                            var oSapUID = oRowData.sapuid;

                            oModel.remove("/ZASSET_RDC_NRDC('" + oSapUID + "')", {
                                success: function () {
                                    sap.m.MessageToast.show("Document No " + sDocNo + " deleted successfully.");
                                    // Refresh the table after deletion
                                    oModel.read("/ZASSET_RDC_NRDC", {
                                        success: function (oData) {
                                            var aItems = oData.results;
                                            sap.ui.core.BusyIndicator.hide();
                                            var oTabModel = that.getView().getModel("TabModel");
                                            oTabModel.setProperty("/items", aItems);
                                        },
                                        error: function () {
                                            sap.ui.core.BusyIndicator.hide();
                                            sap.m.MessageToast.show("Failed to refresh the table after deletion.");
                                        }
                                    });
                                },
                                error: function () {
                                    sap.m.MessageToast.show("Failed to delete Document No " + sDocNo + ".");
                                }
                            });
                        });
                    }
                }
            });
        },

        onReceivingPlantChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var oValue = oInput.getValue();
            var oContext = oInput.getBindingContext("TransModel");
            var sPath = oContext.getPath();
            if (oValue) {
                this.getView().getModel("TransModel").setProperty(sPath + "/editable", false);
            } else {
                this.getView().getModel("TransModel").setProperty(sPath + "/editable", true);
            }

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");

            aData.forEach(function (oRow) {
                oRow.receivingplant = oValue;
                oRow.supplier_code = "";

            });
            oModel.setProperty("/Datas", aData);


        },

        onRowPlantLiveChange(oEvent) {
            var oInput = oEvent.getSource();
            var oValue = oInput.getValue();

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");
            aData.forEach(function (oRow) {
                oRow.plant = oValue;
            });
            oModel.setProperty("/Datas", aData);

        },

        onSupplierCodeLiveChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var oValue = oInput.getValue();
            var oContext = oInput.getBindingContext("TransModel");
            var sPath = oContext.getPath();

            oInput.setValue("");

            if (oValue === "") {
                this.getView().getModel("TransModel").setProperty(sPath + "/receivingplantEditable", true);
            } else if (oValue) {
                sap.m.MessageToast.show("Choose from value help");
                this.getView().getModel("TransModel").setProperty(sPath + "/receivingplantEditable", true);
            } else {
                this.getView().getModel("TransModel").setProperty(sPath + "/receivingplantEditable", false);
            }

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");

            aData.forEach(function (oRow) {
                oRow.supplier_code = "";
                oRow.supplier_name = "";
                oRow.receivingplant = "";
            });

            oModel.setProperty("/Datas", aData);
            oModel.refresh(true);

        },

        onPostingDateChange: function (oEvent) {
            var oDatePicker = oEvent.getSource();
            var oToday = new Date();
            var oSelectedDate = oDatePicker.getDateValue();

            if (oSelectedDate) {
                var todayOnly = new Date(
                    oToday.getFullYear(),
                    oToday.getMonth(),
                    oToday.getDate()
                );

                var selectedOnly = new Date(
                    oSelectedDate.getFullYear(),
                    oSelectedDate.getMonth(),
                    oSelectedDate.getDate()
                );

                if (selectedOnly > todayOnly) {
                    oDatePicker.setValueState("Error");
                    oDatePicker.setValueStateText("Future dates are not allowed.");
                    oDatePicker.setDateValue(null);
                } else {
                    oDatePicker.setValueState("None");
                }
            }
        },


        onSavePress: function () {

            var oTable = this.byId("idTable");
            var aSelectedIndices = oTable.getSelectedIndices();

            // No Selection
            if (aSelectedIndices.length === 0) {
                sap.m.MessageBox.warning("Please select at least one row.");
                return;
            }

            sap.ui.core.BusyIndicator.show(0);

            // Mandatory Validation
            if (!this._validateMandatoryFields(aSelectedIndices)) {
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            // NRDC Validation
            if (!this._validateNRDC(aSelectedIndices)) {
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            // RDC Validation
            if (!this._validateRDC(aSelectedIndices)) {
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            // Return Flag Validation
            if (!this._validateReturnFlag(aSelectedIndices)) {
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            sap.ui.core.BusyIndicator.hide();

            // Continue Save Process
            this._showSaveConfirmation(aSelectedIndices);

        },
        /************************************************************************
         * Mandatory Validation
         ************************************************************************/
        _validateMandatoryFields: function (aSelectedIndices) {

            var oTable = this.byId("idTable");
            var bFailed = false;

            aSelectedIndices.some(function (iIndex) {

                var oRow = oTable.getContextByIndex(iIndex).getObject();

                if (
                    !oRow.posting_date ||
                    !oRow.quantity ||
                    !oRow.uom ||
                    !oRow.unit_price ||
                    !oRow.item_desc
                ) {
                    bFailed = true;
                    return true;
                }

                return false;

            });

            if (bFailed) {

                var sMessage =
                    "Please enter Item Description, Unit Price, Quantity, UOM and Posting Date.";

                if (this.byId("idComboBox").getSelectedKey() === "NRDC") {
                    sMessage =
                        "Please enter Item Description, Plant, Unit Price, Quantity, UOM and Posting Date.";
                }

                sap.m.MessageBox.warning(sMessage);
                return false;
            }

            return true;

        },

        /************************************************************************
         * NRDC Validation
         ************************************************************************/
        _validateNRDC: function (aSelectedIndices) {

            if (this.byId("idComboBox").getSelectedKey() !== "NRDC") {
                return true;
            }

            var oTable = this.byId("idTable");
            var iRow = 0;
            var bFailed = false;

            aSelectedIndices.some(function (iIndex) {

                var oRow = oTable.getContextByIndex(iIndex).getObject();

                var bReceivingPlant =
                    oRow.receivingplant &&
                    oRow.receivingplant.trim() !== "";

                var bSupplier =
                    oRow.supplier_code &&
                    oRow.supplier_code.trim() !== "";

                if (!bReceivingPlant && !bSupplier) {

                    iRow = iIndex + 1;
                    bFailed = true;
                    return true;

                }

                return false;

            });

            if (bFailed) {

                sap.m.MessageBox.warning(
                    "Row " +
                    iRow +
                    ": Either Receiving Plant or Supplier Code is mandatory for NRDC."
                );

                return false;
            }

            return true;

        },

        /************************************************************************
         * RDC Validation
         ************************************************************************/
        _validateRDC: function (aSelectedIndices) {

            if (this.byId("idComboBox").getSelectedKey() !== "RDC") {
                return true;
            }

            var oTable = this.byId("idTable");
            var iRow = 0;
            var bFailed = false;

            aSelectedIndices.some(function (iIndex) {

                var oRow = oTable.getContextByIndex(iIndex).getObject();

                if (!oRow.supplier_code || oRow.supplier_code.trim() === "") {

                    iRow = iIndex + 1;
                    bFailed = true;
                    return true;

                }

                return false;

            });

            if (bFailed) {

                sap.m.MessageBox.warning(
                    "Row " +
                    iRow +
                    ": Supplier Code is mandatory for RDC."
                );

                return false;
            }

            return true;

        },

        /************************************************************************
         * Return Flag Validation
         ************************************************************************/
        _validateReturnFlag: function (aSelectedIndices) {

            var oTable = this.byId("idTable");
            var iRow = 0;
            var bFailed = false;

            aSelectedIndices.some(function (iIndex) {

                var oRow = oTable.getContextByIndex(iIndex).getObject();

                var bReturn = oRow.return_flg === true;

                var bReference =
                    oRow.reference_doc &&
                    oRow.reference_doc.trim() !== "";

                var bRemarks =
                    oRow.remarks &&
                    oRow.remarks.trim() !== "";

                if (bReturn && (!bReference || !bRemarks)) {

                    iRow = iIndex + 1;
                    bFailed = true;
                    return true;

                }

                return false;

            });

            if (bFailed) {

                sap.m.MessageBox.warning(
                    "Row " +
                    iRow +
                    ": If Return Flag is selected, both Reference Document and Remarks are mandatory."
                );

                return false;
            }

            return true;

        },
        /************************************************************************
         * Save Confirmation
         ************************************************************************/
        _showSaveConfirmation: function (aSelectedIndices) {

            var that = this;

            sap.m.MessageBox.confirm(
                "Do you want to save the selected records?",
                {
                    title: "Confirmation",
                    actions: [
                        sap.m.MessageBox.Action.OK,
                        sap.m.MessageBox.Action.CANCEL
                    ],
                    emphasizedAction: sap.m.MessageBox.Action.OK,

                    onClose: function (sAction) {

                        if (sAction !== sap.m.MessageBox.Action.OK) {
                            return;
                        }

                        sap.ui.core.BusyIndicator.show(0);

                        that._generateDocumentNumber(aSelectedIndices);

                    }
                }
            );

        },

        /************************************************************************
         * Generate Document Number
         ************************************************************************/
        /************************************************************************
        * Generate Document Number
        ************************************************************************/
        _generateDocumentNumber: function (aSelectedIndices) {

            var that = this;
            var oModel = this.getView().getModel("ZSB_NUM");

            var sDocType = this.byId("idComboBox").getSelectedKey();
            var sYear = new Date().getFullYear().toString();
            var sPrefix = sDocType + sYear;

            console.log("Document Type:", sDocType);
            console.log("Year:", sYear);
            console.log("Document Prefix:", sPrefix);

            oModel.read("/ZDD_NUM", {
                filters: [new sap.ui.model.Filter("doc_no", sap.ui.model.FilterOperator.StartsWith, sPrefix)],

                urlParameters: {
                    "$orderby": "doc_no desc"
                },

                success: function (oData) {

                    console.log("Existing Document Data:", oData.results);

                    var iMax = 0;

                    oData.results.forEach(function (oItem) {

                        console.log("Checking Document No:", oItem.doc_no);

                        if (oItem.doc_no && oItem.doc_no.startsWith(sPrefix)) {

                            var iRunningNo = parseInt(
                                oItem.doc_no.substring(sPrefix.length),
                                10
                            );

                            console.log("Running Number Found:", iRunningNo
                            );

                            if (iRunningNo > iMax) {
                                iMax = iRunningNo;
                            }
                        }

                    });

                    // Set starting number based on document type if no document exists
                    if (iMax === 0) {
                        if (sDocType === "RDC") {
                            iMax = 50;   // Next will be 0050
                        } else if (sDocType === "NRDC") {
                            iMax = 104;  // Next will be 0105
                        }
                    }

                    console.log("Maximum Existing Number:", iMax);

                    var iNextNo = iMax + 1;

                    console.log("Next Running Number:", iNextNo);


                    var sDocumentNo =
                        sPrefix +
                        String(iNextNo).padStart(4, "0");


                    console.log(
                        "Generated Document Number:",
                        sDocumentNo
                    );


                    that._createHeader(
                        sDocumentNo,
                        sDocType,
                        aSelectedIndices
                    );

                },

                error: function (oError) {

                    console.error(
                        "Document Number Generation Error:",
                        oError
                    );

                    sap.ui.core.BusyIndicator.hide();

                    sap.m.MessageBox.error(
                        "Error while generating Document Number."
                    );

                }

            });

        },
        /************************************************************************
         * Create Header Record
         * Entity : ZDD_NUMBER
         ************************************************************************/
        _createHeader: function (sDocumentNo, sDocType, aSelectedIndices) {

            var that = this;
            var oHeader = this.getView().getModel("ZSB_NUM");


            var oHeaderPayload = {

                doc_no: sDocumentNo

            };


            oHeader.create("/ZDD_NUM", oHeaderPayload, {

                success: function () {

                    // Header created successfully
                    // Now create item records

                    that._createItems(
                        sDocumentNo,
                        sDocType,
                        aSelectedIndices
                    );

                },


                // error: function () {

                //     sap.ui.core.BusyIndicator.hide();

                //     sap.m.MessageBox.error(
                //         "Error while creating header record."
                //     );

                // }
                error: function (oError) {

                    sap.ui.core.BusyIndicator.hide();

                    var sResponse = oError.responseText || "";

                    if (sResponse.includes("key") || sResponse.includes("already exists")) {
                        sap.m.MessageBox.error(
                            "Another user has already created this document. Multiple users are working at the same time. Please try again."
                        );
                    } else {
                        sap.m.MessageBox.error(
                            "Error while creating header record."
                        );
                    }

                }

            });

        },

        /************************************************************************
         * Generate SAP UID
         ************************************************************************/
        _generateSapUID: function () {


            var chars =
                "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";


            var result = "";


            for (var i = 0; i < 15; i++) {

                result += chars.charAt(
                    Math.floor(Math.random() * chars.length)
                );

            }


            return result;

        },

        /************************************************************************
         * Create Item Records
         ************************************************************************/
        _createItems: function (sDocumentNo, sDocType, aSelectedIndices) {

            var that = this;
            var oItem = this.getView().getModel();
            var oTable = this.byId("idTable");

            var iSuccessCount = 0;
            var iErrorCount = 0;
            var iCompleted = 0;
            var iTotalRecords = aSelectedIndices.length;

            aSelectedIndices.forEach(function (iIndex) {

                var oRowData = oTable.getContextByIndex(iIndex).getObject();

                var oPayload = {

                    sapuid: that._generateSapUID(),
                    doc_no: sDocumentNo,
                    doc_type: sDocType,
                    asset_no: oRowData.asset_no,
                    item_desc: oRowData.item_desc,
                    plant: oRowData.plant,
                    unit_price: oRowData.unit_price,
                    quantity: oRowData.quantity,
                    uom: oRowData.uom,
                    total_amount: oRowData.total_amount,
                    receivingplant: oRowData.receivingplant,
                    supplier_code: oRowData.supplier_code,
                    supplier_name: oRowData.supplier_name,
                    reference_doc: oRowData.reference_doc,
                    return_flg: oRowData.return_flg,
                    posting_date: that.formatDate(oRowData.posting_date),
                    requester_name: oRowData.requester_name,
                    hsn_code: oRowData.hsn_code,
                    vehicleno: oRowData.vehicleno,
                    transpotername: oRowData.transpotername,
                    transpoterid: oRowData.transpoterid,
                    handoverpersonname: oRowData.handoverpersonname,
                    termsofdelivery: oRowData.termsofdelivery,

                    remarks: oRowData.remarks
                };

                oItem.create("/ZASSET_RDC_NRDC", oPayload, {

                    success: function () {

                        iSuccessCount++;
                        iCompleted++;

                        if (iCompleted === iTotalRecords) {
                            that._saveCompleted(
                                sDocumentNo,
                                iSuccessCount,
                                iErrorCount
                            );
                        }

                    },

                    error: function () {

                        iErrorCount++;
                        iCompleted++;

                        if (iCompleted === iTotalRecords) {
                            that._saveCompleted(
                                sDocumentNo,
                                iSuccessCount,
                                iErrorCount
                            );
                        }

                    }

                });

            });

        },

        /************************************************************************
         * Save Completed
         ************************************************************************/
        _saveCompleted: function (sDocumentNo, iSuccessCount, iErrorCount) {

            sap.ui.core.BusyIndicator.hide();

            this.byId("idTable").clearSelection();

            if (iErrorCount === 0) {

                sap.m.MessageBox.success("Document No " + sDocumentNo + " generated successfully.");

                this.getView().getModel("TransModel").setProperty("/Datas", []);

            } else {

                sap.m.MessageBox.error(

                    "Header created successfully.\n\n" + iSuccessCount + " item(s) saved.\n" + iErrorCount + " item(s) failed."

                );

            }

        },

        onRefDocLiveChange(oEvent) {
            var oInput = oEvent.getSource();
            var oValue = oInput.getValue();

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");
            aData.forEach(function (oRow) {
                oRow.reference_doc = oValue;
            });
            oModel.setProperty("/Datas", aData);

        },

        onReqNameLiveChange(oEvent) {
            var oInput = oEvent.getSource();
            var oValue = oInput.getValue();

            var oModel = this.getView().getModel("TransModel");
            var aData = oModel.getProperty("/Datas");
            aData.forEach(function (oRow) {
                oRow.requester_name = oValue;
            });
            oModel.setProperty("/Datas", aData);

        },

        isReferenceDocEditable: function (bEditModel, bRowEditable) {
            return bEditModel === true && bRowEditable === true;
        }










    });
});