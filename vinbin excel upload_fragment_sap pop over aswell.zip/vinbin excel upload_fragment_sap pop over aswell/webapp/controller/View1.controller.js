sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "zfvinbinreport/util/xlsx",
    "sap/m/MessageBox",
    "sap/ui/export/library",
    "sap/ui/export/Spreadsheet",
    "sap/m/MessageToast"
], (Controller, xlsx, MessageBox, exportLibrary, Spreadsheet, MessageToast) => {
    "use strict";

    return Controller.extend("zfvinbinreport.controller.View1", {
        onInit() {
            var oModel = new sap.ui.model.json.JSONModel({
                "items": []
            });
            this.getView().setModel(oModel, "TabModel");

            this.ReadFunction();

            // Message Popover : =============================
            // Message model
            this._oMessageModel = new sap.ui.model.json.JSONModel({
                messages: []
            });
            this.getView().setModel(this._oMessageModel, "msg");
            this._oMessagePopover = new sap.m.MessagePopover({
                activeTitlePress: this.onActiveTitlePress.bind(this),
                items: {
                    path: "msg>/messages",
                    template: new sap.m.MessageItem({
                        type: "{msg>type}",
                        title: "{msg>title}",
                        activeTitle: true,
                        description: "{msg>description}",
                        subtitle: "{msg>subtitle}"
                    })
                }
            });

            this.getView().addDependent(this._oMessagePopover);

        },
        ReadFunction: function () {

            sap.ui.core.BusyIndicator.show(0);

            // TABMODEL:

            var that = this;

            let Z_VIN_Model = this.getOwnerComponent().getModel("ZSB_VIN_TRACEABILITY");

            Z_VIN_Model.read("/ZI_VIN_CUSTOM", {
                success: function (oData) {

                    sap.ui.core.BusyIndicator.hide();

                    if (oData.results && oData.results.length > 0) {

                        that.TabModel = new sap.ui.model.json.JSONModel({
                            items: oData.results

                        });
                        that.getView().setModel(that.TabModel, "TabModel");

                        // For sorting based on createtime
                        // var oTable = that.byId("idCodetable");
                        // var oBinding = oTable.getBinding("rows");
                        // if (oBinding) {
                        //     var oSorter = new sap.ui.model.Sorter("createtime", false);
                        //     oBinding.sort(oSorter);
                        // }
                    } else {

                        that.TabModel = new sap.ui.model.json.JSONModel({
                            items: []

                        });
                        that.getView().setModel(that.TabModel, "TabModel");

                        // For sorting based on createtime
                        // var oTable = that.byId("idCodetable");
                        // var oBinding = oTable.getBinding("rows");
                        // if (oBinding) {
                        //     var oSorter = new sap.ui.model.Sorter("createtime", false);
                        //     oBinding.sort(oSorter);
                        // }

                    }
                },
                error: function (oError) {

                    sap.ui.core.BusyIndicator.hide();

                    console.error("Error reading OData:", oError);
                    that.TabModel = new sap.ui.model.json.JSONModel({
                        items: []
                    });
                    that.getView().setModel(that.TabModel, "TabModel");

                    // For sorting based on createtime
                    // var oTable = that.byId("idCodetable");
                    // var oBinding = oTable.getBinding("rows");
                    // if (oBinding) {
                    //     var oSorter = new sap.ui.model.Sorter("createtime", false);
                    //     oBinding.sort(oSorter);
                    // }
                }
            });


        },

        // Reset Function : =========================
        onResetPress: function () {
            this.ReadFunction();
            this.getView().byId("TableId").clearSelection();
        },
        // Add the empty row:
        onAddPress: function () {
            var oModel = this.getView().getModel("TabModel");
            var aItems = oModel.getProperty("/items");
            aItems.push({
                ordRef: "",
                p_material: ""
            });
            oModel.setProperty("/items", aItems);
        },

        onUploadChange: function (oEvent) {
            this._file1 = oEvent.getParameter("files")?.[0] || null;
        },

        onUploadPress: function () {
            const that = this;

            if (!this._file1) {
                MessageToast.show("Please select a file first");
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                try {
                    const data = e.target.result;
                    const workbook = XLSX.read(data, { type: "array" });
                    let tableData = [];

                    workbook.SheetNames.forEach(sheetName => {
                        const rows = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]).map(row => ({

                            orderef: row.Order_Ref,
                            p_mat: row.P_Material,
                            vin: row.VIN,
                            bin: row.BIN,
                            c_min: row.C_MIN,
                            mcu: row.MCU,
                            telematics: row.TELEMATICS,
                            charger: row.CHARGER,
                            color: row.Color,
                            display: row.Display,
                            vcu: row.VCU,
                            part1: row.part1,
                            part2: row.part2,
                            part3: row.part3,
                            part4: row.part4,
                            part5: row.part5,
                            sap_des: row.SAPDescription,
                            crt_on: row.CratedOn,
                            crt_by: row.CraetedBy,
                            last_chg_on: row.LastCreatedOn,
                            last_chg_by: row.LastCreatedBy,
                            life_cycle: row.LifecycleStatus

                        }));
                        tableData = tableData.concat(rows);
                    });

                    const jModel = new sap.ui.model.json.JSONModel({ Datass: tableData });
                    that.getView().setModel(jModel, "UploadModel");

                    MessageToast.show("Excel Data Loaded");
                    that._openUploadFragment();
                }
                catch (err) {
                    MessageBox.error("Failed to read Excel. Check file format.");
                    console.error(err);
                }
            };

            reader.onerror = function (ex) {
                MessageBox.error("File error. Cannot read file.");
                console.error(ex);
            };

            reader.readAsArrayBuffer(this._file1);
        },

        _openUploadFragment: function () {
            const that = this;

            if (!this._uploadDialog) {
                sap.ui.core.Fragment.load({
                    name: "zfvinbinreport.fragment.uploadFragment",
                    id: "excelTableFragment",
                    controller: this
                }).then(dialog => {
                    that._uploadDialog = dialog;
                    that.getView().addDependent(dialog);
                    dialog.open();
                });
            } else {
                this._uploadDialog.open();
            }

        },

        // onUpload_CancelPress: function () {
        //     const oTable = sap.ui.core.Fragment.byId("excelTableFragment", "UploadTableId");
        //     oTable.clearSelection();
        //     this._uploadDialog.close();
        // },
        onUpload_CancelPress: function () {

            const oTable = sap.ui.core.Fragment.byId("excelTableFragment", "UploadTableId");

            if (oTable) {
                oTable.clearSelection();
            }

            // Clear MessagePopover data 
            if (this._oMessageModel) {
                this._oMessageModel.setProperty("/messages", []);
            }

            // Close popover 
            if (this._oMessagePopover) {
                this._oMessagePopover.close();
            }

            // Close fragment
            if (this._uploadDialog) {
                this._uploadDialog.close();
            }
        },

        // ============================================================
        // Upload Save Press : ========================================
        // ============================================================
        onUpload_SavePress: function () {
            const that = this;
            const oTable = sap.ui.core.Fragment.byId("excelTableFragment", "UploadTableId");

            if (!oTable) {
                MessageToast.show("Table not found");
                return;
            }

            const selectedIdx = oTable.getSelectedIndices();

            if (selectedIdx.length === 0) {
                MessageToast.show("Please select one or more rows to save.");
                return;
            }

            // Fetch data
            const uploadData = this.getView().getModel("UploadModel").getProperty("/Datass") || [];
            const savedData = this.getView().getModel("TabModel").getProperty("/items") || [];

            const newPayloads = [];
            const duplicateRows = [];

            // ============================================
            // Process Selected Rows :=====================
            // ============================================
            selectedIdx.forEach(idx => {
                const row = uploadData[idx];

                // Mandatory check
                if (!row.orderef || !row.p_mat || !row.vin) {
                    duplicateRows.push(idx + 1);
                    return;
                }

                // Check duplicate in existing backend data
                const existsInSaved = savedData.some(s =>
                    s.vin === row.vin
                );

                // Check duplicate among new payloads
                const existsInNew = newPayloads.some(s =>
                    s.vin === row.vin
                );

                if (existsInSaved || existsInNew) {
                    duplicateRows.push(idx + 1);   // store row number
                    return;
                }

                // Add to payload
                newPayloads.push({
                    // Manufacturingorder: String(row.orderef),
                    // SerialNumber: row.vin,
                    // Material: row.p_mat,
                    // c_min: row.c_min,

                    Color: row.color,
                    Telematics: row.telematics,
                    Charger: row.charger,

                    Display: row.display,
                    Vcu: row.vcu,
                    Mcu: row.mcu,

                    part1: row.part1,
                    part2: row.part2,
                    part3: row.part3,
                    part4: row.part4,
                    part5: row.part5

                });
            });


            // ============================
            // Show duplicate warning 
            // ============================
            if (duplicateRows.length > 0) {
                MessageBox.warning(
                    "Some selected rows were skipped because they already exist:\nRow(s): " +
                    duplicateRows.join(", ")
                );
            }

            // nothing to save
            if (newPayloads.length === 0) {
                MessageToast.show("No new rows to save.");
                oTable.clearSelection();
                return;
            }

            // ============================
            // Save Valid Rows to Backend
            // ============================
            const ModelV = this.getView().getModel("ZSB_VIN_TRACEABILITY");
            let completed = 0;
            let successCount = 0;

            newPayloads.forEach(payload => {
                ModelV.create("/ZI_VIN_CUSTOM", payload, {
                    success: function (response) {
                        that._updateMainModel([response]);
                        successCount++;
                        completed++;

                        if (completed === newPayloads.length) {
                            if (successCount > 0) {
                                MessageToast.show(successCount + " row(s) saved successfully.");
                            }
                            that._uploadDialog.close();
                            oTable.clearSelection();
                            that._reloadTableData();
                        }
                    },
                    error: function () {
                        completed++;

                        if (completed === newPayloads.length) {
                            MessageToast.show("Some rows failed to save.");
                        }
                    }
                });
            });
        },
        _updateMainModel: function (newRows) {
            const oMainModel = this.getView().getModel("TabModel");
            const existing = oMainModel.getProperty("/items") || [];
            oMainModel.setProperty("/items", existing.concat(newRows));
            oMainModel.refresh(true);
        },

        // ============================================================
        // Save Function in Upload : ==================================
        // ============================================================

        onCreate: function () {

            sap.ui.core.BusyIndicator.show(0);

            const oTable = sap.ui.core.Fragment.byId("excelTableFragment", "UploadTableId");

            if (!oTable) {
                sap.m.MessageToast.show("Table not found");
                return;
            }

            const aSelectedIndices = oTable.getSelectedIndices();
            const oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

            if (aSelectedIndices.length === 0) {
                sap.ui.core.BusyIndicator.hide();
                sap.m.MessageToast.show("No rows selected");
                return;
            }

            let aValidPayloads = [];
            let aDuplicateVINs = [];
            let aNotInTraceabilityVINs = [];
            let iProcessed = 0;

            // VINs INSIDE CURRENT UPLOAD
            let oProcessedVINs = new Set();

            let aMessages = [];

            const fnFinalCheck = () => {

                if (iProcessed !== aSelectedIndices.length) {
                    return;
                }

                // SUCCESS MESSAGE
                if (aValidPayloads.length > 0) {

                    aMessages.push({
                        type: "Success",
                        title: `Saved VINs (${aValidPayloads.length})`,
                        description: aValidPayloads.map(p => p.SerialNumber).join(", ")
                    });

                    // CREATE ONLY VALID RECORDS
                    aValidPayloads.forEach((oPayload) => {

                        oModel.create("/ZI_VIN_CUSTOM", oPayload, {

                            success: function () {
                                console.log("Created:", oPayload.SerialNumber);
                            },

                            error: function (err) {

                                console.error("Create failed", err);

                                aDuplicateVINs.push(
                                    `${oPayload.SerialNumber} (Creation failed)`
                                );
                            }
                        });

                    });

                    oModel.refresh(true);
                    this.ReadFunction();
                }

                // DUPLICATE MESSAGE
                if (aDuplicateVINs.length > 0) {

                    aMessages.push({
                        type: "Warning",
                        title: `Duplicate / Skipped VINs (${aDuplicateVINs.length})`,
                        active: true,
                        description: aDuplicateVINs.join(", "),
                        vins: aDuplicateVINs
                    });
                }

                oTable.clearSelection();

                this._oMessageModel.setProperty("/messages", aMessages);

                // OPEN MESSAGEPOPOVER
                if (aMessages.length > 0) {

                } else {
                    sap.m.MessageToast.show("No records processed");
                }
                sap.ui.core.BusyIndicator.hide();

            };

            aSelectedIndices.forEach((iIndex) => {

                const oContext = oTable.getContextByIndex(iIndex);

                if (!oContext) {
                    iProcessed++;
                    fnFinalCheck();
                    return;
                }

                const oData = oContext.getObject();
                const sVIN = oData.vin;

                // CHECK DUPLICATE INSIDE EXCEL SELECTION FIRST
                if (oProcessedVINs.has(sVIN)) {

                    aDuplicateVINs.push(`${sVIN} (Duplicate in upload)`);

                    iProcessed++;
                    fnFinalCheck();
                    return;
                }

                // ADD TO TRACKER
                oProcessedVINs.add(sVIN);

                // STEP 1: TRACEABILITY CHECK
                oModel.read("/ZI_VIN_TRACEABILITY", {

                    filters: [
                        new sap.ui.model.Filter(
                            "SerialNumber",
                            sap.ui.model.FilterOperator.EQ,
                            sVIN
                        )
                    ],

                    success: function (oTrace) {

                        // NOT FOUND IN TRACEABILITY
                        if (!oTrace.results || oTrace.results.length === 0) {

                            aDuplicateVINs.push(
                                `${sVIN} (Not in traceability)`
                            );

                            iProcessed++;
                            fnFinalCheck();
                            return;
                        }

                        const sManufacturingOrder =
                            String(oTrace.results[0].ManufacturingOrder)
                                .replace(/^0+/, '');

                        const oMaterial = oTrace.results[0].Material;

                        const oPayload = {

                            Manufacturingorder: sManufacturingOrder,
                            material: oMaterial,
                            SerialNumber: sVIN,

                            bin: oData.bin,
                            c_min: oData.c_min,
                            Color: oData.color,
                            Display: oData.display,
                            Telematics: oData.telematics,
                            Charger: oData.charger,
                            Vcu: oData.vcu,
                            Mcu: oData.mcu,

                            part1: oData.part1,
                            part2: oData.part2,
                            part3: oData.part3,
                            part4: oData.part4,
                            part5: oData.part5
                        };

                        // STEP 2: CHECK DUPLICATE IN CUSTOM TABLE
                        oModel.read("/ZI_VIN_CUSTOM", {

                            filters: [

                                new sap.ui.model.Filter(
                                    "Manufacturingorder",
                                    sap.ui.model.FilterOperator.EQ,
                                    sManufacturingOrder
                                ),

                                new sap.ui.model.Filter(
                                    "SerialNumber",
                                    sap.ui.model.FilterOperator.EQ,
                                    sVIN
                                )
                            ],

                            success: function (oCustomResponse) {

                                // ALREADY EXISTS IN DB
                                if (
                                    oCustomResponse.results &&
                                    oCustomResponse.results.length > 0
                                ) {

                                    aDuplicateVINs.push(
                                        `${sVIN} (Already exists)`
                                    );

                                } else {

                                    // VALID PAYLOAD
                                    aValidPayloads.push(oPayload);
                                }

                                iProcessed++;
                                fnFinalCheck();

                            }.bind(this),

                            error: function () {

                                aDuplicateVINs.push(
                                    `${sVIN} (Duplicate check failed)`
                                );

                                iProcessed++;
                                fnFinalCheck();
                            }
                        });

                    }.bind(this),

                    error: function () {

                        aDuplicateVINs.push(
                            `${sVIN} (Traceability error)`
                        );

                        iProcessed++;
                        fnFinalCheck();
                    }
                });

            });

        },

        // ===========================================================
        // Delete Function : =========================================
        // ===========================================================
        onDeletePress: function () {
            var that = this;
            var oTable = this.byId("TableId");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

            if (aSelectedIndices.length === 0) {
                sap.m.MessageToast.show("Select at least one row");
                return;
            }

            sap.m.MessageBox.confirm(
                "Do you want to delete the selected row(s)?",
                {
                    title: "Confirm Delete",
                    actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.OK,

                    onClose: function (sAction) {
                        if (sAction === sap.m.MessageBox.Action.OK) {

                            for (var i = aSelectedIndices.length - 1; i >= 0; i--) {

                                var oContext = oTable.getContextByIndex(aSelectedIndices[i]);

                                if (oContext) {

                                    var oData = oContext.getObject();

                                    var sPath = oModel.createKey("/ZI_VIN_CUSTOM", {
                                        Manufacturingorder: oData.Manufacturingorder,
                                        SerialNumber: oData.SerialNumber
                                    });

                                    oModel.remove(sPath, {
                                        success: function () {
                                            oModel.refresh(true);
                                            oTable.clearSelection();
                                            that.ReadFunction();
                                        },
                                        error: function (oError) {
                                            console.error("Delete failed:", oError);
                                            sap.m.MessageBox.error("Delete failed");
                                        }
                                    });
                                }
                            }

                            sap.m.MessageToast.show("Selected row(s) deleted successfully");
                        }
                    }
                }
            );
        },

        // onDeletePress: function () {
        //     var that = this;
        //     var oTable = this.byId("TableId");
        //     var aSelectedIndices = oTable.getSelectedIndices();
        //     var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

        //     if (aSelectedIndices.length === 0) {
        //         sap.m.MessageToast.show("Select at least one row");
        //         return;
        //     }

        //     for (var i = aSelectedIndices.length - 1; i >= 0; i--) {
        //         var oContext = oTable.getContextByIndex(aSelectedIndices[i]);

        //         if (oContext) {
        //             var oData = oContext.getObject();
        //             var sSerialNumber = oData.SerialNumber;
        //             var sMO = oData.Manufacturingorder;
        //             var sPath = "/ZI_VIN_CUSTOM(SerialNumber='" + sSerialNumber +
        //                 "',Manufacturingorder='" + sMO + "')";

        //             oModel.remove(sPath, {
        //                 success: function () {
        //                     console.log("Deleted:", sSerialNumber);
        //                     sap.m.MessageToast.show("Selected rows deleted successfully");
        //                     oModel.refresh(true);
        //                     oTable.clearSelection();
        //                     that.ReadFunction();
        //                 },
        //                 error: function (oError) {
        //                     console.error("Delete failed:", oError);
        //                 }
        //             });
        //         }
        //     }
        // },
        // ===========================================================
        // Update Function : =========================================
        // ===========================================================

        // onUpdatePress: function () {
        //     var that = this;
        //     var oTable = this.byId("TableId");
        //     var aSelectedIndices = oTable.getSelectedIndices();
        //     var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

        //     if (aSelectedIndices.length === 0) {
        //         sap.m.MessageToast.show("Select at least one row");
        //         return;
        //     }

        //     var aSelectedData = [];
        //     var aFilters = [];

        //     // filters
        //     for (var i = 0; i < aSelectedIndices.length; i++) {
        //         var oContext = oTable.getContextByIndex(aSelectedIndices[i]);
        //         if (oContext) {
        //             var oData = oContext.getObject();
        //             aSelectedData.push(oData);

        //             aFilters.push(
        //                 new sap.ui.model.Filter("bin", sap.ui.model.FilterOperator.EQ, oData.bin)
        //             );
        //         }
        //     }

        //     // Remove duplicate filters
        //     var aUniqueBins = [...new Set(aSelectedData.map(item => item.bin))];
        //     aFilters = aUniqueBins.map(function (bin) {
        //         return new sap.ui.model.Filter("bin", sap.ui.model.FilterOperator.EQ, bin);
        //     });

        //     // Backend
        //     oModel.read("/ZI_VIN_CUSTOM", {
        //         filters: aFilters,
        //         success: function (oResponse) {

        //             var bDuplicate = false;

        //             // Check if any bin already exists for different SerialNumber
        //             aSelectedData.forEach(function (oSel) {
        //                 oResponse.results.forEach(function (oRes) {
        //                     if (oRes.bin === oSel.bin &&
        //                         oRes.SerialNumber !== oSel.SerialNumber) {
        //                         bDuplicate = true;
        //                     }
        //                 });
        //             });

        //             if (bDuplicate) {
        //                 sap.m.MessageBox.error("Duplicate bins are not allowed");
        //                 return;
        //             }

        //             // Update
        //             aSelectedData.forEach(function (oData) {

        //                 var sSerialNumber = oData.SerialNumber;
        //                 var sMO = oData.Manufacturingorder;

        //                 var sPath = "/ZI_VIN_CUSTOM(SerialNumber='" + sSerialNumber +
        //                     "',Manufacturingorder='" + sMO + "')";

        //                 var oUpdatedData = {
        //                     SerialNumber: sSerialNumber,
        //                     Manufacturingorder: sMO,
        //                     material: oData.material,
        //                     bin: oData.bin,
        //                     c_min: oData.c_min,
        //                     Color: oData.Color,
        //                     Display: oData.Display,
        //                     Telematics: oData.Telematics,
        //                     Charger: oData.Charger,
        //                     Vcu: oData.Vcu,
        //                     Mcu: oData.Mcu,
        //                     part1: oData.part1,
        //                     part2: oData.part2,
        //                     part3: oData.part3,
        //                     part4: oData.part4,
        //                     part5: oData.part5
        //                 };

        //                 oModel.update(sPath, oUpdatedData, {
        //                     success: function () {
        //                         sap.m.MessageToast.show("Updated successfully");
        //                         oModel.refresh(true);
        //                         oTable.clearSelection();
        //                         that.ReadFunction();
        //                     },
        //                     error: function (oError) {
        //                         console.error("Update failed:", oError);
        //                         sap.m.MessageBox.error("Update failed");
        //                     }
        //                 });
        //             });

        //         },
        //         error: function () {
        //             sap.m.MessageBox.error("Error checking bin from backend");
        //         }
        //     });
        // },
        // onUpdatePress: function () {
        //     sap.ui.core.BusyIndicator.show(0);
        //     var that = this;
        //     var oTable = this.byId("TableId");
        //     var aSelectedIndices = oTable.getSelectedIndices();
        //     var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

        //     if (aSelectedIndices.length === 0) {
        //         sap.m.MessageToast.show("Select at least one row");
        //         sap.ui.core.BusyIndicator.hide();
        //         return;
        //     }

        //     if (aSelectedIndices.length > 1) {
        //         sap.m.MessageToast.show("Please select only one row to update");
        //         sap.ui.core.BusyIndicator.hide();
        //         return;
        //     }

        //     var aSelectedData = [];

        //     // Fields to validate
        //     var aFieldsToCheck = ["bin", "c_min", "Mcu", "Telematics", "Charger", "Display", "Vcu"];

        //     // Collect selected data
        //     for (var i = 0; i < aSelectedIndices.length; i++) {
        //         var oContext = oTable.getContextByIndex(aSelectedIndices[i]);
        //         if (oContext) {
        //             aSelectedData.push(oContext.getObject());
        //         }
        //     }

        //     var fnCheckField = function (index) {

        //         if (index >= aFieldsToCheck.length) {
        //             // No duplicates proceed with update
        //             fnUpdate();
        //             return;
        //         }

        //         var sField = aFieldsToCheck[index];

        //         // Unique values for this field
        //         var aUniqueValues = [...new Set(aSelectedData.map(item => item[sField]))];

        //         var aFilters = aUniqueValues
        //             .filter(v => v)
        //             .map(function (value) {
        //                 return new sap.ui.model.Filter(sField, sap.ui.model.FilterOperator.EQ, value);
        //             });

        //         if (aFilters.length === 0) {
        //             fnCheckField(index + 1);
        //             return;
        //         }

        //         // Backend check
        //         oModel.read("/ZI_VIN_CUSTOM", {
        //             filters: aFilters,
        //             success: function (oResponse) {

        //                 var bDuplicate = false;

        //                 aSelectedData.forEach(function (oSel) {
        //                     oResponse.results.forEach(function (oRes) {
        //                         if (oRes[sField] === oSel[sField] &&
        //                             oRes.SerialNumber !== oSel.SerialNumber &&
        //                             oSel[sField]) {
        //                             bDuplicate = true;
        //                         }
        //                     });
        //                 });

        //                 if (bDuplicate) {
        //                     // Message
        //                     sap.m.MessageBox.error("Duplicate " + sField + " are not allowed");

        //                     // 
        //                     oModel.refresh(true);
        //                     oTable.clearSelection();
        //                     sap.ui.core.BusyIndicator.hide();
        //                     return;
        //                 }

        //                 // 👉 Check next field
        //                 fnCheckField(index + 1);
        //             },
        //             error: function () {
        //                 sap.m.MessageBox.error("Error checking " + sField);
        //                 sap.ui.core.BusyIndicator.hide();
        //             }
        //         });
        //     };

        //     // Update function
        //     var fnUpdate = function () {
        //         aSelectedData.forEach(function (oData) {

        //             var sSerialNumber = oData.SerialNumber;
        //             var sMO = oData.Manufacturingorder;

        //             var sPath = "/ZI_VIN_CUSTOM(SerialNumber='" + sSerialNumber +
        //                 "',Manufacturingorder='" + sMO + "')";

        //             var oUpdatedData = {
        //                 SerialNumber: sSerialNumber,
        //                 Manufacturingorder: sMO,
        //                 material: oData.material,
        //                 bin: oData.bin,
        //                 c_min: oData.c_min,
        //                 Color: oData.Color,
        //                 Display: oData.Display,
        //                 Telematics: oData.Telematics,
        //                 Charger: oData.Charger,
        //                 Vcu: oData.Vcu,
        //                 Mcu: oData.Mcu,
        //                 part1: oData.part1,
        //                 part2: oData.part2,
        //                 part3: oData.part3,
        //                 part4: oData.part4,
        //                 part5: oData.part5
        //             };

        //             oModel.update(sPath, oUpdatedData, {
        //                 success: function () {
        //                     sap.ui.core.BusyIndicator.hide();
        //                     sap.m.MessageToast.show("Updated successfully");
        //                     oModel.refresh(true);
        //                     oTable.clearSelection();
        //                     that.ReadFunction();
        //                 },
        //                 error: function () {
        //                     sap.ui.core.BusyIndicator.hide();
        //                     sap.m.MessageBox.error("Update failed");
        //                 }
        //             });
        //         });
        //     };

        //     // Start validation
        //     fnCheckField(0);
        // },
        onUpdatePress: function () {
            sap.ui.core.BusyIndicator.show(0);
            var that = this;
            var oTable = this.byId("TableId");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

            if (aSelectedIndices.length === 0) {
                sap.m.MessageToast.show("Select at least one row");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            if (aSelectedIndices.length > 1) {
                sap.m.MessageToast.show("Please select only one row to update");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            var aSelectedData = [];

            var aFieldsToCheck = ["bin", "c_min", "Mcu", "Telematics", "Charger", "Display", "Vcu"];

            for (var i = 0; i < aSelectedIndices.length; i++) {
                var oContext = oTable.getContextByIndex(aSelectedIndices[i]);
                if (oContext) {
                    aSelectedData.push(oContext.getObject());
                }
            }

            var fnCheckField = function (index) {

                if (index >= aFieldsToCheck.length) {
                    fnUpdate();
                    return;
                }

                var sField = aFieldsToCheck[index];

                var aUniqueValues = [...new Set(aSelectedData.map(item => item[sField]))];

                var aFilters = aUniqueValues
                    .filter(v => v)
                    .map(function (value) {
                        return new sap.ui.model.Filter(sField, sap.ui.model.FilterOperator.EQ, value);
                    });

                if (aFilters.length === 0) {
                    fnCheckField(index + 1);
                    return;
                }

                oModel.read("/ZI_VIN_CUSTOM", {
                    filters: aFilters,
                    success: function (oResponse) {

                        var bDuplicate = false;

                        aSelectedData.forEach(function (oSel) {
                            oResponse.results.forEach(function (oRes) {
                                if (oRes[sField] === oSel[sField] &&
                                    oRes.SerialNumber !== oSel.SerialNumber &&
                                    oSel[sField]) {
                                    bDuplicate = true;
                                }
                            });
                        });

                        if (bDuplicate) {
                            sap.m.MessageBox.error("Duplicate " + sField + " are not allowed");
                            oModel.refresh(true);
                            oTable.clearSelection();
                            sap.ui.core.BusyIndicator.hide();
                            return;
                        }

                        fnCheckField(index + 1);
                    },
                    error: function () {
                        sap.m.MessageBox.error("Error checking " + sField);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            };

            var fnUpdate = function () {
                aSelectedData.forEach(function (oData) {

                    var sPath = oModel.createKey("/ZI_VIN_CUSTOM", {
                        Manufacturingorder: oData.Manufacturingorder,
                        SerialNumber: oData.SerialNumber
                    });

                    var oUpdatedData = {
                        SerialNumber: oData.SerialNumber,
                        Manufacturingorder: oData.Manufacturingorder,
                        material: oData.material,
                        bin: oData.bin,
                        c_min: oData.c_min,
                        Color: oData.Color,
                        Display: oData.Display,
                        Telematics: oData.Telematics,
                        Charger: oData.Charger,
                        Vcu: oData.Vcu,
                        Mcu: oData.Mcu,
                        part1: oData.part1,
                        part2: oData.part2,
                        part3: oData.part3,
                        part4: oData.part4,
                        part5: oData.part5
                    };

                    oModel.update(sPath, oUpdatedData, {
                        success: function () {
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Updated successfully");
                            oModel.refresh(true);
                            oTable.clearSelection();
                            that.ReadFunction();
                        },
                        error: function (oError) {
                            sap.ui.core.BusyIndicator.hide();
                            console.log(oError);
                            sap.m.MessageBox.error("Update failed");
                        }
                    });
                });
            };

            fnCheckField(0);
        },


        // ===========================================================
        // Role Based : ==============================================
        // ===========================================================
        onAfterRendering: function () {
            var oUserRoleModel = new sap.ui.model.json.JSONModel();
            this.getView().setModel(oUserRoleModel, "UserModel");

            var oModel = this.getView().getModel("ZCE_USER_BUSINESS_ROLE"); // OData V2 service
            var sUserId = sap.ushell.Container.getUser().getId(); // gets current logged-in user

            var filter1 = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId)
            var filter2 = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, "ZF_UPDATE_ROLE")

            var that = this;
            oModel.read("/ZCE_USERBUSINESSROLE", {
                filters: [filter1, filter2],
                success: function (oData) {
                    if (oData.results.length > 0) {
                        //   console.log("Tenant user found:", tenantUser);
                        that.AdminPanelAuth = new sap.ui.model.json.JSONModel({
                            Samples: { Role: true }
                        });
                        that.getView().setModel(that.AdminPanelAuth, "AdminPanelAuth");
                        console.log("that.AdminPanelAuth:", that.AdminPanelAuth);
                        sap.ui.core.BusyIndicator.hide();
                        //resolve(oData.results);

                        // You can handle the case where the tenant user is found here
                    } else {
                        console.log("Tenant user not found");
                        that.AdminPanelAuth = new sap.ui.model.json.JSONModel({
                            Samples: { Role: false }
                        });
                        that.getView().setModel(that.AdminPanelAuth, "AdminPanelAuth");
                        console.log("that.AdminPanelAuth:", that.AdminPanelAuth);
                        sap.ui.core.BusyIndicator.hide();
                        // resolve(oData.results);
                    }
                },
                error: function (oError) {
                    console.error("Failed to fetch roles", oError);
                    oUserRoleModel.setProperty("/roles", []);
                }
            });

        },

        // ===========================================================
        // Download Function :========================================
        // ===========================================================

        onExportPress: function () {
            var that = this;  // Keep reference to this controller

            sap.m.MessageBox.confirm("Do you want to download the data?", {
                onClose: function (oAction) {
                    if (oAction === sap.m.MessageBox.Action.OK) {
                        var oTable = that.getView().byId("TableId");
                        var oBinding = oTable.getBinding("rows");
                        var aCols = that._createColumns();

                        var oSettings = {
                            workbook: {
                                columns: aCols,
                                hierarchyLevel: "Level"
                            },
                            dataSource: oBinding,
                            fileName: "Vin/Bin Report Data"
                        };

                        var oSheet = new Spreadsheet(oSettings);
                        oSheet.build().finally(function () {
                            oSheet.destroy();
                        });
                    }
                    // Close the Message Box if cancels
                }
            });

        },
        _createColumns: function () {

            var EdmType = exportLibrary.EdmType;

            var aCols = [];
            aCols.push({
                label: "Order Reference",
                property: "Manufacturingorder",
                type: EdmType.String
            });

            aCols.push({
                label: "P_Material",
                property: "material",
                type: EdmType.String
            });

            aCols.push({
                label: "VIN",
                property: "SerialNumber",
                type: EdmType.String
            });

            aCols.push({
                label: "BIN",
                property: "bin",
                type: EdmType.String
            });

            aCols.push({
                label: "C_MIN",
                property: "c_min",
                type: EdmType.String
            });

            aCols.push({
                label: "MCU",
                property: "Mcu",
                type: EdmType.String
            });

            aCols.push({
                label: "Telematics",
                property: "Telematics",
                type: EdmType.String
            });

            aCols.push({
                label: "Charger",
                property: "Charger",
                type: EdmType.String
            });

            aCols.push({
                label: "Color",
                property: "Color",
                type: EdmType.String
            });

            aCols.push({
                label: "Display",
                property: "Display",
                type: EdmType.String
            });

            aCols.push({
                label: "Vcu",
                property: "Vcu",
                type: EdmType.String
            });

            aCols.push({
                label: "Part 1",
                property: "part1",
                type: EdmType.String
            });

            aCols.push({
                label: "Part 2",
                property: "part2",
                type: EdmType.String
            });

            aCols.push({
                label: "Part 3",
                property: "part3",
                type: EdmType.String
            });

            aCols.push({
                label: "Part 4",
                property: "part4",
                type: EdmType.String
            });

            aCols.push({
                label: "Part 5",
                property: "part5",
                type: EdmType.String
            });

            aCols.push({
                label: "SAP Description",
                property: "sapdes",
                type: EdmType.String
            });

            aCols.push({
                label: "Created On",
                property: "createdon",
                type: EdmType.String
            });

            aCols.push({
                label: "Created By",
                property: "createdby",
                type: EdmType.String
            });

            aCols.push({
                label: "Last Changed On",
                property: "changedon",
                type: EdmType.String
            });

            aCols.push({
                label: "Last Changed By",
                property: "changedby",
                type: EdmType.String
            });

            aCols.push({
                label: "Lifecycle Status",
                property: "lifecyclestatus",
                type: EdmType.String
            });


            return aCols;
        },

        // ===========================================================
        // Message PopOver : =========================================
        // ===========================================================

        handleMessagePopoverPress: function (oEvent) {

            if (!this._oMessagePopover) {
                this._oMessagePopover = new sap.m.MessagePopover({
                    items: {
                        path: "msg>/messages",
                        template: new sap.m.MessageItem({
                            type: "{msg>type}",
                            title: "{msg>title}",
                            description: "{msg>description}",

                        })
                    },

                });

                this.getView().addDependent(this._oMessagePopover);
            }

            this._oMessagePopover.toggle(oEvent.getSource());
        },

        onGoPress: async function () {

            var oValue = this.byId("VinIdInput").getValue();

            let aFilter = [];

            if (oValue) {
                aFilter.push(
                    new sap.ui.model.Filter("SerialNumber", sap.ui.model.FilterOperator.EQ, oValue)
                );
            }

            const oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");
            const that = this;
            that.getView().setBusy(true);

            let aAllItems = [];
            let iSkip = 0;
            const iTop = 200;

            // --- Recursive fetch (paging) ---
            function fetchData() {
                oModel.read("/ZI_VIN_CUSTOM", {
                    filters: aFilter,
                    urlParameters: {
                        "$skip": iSkip,
                        "$top": iTop
                    },
                    success: function (oData) {
                        if (oData.results.length > 0) {
                            aAllItems = aAllItems.concat(oData.results);
                            iSkip += iTop;
                            fetchData(); // continue loading
                        } else {
                            that.getView().setBusy(false);
                            console.log("Total rows fetched:", aAllItems.length);

                            let aResults = aAllItems;

                            // After fetchData() completes
                            aAllItems.sort(function (a, b) {
                                return Number(a.boxno) - Number(b.boxno); // 
                            });

                            const TabModel = new sap.ui.model.json.JSONModel({
                                items: aAllItems
                            });
                            that.getView().setModel(TabModel, "TabModel");

                            //  Message if no results
                            if (aResults.length === 0) {
                                sap.m.MessageToast.show("No records found for the given filters.");
                            }
                        }
                    },
                    error: function (error) {
                        that.getView().setBusy(false);
                        console.error("Error fetching data:", error);
                        sap.m.MessageToast.show("Error fetching data.");
                    }
                });
            }

            // Start fetching
            fetchData();
        },

        // ===========================================================
        // Customer Value help request :==============================
        // ===========================================================
        onVinValueHelpRequest: function () {

            sap.ui.core.BusyIndicator.show();

            var oModel = this.getView().getModel("ZSB_VIN_TRACEABILITY");

            // Check if the model is valid
            if (!oModel) {
                console.error("OData model is not properly initialized.");
                sap.ui.core.BusyIndicator.hide();
                return;
            }

            var that = this;
            var aAllItems = []; // Array to hold all retrieved items

            // Function to fetch data recursively
            function fetchData(skipCount) {

                oModel.read("/ZI_VIN_CUSTOM", {
                    //   filters: oFilters,
                    urlParameters: {
                        $top: 5000,  // Request a chunk of 5000 records
                        $skip: skipCount  // Start from the skipCount position
                    },
                    success: function (oData) {
                        var aItems = oData.results;
                        aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                        // Check if there are more records to fetch
                        if (oData.results.length >= 5000) {
                            // If there are more records, fetch next chunk
                            fetchData(skipCount + 5000);
                        } else {
                            // If no more records, all data is fetched
                            finishFetching();
                        }
                    },
                    error: function (oError) {
                        console.error("Error reading data: ", oError);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }

            function finishFetching() {


                // Once all data is fetched, proceed to display it
                that.oJSONModel = new sap.ui.model.json.JSONModel({
                    Datas: aAllItems
                });
                that.getView().setModel(that.oJSONModel, "oJSONModel");
                console.log("that.oJSONModel:", that.oJSONModel)

                // Load the value help dialog fragment
                that._oBasicSearchField = new sap.m.SearchField();
                that.loadFragment({
                    name: "zfvinbinreport.fragment.VinFragment"
                }).then(function (oDialog) {
                    var oFilterBar = oDialog.getFilterBar();

                    var oColumnProductCode;
                    that._oVHD_ = oDialog;
                    that.getView().addDependent(oDialog);

                    // Set key fields for filtering in the Define Conditions Tab
                    oDialog.setRangeKeyFields([{
                        label: "Vin",
                        key: "SerialNumber",
                        type: "string",
                        typeInstance: new sap.ui.model.type.String({}, {
                            maxLength: 10
                        })
                    }]);

                    // Set Basic Search for FilterBar
                    oFilterBar.setFilterBarExpanded(false);
                    oFilterBar.setBasicSearch(that._oBasicSearchField);

                    // Trigger filter bar search when the basic search is fired
                    that._oBasicSearchField.attachSearch(function () {
                        oFilterBar.search();
                    });

                    oDialog.getTableAsync().then(function (oTable) {
                        oTable.setModel(that.oJSONModel);

                        // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                        if (oTable.bindRows) {
                            // Desktop/Table scenario (sap.ui.table.Table)
                            oTable.bindAggregation("rows", {
                                path: "oJSONModel>/Datas",
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.ui.table.Table oColumnProductCode
                            oColumnProductCode = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: "Vin" }),
                                template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>SerialNumber}" })
                            });
                            oColumnProductCode.data({
                                fieldName: "SerialNumber"
                            });

                            oTable.addColumn(oColumnProductCode);


                        } else if (oTable.bindItems) {
                            // Mobile scenario (sap.m.Table)
                            oTable.bindAggregation("items", {
                                path: "oJSONModel>/Datas",
                                template: new sap.m.ColumnListItem({
                                    cells: [
                                        new sap.m.Text({ text: "{oJSONModel>SerialNumber}" }),


                                    ]
                                }),
                                events: {
                                    dataReceived: function () {
                                        oDialog.update();
                                    }
                                }
                            });

                            // Define columns for sap.m.Table (if necessary)
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({ text: "Vin" })
                            }));

                        }

                        oDialog.update();
                        sap.ui.core.BusyIndicator.hide();
                    });

                    oDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                });
            }

            // Start fetching data from the beginning
            fetchData(0);

        },

        onValueHelpOkPress_Vin: function (oEvent) {

            var oToken = oEvent.getParameter("tokens")[0];

            var aValue = oToken.getText();

            this.byId("VinIdInput").setValue(aValue);

            this._oVHD_.close();

        },

        onValueHelpCancelPress_Vin: function () {
            this._oVHD_.close();
        },

        onValueHelpAfterClose_Vin: function () {
            this._oVHD_.destroy();
        },

        onFilterBarSearch_Vin: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "SerialNumber", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery })


                ],
                and: false
            }));

            this._filterTableVin(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },
        _filterTableVin: function (oFilter) {
            var oVHD = this._oVHD_;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },

        onActiveTitlePress: function (oEvent) {

            var oItem = oEvent.getParameter("item") || oEvent.getSource();

            var oContext = oItem.getBindingContext("msg");

            if (!oContext) {
                sap.m.MessageToast.show("No data found");
                return;
            }

            var oData = oContext.getObject();
            var aVINs = oData.vins;

            if (!aVINs) {
                sap.m.MessageToast.show("No VINs found");
                return;
            }

            if (typeof aVINs === "string") {
                aVINs = aVINs.split(",");
            }

            if (!Array.isArray(aVINs)) {
                aVINs = [aVINs];
            }

            if (aVINs.length === 0) {
                sap.m.MessageToast.show("No VINs to download");
                return;
            }

            sap.m.MessageBox.confirm(
                "Do you want to download the unsaved VINs?",
                {
                    title: "Confirm Download",
                    actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.OK,
                    onClose: function (sAction) {

                        if (sAction === sap.m.MessageBox.Action.OK) {

                            var aTempData = aVINs.map(function (sVIN) {
                                return {
                                    vin: sVIN
                                };
                            });

                            var oSheet = new Spreadsheet({
                                workbook: {
                                    columns: this._createVINColumns()
                                },
                                dataSource: aTempData,
                                fileName: "VIN-Download.xlsx"
                            });

                            oSheet.build().finally(function () {
                                oSheet.destroy();
                            });
                        }
                    }.bind(this)
                }
            );
        },
        _createVINColumns: function () {

            var EdmType = exportLibrary.EdmType;

            return [
                {
                    label: "VIN",
                    property: "vin",
                    type: EdmType.String
                }
            ];
        },







    });
});