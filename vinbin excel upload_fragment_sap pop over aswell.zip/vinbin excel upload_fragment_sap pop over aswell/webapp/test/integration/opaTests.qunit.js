/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["zfvinbinreport/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
