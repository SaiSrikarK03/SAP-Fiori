sap.ui.define([
	"zfvinbinreport/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
