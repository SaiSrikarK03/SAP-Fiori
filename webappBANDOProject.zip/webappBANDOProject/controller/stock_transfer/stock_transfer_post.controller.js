sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",
        "bando/util/jspdf/html2canvasmin",
        "bando/util/jspdf/jspdfmin",
        "bando/util/importfile/importexcelfile",
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
        "use strict";

        return BaseController.extend("bando.controller.stock_transfer.stock_transfer_post", {



            onInit: function () {


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("stock_transfer_post").attachMatched(this._onRouteMatched, this);

            },

            _onRouteMatched: function () {
                // Clear filters
                // this.byId("idDateRange").setDateValue(null);
                // this.byId("idDateRange").setSecondDateValue(null);
                // this.byId("idPlant").setValue("");
                // this.byId("idMaterial").setValue("");
                // this.byId("idProductGroup").setValue("");

                // Optionally: clear or re-fetch table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);
                this.HeaderModel = new sap.ui.model.json.JSONModel({

                    HeaderData: {
                        idDate: "",
                        idDateFrom: "",
                        idDateTo: "",
                        idRequestNo: "",
                        idFromTo: "",
                        // idStatus: "",

                    }
                })

                this.getView().setModel(this.HeaderModel, "HeaderModel");
            },


            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },





            // GoStockPostTableOpen: function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // OData model
            //     const oTabModel = oView.getModel("TabModel");           // Local JSON model

            //     // Get header values - CORRECTED DATE RANGE METHOD
            //     const oDateRange = oView.byId("idDateRange");
            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();
            //     const sRequestNo = oView.byId("idRequestNo").getValue().trim();
            //     const sRequester = oView.byId("idRequester").getValue().trim();
            //     const sPlant = oView.byId("idPlant").getValue().trim();

            //     // Validate: at least one filter required
            //     if (!oStartDate && !oEndDate && !sRequestNo && !sRequester && !sPlant) {
            //         sap.m.MessageBox.error("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];
            //     const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

            //     // Date Range filter - CORRECTED USING BT OPERATOR
            //     if (oStartDate && oEndDate) {
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "requestdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     } else if (oStartDate) {
            //         // Only start date provided
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.GE, sStartDate));
            //     } else if (oEndDate) {
            //         // Only end date provided
            //         const sEndDate = oDateFormat.format(oEndDate);
            //         aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.LE, sEndDate));
            //     }

            //     // 🔹 Request Number filter (zero-padded to 10 digits)
            //     if (sRequestNo) {
            //         const sFormattedReqNo = sRequestNo.padStart(10, '0');
            //         aFilters.push(new sap.ui.model.Filter("requestno", sap.ui.model.FilterOperator.EQ, sFormattedReqNo));
            //     }
            //     if (sRequester) {
            //         aFilters.push(new sap.ui.model.Filter(
            //             "requester",
            //             sap.ui.model.FilterOperator.Contains,
            //             sRequester
            //         ));
            //     }

            //     if (sPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, sPlant));
            //     }

            //     // Show footer
            //     const oDynamicPage = this.byId("dynamicpageStockRequestScreen");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // OData Read
            //     oModel.read("/ZC_STOCK_TRANSFER_GT", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();
            //             oTabModel.setProperty("/Samples", oData.results);
            //             oView.byId("idStockRequestTable").setVisible(true);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            //         },
            //         error: function (oError) {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            //         }
            //     });
            // },

            // Modified to accept a callback (optional)
            GoStockPostTableOpen: function (callback) {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const oTabModel = oView.getModel("TabModel");

                const oDateRange = oView.byId("idDateRange");
                const oStartDate = oDateRange.getDateValue();
                const oEndDate = oDateRange.getSecondDateValue();
                const sRequestNo = oView.byId("idRequestNo").getValue().trim();
                const sRequester = oView.byId("idRequester").getValue().trim();
                const sPlant = oView.byId("idPlant").getValue().trim();

                if (!oStartDate && !oEndDate && !sRequestNo && !sRequester && !sPlant) {
                    sap.m.MessageBox.error("Please enter at least one filter criteria.");
                    if (callback && typeof callback === 'function') callback([]);
                    return;
                }

                const aFilters = [];
                const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

                if (oStartDate && oEndDate) {
                    const sStartDate = oDateFormat.format(oStartDate);
                    const sEndDate = oDateFormat.format(oEndDate);
                    aFilters.push(new sap.ui.model.Filter({
                        path: "requestdate",
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: sStartDate,
                        value2: sEndDate
                    }));
                } else if (oStartDate) {
                    aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.GE, oDateFormat.format(oStartDate)));
                } else if (oEndDate) {
                    aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.LE, oDateFormat.format(oEndDate)));
                }

                if (sRequestNo) {
                    const sFormattedReqNo = sRequestNo.padStart(10, '0');
                    aFilters.push(new sap.ui.model.Filter("requestno", sap.ui.model.FilterOperator.EQ, sFormattedReqNo));
                }
                if (sRequester) {
                    aFilters.push(new sap.ui.model.Filter("requester", sap.ui.model.FilterOperator.Contains, sRequester));
                }
                if (sPlant) {
                    aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, sPlant));
                }

                const oDynamicPage = this.byId("dynamicpageStockRequestScreen");
                if (oDynamicPage) oDynamicPage.setShowFooter(true);

                sap.ui.core.BusyIndicator.show(0);

                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    filters: aFilters,
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        const aResults = oData.results || [];
                        oTabModel.setProperty("/Samples", aResults);
                        oView.byId("idStockRequestTable").setVisible(true);

                        const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                        if (callback && typeof callback === 'function') {
                            callback(aResults);
                        }
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");
                        console.error("OData read error:", oError);
                        const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                        if (callback && typeof callback === 'function') callback([]);
                    }
                });
            },

            // New filter method
            applyAllFiltersStock: function () {
                const oView = this.getView();
                const oCombo = oView.byId("comboMatDocStatusFilter");
                const sStatus = oCombo.getSelectedKey(); // "", "COMPLETED", "NOT_COMPLETED"

                // If "All", just reload normally (no callback, direct table update)
                if (!sStatus || sStatus === "") {
                    this.GoStockPostTableOpen(); // no callback = normal refresh
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                // Fetch fresh data with main filters, then apply status filter
                this.GoStockPostTableOpen(function (aRawData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!aRawData || aRawData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Apply completion filter inline (no extra function)
                    const aFiltered = aRawData.filter(function (item) {
                        const sMatDocNo = item.materialdocumentno;
                        // Determine if completed: value exists, not null, not "0", not all zeros
                        let isCompleted = false;
                        if (sMatDocNo && typeof sMatDocNo === "string") {
                            const trimmed = sMatDocNo.trim();
                            if (trimmed !== "" && !/^0+$/.test(trimmed)) {
                                isCompleted = true;
                            }
                        }

                        if (sStatus === "COMPLETED") {
                            return isCompleted === true;
                        } else { // NOT_COMPLETED
                            return isCompleted === false;
                        }
                    });

                    // Update the table model with filtered data
                    const oTabModel = oView.getModel("TabModel");
                    oTabModel.setProperty("/Samples", aFiltered);

                    sap.m.MessageToast.show(`Filtered to ${aFiltered.length} records (${sStatus.toLowerCase()})`);
                });
            },


            onIssueQtyLiveChange: function (oEvent) {
                var oInput = oEvent.getSource();
                var sValue = oEvent.getParameter("value");
                var oBindingContext = oInput.getBindingContext("TabModel");

                if (oBindingContext) {
                    var oRow = oBindingContext.getObject();
                    var batchQty = parseFloat(oRow.Batchqty) || 0;
                    var newIssueQty = parseFloat(sValue) || 0;
                    var isBatchManaged = oRow.isbatchmanagementrequired === "true";
                    var batch = oRow.batch || "";
                    var sRequestNo = oRow.requestno;

                    // If user clears the field, allow it
                    if (sValue === "" || sValue === null) {
                        return;
                    }

                    // Validate negative values
                    if (newIssueQty < 0) {
                        sap.m.MessageBox.error("Issue quantity cannot be negative.");
                        oInput.setValue("");
                        return;
                    }

                    // Check if this is a batch-managed material
                    if (isBatchManaged) {
                        // For batch-managed materials, check if batch is filled
                        if (!batch || batch.trim() === "") {
                            sap.m.MessageBox.error("Please select a Batch first before entering Issue Quantity.");
                            oInput.setValue("");
                            return;
                        }

                        // Check if Batchqty is available
                        if (batchQty <= 0) {
                            sap.m.MessageBox.error("Batch quantity is not available. Please select a valid batch.");
                            oInput.setValue("");
                            return;
                        }

                        // Get all rows to calculate total allocated batch quantity
                        var oModel = this.getView().getModel("TabModel");
                        var aData = oModel.getProperty("/Samples") || [];
                        var currentRowPath = oBindingContext.getPath();

                        // Calculate total allocated quantity for this batch in the same request
                        var totalAllocated = 0;

                        aData.forEach(function (oTableRow) {
                            // Skip the current row - compare by object reference
                            if (oRow === oTableRow) {
                                return;
                            }

                            // Only consider rows with same request no, same batch, and batch management required
                            if (oTableRow.requestno === sRequestNo &&
                                oTableRow.batch === batch &&
                                oTableRow.isbatchmanagementrequired === "true" &&
                                oTableRow.issueqty) {

                                totalAllocated += parseFloat(oTableRow.issueqty) || 0;
                            }
                        });

                        // Calculate available quantity for this row
                        var availableForThisRow = batchQty - totalAllocated;

                        // Check if new issue quantity exceeds available batch quantity
                        if (newIssueQty > availableForThisRow) {
                            if (availableForThisRow <= 0) {
                                sap.m.MessageBox.error(
                                    "Batch " + batch + " is fully allocated for request number " + sRequestNo +
                                    ".\nTotal batch quantity: " + batchQty +
                                    "\nAlready allocated by other rows: " + totalAllocated
                                );
                                oInput.setValue("");

                                // Clear the batch field
                                oModel.setProperty(currentRowPath + "/batch", "");
                            } else {
                                sap.m.MessageBox.error(
                                    "Issue quantity exceeds available batch quantity.\n" +
                                    "Available: " + availableForThisRow + "\n" +
                                    "Total batch: " + batchQty + "\n" +
                                    "Already allocated: " + totalAllocated
                                );
                                oInput.setValue(availableForThisRow.toString());
                            }
                        }
                    } else {
                        // For non-batch managed materials, check against requested quantity
                        var reqQty = parseFloat(oRow.reqqty) || 0;
                        if (reqQty > 0 && newIssueQty > reqQty) {
                            sap.m.MessageBox.warning(
                                "Issue quantity (" + newIssueQty + ") exceeds requested quantity (" + reqQty + ")."
                            );
                        }
                    }
                }
            },

            onAddRow: function () {
                var oView = this.getView();
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                // Find selected rows
                var selectedRows = aData.filter(function (item) {
                    return item.__selected === true;
                });

                // Check if exactly one row is selected
                if (selectedRows.length !== 1) {
                    sap.m.MessageBox.error(
                        "Please select exactly one row to copy.",
                        {
                            title: "Selection Error"
                        }
                    );
                    return;
                }

                var oSelectedRow = selectedRows[0];
                var sSelectedRequestNo = oSelectedRow.requestno;

                // Find all rows with the same request number to determine next item number
                var sameRequestRows = aData.filter(function (item) {
                    return item.requestno === sSelectedRequestNo;
                });

                // Calculate next requestnoitem
                var iNextItem = 1;
                if (sameRequestRows.length > 0) {
                    var maxItem = sameRequestRows.reduce(function (max, item) {
                        var itemNum = parseInt(item.requestnoitem) || 0;
                        return itemNum > max ? itemNum : max;
                    }, 0);
                    iNextItem = maxItem + 1;
                }

                // Create a new row by copying the selected row
                var oNewRow = {
                    // Selection
                    __selected: true,

                    // Hidden / technical fields (reset these)
                    sap_uuid: "",
                    gtsavedstatus: "",
                    materialdocumentno: "",
                    matdocyear: "",

                    // Header fields (copy most, update requestnoitem)
                    requestno: sSelectedRequestNo,
                    requestnoitem: iNextItem.toString(),
                    requestdate: oSelectedRow.requestdate || "",
                    postingdate: oSelectedRow.postingdate || "",
                    requester: oSelectedRow.requester || "",
                    plant: oSelectedRow.plant || "",

                    // Material details (copy these)
                    description: oSelectedRow.description || "",
                    materialcode: oSelectedRow.materialcode || "",
                    uom: oSelectedRow.uom || "",
                    category: oSelectedRow.category || "",

                    // Movement details (copy these)
                    fromplant: oSelectedRow.fromplant || "1200",
                    fromstorageloc: oSelectedRow.fromstorageloc || "",
                    toplant: oSelectedRow.toplant || "1200",
                    tostoragelocation: oSelectedRow.tostoragelocation || "",

                    // Batch-related (copy these)
                    batch: oSelectedRow.batch || "",
                    vendorbatch: oSelectedRow.vendorbatch || "",
                    Batchqty: oSelectedRow.Batchqty || "",
                    isbatchmanagementrequired: oSelectedRow.isbatchmanagementrequired || "",

                    // Quantities (copy containers and request qty, reset issue qty)
                    nocontainers: oSelectedRow.nocontainers || "",
                    reqqty: oSelectedRow.reqqty || "",
                    issueqty: "", // Reset issue quantity for new row

                    // Additional field from your table
                    // Batchqty: ""
                };

                // Unselect the original row (optional)
                // oSelectedRow.__selected = false;

                // Add the new row
                aData.push(oNewRow);
                oModel.setProperty("/Samples", aData);

                // Optionally show success message
                sap.m.MessageToast.show("New row added successfully with Request No Item: " + iNextItem);
            },


            onRemoveRow: function () {
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                var aRowsToKeep = [];
                var bAnyDeleted = false;
                var bAnyBlocked = false;

                aData.forEach(function (row) {
                    if (row.__selected) {
                        if (!row.sap_uuid || row.sap_uuid.trim() === "") {
                            // Deletable row — skip adding to keep list
                            bAnyDeleted = true;
                        } else {
                            // Selected but not deletable — keep it
                            aRowsToKeep.push(row);
                            bAnyBlocked = true;
                        }
                    } else {
                        // Not selected — keep it
                        aRowsToKeep.push(row);
                    }
                });

                oModel.setProperty("/Samples", aRowsToKeep);

                // Show appropriate message
                if (bAnyDeleted && bAnyBlocked) {
                    sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
                } else if (bAnyBlocked && !bAnyDeleted) {
                    sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
                } else if (bAnyDeleted) {
                    sap.m.MessageBox.success("Selected rows removed successfully.");
                } else {
                    sap.m.MessageBox.information("No rows were selected for deletion.");
                }
            },

            onBeforeRendering: function () {
                var oUserInfo = sap.ushell.Container.getService("UserInfo");

                // User ID (e.g. "I123456")
                this.sUserId = oUserInfo.getId();

                // Full name (e.g. "John Doe")
                this.sUserFullName = oUserInfo.getFullName();

                // First name
                this.sUserFirstName = oUserInfo.getFirstName();

                // Last name
                this.sUserLastName = oUserInfo.getLastName();

                // Email address
                this.sUserEmail = oUserInfo.getEmail();

                console.log("User ID:", this.sUserId);
                console.log("Full Name:", this.sUserFullName);
            },


            generateUUID: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            onSavePress: async function () {
                const oView = this.getView();
                const oLocalModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const aData = oLocalModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData) || aData.length === 0) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                // ✅ Check which rows were selected
                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                // ✅ NEW: Check if some selected rows are already saved
                const aAlreadySaved = aSelectedRows.filter(row => row.sap_uuid);

                if (aAlreadySaved.length > 0) {
                    sap.m.MessageBox.warning("Some selected rows are already saved and cannot be saved again.");
                    return;
                }

                // ✅ Mandatory fields validation
                const aInvalidRows = [];
                aSelectedRows.forEach(row => {
                    const missingFields = [];
                    if (!row.materialcode) missingFields.push("Part No");
                    if (!row.reqqty) missingFields.push("Request Quantity");
                    if (!row.uom) missingFields.push("UOM");
                    if (!row.fromplant) missingFields.push("From Plant");
                    if (!row.toplant) missingFields.push("To Plant");

                    if (missingFields.length > 0) {
                        const rowIndex = aData.indexOf(row) + 1;
                        aInvalidRows.push(`Row ${rowIndex}: ${missingFields.join(", ")}`);
                    }
                });

                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error(
                        "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
                    );
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {
                    // ✅ POST each selected entry to ZC_STOCK_TRANSFER_GT
                    const aPromises = aSelectedRows.map((row) => {
                        // Prepare payload with existing data
                        const oPayload = {
                            sap_uuid: this.generateUUID(),
                            // requestdate: new Date(), // You might want to get this from a field
                            requestdate: row.requestdate ? new Date(row.requestdate.toLocaleDateString('en-CA')) : null,
                            postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                            requester: this.sUserFullName || "",
                            plant: row.fromplant,
                            requestno: row.requestno || "", // Use existing if available
                            requestnoitem: row.requestnoitem || "", // Use existing if available
                            materialcode: row.materialcode,
                            isbatchmanagementrequired: String(row.isbatchmanagementrequired || "false"),
                            description: row.description || "",
                            reqqty: row.reqqty !== null && row.reqqty !== undefined
                                ? Number(row.reqqty).toFixed(3)
                                : null,
                            issueqty: row.issueqty ? String(row.issueqty) : null,
                            uom: row.uom,
                            fromplant: row.fromplant,
                            fromstorageloc: row.fromstorageloc || "",
                            toplant: row.toplant,
                            tostoragelocation: row.tostoragelocation || "",
                            batch: row.batch || "",
                            vendorbatch: row.vendorbatch || "",
                            Batchqty: row.Batchqty || "",
                            nocontainers: row.nocontainers || "",
                            category: row.category || "",
                            screenname: "STOCK_TRANSFER",
                            screencode: "ST01",
                            gtsavedstatus: "GT",
                            requestedby: this.sUserId,
                            createdat: new Date(),
                            createdby: this.sUserId,
                        };

                        return new Promise((resolve, reject) => {
                            oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
                                success: function (data) {
                                    console.log("Successfully created:", data);
                                    resolve(data);
                                },
                                error: function (err) {
                                    console.error("Failed to create:", err);
                                    reject(err);
                                }
                            });
                        });
                    });

                    const results = await Promise.allSettled(aPromises);

                    const aFailed = results.filter(r => r.status === "rejected");
                    if (aFailed.length > 0) {
                        console.error("Failed creations:", aFailed);
                        sap.ui.core.BusyIndicator.hide();

                        const errorMessages = aFailed.map((failed, index) =>
                            `Item ${index + 1}: ${failed.reason?.message || 'Unknown error'}`
                        ).join('\n');

                        sap.m.MessageBox.error(`${aFailed.length} row(s) failed to save. Errors:\n${errorMessages}`);
                        return;
                    }

                    sap.ui.core.BusyIndicator.hide();

                    // ✅ Update local model after successful save
                    const aUpdatedData = oLocalModel.getProperty("/Samples");
                    aUpdatedData.forEach(row => {
                        if (row.__selected) {
                            row.gtsavedstatus = "GT";
                            row.__selected = false; // Clear selection
                        }
                    });
                    oLocalModel.setProperty("/Samples", aUpdatedData);

                    sap.m.MessageToast.show(`Successfully saved ${aSelectedRows.length} row(s)!`);

                    // Optional: Refresh table or clear data
                    // this.refreshTableAfterSave();
                    this.GoStockPostTableOpen();

                } catch (error) {
                    sap.ui.core.BusyIndicator.hide();
                    console.error("Error in onSavePress:", error);
                    sap.m.MessageBox.error("Failed to save data: " + error.message);
                }
            },




            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }

                const aSavedRows = aSelectedRows.filter(item => item.sap_uuid);

                if (aSavedRows.length === 0) {
                    sap.m.MessageBox.warning("No saved rows selected for update. Please save the row first");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {

                    const sKey = oODataModel.createKey("/ZC_STOCK_TRANSFER_GT", {
                        sap_uuid: item.sap_uuid,
                    });

                    // Prepare payload with only editable fields
                    const oPayload = {
                        // confirmedqty: String(parseInt(item.confirmedqty)),
                        // scrapqty: String(parseInt(item.scrapqty)),

                        // confirmedqty: String(item.confirmedqty),
                        // scrapqty: String(item.scrapqty),
                        postingdate: item.postingdate ? new Date(item.postingdate.toLocaleDateString('en-CA')) : null,
                        updatestatusgistatus: "GT",
                        batch: item.batch,
                        vendorbatch: item.vendorbatch,
                        Batchqty: item.Batchqty,
                        issueqty: item.issueqty ? String(item.issueqty) : null,
                    };

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);
                    oTabModel.refresh(true);
                    // this.GoMixingActual()
                });
            },


            onSaveOrUpdatePress: async function () {
                const oView = this.getView();
                const oLocalModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const aData = oLocalModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData) || aData.length === 0) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                // Get selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                // Separate into new (to save) and existing (to update)
                const aToSave = aSelectedRows.filter(row => !row.sap_uuid);
                const aToUpdate = aSelectedRows.filter(row => row.sap_uuid);

                // Validate new rows (mandatory fields)
                if (aToSave.length > 0) {
                    const aInvalidRows = [];
                    aToSave.forEach(row => {
                        const missingFields = [];
                        if (!row.materialcode) missingFields.push("Part No");
                        if (!row.reqqty) missingFields.push("Request Quantity");
                        if (!row.uom) missingFields.push("UOM");
                        if (!row.fromplant) missingFields.push("From Plant");
                        if (!row.toplant) missingFields.push("To Plant");

                        if (missingFields.length > 0) {
                            const rowIndex = aData.indexOf(row) + 1;
                            aInvalidRows.push(`Row ${rowIndex}: ${missingFields.join(", ")}`);
                        }
                    });

                    if (aInvalidRows.length > 0) {
                        sap.m.MessageBox.error(
                            "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
                        );
                        return;
                    }
                }

                // If no rows to process (shouldn't happen because selected > 0)
                if (aToSave.length === 0 && aToUpdate.length === 0) {
                    sap.m.MessageBox.warning("No rows to save or update.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {
                    // Prepare promises for save
                    const savePromises = aToSave.map(row => {
                        const oPayload = {
                            sap_uuid: this.generateUUID(),
                            requestdate: row.requestdate ? new Date(row.requestdate.toLocaleDateString('en-CA')) : null,
                            postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                            requester: this.sUserFullName || "",
                            plant: row.fromplant,
                            requestno: row.requestno || "",
                            requestnoitem: row.requestnoitem || "",
                            materialcode: row.materialcode,
                            isbatchmanagementrequired: String(row.isbatchmanagementrequired || "false"),
                            description: row.description || "",
                            reqqty: row.reqqty !== null && row.reqqty !== undefined
                                ? Number(row.reqqty).toFixed(3)
                                : null,
                            issueqty: row.issueqty ? String(row.issueqty) : null,
                            uom: row.uom,
                            fromplant: row.fromplant,
                            fromstorageloc: row.fromstorageloc || "",
                            toplant: row.toplant,
                            tostoragelocation: row.tostoragelocation || "",
                            batch: row.batch || "",
                            vendorbatch: row.vendorbatch || "",
                            Batchqty: row.Batchqty || "",
                            nocontainers: row.nocontainers || "",
                            category: row.category || "",
                            screenname: "STOCK_TRANSFER",
                            screencode: "ST01",
                            gtsavedstatus: "GT",
                            requestedby: this.sUserId,
                            createdat: new Date(),
                            createdby: this.sUserId,
                        };

                        return new Promise((resolve, reject) => {
                            oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });
                    });

                    // Prepare promises for update
                    const updatePromises = aToUpdate.map(row => {
                        const sKey = oODataModel.createKey("/ZC_STOCK_TRANSFER_GT", {
                            sap_uuid: row.sap_uuid,
                        });

                        const oPayload = {
                            postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                            updatestatusgistatus: "GT",
                            batch: row.batch,
                            vendorbatch: String(row.vendorbatch),
                            Batchqty: row.Batchqty,
                            issueqty: row.issueqty ? String(row.issueqty) : null,
                        };

                        return new Promise((resolve, reject) => {
                            oODataModel.update(sKey, oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });
                    });

                    // Combine all promises
                    const allPromises = [...savePromises, ...updatePromises];
                    const results = await Promise.allSettled(allPromises);

                    // Count successes and failures
                    const succeeded = results.filter(r => r.status === "fulfilled").length;
                    const failed = results.filter(r => r.status === "rejected").length;

                    // Update local model: clear selection for all processed rows
                    const aUpdatedData = oLocalModel.getProperty("/Samples");
                    aUpdatedData.forEach(row => {
                        if (row.__selected) {
                            // For saved rows, set status; for updated, status may already be GT
                            if (!row.sap_uuid) {
                                // This row was saved, set status (though not strictly needed for UI)
                                row.gtsavedstatus = "GT";
                            }
                            row.__selected = false;
                        }
                    });
                    oLocalModel.setProperty("/Samples", aUpdatedData);

                    sap.ui.core.BusyIndicator.hide();

                    // Show result message
                    let message = `${succeeded} row(s) processed successfully.`;
                    if (failed > 0) {
                        message += `\n${failed} row(s) failed. Check console for details.`;
                        // Optionally list errors
                        const errors = results
                            .filter(r => r.status === "rejected")
                            .map((r, idx) => `Error ${idx + 1}: ${r.reason?.message || 'Unknown'}`)
                            .join('\n');
                        console.error("Failed operations:\n", errors);
                        sap.m.MessageBox.error(message);
                    } else {
                        sap.m.MessageBox.success(message);
                    }

                    // Optional: refresh table or navigate
                    this.GoStockPostTableOpen(); // or this.GoMixingActual() depending on context
                } catch (error) {
                    sap.ui.core.BusyIndicator.hide();
                    console.error("Unexpected error in onSaveOrUpdatePress:", error);
                    sap.m.MessageBox.error("An unexpected error occurred: " + error.message);
                }
            },







            onDeletePress: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const oTabModel = oView.getModel("TabModel");
                const aData = oTabModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData)) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to delete.");
                    return;
                }
                if (aSelectedRows.some(row => !row.sap_uuid)) {
                    sap.m.MessageBox.warning("Row not saved to delete.");
                    return;
                }



                sap.m.MessageBox.confirm(
                    `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
                    {
                        title: "Confirm Deletion",
                        actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (oAction) {
                            if (oAction !== sap.m.MessageBox.Action.OK) return;

                            sap.ui.core.BusyIndicator.show(0);

                            const aDeletePromises = aSelectedRows.map(row => {
                                return new Promise((resolve, reject) => {
                                    if (!row.sap_uuid) {
                                        reject("Missing sap_uuid for deletion.");
                                        return;
                                    }

                                    const sKeyPath = `/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`;

                                    oModel.remove(sKeyPath, {
                                        success: resolve,
                                        error: reject
                                    });
                                });
                            });

                            Promise.allSettled(aDeletePromises).then(results => {
                                sap.ui.core.BusyIndicator.hide();

                                const aFailed = results.filter(r => r.status === "rejected");
                                const aSuccess = results.filter(r => r.status === "fulfilled");

                                // Remove deleted rows from TabModel local data
                                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                                oTabModel.setProperty("/Samples", aRemainingData);

                                if (aSuccess.length > 0) {
                                    sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                                }

                                if (aFailed.length > 0) {
                                    sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                                    console.error("Deletion errors:", aFailed);
                                }
                            });
                        }
                    }
                );
            },



            // BATCH FRAGMENRT


            onBatchFragmentOpen: function (oEvent) {
                this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
                var oView = this.getView();
                var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
                var oRow = oCtx.getObject();

                // 🟩 Ensure material is selected first
                if (!oRow.materialcode) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    return;
                }

                // 🟩 Ensure Plant is selected if required
                if (!oRow.fromplant && !oRow.toplant) {
                    sap.m.MessageBox.information("Please select a Plant first.");
                    return;
                }
                // 🟩 Ensure Storage Location is selected if available
                if (!oRow.fromstorageloc) {
                    sap.m.MessageBox.information("Please select a Storage Location first.");
                    return;
                }

                // Lazy-load fragment
                if (!this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
                        this
                    );
                    oView.addDependent(this._oStockTransferBatchDialog);
                }

                // Load data before opening - using material, plant and storage location from current row
                this._loadStockTransferBatchData(oRow.materialcode, oRow.fromplant, oRow.fromstorageloc);
            },



            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     const oBatchModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB");
            //     const oStockModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }

            //     this._oBusyDialog.open();

            //     // Build filters for both services
            //     const aBatchFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     const aStockFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant)
            //     ];

            //     // Read from both OData services
            //     Promise.all([
            //         new Promise((resolve, reject) => {
            //             oBatchModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
            //                 filters: aBatchFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         }),
            //         new Promise((resolve, reject) => {
            //             oStockModel.read("/ZC_STOCK_BATCH", {
            //                 filters: aStockFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         })
            //     ]).then(function (results) {
            //         that._oBusyDialog.close();

            //         const oBatchData = results[0];
            //         const oStockData = results[1];

            //         console.log("✅ Batch data received:", oBatchData);
            //         console.log("✅ Stock data received:", oStockData);

            //         // Create a map of ALL properties from stock data keyed by Batch
            //         const oStockDataMap = {};
            //         oStockData.results.forEach(function (item) {
            //             if (item.Batch) {
            //                 // Store all properties from stock data for this batch
            //                 oStockDataMap[item.Batch] = {
            //                     ...item, // Spread all properties from stock data item
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             }
            //         });

            //         // 🛠 FILTER MANUALLY BY STORAGE LOCATION (Backend not filtering)
            //         const aFilteredBatchData = oBatchData.results.filter(function (batchItem) {
            //             return batchItem.StorageLocation === sStorageLoc;
            //         });

            //         console.log("🔍 Filtered batch data (Frontend Filter Applied):", aFilteredBatchData);

            //         // Merge batch data with ALL stock data properties
            //         const aMergedBatches = aFilteredBatchData.map(function (batchItem) {
            //             const stockItem = oStockDataMap[batchItem.Batch] || {};
            //             return {
            //                 ...batchItem,  // Batch data properties
            //                 ...stockItem   // Stock data properties (will override batch data if same property names)
            //             };
            //         });

            //         // Create JSON model from merged data
            //         const oJSONModel = new sap.ui.model.json.JSONModel({
            //             Batches: aMergedBatches
            //         });

            //         // Set model to the fragment dialog
            //         that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //         console.log("✅ Bound rows with merged data:", oJSONModel.getData());

            //         // Debug: Check if BatchBySupplier is in the merged data
            //         console.log("🔍 Sample merged item:", aMergedBatches.length > 0 ? aMergedBatches[0] : "No data");
            //         if (aMergedBatches.length > 0) {
            //             console.log("🔍 BatchBySupplier value in merged data:", aMergedBatches[0].BatchBySupplier);
            //         }

            //         // Open the dialog
            //         that._oStockTransferBatchDialog.open();

            //     }).catch(function (oError) {
            //         that._oBusyDialog.close();
            //         sap.m.MessageToast.show("Failed to load batch data.");
            //         console.error("❌ OData Error:", oError);
            //     });
            // },
            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     // Use the new single OData model
            //     const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }
            //     this._oBusyDialog.open();

            //     // Build filters for the new service (property names: Product, Plant, StorageLocation)
            //     const aFilters = [
            //         new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     // Read from the new entity set "/ZC_STOCK_BATCH_F4"
            //     oBatchModel.read("/ZC_STOCK_BATCH_F4", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             that._oBusyDialog.close();

            //             console.log("✅ Batch/Stock data received:", oData);

            //             // The response contains an array 'results'
            //             const aRawData = oData.results || [];

            //             // Prepare merged data (no merging needed, but map Supplier -> BatchBySupplier)
            //             const aMergedBatches = aRawData.map(function (item) {
            //                 return {
            //                     ...item,                           // keep all original fields
            //                     BatchBySupplier: item.Supplier || "",  // map Supplier to BatchBySupplier for fragment compatibility
            //                     // Ensure ShelfLifeExpirationDate is a Date object (if needed for sorting)
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             });

            //             // Create JSON model
            //             const oJSONModel = new sap.ui.model.json.JSONModel({
            //                 Batches: aMergedBatches
            //             });

            //             // Set model on the dialog
            //             that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //             console.log("✅ Bound rows with data:", oJSONModel.getData());

            //             // Open dialog
            //             that._oStockTransferBatchDialog.open();
            //         },
            //         error: function (oError) {
            //             that._oBusyDialog.close();
            //             sap.m.MessageToast.show("Failed to load batch data.");
            //             console.error("❌ OData Error:", oError);
            //         }
            //     });
            // },
            _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
    const oView = this.getView();
    const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
    const that = this;

    if (!this._oBusyDialog) {
        this._oBusyDialog = new sap.m.BusyDialog({
            text: "Loading batches...",
            title: "Please wait"
        });
    }
    this._oBusyDialog.open();

    const aFilters = [
        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
    ];

    oBatchModel.read("/ZC_STOCK_BATCH_F4", {
        filters: aFilters,
        success: function (oData) {
            that._oBusyDialog.close();

            console.log("✅ Batch/Stock data received:", oData);

            const aRawData = oData.results || [];

            // 🔁 Deduplicate by Batch (keep first occurrence)
            const uniqueMap = new Map();
            for (const item of aRawData) {
                if (!uniqueMap.has(item.Batch)) {
                    // Map fields for fragment compatibility
                    const mappedItem = {
                        ...item,
                        Material: item.Product || "",               // for column "Material"
                        BatchBySupplier: item.Supplier || "",       // for column "BatchBySupplier"
                        ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
                            new Date(item.ShelfLifeExpirationDate) : null
                    };
                    uniqueMap.set(item.Batch, mappedItem);
                }
            }

            // Convert map values back to array
            const aUniqueBatches = Array.from(uniqueMap.values());

            console.log(`✅ Deduplicated: ${aRawData.length} → ${aUniqueBatches.length} unique batches`);

            const oJSONModel = new sap.ui.model.json.JSONModel({
                Batches: aUniqueBatches
            });

            that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            that._oStockTransferBatchDialog.open();
        },
        error: function (oError) {
            that._oBusyDialog.close();
            sap.m.MessageToast.show("Failed to load batch data.");
            console.error("❌ OData Error:", oError);
        }
    });
},

            // Optional: Add search function for the new field
            onStockTransferBatchSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                var oTable = sap.ui.getCore().byId("idStockTransferBatchTable");
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");

                if (sValue) {
                    var aFilters = [
                        new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Batch", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("ShelfLifeExpirationDate", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            onStockTransferBatchSelected: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oCtx = oSelectedItem.getBindingContext("BatchModel").getObject();

                console.log("✅ Selected batch data:", oCtx);

                // FIX: use the correct source input field variable
                if (this._oBatchInputSource) {
                    var oRowCtx = this._oBatchInputSource.getBindingContext("TabModel");

                    // Update TabModel values
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/batch", oCtx.Batch);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/storagelocation", oCtx.StorageLocation);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/Batchqty", oCtx.MatlWrhsStkQtyInMatlBaseUnit);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/vendorbatch", oCtx.BatchBySupplier || "");

                    // Update the input field UI value
                    this._oBatchInputSource.setValue(oCtx.Batch);

                    console.log("✅ Updated TabModel with batch:", oCtx.Batch, "and storage location:", oCtx.StorageLocation, "and quantity:", oCtx.MatlWrhsStkQtyInMatlBaseUnit);
                }

                // Close dialog
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },



            onStockTransferBatchVHClose: function () {
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },





            // BATCH FRAGMENT END









            onStockTransferRequestNoValueHelp: function (oEvent) {
                this._oInputField = oEvent.getSource();
                var oView = this.getView();

                // Show loading
                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading requests...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                var oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                var that = this;

                // Read OData from ZSB_STOCK_TRANSFER_GT service
                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    urlParameters: {
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        var oSeen = new Set();

                        var aAll = oData.results
                            .map(function (item) {
                                return (item.requestno || "").trim();
                            })
                            .filter(function (requestno) {
                                if (!requestno || oSeen.has(requestno)) {
                                    return false;
                                }
                                oSeen.add(requestno);
                                return true;
                            })
                            // Add sorting here - ascending order
                            .sort(function (a, b) {
                                // Compare as strings for alphanumeric values
                                return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
                            })
                            .map(function (requestno) {
                                return { requestno: requestno };
                            });

                        console.log("Request No Value Help Loaded:", aAll.length, "records");

                        // Create JSON model
                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            Requests: aAll
                        });

                        // Load and configure ValueHelpDialog
                        that.loadFragment({
                            name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferRequestNo"
                        }).then(function (oDialog) {
                            that._oStockTransferRequestNoDialog = oDialog;
                            that.getView().addDependent(oDialog);

                            // Set the model for the dialog
                            oDialog.setModel(oJSONModel, "VHModel");

                            // Configure table binding
                            that._configureRequestNoValueHelpDialogTable(oDialog, aAll);

                            oDialog.open();
                        }).catch(function (oError) {
                            that._oBusyDialog.close();
                            sap.m.MessageToast.show("Error loading value help dialog");
                            console.error(oError);
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Error fetching requests from OData");
                        console.error(oError);
                    }
                });
            },

            _configureRequestNoValueHelpDialogTable: function (oDialog, aData) {
                oDialog.getTableAsync().then(function (oTable) {
                    // Set model for the table
                    var oModel = new sap.ui.model.json.JSONModel({ Requests: aData });
                    oTable.setModel(oModel, "VHModel");

                    if (oTable.setGrowing) {
                        oTable.setGrowing(false);
                    }

                    // For sap.ui.table.Table (Desktop)
                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", {
                            path: "VHModel>/Requests"
                        });

                        // Define columns - only requestno
                        var aColumns = [
                            {
                                label: "Request No",
                                template: new sap.m.Text({ text: "{VHModel>requestno}" })
                            }
                        ];

                        aColumns.forEach(function (oColConfig) {
                            var oColumn = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: oColConfig.label }),
                                template: oColConfig.template,
                                width: "150px"
                            });
                            oTable.addColumn(oColumn);
                        });
                    }

                    // For sap.m.Table (Mobile)
                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", {
                            path: "VHModel>/Requests",
                            template: new sap.m.ColumnListItem({
                                cells: [
                                    new sap.m.Text({ text: "{VHModel>requestno}" })
                                ]
                            })
                        });

                        // Add column
                        oTable.addColumn(new sap.m.Column({
                            header: new sap.m.Label({ text: "Request No" })
                        }));
                    }
                });
            },

            onStockTransferRequestNoFilterSearch: function (oEvent) {
                var sSearchQuery = oEvent.getParameter("searchQuery"),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilterStrings = [];

                // Filter bar values
                aSelectionSet.forEach(function (oControl) {
                    var v = oControl.getValue();
                    if (v) {
                        aFilterStrings.push(`substringof('${v}', ${oControl.getName()})`);
                    }
                });

                // Global search
                if (sSearchQuery) {
                    aFilterStrings.push(
                        "substringof('" + sSearchQuery + "', requestno)"
                    );
                }

                var sFilterQuery = aFilterStrings.join(" and ");

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_GT"); // Use default model or specify your model name
                var that = this;

                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Searching...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    urlParameters: {
                        "$filter": sFilterQuery,
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        // var oJSON = new sap.ui.model.json.JSONModel({ Requests: oData.results });
                        var oSeen = new Set();

                        var aUnique = oData.results
                            .map(function (item) {
                                return (item.requestno || "").trim();
                            })
                            .filter(function (requestno) {
                                if (!requestno || oSeen.has(requestno)) {
                                    return false;
                                }
                                oSeen.add(requestno);
                                return true;
                            })
                            .map(function (requestno) {
                                return { requestno: requestno };
                            });

                        var oJSON = new sap.ui.model.json.JSONModel({ Requests: aUnique });

                        var oDialog = that._oStockTransferRequestNoDialog;
                        oDialog.setModel(oJSON, "VHModel");

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(oJSON, "VHModel");

                            if (oTable.bindRows) {
                                oTable.bindRows("VHModel>/Requests");
                            }
                            if (oTable.bindItems) {
                                oTable.bindItems({
                                    path: "VHModel>/Requests",
                                    template: oTable.getBindingInfo("items").template
                                });
                            }
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        console.error(oError);
                        sap.m.MessageToast.show("Search failed.");
                    }
                });
            },

            onStockTransferRequestNoOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");

                if (aTokens && aTokens.length > 0) {
                    var oSelectedItem = aTokens[0];
                    var sRequestNo = oSelectedItem.getKey();

                    if (this._oInputField) {
                        this._oInputField.setValue(sRequestNo);

                        // Optional: Trigger change event or additional logic
                        this._oInputField.fireChange({
                            value: sRequestNo
                        });
                    }
                }

                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.close();
                }
            },

            onStockTransferRequestNoCancelPress: function () {
                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.close();
                }
            },

            onStockTransferRequestNoAfterClose: function () {
                // Clean up if needed
                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.destroy();
                    this._oStockTransferRequestNoDialog = null;
                }
                this._oInputField = null;
            },








            // onTransferPostPress: function () {

            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TRANSFER_API"); // ✅ API Model
            //     const aData = oView.getModel("TabModel").getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ mandatory validations
            //     const invalid = [];

            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];

            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");
            //         // if (!row.fromplant) missing.push("From Plant");
            //         // if (!row.fromstorage) missing.push("From Storage");
            //         // if (!row.toplant) missing.push("To Plant");
            //         // if (!row.tostorage) missing.push("To Storage");

            //         if (missing.length > 0) {
            //             invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //         }
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Please fill mandatory fields:\n\n" + invalid.join("\n")
            //         );
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aPromises = aSelectedRows.map(row => {

            //         const payload = {

            //             // =============================
            //             // REQUIRED KEYS
            //             // =============================
            //             // materialdocument: "", // returned after posting
            //             // matdocyear: new Date().getFullYear().toString(),
            //             // id: this.generateUUID(), // must be unique
            //             // =============================

            //             postingdate: new Date(),
            //             goodsmovementcode: "04",         // Standard posting
            //             goodsmovementtype: "311",        // Stock Transfer

            //             material: row.materialcode,
            //             quantityinentryunit:row.quantity,
            //             entryunit: row.uom,
            //             // uom: row.uom,

            //             plant: row.plant,
            //             storagelocation: row.fromstorage,

            //             issuingorreceivingstorageloc: row.tostorage,

            //             batch: row.batch,
            //             errorresponse: ""
            //         };

            //         console.log("Transfer API Payload:", payload);

            //         return new Promise((resolve, reject) => {
            //             oDataModel.create("/ZC_STOCK_TRANSFER_API", payload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });

            //     });

            //     Promise.allSettled(aPromises).then(results => {

            //         sap.ui.core.BusyIndicator.hide();

            //         const failed = results.filter(r => r.status === "rejected");

            //         if (failed.length > 0) {
            //             sap.m.MessageBox.error(
            //                 `${failed.length} row(s) failed to post to transfer API.`
            //             );
            //         } else {
            //             sap.m.MessageBox.success(
            //                 "Stock Transfer posted successfully!",
            //                 {
            //                     onClose: () => this._refreshMixingTable()
            //                 }
            //             );
            //         }

            //     });

            // },


            // onTransferPostPress: function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TRANSFER_API"); // ✅ API Model
            //     const aData = oView.getModel("TabModel").getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ mandatory validations
            //     const invalid = [];

            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];

            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");

            //         if (missing.length > 0) {
            //             invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //         }
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Please fill mandatory fields:\n\n" + invalid.join("\n")
            //         );
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aPromises = aSelectedRows.map(row => {
            //         const payload = {
            //             postingdate: new Date(),
            //             goodsmovementcode: "04",     // Standard posting
            //             goodsmovementtype: "311",    // Stock Transfer
            //             material: row.materialcode,
            //             quantityinentryunit: row.quantity,
            //             entryunit: row.uom,
            //             plant: row.plant,
            //             storagelocation: row.fromstorgaeloc,
            //             issuingorreceivingstorageloc: row.tostoragelocation,
            //             batch: row.batch,
            //             errorresponse: ""
            //         };

            //         console.log("📦 Transfer API Payload:", payload);

            //         return new Promise((resolve, reject) => {
            //             oDataModel.create("/ZC_STOCK_TRANSFER_API", payload, {
            //                 success: function (oResponse) {
            //                     console.log("✅ Transfer API Success:", oResponse);
            //                     resolve(oResponse);
            //                 },
            //                 error: function (oError) {
            //                     console.error("❌ Transfer API Error:", oError);
            //                     reject(oError);
            //                 }
            //             });
            //         });
            //     });

            //     Promise.allSettled(aPromises).then(results => {
            //         sap.ui.core.BusyIndicator.hide();

            //         console.log("📊 All Transfer Post Results:", results);
            //     });
            // },



            // onTransferPostPress: function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TRANSFER_API"); // ✅ API Model
            //     const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // ✅ API Model
            //     const aData = oView.getModel("TabModel").getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }



            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     // ✅ mandatory validations
            //     const invalid = [];

            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];

            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");

            //         if (missing.length > 0) {
            //             invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //         }
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Please fill mandatory fields:\n\n" + invalid.join("\n")
            //         );
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aPromises = aSelectedRows.map(row => {
            //         const payload = {
            //             postingdate: new Date(),
            //             goodsmovementcode: "04",     // Standard posting
            //             goodsmovementtype: "311",    // Stock Transfer
            //             material: row.materialcode,
            //             quantityinentryunit: row.quantity,
            //             entryunit: row.uom,
            //             plant: row.plant,
            //             storagelocation: row.fromstorgaeloc,
            //             issuingorreceivingstorageloc: row.tostoragelocation,
            //             batch: row.batch,
            //             errorresponse: ""
            //         };

            //         console.log("📦 Transfer API Payload:", payload);

            //         return new Promise((resolve, reject) => {
            //             oDataModel.create("/ZC_STOCK_TRANSFER_API", payload, {
            //                 success: (oResponse) => {
            //                     console.log("✅ Transfer API Success:", oResponse);

            //                     const oTabModel = oView.getModel("TabModel");
            //                     const aSamples = oTabModel.getProperty("/Samples");

            //                     // Find row based on sap_uuid
            //                     const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);

            //                     if (iIndex !== -1) {
            //                         // ✅ update table visible fields
            //                         aSamples[iIndex].materialdocumentno = oResponse.materialdocument;
            //                         aSamples[iIndex].matdocyear = oResponse.matdocyear;
            //                         aSamples[iIndex].postedstatus = "Y";   // optional

            //                         oTabModel.refresh(true);
            //                     }

            //                     // ✅ Backend PATCH update persist fields
            //                     const oUpdatePayload = {
            //                         materialdocumentno: oResponse.materialdocument,
            //                         matdocyear: oResponse.matdocyear
            //                     };

            //                     // update OData entity based on SAP UUID
            //                     oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
            //                         success: () => console.log("✅ GT Table Updated Successfully"),
            //                         error: (err) => console.error("❌ Error Updating GT Entity", err)
            //                     });

            //                     resolve(oResponse);
            //                 },

            //                 error: function (oError) {
            //                     console.error("❌ Transfer API Error:", oError);
            //                     reject(oError);
            //                 }
            //             });
            //         });
            //     });

            //     Promise.allSettled(aPromises).then(results => {
            //         sap.ui.core.BusyIndicator.hide();

            //         console.log("📊 All Transfer Post Results:", results);
            //     });
            // },



            // onTransferPostPress: function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TRANSFER_API"); // ✅ API Model
            //     const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // ✅ GT Model
            //     const aData = oView.getModel("TabModel").getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ prevent already posted
            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     // ✅ mandatory validations
            //     const invalid = [];
            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];
            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");

            //         if (missing.length > 0) {
            //             invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //         }
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aPromises = aSelectedRows.map((row, idx) => {
            //         const payload = {
            //             postingdate: new Date(),
            //             goodsmovementcode: "04",
            //             goodsmovementtype: "311",
            //             material: row.materialcode,
            //             quantityinentryunit: row.quantity,
            //             entryunit: row.uom,
            //             plant: row.plant,
            //             storagelocation: row.fromstorgaeloc,
            //             issuingorreceivingstorageloc: row.tostoragelocation,
            //             batch: row.batch,
            //             errorresponse: ""
            //         };

            //         console.log("📦 Transfer API Payload:", payload);

            //         return new Promise((resolve) => {
            //             oDataModel.create("/ZC_STOCK_TRANSFER_API", payload, {
            //                 success: (oResponse) => {
            //                     console.log("✅ Transfer API Success:", oResponse);

            //                     const oTabModel = oView.getModel("TabModel");
            //                     const aSamples = oTabModel.getProperty("/Samples");

            //                     // Find row by UUID
            //                     const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);

            //                     if (iIndex !== -1 && oResponse.materialdocument) {
            //                         // ✅ update visible table fields
            //                         aSamples[iIndex].materialdocumentno = oResponse.materialdocument;
            //                         aSamples[iIndex].matdocyear = oResponse.matdocyear;
            //                         aSamples[iIndex].postedstatus = "Y";
            //                         oTabModel.refresh(true);

            //                         // ✅ persist update to backend
            //                         const oUpdatePayload = {
            //                             materialdocumentno: oResponse.materialdocument,
            //                             matdocyear: oResponse.matdocyear
            //                         };
            //                         oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
            //                             success: () => console.log("✅ GT Table Updated Successfully"),
            //                             error: (err) => console.error("❌ Error Updating GT Entity", err)
            //                         });
            //                     }

            //                     // ✅ detect backend errorresponse string
            //                     let sError = "";
            //                     if (oResponse.errorresponse) {
            //                         try {
            //                             const errObj = JSON.parse(oResponse.errorresponse);
            //                             sError = errObj?.error?.message?.value || "Unknown Error";
            //                         } catch (e) {
            //                             sError = oResponse.errorresponse;
            //                         }
            //                     }

            //                     resolve({
            //                         index: idx + 1,
            //                         success: !!oResponse.materialdocument,
            //                         error: sError
            //                     });
            //                 },

            //                 error: (oError) => {
            //                     console.error("❌ Transfer API Error:", oError);
            //                     let sErrorMsg = "Unknown error";
            //                     try {
            //                         const oErr = JSON.parse(oError.responseText);
            //                         sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
            //                     } catch (e) {
            //                         // fallback
            //                     }

            //                     resolve({
            //                         index: idx + 1,
            //                         success: false,
            //                         error: sErrorMsg
            //                     });
            //                 }
            //             });
            //         });
            //     });

            //     Promise.allSettled(aPromises).then(results => {
            //         sap.ui.core.BusyIndicator.hide();

            //         console.log("📊 All Transfer Post Results:", results);

            //         // ✅ collect errors only
            //         const aFailed = results
            //             .map(r => r.value)
            //             .filter(r => !r.success);

            //         if (aFailed.length > 0) {
            //             const sMsg = aFailed
            //                 .map(f => `Row ${f.index} - ${f.error}`)
            //                 .join("\n");

            //             sap.m.MessageBox.error("The following line items failed to post:\n\n" + sMsg);
            //         } else {
            //             sap.m.MessageBox.success("All selected line items posted successfully.");
            //         }
            //     });
            // },



            // simgle line used till yesterday

            // onTransferPostPress: async function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TRANSFER_API"); // ✅ API Model
            //     const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // ✅ GT Model
            //     const oTabModel = oView.getModel("TabModel");
            //     const aData = oTabModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ prevent already posted
            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     // ✅ mandatory validations
            //     const invalid = [];
            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];
            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");

            //         if (missing.length > 0) {
            //             invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //         }
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
            //         return;
            //     }

            //     // ✅ Start posting
            //     sap.ui.core.BusyIndicator.show(0);

            //     const aResults = [];

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];

            //         const payload = {
            //             postingdate: new Date(),
            //             goodsmovementcode: "04",
            //             goodsmovementtype: "311",
            //             material: row.materialcode,
            //             quantityinentryunit: row.quantity,
            //             entryunit: row.uom,
            //             plant: row.plant,
            //             storagelocation: row.fromstorageloc,
            //             issuingorreceivingstorageloc: row.tostoragelocation,
            //             batch: row.batch,
            //             errorresponse: ""
            //         };

            //         console.log(`📦 [${i + 1}/${aSelectedRows.length}] Posting payload:`, payload);

            //         // ✅ Sequential post (await one before next)
            //         const result = await new Promise((resolve) => {
            //             oDataModel.create("/ZC_STOCK_TRANSFER_API", payload, {
            //                 success: (oResponse) => {
            //                     console.log("✅ Transfer API Success:", oResponse);

            //                     // find and update the corresponding row in TabModel
            //                     const aSamples = oTabModel.getProperty("/Samples");
            //                     const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);

            //                     if (iIndex !== -1 && oResponse.materialdocument) {
            //                         aSamples[iIndex].materialdocumentno = oResponse.materialdocument;
            //                         aSamples[iIndex].matdocyear = oResponse.matdocyear;
            //                         aSamples[iIndex].postedstatus = "Y";
            //                         oTabModel.refresh(true);

            //                         // ✅ Update GT entity
            //                         const oUpdatePayload = {
            //                             materialdocumentno: oResponse.materialdocument,
            //                             matdocyear: oResponse.matdocyear
            //                         };
            //                         oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
            //                             success: () => console.log("✅ GT Table Updated Successfully"),
            //                             error: (err) => console.error("❌ Error Updating GT Entity", err)
            //                         });
            //                     }

            //                     // ✅ Detect backend errorresponse string
            //                     let sError = "";
            //                     if (oResponse.errorresponse) {
            //                         try {
            //                             const errObj = JSON.parse(oResponse.errorresponse);
            //                             sError = errObj?.error?.message?.value || "Unknown Error";
            //                         } catch (e) {
            //                             sError = oResponse.errorresponse;
            //                         }
            //                     }

            //                     resolve({
            //                         index: i + 1,
            //                         success: !!oResponse.materialdocument,
            //                         error: sError
            //                     });
            //                 },

            //                 error: (oError) => {
            //                     console.error("❌ Transfer API Error:", oError);
            //                     let sErrorMsg = "Unknown error";
            //                     try {
            //                         const oErr = JSON.parse(oError.responseText);
            //                         sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
            //                     } catch (e) {}
            //                     resolve({
            //                         index: i + 1,
            //                         success: false,
            //                         error: sErrorMsg
            //                     });
            //                 }
            //             });
            //         });

            //         aResults.push(result);
            //     }

            //     sap.ui.core.BusyIndicator.hide();

            //     console.log("📊 All Transfer Post Results:", aResults);

            //     // ✅ Show summary result
            //     const aFailed = aResults.filter(r => !r.success);
            //     if (aFailed.length > 0) {
            //         const sMsg = aFailed.map(f => `Row ${f.index} - ${f.error}`).join("\n");
            //         sap.m.MessageBox.error("The following line items failed to post:\n\n" + sMsg);
            //     } else {
            //         sap.m.MessageBox.success("All selected line items posted successfully.");
            //     }
            // },


            // onTransferPostPress: async function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TR_HDITM_API"); // Main OData model
            //     const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // GT model for updating
            //     const oTabModel = oView.getModel("TabModel");
            //     const aData = oTabModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ Selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ Prevent already posted items
            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     // ✅ Mandatory field validation
            //     const invalid = [];
            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];
            //         if (!row.materialcode) missing.push("Material");
            //         if (!row.quantity) missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");
            //         if (!row.plant) missing.push("Plant");
            //         if (!row.fromstorageloc) missing.push("From Storage Location");
            //         if (!row.tostoragelocation) missing.push("To Storage Location");
            //         if (missing.length > 0) invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
            //         return;
            //     }

            //     // ✅ Build deep insert payload (Header + multiple Items)
            //     const sPostingDate = new Date();//.toISOString().split("T")[0]; // YYYY-MM-DD
            //     const sGoodsMovementCode = "04"; // Transfer
            //     const sGoodsMovementType = "311";

            //     const oHeaderPayload = {
            //         Postingdate: sPostingDate,
            //         Goodsmovementcode: sGoodsMovementCode,
            //         Response: "",
            //         Errorresponse: "",
            //         toitem: aSelectedRows.map(row => ({
            //             Material: row.materialcode,
            //             Quantityinentryunit: row.quantity,
            //             Entryunit: row.uom,
            //             Uom: row.uom,
            //             Plant: row.plant,
            //             Storagelocation: row.fromstorageloc,
            //             Issuingorreceivingstorageloc: row.tostoragelocation,
            //             Batch: row.batch,
            //             Goodsmovementtype: sGoodsMovementType,
            //             postingdate: sPostingDate,
            //             goodsmovementcode: sGoodsMovementCode
            //         }))
            //     };

            //     console.log("📦 Final Deep Payload:", oHeaderPayload);

            //     sap.ui.core.BusyIndicator.show(0);

            //     // ✅ Deep insert (header with multiple items)
            //     oDataModel.create("/header", oHeaderPayload, {
            //         success: (oResponse) => {
            //             console.log("✅ Stock Transfer Success:", oResponse);
            //             sap.ui.core.BusyIndicator.hide();

            //             const aSamples = oTabModel.getProperty("/Samples");

            //             // If backend returns items with doc numbers
            //             if (oResponse.toitem && Array.isArray(oResponse.toitem.results)) {
            //                 oResponse.toitem.results.forEach(result => {
            //                     const iIndex = aSamples.findIndex(item => 
            //                         item.materialcode === result.Material &&
            //                         item.quantity === result.Quantityinentryunit
            //                     );
            //                     if (iIndex !== -1) {
            //                         aSamples[iIndex].materialdocumentno = oResponse.Materialdocument;
            //                         aSamples[iIndex].matdocyear = oResponse.Matdocyear;
            //                         aSamples[iIndex].postedstatus = "Y";

            //                         const oUpdatePayload = {
            //                             materialdocumentno: oResponse.Materialdocument,
            //                             matdocyear: oResponse.Matdocyear
            //                         };

            //                         // ✅ Update local GT table
            //                         oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${aSamples[iIndex].sap_uuid}')`, oUpdatePayload, {
            //                             success: () => console.log("✅ GT Table Updated Successfully"),
            //                             error: (err) => console.error("❌ Error Updating GT Entity", err)
            //                         });
            //                     }
            //                 });
            //                 oTabModel.refresh(true);
            //             }

            //             sap.m.MessageBox.success("All selected line items posted successfully.");
            //         },
            //         error: (oError) => {
            //             console.error("❌ Stock Transfer Error:", oError);
            //             sap.ui.core.BusyIndicator.hide();

            //             let sErrorMsg = "Unknown error";
            //             try {
            //                 const oErr = JSON.parse(oError.responseText);
            //                 sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
            //             } catch (e) { }
            //             sap.m.MessageBox.error("Stock transfer posting failed:\n\n" + sErrorMsg);
            //         }
            //     });
            // }






            // latest version

            // onTransferPostPress: async function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_STOCK_TR_HDITM_API"); // Main OData model
            //     const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // GT model for updating
            //     const oTabModel = oView.getModel("TabModel");
            //     const aData = oTabModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     // ✅ Selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ Prevent already posted items
            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     // ✅ Mandatory field validation
            //     const invalid = [];
            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];
            //         if (!row.materialcode) missing.push("Material");
            //         // if (!row.reqqty) missing.push("Request Quantity");
            //         // if (!row.issueqty) missing.push("Issue Quantity");
            //         if (row.reqqty === "" || row.reqqty == null || row.reqqty == "0.000") missing.push("Request Quantity");
            //         if (row.issueqty === "" || row.issueqty == null || row.issueqty == "0.000") missing.push("Issue Quantity");
            //         if (row.postingdate === "" || row.postingdate == null) missing.push("Posting Date");


            //         if (!row.uom) missing.push("Unit");
            //         if (!row.plant) missing.push("Plant");
            //         // if (!row.batch) missing.push("Batch");
            //         if (!row.fromstorageloc) missing.push("From Storage Location");
            //         if (!row.tostoragelocation) missing.push("To Storage Location");
            //         if (missing.length > 0) invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
            //         return;
            //     }


            //     // ✅ Ensure all selected rows have the same requestno
            //     const aUniqueRequestNos = [...new Set(aSelectedRows.map(r => r.requestno))];
            //     if (aUniqueRequestNos.length !== 1) {
            //         sap.m.MessageBox.error("All selected rows must have the same Request No to post together.");
            //         return;
            //     }
            //     const sRequestNo = aUniqueRequestNos[0];


            //     // new added for posting date:
            //     // ✅ Ensure all selected rows have the same Posting Date
            //     const aPostingDates = aSelectedRows.map(r =>
            //         new Date(r.postingdate).toDateString() // normalize date (ignores time)
            //     );

            //     const sFirstPostingDate = aPostingDates[0];

            //     // Find rows with different posting dates
            //     const aInvalidRows = aSelectedRows
            //         .map((row, index) => ({
            //             index: index + 1, // table row number (1-based)
            //             postingdate: row.postingdate
            //         }))
            //         .filter((row, idx) => aPostingDates[idx] !== sFirstPostingDate);

            //     if (aInvalidRows.length > 0) {
            //         const sErrorDetails = aInvalidRows
            //             .map(r => `Row ${r.index} (Posting Date: ${r.postingdate})`)
            //             .join("\n");

            //         sap.m.MessageBox.error(
            //             `All selected rows must have the same Posting Date.\n\nMismatch found in:\n${sErrorDetails}`
            //         );
            //         return;
            //     }



            //     // 🔹 Sort the selected rows in the same sequence as the table
            //     // First by requestdate (ascending), then by requestno (ascending), then by requestnoitem (ascending)
            //     aSelectedRows.sort((a, b) => {
            //         // Sort by requestdate (ascending)
            //         const dateA = new Date(a.requestdate);
            //         const dateB = new Date(b.requestdate);

            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;

            //         // If dates are equal, sort by requestno (ascending)
            //         const reqNoA = a.requestno || "";
            //         const reqNoB = b.requestno || "";
            //         if (reqNoA < reqNoB) return -1;
            //         if (reqNoA > reqNoB) return 1;

            //         // If request numbers are equal, sort by requestnoitem (ascending)
            //         const itemA = a.requestnoitem || "";
            //         const itemB = b.requestnoitem || "";
            //         if (itemA < itemB) return -1;
            //         if (itemA > itemB) return 1;

            //         return 0;
            //     });


            //     // ✅ Build deep insert payload (Header + multiple Items)
            //     // const sPostingDate = new Date(); // backend expects Edm.DateTime
            //     const sPostingDate = new Date(aSelectedRows[0].postingdate);



            //     const sGoodsMovementCode = "04"; // Transfer
            //     const sGoodsMovementType = "311";

            //     const oHeaderPayload = {
            //         // Postingdate: sPostingDate,
            //         Postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,

            //         Goodsmovementcode: sGoodsMovementCode,
            //         MaterialDocumentHeaderText: sRequestNo,
            //         Response: "",
            //         Errorresponse: "",
            //         toitem: aSelectedRows.map(row => ({
            //             Material: row.materialcode,
            //             Quantityinentryunit: row.issueqty,
            //             Entryunit: row.uom,
            //             Uom: row.uom,
            //             Plant: row.plant,
            //             Storagelocation: row.fromstorageloc,
            //             Issuingorreceivingstorageloc: row.tostoragelocation,
            //             Batch: row.batch,
            //             Goodsmovementtype: sGoodsMovementType,
            //             // postingdate: sPostingDate,
            //             Postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,
            //             goodsmovementcode: sGoodsMovementCode
            //         }))
            //     };

            //     console.log("📦 Final Deep Payload:", oHeaderPayload);

            //     sap.ui.core.BusyIndicator.show(0);

            //     // ✅ Deep insert (header with multiple items)
            //     oDataModel.create("/header", oHeaderPayload, {
            //         success: (oResponse) => {
            //             console.log("✅ Stock Transfer Success:", oResponse);
            //             sap.ui.core.BusyIndicator.hide();

            //             // Extract the material doc number and year
            //             const sMatDoc = oResponse.Materialdocument;
            //             const sMatYear = oResponse.Matdocyear;

            //             if (!sMatDoc || !sMatYear) {
            //                 sap.m.MessageBox.error("No Material Document returned from backend.");
            //                 return;
            //             }

            //             // ✅ Update all selected rows in the table
            //             const aSamples = oTabModel.getProperty("/Samples");
            //             aSelectedRows.forEach(row => {
            //                 const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);
            //                 if (iIndex !== -1) {
            //                     aSamples[iIndex].materialdocumentno = sMatDoc;
            //                     aSamples[iIndex].matdocyear = sMatYear;
            //                     // aSamples[iIndex].postedstatus = "Y";

            //                     // ✅ Update GT entity table as well
            //                     const oUpdatePayload = {
            //                         materialdocumentno: sMatDoc,
            //                         matdocyear: sMatYear,
            //                         batch: row.batch,
            //                         vendorbatch: row.vendorbatch,
            //                         issueqty: row.issueqty

            //                         // issueqty: row.issueqty ? String(row.issueqty),
            //                         // batch: row.batch

            //                     };
            //                     oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
            //                         success: () => console.log(`✅ GT Updated for ${row.sap_uuid}`),
            //                         error: (err) => console.error("❌ GT Update Error:", err)
            //                     });
            //                 }
            //             });

            //             oTabModel.refresh(true);

            //             sap.m.MessageBox.success(
            //                 `All selected line items posted successfully.\n\nMaterial Document: ${sMatDoc}\nYear: ${sMatYear}`
            //             );
            //         },
            //         error: (oError) => {
            //             console.error("❌ Stock Transfer Error:", oError);
            //             sap.ui.core.BusyIndicator.hide();

            //             let sErrorMsg = "Unknown error";
            //             try {
            //                 const oErr = JSON.parse(oError.responseText);
            //                 sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
            //             } catch (e) { }
            //             sap.m.MessageBox.error("Stock transfer posting failed:\n\n" + sErrorMsg);
            //         }
            //     });
            // },


            onTransferPostPress: async function () {
                const oView = this.getView();
                const oDataModel = oView.getModel("ZSB_STOCK_TR_HDITM_API"); // Main OData model
                const oUpdateModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // GT model for updating
                const oTabModel = oView.getModel("TabModel");
                const aData = oTabModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.error("No data available in the table.");
                    return;
                }

                // ✅ Selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                // const aSavedRows = aSelectedRows.filter(item => item.sap_uuid);

                // if (aSavedRows.length === 0) {
                //     sap.m.MessageBox.warning("No saved rows selected for update. Please save the row first");
                //     return;
                // }
                // Check that ALL selected rows are saved (have sap_uuid)
                const aUnsavedRows = aSelectedRows.filter(item => !item.sap_uuid);

                if (aUnsavedRows.length > 0) {
                    sap.m.MessageBox.warning("Some selected rows are not saved. Please save all selected rows.");
                    return;
                }


                // ✅ Prevent already posted items
                const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
                if (aAlreadyPosted.length > 0) {
                    const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
                    sap.m.MessageBox.warning(
                        `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
                    );
                    return;
                }

                // ✅ Mandatory field validation
                const invalid = [];
                aSelectedRows.forEach((row, idx) => {
                    const missing = [];
                    if (!row.materialcode) missing.push("Material");
                    if (row.reqqty === "" || row.reqqty == null || row.reqqty == "0.000") missing.push("Request Quantity");
                    if (row.issueqty === "" || row.issueqty == null || row.issueqty == "0.000") missing.push("Issue Quantity");
                    if (row.postingdate === "" || row.postingdate == null) missing.push("Posting Date");
                    if (!row.uom) missing.push("Unit");
                    if (!row.plant) missing.push("Plant");
                    if (!row.fromstorageloc) missing.push("From Storage Location");
                    if (!row.tostoragelocation) missing.push("To Storage Location");
                    if (missing.length > 0) invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
                });

                if (invalid.length > 0) {
                    sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
                    return;
                }

                // 🔹 Sort the selected rows in the same sequence as the table
                // First by requestdate (ascending), then by requestno (ascending), then by requestnoitem (ascending)
                aSelectedRows.sort((a, b) => {
                    // Sort by requestdate (ascending)
                    const dateA = new Date(a.requestdate);
                    const dateB = new Date(b.requestdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by requestno (ascending)
                    const reqNoA = a.requestno || "";
                    const reqNoB = b.requestno || "";
                    if (reqNoA < reqNoB) return -1;
                    if (reqNoA > reqNoB) return 1;

                    // If request numbers are equal, sort by requestnoitem (ascending)
                    const itemA = a.requestnoitem || "";
                    const itemB = b.requestnoitem || "";
                    if (itemA < itemB) return -1;
                    if (itemA > itemB) return 1;

                    return 0;
                });

                // 🔹 Group selected rows by request number
                const groupedByRequestNo = {};
                aSelectedRows.forEach(row => {
                    const requestNo = row.requestno;
                    if (!groupedByRequestNo[requestNo]) {
                        groupedByRequestNo[requestNo] = [];
                    }
                    groupedByRequestNo[requestNo].push(row);
                });

                // 🔹 Get all unique request numbers
                const aUniqueRequestNos = Object.keys(groupedByRequestNo);

                // Remove the validation that requires all rows to have the same request number
                // (we're now allowing multiple request numbers to be posted)

                // ✅ For each request number, ensure all rows within that request have the same Posting Date
                for (const requestNo of aUniqueRequestNos) {
                    const rows = groupedByRequestNo[requestNo];
                    const aPostingDates = rows.map(r =>
                        new Date(r.postingdate).toDateString()
                    );
                    const sFirstPostingDate = aPostingDates[0];
                    const aInvalidRows = rows
                        .map((row, index) => ({
                            index: index + 1,
                            postingdate: row.postingdate
                        }))
                        .filter((row, idx) => aPostingDates[idx] !== sFirstPostingDate);

                    if (aInvalidRows.length > 0) {
                        const sErrorDetails = aInvalidRows
                            .map(r => `Row ${r.index} (Posting Date: ${r.postingdate})`)
                            .join("\n");
                        sap.m.MessageBox.error(
                            `All selected rows for Request No ${requestNo} must have the same Posting Date.\n\nMismatch found in:\n${sErrorDetails}`
                        );
                        return;
                    }
                }

                // 🔹 Function to post a single request number
                // const postSingleRequest = (requestNo, rows) => {
                //     return new Promise((resolve, reject) => {
                //         // Get posting date from the first row of this request
                //         const sPostingDate = new Date(rows[0].postingdate);
                //         const sGoodsMovementCode = "04"; // Transfer
                //         const sGoodsMovementType = "311";

                //         const oHeaderPayload = {
                //             Postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,
                //             Goodsmovementcode: sGoodsMovementCode,
                //             MaterialDocumentHeaderText: requestNo,
                //             Response: "",
                //             Errorresponse: "",
                //             toitem: rows.map(row => ({
                //                 Material: row.materialcode,
                //                 Quantityinentryunit: row.issueqty,
                //                 Entryunit: row.uom,
                //                 Uom: row.uom,
                //                 Plant: row.plant,
                //                 Storagelocation: row.fromstorageloc,
                //                 Issuingorreceivingstorageloc: row.tostoragelocation,
                //                 Batch: row.batch,
                //                 Goodsmovementtype: sGoodsMovementType,
                //                 postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,
                //                 goodsmovementcode: sGoodsMovementCode
                //             }))
                //         };

                //         console.log(`📦 Posting Request No: ${requestNo}`, oHeaderPayload);

                //         oDataModel.create("/header", oHeaderPayload, {
                //             success: (oResponse) => {
                //                 console.log(`✅ Request ${requestNo} Success:`, oResponse);

                //                 const sMatDoc = oResponse.Materialdocument;
                //                 const sMatYear = oResponse.Matdocyear;

                //                 if (!sMatDoc || !sMatYear) {
                //                     reject(new Error(`No Material Document returned for Request No ${requestNo}`));
                //                     return;
                //                 }

                //                 // ✅ Update rows in the table model
                //                 const aSamples = oTabModel.getProperty("/Samples");
                //                 rows.forEach(row => {
                //                     const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);
                //                     if (iIndex !== -1) {
                //                         aSamples[iIndex].materialdocumentno = sMatDoc;
                //                         aSamples[iIndex].matdocyear = sMatYear;
                //                     }
                //                 });
                //                 oTabModel.setProperty("/Samples", aSamples);

                //                 // ✅ Update GT entity table
                //                 const updatePromises = rows.map(row => {
                //                     return new Promise((resolveUpdate, rejectUpdate) => {
                //                         const oUpdatePayload = {
                //                             materialdocumentno: sMatDoc,
                //                             matdocyear: sMatYear,
                //                             batch: row.batch,
                //                             vendorbatch: row.vendorbatch,
                //                             postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                //                             issueqty: row.issueqty
                //                         };
                //                         oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
                //                             success: () => {
                //                                 console.log(`✅ GT Updated for ${row.sap_uuid}`);
                //                                 resolveUpdate();
                //                             },
                //                             error: (err) => {
                //                                 console.error("❌ GT Update Error:", err);
                //                                 resolveUpdate(); // Continue even if GT update fails
                //                             }
                //                         });
                //                     });
                //                 });

                //                 Promise.all(updatePromises).then(() => {
                //                     resolve({
                //                         requestNo: requestNo,
                //                         matDoc: sMatDoc,
                //                         matYear: sMatYear,
                //                         rowCount: rows.length
                //                     });
                //                 });
                //             },
                //             error: (oError) => {
                //                 console.error(`❌ Request ${requestNo} Error:`, oError);
                //                 let sErrorMsg = "Unknown error";
                //                 try {
                //                     const oErr = JSON.parse(oError.responseText);
                //                     sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
                //                 } catch (e) { }
                //                 reject(new Error(`Stock transfer posting failed for Request No ${requestNo}:\n${sErrorMsg}`));
                //             }
                //         });
                //     });
                // };
                const postSingleRequest = (requestNo, rows) => {
                    return new Promise((resolve, reject) => {
                        const sPostingDate = new Date(rows[0].postingdate);
                        const sGoodsMovementCode = "04";
                        const sGoodsMovementType = "311";

                        const oHeaderPayload = {
                            Postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,
                            Goodsmovementcode: sGoodsMovementCode,
                            MaterialDocumentHeaderText: requestNo,
                            Response: "",
                            Errorresponse: "",
                            toitem: rows.map(row => ({
                                Material: row.materialcode,
                                Quantityinentryunit: row.issueqty,
                                Entryunit: row.uom,
                                Uom: row.uom,
                                Plant: row.plant,
                                Storagelocation: row.fromstorageloc,
                                Issuingorreceivingstorageloc: row.tostoragelocation,
                                Batch: row.batch,
                                Goodsmovementtype: sGoodsMovementType,
                                postingdate: sPostingDate ? new Date(sPostingDate.toLocaleDateString('en-CA')) : null,
                                goodsmovementcode: sGoodsMovementCode
                            }))
                        };

                        console.log(`📦 Posting Request No: ${requestNo}`, oHeaderPayload);

                        oDataModel.create("/header", oHeaderPayload, {
                            success: (oResponse) => {
                                console.log(`📥 Response for ${requestNo}:`, oResponse);

                                // 🔥 CRITICAL: Check for business error inside success response
                                // The error could be in oResponse.error (string) or oResponse.Errorresponse
                                let errorObj = null;
                                if (oResponse.error && typeof oResponse.error === "string") {
                                    try {
                                        errorObj = JSON.parse(oResponse.error);
                                    } catch (e) { }
                                } else if (oResponse.Errorresponse && typeof oResponse.Errorresponse === "string") {
                                    try {
                                        errorObj = JSON.parse(oResponse.Errorresponse);
                                    } catch (e) { }
                                } else if (oResponse.error && typeof oResponse.error === "object") {
                                    errorObj = oResponse.error;
                                }

                                // If an error object exists, extract deficiency messages
                                if (errorObj && errorObj.error) {
                                    const details = errorObj.error?.innererror?.errordetails;
                                    let deficitMessages = [];
                                    if (details && Array.isArray(details)) {
                                        deficitMessages = details
                                            .filter(d => d.code === "M7/021")
                                            .map(d => d.message)
                                            .filter(msg => msg && msg.trim() !== "");
                                    }
                                    if (deficitMessages.length > 0) {
                                        const errorText = deficitMessages.join("\n");
                                        reject(new Error(`${errorText}`));
                                    } else {
                                        const genericMsg = errorObj.error?.message?.value || "Material Document processing failed";
                                        reject(new Error(genericMsg));
                                    }
                                    return;
                                }

                                // Normal success path
                                const sMatDoc = oResponse.Materialdocument;
                                const sMatYear = oResponse.Matdocyear;

                                if (!sMatDoc || !sMatYear || sMatYear === "0000") {
                                    reject(new Error(`No valid Material Document returned for Request No ${requestNo}`));
                                    return;
                                }

                                // Update table model
                                const aSamples = oTabModel.getProperty("/Samples");
                                rows.forEach(row => {
                                    const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);
                                    if (iIndex !== -1) {
                                        aSamples[iIndex].materialdocumentno = sMatDoc;
                                        aSamples[iIndex].matdocyear = sMatYear;
                                    }
                                });
                                oTabModel.setProperty("/Samples", aSamples);

                                // Update GT entity
                                const updatePromises = rows.map(row => {
                                    return new Promise((resolveUpdate) => {
                                        const oUpdatePayload = {
                                            materialdocumentno: sMatDoc,
                                            matdocyear: sMatYear,
                                            batch: row.batch,
                                            vendorbatch: row.vendorbatch,
                                            postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                                            issueqty: row.issueqty
                                        };
                                        oUpdateModel.update(`/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
                                            success: () => {
                                                console.log(`✅ GT Updated for ${row.sap_uuid}`);
                                                resolveUpdate();
                                            },
                                            error: (err) => {
                                                console.error("❌ GT Update Error:", err);
                                                resolveUpdate();
                                            }
                                        });
                                    });
                                });

                                Promise.all(updatePromises).then(() => {
                                    resolve({
                                        requestNo: requestNo,
                                        matDoc: sMatDoc,
                                        matYear: sMatYear,
                                        rowCount: rows.length
                                    });
                                });
                            },
                            error: (oError) => {
                                // HTTP-level error (e.g., 500, 404)
                                console.error(`❌ HTTP Error for ${requestNo}:`, oError);
                                let sErrorMsg = "Unknown error";
                                try {
                                    const oErr = JSON.parse(oError.responseText);
                                    const details = oErr?.error?.innererror?.errordetails;
                                    if (details && Array.isArray(details)) {
                                        const deficitMessages = details
                                            .filter(d => d.code === "M7/021")
                                            .map(d => d.message)
                                            .filter(msg => msg && msg.trim() !== "");
                                        if (deficitMessages.length > 0) {
                                            sErrorMsg = deficitMessages.join("\n");
                                        } else {
                                            sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
                                        }
                                    } else {
                                        sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
                                    }
                                } catch (e) { }
                                reject(new Error(sErrorMsg));
                            }
                        });
                    });
                };

                // ✅ Sequential posting of each request number
                sap.ui.core.BusyIndicator.show(0);

                const results = [];
                let hasError = false;
                let errorMessage = "";

                try {
                    for (let i = 0; i < aUniqueRequestNos.length; i++) {
                        const requestNo = aUniqueRequestNos[i];
                        const rows = groupedByRequestNo[requestNo];

                        // Show progress
                        sap.m.MessageToast.show(`Posting Request No: ${requestNo} (${i + 1}/${aUniqueRequestNos.length})`);

                        try {
                            const result = await postSingleRequest(requestNo, rows);
                            results.push(result);

                            // Small delay between posts (optional)
                            if (i < aUniqueRequestNos.length - 1) {
                                await new Promise(resolve => setTimeout(resolve, 500));
                            }
                        } catch (error) {
                            hasError = true;
                            errorMessage = error.message;
                            break; // Stop further processing on error
                        }
                    }

                    sap.ui.core.BusyIndicator.hide();

                    if (hasError) {
                        sap.m.MessageBox.error(errorMessage);
                        // Refresh table to show any partially updated data
                        oTabModel.refresh(true);
                    } else {
                        // ✅ All posts successful
                        oTabModel.refresh(true);

                        // Show success message with details
                        let successMessage = `All selected request numbers posted successfully.\n\n`;

                        if (results.length === 1) {
                            // Single request number
                            successMessage += `Material Document: ${results[0].matDoc}\n`;
                            successMessage += `Year: ${results[0].matYear}\n`;
                            successMessage += `Line Items: ${results[0].rowCount}`;
                        } else {
                            // Multiple request numbers
                            successMessage += `Total Request Numbers: ${results.length}\n\n`;
                            results.forEach((result, index) => {
                                successMessage += `Request No ${result.requestNo}:\n`;
                                successMessage += `  Material Document: ${result.matDoc}\n`;
                                successMessage += `  Line Items: ${result.rowCount}\n\n`;
                            });
                        }

                        sap.m.MessageBox.success(successMessage);

                    }
                } catch (error) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageBox.error("An unexpected error occurred: " + error.message);
                    oTabModel.refresh(true);
                }
            },





        });
    });