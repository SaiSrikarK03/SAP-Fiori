sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",

        "bando/util/importfile/importexcelfile",
        "bando/util/pdf-lib/pdf-lib.min"
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, importexcelfile, PDFLibjs) {
        "use strict";

        return BaseController.extend("bando.controller.stock_transfer.stock_transfer_request", {



            // "bando/util/jspdf/html2canvasmin",
            // "bando/util/jspdf/jspdfmin",

            // onInit: function () {
            //     // Create and set local table model
            //     var TabModel = new sap.ui.model.json.JSONModel({
            //         Samples: []
            //     });
            //     this.getView().setModel(TabModel, "TabModel");

            //     // Create and set select-all model
            //     var Tab_SelectAll = new sap.ui.model.json.JSONModel({
            //         Samples: {
            //             selectall: false
            //         }
            //     });
            //     this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");

            //     // Removed route-matched logic
            // },


            onInit: function () {


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("stock_transfer_request").attachMatched(this._onRouteMatched, this);

            },

            _onRouteMatched: function () {
                // Clear filters
                // this.byId("idDateRange").setDateValue(null);
                // this.byId("idDateRange").setSecondDateValue(null);
                // this.byId("idPlant").setValue("");
                // this.byId("idMaterial").setValue("");
                // this.byId("idProductGroup").setValue("");

                // Optionally: clear or re-fetch table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);
                this.HeaderModel = new sap.ui.model.json.JSONModel({

                    HeaderData: {
                        idRequestDate: "",
                        idRequester: "",
                        idPlant: "",
                        idRequestNo: "",
                        // idPostedStatus: "",

                    }
                })

                this.getView().setModel(this.HeaderModel, "HeaderModel");
            },


            // onBeforeRendering: function () {
            //     var oUserInfo = sap.ushell.Container.getService("UserInfo");
            //     this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
            // },



            onBeforeRendering: function () {
                var oUserInfo = sap.ushell.Container.getService("UserInfo");

                // User ID (e.g. "I123456")
                this.sUserId = oUserInfo.getId();

                // Full name (e.g. "John Doe")
                this.sUserFullName = oUserInfo.getFullName();

                // First name
                this.sUserFirstName = oUserInfo.getFirstName();

                // Last name
                this.sUserLastName = oUserInfo.getLastName();

                // Email address
                this.sUserEmail = oUserInfo.getEmail();

                console.log("User ID:", this.sUserId);
                console.log("Full Name:", this.sUserFullName);
            },





            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },









            GoStockReqTableOpen: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // OData model
                const oTabModel = oView.getModel("TabModel");     // Local model

                // Get header values
                const oRequestDate = oView.byId("idRequestDate").getDateValue();
                const oRequester = oView.byId("idRequester").getValue().trim();
                const oPlant = oView.byId("idPlant").getValue().trim();
                const oRequestNo = oView.byId("idRequestNo").getValue().trim();
                // const oPostedStatus = oView.byId("idPostedStatus").getSelectedKey();
                // const oMaterialDocNo = oView.byId("idMaterialDocNo").getValue().trim();
                // && !oMaterialDocNo

                // Validate: at least one filter required
                if (!oRequestDate && !oRequester && !oPlant && !oRequestNo) {//&& !oPostedStatus
                    sap.m.MessageBox.error("Please enter at least one filter criteria.");
                    return;
                }

                const aFilters = [];

                // Format date
                if (oRequestDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    const sReqDate = oDateFormat.format(oRequestDate);

                    aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.EQ, sReqDate));
                }

                if (oRequester) {
                    aFilters.push(new sap.ui.model.Filter("requester", sap.ui.model.FilterOperator.EQ, oRequester));
                }

                if (oPlant) {
                    aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
                }

                // if (oRequestNo) {
                //     aFilters.push(new sap.ui.model.Filter("requestno", sap.ui.model.FilterOperator.EQ, oRequestNo));
                // }
                if (oRequestNo) {
                    // Pad with leading zeros to match 10-digit format
                    const sFormattedReqNo = oRequestNo.padStart(10, '0');
                    aFilters.push(new sap.ui.model.Filter("requestno", sap.ui.model.FilterOperator.EQ, sFormattedReqNo));
                }


                // if (oPostedStatus) {
                //     aFilters.push(new sap.ui.model.Filter("postedstatus", sap.ui.model.FilterOperator.EQ, oPostedStatus));
                // }

                // if (oMaterialDocNo) {
                //     aFilters.push(new sap.ui.model.Filter("materialdocumentno", sap.ui.model.FilterOperator.EQ, oMaterialDocNo));
                // }

                // Show footer
                const oDynamicPage = this.byId("dynamicpageStockRequestScreen");
                if (oDynamicPage) {
                    oDynamicPage.setShowFooter(true);
                }

                sap.ui.core.BusyIndicator.show(0);

                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    filters: aFilters,
                    // success: function (oData) {
                    //     sap.ui.core.BusyIndicator.hide();

                    //     // Filter logic if needed
                    //     const aFiltered = oData.results;

                    //     oTabModel.setProperty("/Samples", aFiltered);
                    //     oView.byId("idStockRequestTable").setVisible(true);
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();

                        // Filter out rows that have a materialdocumentno value
                        const aFiltered = oData.results.filter(item => {
                            return !item.materialdocumentno; // keep only rows with empty or null materialdocumentno
                        });

                        oTabModel.setProperty("/Samples", aFiltered);
                        oView.byId("idStockRequestTable").setVisible(true);


                        // Model for select-all checkbox
                        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                            Samples: {
                                selectall: false
                            }
                        });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");

                        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                            Samples: {
                                selectall: false
                            }
                        });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                    }
                });
            },





            onAddRow: function () {
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                // Create a blank row (add fields as required)
                var oNewRow = {
                    sap_uuid: "",
                    materialcode: "",
                    description: "",
                    reqqty: "",
                    issueqty: "",
                    uom: "",
                    fromplant: "1200",
                    fromstorage: "",
                    toplant: "1200",
                    tostorage: "",
                    containers: "",
                    texts: "",
                    __selected: false
                };

                aData.push(oNewRow);
                oModel.setProperty("/Samples", aData);
            },


            onRemoveRow: function () {
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                var aRowsToKeep = [];
                var bAnyDeleted = false;
                var bAnyBlocked = false;

                aData.forEach(function (row) {
                    if (row.__selected) {
                        if (!row.sap_uuid || row.sap_uuid.trim() === "") {
                            // Deletable row — skip adding to keep list
                            bAnyDeleted = true;
                        } else {
                            // Selected but not deletable — keep it
                            aRowsToKeep.push(row);
                            bAnyBlocked = true;
                        }
                    } else {
                        // Not selected — keep it
                        aRowsToKeep.push(row);
                    }
                });

                oModel.setProperty("/Samples", aRowsToKeep);

                // Show appropriate message
                if (bAnyDeleted && bAnyBlocked) {
                    sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
                } else if (bAnyBlocked && !bAnyDeleted) {
                    sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
                } else if (bAnyDeleted) {
                    sap.m.MessageBox.success("Selected rows removed successfully.");
                } else {
                    sap.m.MessageBox.information("No rows were selected for deletion.");
                }
            },









            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },

            onRequestQtyChange: function(oEvent) {
    var oInput = oEvent.getSource();
    var oBindingContext = oInput.getBindingContext("TabModel");
    
    if (!oBindingContext) {
        return;
    }

    // Get the batch quantity from the same row
    var sBatchQtyPath = oBindingContext.getPath() + "/Batchqty";
    var oModel = oInput.getModel("TabModel");
    var nBatchQty = parseFloat(oModel.getProperty(sBatchQtyPath));

    // If batch qty is not a valid number, skip validation
    if (isNaN(nBatchQty)) {
        return;
    }

    // Get the current input value (as string)
    var sCurrentValue = oInput.getValue();
    var nRequestQty = parseFloat(sCurrentValue);

    // If the input is empty or not a number, do nothing
    if (sCurrentValue === "" || isNaN(nRequestQty)) {
        return;
    }

    // If request qty exceeds batch qty, correct it
    if (nRequestQty > nBatchQty) {
        // Option 1: Set the input value to the batch qty (and update the model)
        oInput.setValue(String(nBatchQty));
        oModel.setProperty(oBindingContext.getPath() + "/reqqty", nBatchQty);
        
        // Option 2: Show a warning message (optional)
        sap.m.MessageToast.show("Request quantity cannot exceed batch quantity (" + nBatchQty + ")");
    }
},


onIssueQtyChange: function(oEvent) {
    var oInput = oEvent.getSource();
    var oBindingContext = oInput.getBindingContext("TabModel");
    
    if (!oBindingContext) {
        return;
    }

    var oModel = oInput.getModel("TabModel");
    var sPath = oBindingContext.getPath();

    // --- New: Validate that Request Quantity is filled and valid ---
    var sReqQty = oModel.getProperty(sPath + "/reqqty");
    var nRequestQty = parseFloat(sReqQty);

    // Check if request quantity is missing, empty, not a number, or <= 0
    if (sReqQty === undefined || sReqQty === null || sReqQty === "" || isNaN(nRequestQty) || nRequestQty <= 0) {
        // Clear the issue quantity input and model
        oInput.setValue("");
        oModel.setProperty(sPath + "/issueqty", "");
        sap.m.MessageToast.show("Please fill a valid Request Quantity (greater than 0) before entering Issue Quantity.");
        return;
    }

    // --- Original validation: Issue Quantity cannot exceed Request Quantity ---
    var sCurrentValue = oInput.getValue();
    var nIssueQty = parseFloat(sCurrentValue);

    if (sCurrentValue === "" || isNaN(nIssueQty)) {
        return;
    }

    if (nIssueQty > nRequestQty) {
        oInput.setValue(String(nRequestQty));
        oModel.setProperty(sPath + "/issueqty", nRequestQty);
        sap.m.MessageToast.show("Issue quantity cannot exceed request quantity (" + nRequestQty + ")");
    }
},




            // onImportExl: function () {
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");

            //     // ✅ Helper: Load XLSX library if not loaded yet
            //     function ensureXLSX(callback) {
            //         if (window.XLSX) {
            //             return callback();
            //         }

            //         const script = document.createElement("script");
            //         script.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"; // or your local version
            //         script.onload = callback;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     // ✅ Main import logic
            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);
            //             const workbook = XLSX.read(data, { type: "array" });
            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in Excel file.");
            //                 return;
            //             }

            //             // Map Excel rows to model structure
            //             const aImportedRows = jsonData.map(row => ({
            //                 materialcode: row["Material Code"] || "",
            //                 description: row["Description"] || "",
            //                 reqqty: row["Request Quantity"] || "",
            //                 issueqty: row["Issue Quantity"] || "",
            //                 uom: row["UOM"] || "",
            //                 fromplant: row["From Plant"] || "",
            //                 fromstorageloc: row["From Storage Location"] || "",
            //                 toplant: row["To Plant"] || "",
            //                 tostoragelocation: row["To Storage Location"] || "",
            //                 nocontainers: row["No Containers"] || "",
            //                 // texts: row["Texts"] || "",
            //                 category: row["Category"] || "",
            //                 requestno: row["Request No"] || "",
            //                 __selected: false // default unselected
            //             }));

            //             // ✅ Append imported rows after existing ones
            //             const aExistingRows = oTabModel.getProperty("/Samples") || [];
            //             const aCombined = aExistingRows.concat(aImportedRows);
            //             oTabModel.setProperty("/Samples", aCombined);

            //             sap.m.MessageToast.show(`Imported ${aImportedRows.length} rows successfully.`);
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // ✅ File input setup
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";
            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };
            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },




            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");

            //     // ✅ Helper: Load XLSX library if not loaded yet
            //     function ensureXLSX(callback) {
            //         if (window.XLSX) {
            //             return callback();
            //         }

            //         const script = document.createElement("script");
            //         script.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
            //         script.onload = callback;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     // ✅ Main import logic
            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);
            //             const workbook = XLSX.read(data, { type: "array" });
            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in Excel file.");
            //                 return;
            //             }

            //             // Map Excel rows to model structure
            //             const aImportedRows = jsonData.map(row => ({
            //                 materialcode: row["Material Code"] || "",
            //                 description: row["Description"] || "",
            //                 reqqty: row["Request Quantity"] || "",
            //                 issueqty: row["Issue Quantity"] || "",
            //                 uom: row["UOM"] || "",
            //                 fromplant: row["From Plant"] || "",
            //                 fromstorageloc: row["From Storage Location"] || "",
            //                 toplant: row["To Plant"] || "",
            //                 tostoragelocation: row["To Storage Location"] || "",
            //                 nocontainers: row["No Containers"] || "",
            //                 category: row["Category"] || "",
            //                 requestno: row["Request No"] || "",
            //                 __selected: true // default unselected
            //             }));

            //             // Validate and enrich the imported data
            //             validateAndEnrichStockTransferData(aImportedRows);
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // ✅ Validation and enrichment function
            //     async function validateAndEnrichStockTransferData(aImportedRows) {
            //         const oStockTransferModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //         try {
            //             const aErrors = [];

            //             // 🧠 STEP 1: Gather all unique material codes and descriptions
            //             const aUniqueMaterials = [...new Set(
            //                 aImportedRows
            //                     .map(r => String(r.materialcode || "").trim())
            //                     .filter(Boolean)
            //             )];

            //             const aUniqueDescriptions = [...new Set(
            //                 aImportedRows
            //                     .map(r => String(r.description || "").trim())
            //                     .filter(Boolean)
            //             )];

            //             if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
            //                 sap.m.MessageBox.error("No material data found in the Excel file.");
            //                 return;
            //             }

            //             // 🧠 STEP 2: Build filters for both code and description
            //             const filters = [];
            //             if (aUniqueMaterials.length > 0) {
            //                 filters.push(new sap.ui.model.Filter({
            //                     filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
            //                     and: false
            //                 }));
            //             }
            //             if (aUniqueDescriptions.length > 0) {
            //                 filters.push(new sap.ui.model.Filter({
            //                     filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
            //                     and: false
            //                 }));
            //             }

            //             // 🧠 STEP 3: Fetch stock transfer material data from ZC_STOCK_TRANSFER_F4
            //             const oMaterialResults = await new Promise((resolve, reject) => {
            //                 oStockTransferModel.read("/ZC_STOCK_TRANSFER_F4", {
            //                     filters: filters.length > 0 ? filters : undefined,
            //                     urlParameters: {
            //                         "$top": 9999
            //                     },
            //                     success: data => resolve(data.results || []),
            //                     error: reject
            //                 });
            //             });

            //             // Build lookup maps
            //             const codeToName = {};
            //             const nameToCode = {};
            //             const codeToBaseUnit = {}; // Map for BaseUnit

            //             oMaterialResults.forEach(entry => {
            //                 const code = String(entry.Product || "").trim();
            //                 const name = String(entry.ProductName || "").trim();
            //                 const baseUnit = String(entry.BaseUnit || "").trim();

            //                 if (code) {
            //                     codeToName[code] = name;
            //                     codeToBaseUnit[code] = baseUnit;
            //                 }
            //                 if (name) {
            //                     nameToCode[name] = code;
            //                 }
            //             });

            //             // 🧠 STEP 4: Validate & enrich each row
            //             aImportedRows.forEach((row, idx) => {
            //                 const code = String(row.materialcode || "").trim();
            //                 const desc = String(row.description || "").trim();

            //                 if (!code && !desc) {
            //                     aErrors.push(`Row ${idx + 1}: Material code and description both missing.`);
            //                     return;
            //                 }

            //                 if (code && !desc) {
            //                     // Only material code provided - fetch description
            //                     if (codeToName[code]) {
            //                         row.description = codeToName[code];
            //                         // Also set UOM from BaseUnit if available
            //                         if (codeToBaseUnit[code] && !row.uom) {
            //                             row.uom = codeToBaseUnit[code];
            //                         }
            //                     } else {
            //                         aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
            //                     }
            //                 } else if (!code && desc) {
            //                     // Only description provided - fetch material code
            //                     if (nameToCode[desc]) {
            //                         row.materialcode = nameToCode[desc];
            //                         // Also set UOM from BaseUnit if available
            //                         const foundCode = nameToCode[desc];
            //                         if (codeToBaseUnit[foundCode] && !row.uom) {
            //                             row.uom = codeToBaseUnit[foundCode];
            //                         }
            //                     } else {
            //                         aErrors.push(`Row ${idx + 1}: Description "${desc}" not found in material master.`);
            //                     }
            //                 } else if (code && desc) {
            //                     // Both provided - validate they match
            //                     const validDesc = codeToName[code];
            //                     if (!validDesc) {
            //                         aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
            //                     } else if (validDesc !== desc) {
            //                         aErrors.push(
            //                             `Row ${idx + 1}: Description "${desc}" does not match material "${code}" (expected "${validDesc}").`
            //                         );
            //                     } else {
            //                         // Set UOM from BaseUnit if available and not already set
            //                         if (codeToBaseUnit[code] && !row.uom) {
            //                             row.uom = codeToBaseUnit[code];
            //                         }
            //                     }
            //                 }
            //             });

            //             // 🚫 STEP 5: Show all accumulated errors together
            //             if (aErrors.length > 0) {
            //                 sap.m.MessageBox.error(aErrors.join("\n\n"));
            //                 return;
            //             }

            //             // ✅ STEP 6: Import Validated & Enriched Data
            //             const aExistingRows = oTabModel.getProperty("/Samples") || [];
            //             const aCombined = aExistingRows.concat(aImportedRows);
            //             oTabModel.setProperty("/Samples", aCombined);

            //             sap.m.MessageToast.show(`Imported and validated ${aImportedRows.length} rows successfully.`);

            //         } catch (error) {
            //             console.error("Validation error:", error);
            //             sap.m.MessageBox.error("Validation failed. Please try again.");
            //         }
            //     }

            //     // ✅ File input setup
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";
            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };
            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },

            /**
             * onImportExl
             * 
             * Imports stock transfer data from an Excel file, validates and enriches it using material master data,
             * calculates request quantities based on container conversions, and merges valid rows into the UI model.
             * Shows errors for missing/invalid materials, mismatched descriptions, or conversion failures,
             * and provides success messages for imported rows.
             */

            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //     // ✅ Helper: Load XLSX library if not loaded yet
            //     function ensureXLSX(cb) {
            //         if (window.XLSX) return cb();

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     // ✅ Get material conversion helper (similar to your existing function)
            //     async function getMaterialConversion(sMaterial) {
            //         return new Promise((resolve, reject) => {
            //             const aFilters = [
            //                 new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
            //             ];

            //             sap.ui.core.BusyIndicator.show(0);

            //             oODataModel.read("/ZC_STOCK_CONTAINER", {
            //                 filters: aFilters,
            //                 success: function (oData) {
            //                     sap.ui.core.BusyIndicator.hide();

            //                     const oConv = oData.results.find(
            //                         item => item.AlternativeUnit !== item.BaseUnit
            //                     );

            //                     if (oConv) {
            //                         resolve(oConv);
            //                     } else {
            //                         reject("No valid conversion row found");
            //                     }
            //                 },
            //                 error: function (err) {
            //                     sap.ui.core.BusyIndicator.hide();
            //                     reject(err);
            //                 }
            //             });
            //         });
            //     }

            //     // ✅ Process container conversion for a single row
            //     async function processContainerConversion(row) {
            //         const sMaterial = row.materialcode;
            //         const iContainers = parseFloat(row.nocontainers);

            //         if (!sMaterial || !iContainers || isNaN(iContainers)) {
            //             return; // Skip if no material or invalid containers
            //         }

            //         try {
            //             const oConv = await getMaterialConversion(sMaterial);
            //             const num = parseFloat(oConv.QuantityNumerator);
            //             const den = parseFloat(oConv.QuantityDenominator);
            //             const quantity = iContainers * (num / den);

            //             row.reqqty = quantity; // Update the request quantity
            //             row.conversionApplied = true; // Flag to track successful conversion
            //         } catch (err) {
            //             console.error(`Conversion failed for material ${sMaterial}:`, err);
            //             row.conversionError = `Conversion not found for ${sMaterial}`;
            //             // Keep the original reqqty if conversion fails
            //         }
            //     }


            //     // ✅ Main import logic
            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);
            //             const workbook = XLSX.read(data, { type: "array" });
            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in Excel file.");
            //                 return;
            //             }

            //             // Map Excel rows to model structure
            //             const aImportedRows = jsonData.map(row => ({
            //                 materialcode: row["Material Code"] || "",
            //                 description: row["Description"] || "",
            //                 reqqty: row["Request Quantity"] || "",
            //                 issueqty: row["Issue Quantity"] || "",
            //                 uom: row["UOM"] || "",
            //                 fromplant: row["From Plant"] || "",
            //                 fromstorageloc: row["From Storage Location"] || "",
            //                 toplant: row["To Plant"] || "",
            //                 tostoragelocation: row["To Storage Location"] || "",
            //                 nocontainers: row["No Containers"] || "",
            //                 category: row["Category"] || "",
            //                 requestno: row["Request No"] || "",
            //                 __selected: true, // default selected
            //                 conversionApplied: false, // Track conversion status
            //                 conversionError: "" // Track conversion errors
            //             }));

            //             // Validate and enrich the imported data
            //             validateAndEnrichStockTransferData(aImportedRows);
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // ✅ Validation and enrichment function
            //     async function validateAndEnrichStockTransferData(aImportedRows) {
            //         const oStockTransferModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //         try {
            //             const aErrors = [];
            //             const aConversionPromises = [];

            //             // 🧠 STEP 1: Gather all unique material codes and descriptions
            //             const aUniqueMaterials = [...new Set(
            //                 aImportedRows
            //                     .map(r => String(r.materialcode || "").trim())
            //                     .filter(Boolean)
            //             )];

            //             const aUniqueDescriptions = [...new Set(
            //                 aImportedRows
            //                     .map(r => String(r.description || "").trim())
            //                     .filter(Boolean)
            //             )];

            //             if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
            //                 sap.m.MessageBox.error("No material data found in the Excel file.");
            //                 return;
            //             }

            //             // 🧠 STEP 2: Build filters for both code and description
            //             const filters = [];
            //             if (aUniqueMaterials.length > 0) {
            //                 filters.push(new sap.ui.model.Filter({
            //                     filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
            //                     and: false
            //                 }));
            //             }
            //             if (aUniqueDescriptions.length > 0) {
            //                 filters.push(new sap.ui.model.Filter({
            //                     filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
            //                     and: false
            //                 }));
            //             }

            //             // 🧠 STEP 3: Fetch stock transfer material data from ZC_STOCK_TRANSFER_F4
            //             const oMaterialResults = await new Promise((resolve, reject) => {
            //                 oStockTransferModel.read("/ZC_STOCK_TRANSFER_F4", {
            //                     filters: filters.length > 0 ? filters : undefined,
            //                     urlParameters: {
            //                         "$top": 9999
            //                     },
            //                     success: data => resolve(data.results || []),
            //                     error: reject
            //                 });
            //             });

            //             // Build lookup maps
            //             const codeToName = {};
            //             const nameToCode = {};
            //             const codeToBaseUnit = {}; // Map for BaseUnit

            //             oMaterialResults.forEach(entry => {
            //                 const code = String(entry.Product || "").trim();
            //                 const name = String(entry.ProductName || "").trim();
            //                 const baseUnit = String(entry.BaseUnit || "").trim();

            //                 if (code) {
            //                     codeToName[code] = name;
            //                     codeToBaseUnit[code] = baseUnit;
            //                 }
            //                 if (name) {
            //                     nameToCode[name] = code;
            //                 }
            //             });

            //             // 🧠 STEP 4: Validate & enrich each row
            //             aImportedRows.forEach((row, idx) => {
            //                 const code = String(row.materialcode || "").trim();
            //                 const desc = String(row.description || "").trim();

            //                 if (!code && !desc) {
            //                     aErrors.push(`Row ${idx + 1}: Material code and description both missing.`);
            //                     return;
            //                 }

            //                 if (code && !desc) {
            //                     // Only material code provided - fetch description
            //                     if (codeToName[code]) {
            //                         row.description = codeToName[code];
            //                         // Also set UOM from BaseUnit if available
            //                         if (codeToBaseUnit[code] && !row.uom) {
            //                             row.uom = codeToBaseUnit[code];
            //                         }
            //                     } else {
            //                         aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
            //                     }
            //                 } else if (!code && desc) {
            //                     // Only description provided - fetch material code
            //                     if (nameToCode[desc]) {
            //                         row.materialcode = nameToCode[desc];
            //                         // Also set UOM from BaseUnit if available
            //                         const foundCode = nameToCode[desc];
            //                         if (codeToBaseUnit[foundCode] && !row.uom) {
            //                             row.uom = codeToBaseUnit[foundCode];
            //                         }
            //                     } else {
            //                         aErrors.push(`Row ${idx + 1}: Description "${desc}" not found in material master.`);
            //                     }
            //                 } else if (code && desc) {
            //                     // Both provided - validate they match
            //                     const validDesc = codeToName[code];
            //                     if (!validDesc) {
            //                         aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
            //                     } else if (validDesc !== desc) {
            //                         aErrors.push(
            //                             `Row ${idx + 1}: Description "${desc}" does not match material "${code}" (expected "${validDesc}").`
            //                         );
            //                     } else {
            //                         // Set UOM from BaseUnit if available and not already set
            //                         if (codeToBaseUnit[code] && !row.uom) {
            //                             row.uom = codeToBaseUnit[code];
            //                         }
            //                     }
            //                 }

            //                 // 🧠 STEP 5: Queue container conversion for this row if applicable
            //                 const iContainers = parseFloat(row.nocontainers);
            //                 if (row.materialcode && iContainers && !isNaN(iContainers)) {
            //                     aConversionPromises.push(processContainerConversion(row));
            //                 }
            //             });

            //             // 🧠 STEP 6: Wait for all container conversions to complete
            //             if (aConversionPromises.length > 0) {
            //                 sap.m.MessageToast.show(`Processing container conversions for ${aConversionPromises.length} rows...`);
            //                 await Promise.allSettled(aConversionPromises);
            //             }

            //             // 🧠 STEP 7: Check for conversion errors and successes
            //             const aSuccessfulConversions = aImportedRows.filter(row => row.conversionApplied).length;
            //             const aConversionErrors = aImportedRows.filter(row => row.conversionError);

            //             aConversionErrors.forEach(row => {
            //                 aErrors.push(row.conversionError);
            //             });

            //             // 🚫 STEP 8: Show all accumulated errors together
            //             if (aErrors.length > 0) {
            //                 let errorMessage = aErrors.join("\n\n");
            //                 if (aSuccessfulConversions > 0) {
            //                     errorMessage += `\n\nNote: ${aSuccessfulConversions} rows were successfully processed with container conversions.`;
            //                 }
            //                 sap.m.MessageBox.error(errorMessage);
            //                 if (aSuccessfulConversions === 0) return; // Don't import if all failed
            //             }

            //             // ✅ STEP 9: Import Validated & Enriched Data
            //             const aExistingRows = oTabModel.getProperty("/Samples") || [];
            //             const aCombined = aExistingRows.concat(aImportedRows);
            //             oTabModel.setProperty("/Samples", aCombined);

            //             let successMessage = `Imported and validated ${aImportedRows.length} rows successfully.`;
            //             if (aSuccessfulConversions > 0) {
            //                 successMessage += ` ${aSuccessfulConversions} rows had container conversions applied.`;
            //             }
            //             sap.m.MessageToast.show(successMessage);

            //         } catch (error) {
            //             console.error("Validation error:", error);
            //             sap.m.MessageBox.error("Validation failed. Please try again.");
            //         }
            //     }

            //     // ✅ File input setup
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";
            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };
            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            onImportExl: function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

                // ✅ Helper: Load XLSX library if not loaded yet
                function ensureXLSX(cb) {
                    if (window.XLSX) return cb();

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                // ✅ Get material conversion helper
                async function getMaterialConversion(sMaterial) {
                    return new Promise((resolve, reject) => {
                        const aFilters = [
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
                        ];

                        sap.ui.core.BusyIndicator.show(0);

                        oODataModel.read("/ZC_STOCK_CONTAINER", {
                            filters: aFilters,
                            success: function (oData) {
                                sap.ui.core.BusyIndicator.hide();

                                const oConv = oData.results.find(
                                    item => item.AlternativeUnit !== item.BaseUnit
                                );

                                if (oConv) {
                                    resolve(oConv);
                                } else {
                                    reject("No valid conversion row found");
                                }
                            },
                            error: function (err) {
                                sap.ui.core.BusyIndicator.hide();
                                reject(err);
                            }
                        });
                    });
                }

                // ✅ Process container conversion for a single row
                async function processContainerConversion(row) {
                    const sMaterial = row.materialcode;
                    const iContainers = parseFloat(row.nocontainers);

                    if (!sMaterial || !iContainers || isNaN(iContainers)) {
                        return; // Skip if no material or invalid containers
                    }

                    try {
                        const oConv = await getMaterialConversion(sMaterial);
                        const num = parseFloat(oConv.QuantityNumerator);
                        const den = parseFloat(oConv.QuantityDenominator);
                        const quantity = iContainers * (num / den);

                        row.reqqty = quantity; // Update the request quantity
                        row.conversionApplied = true; // Flag to track successful conversion
                    } catch (err) {
                        console.error(`Conversion failed for material ${sMaterial}:`, err);
                        row.conversionError = sMaterial; // Just store the material code
                        // Keep the original reqqty if conversion fails
                    }
                }


                // ✅ NEW: Fetch batch management field for materials
                async function fetchBatchManagementField(materialCodes) {
                    return new Promise((resolve, reject) => {
                        if (!materialCodes || materialCodes.length === 0) {
                            resolve({});
                            return;
                        }

                        const oStockTransferModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");
                        const filters = materialCodes.map(mat =>
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, mat)
                        );

                        oStockTransferModel.read("/ZC_STOCK_TRANSFER_F4", {
                            filters: [new sap.ui.model.Filter({
                                filters: filters,
                                and: false
                            })],
                            urlParameters: {
                                "$top": 9999
                            },
                            success: function (oData) {
                                // Create a map: material code -> IsBatchManagementRequired
                                const batchManagedMap = {};
                                oData.results.forEach(item => {
                                    const code = String(item.Product || "").trim();
                                    if (code) {
                                        batchManagedMap[code] = item.IsBatchManagementRequired || false;
                                    }
                                });
                                resolve(batchManagedMap);
                            },
                            error: function (err) {
                                reject(err);
                            }
                        });
                    });
                }

                // ✅ Main import logic
                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = new Uint8Array(e.target.result);
                        const workbook = XLSX.read(data, { type: "array" });
                        const sheetName = workbook.SheetNames[0];
                        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in Excel file.");
                            return;
                        }

                        // Map Excel rows to model structure
                        const aImportedRows = jsonData.map(row => ({
                            materialcode: row["Material Code"] || "",
                            description: row["Description"] || "",
                            reqqty: row["Request Quantity"] || "",
                            issueqty: row["Issue Quantity"] || "",
                            uom: row["UOM"] || "",
                            fromplant: row["From Plant"] || "",
                            fromstorageloc: row["From Storage Location"] || "",
                            toplant: row["To Plant"] || "",
                            tostoragelocation: row["To Storage Location"] || "",
                            nocontainers: row["No Containers"] || "",
                            category: row["Category"] || "",
                            requestno: row["Request No"] || "",
                            __selected: true, // default selected
                            conversionApplied: false, // Track conversion status
                            conversionError: "" // Track conversion errors
                        }));

                        // Validate and enrich the imported data
                        validateAndEnrichStockTransferData(aImportedRows);
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsArrayBuffer(file);
                }

                // ✅ Validation and enrichment function
                async function validateAndEnrichStockTransferData(aImportedRows) {
                    const oStockTransferModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

                    try {
                        const aErrors = [];
                        const aConversionPromises = [];

                        // 🧠 STEP 1: Gather all unique material codes and descriptions
                        const aUniqueMaterials = [...new Set(
                            aImportedRows
                                .map(r => String(r.materialcode || "").trim())
                                .filter(Boolean)
                        )];

                        const aUniqueDescriptions = [...new Set(
                            aImportedRows
                                .map(r => String(r.description || "").trim())
                                .filter(Boolean)
                        )];

                        if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
                            sap.m.MessageBox.error("No material data found in the Excel file.");
                            return;
                        }

                        // 🧠 STEP 2: Build filters for both code and description
                        const filters = [];
                        if (aUniqueMaterials.length > 0) {
                            filters.push(new sap.ui.model.Filter({
                                filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
                                and: false
                            }));
                        }
                        if (aUniqueDescriptions.length > 0) {
                            filters.push(new sap.ui.model.Filter({
                                filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
                                and: false
                            }));
                        }

                        // 🧠 STEP 3: Fetch stock transfer material data from ZC_STOCK_TRANSFER_F4
                        const oMaterialResults = await new Promise((resolve, reject) => {
                            oStockTransferModel.read("/ZC_STOCK_TRANSFER_F4", {
                                filters: filters.length > 0 ? filters : undefined,
                                urlParameters: {
                                    "$top": 9999
                                },
                                success: data => resolve(data.results || []),
                                error: reject
                            });
                        });

                        // Build lookup maps
                        const codeToName = {};
                        const nameToCode = {};
                        const codeToBaseUnit = {}; // Map for BaseUnit

                        oMaterialResults.forEach(entry => {
                            const code = String(entry.Product || "").trim();
                            const name = String(entry.ProductName || "").trim();
                            const baseUnit = String(entry.BaseUnit || "").trim();

                            if (code) {
                                codeToName[code] = name;
                                codeToBaseUnit[code] = baseUnit;
                            }
                            if (name) {
                                nameToCode[name] = code;
                            }
                        });

                        // 🧠 STEP 4: Validate & enrich each row (without batch management yet)
                        aImportedRows.forEach((row, idx) => {
                            const code = String(row.materialcode || "").trim();
                            const desc = String(row.description || "").trim();

                            if (!code && !desc) {
                                aErrors.push(`Row ${idx + 1}: Material code and description both missing.`);
                                return;
                            }

                            if (code && !desc) {
                                // Only material code provided - fetch description
                                if (codeToName[code]) {
                                    row.description = codeToName[code];
                                    // Also set UOM from BaseUnit if available
                                    if (codeToBaseUnit[code] && !row.uom) {
                                        row.uom = codeToBaseUnit[code];
                                    }
                                } else {
                                    aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
                                }
                            } else if (!code && desc) {
                                // Only description provided - fetch material code
                                if (nameToCode[desc]) {
                                    row.materialcode = nameToCode[desc];
                                    // Also set UOM from BaseUnit if available
                                    const foundCode = nameToCode[desc];
                                    if (codeToBaseUnit[foundCode] && !row.uom) {
                                        row.uom = codeToBaseUnit[foundCode];
                                    }
                                } else {
                                    aErrors.push(`Row ${idx + 1}: Description "${desc}" not found in material master.`);
                                }
                            } else if (code && desc) {
                                // Both provided - validate they match
                                const validDesc = codeToName[code];
                                if (!validDesc) {
                                    aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
                                } else if (validDesc !== desc) {
                                    aErrors.push(
                                        `Row ${idx + 1}: Description "${desc}" does not match material "${code}" (expected "${validDesc}").`
                                    );
                                } else {
                                    // Set UOM from BaseUnit if available and not already set
                                    if (codeToBaseUnit[code] && !row.uom) {
                                        row.uom = codeToBaseUnit[code];
                                    }
                                }
                            }

                            // 🧠 STEP 5: Queue container conversion for this row if applicable
                            const iContainers = parseFloat(row.nocontainers);
                            if (row.materialcode && iContainers && !isNaN(iContainers)) {
                                aConversionPromises.push(processContainerConversion(row));
                            }
                        });

                        // 🧠 STEP 6: Fetch batch management field for all materials
                        const validMaterialCodes = aImportedRows
                            .map(row => String(row.materialcode || "").trim())
                            .filter(Boolean);

                        const batchManagedMap = await fetchBatchManagementField(validMaterialCodes);

                        // Set batch management field for each row
                        aImportedRows.forEach(row => {
                            const code = String(row.materialcode || "").trim();
                            if (code && batchManagedMap[code] !== undefined) {
                                row.isbatchmanagementrequired = batchManagedMap[code];
                            }
                        });

                        // 🧠 STEP 7: Wait for all container conversions to complete
                        if (aConversionPromises.length > 0) {
                            sap.m.MessageToast.show(`Processing container conversions for ${aConversionPromises.length} rows...`);
                            await Promise.allSettled(aConversionPromises);
                        }

                        // 🧠 STEP 8: Check for conversion errors and successes
                        const aSuccessfulConversions = aImportedRows.filter(row => row.conversionApplied).length;
                        const aFailedConversions = aImportedRows.filter(row => row.conversionError);

                        // Get unique materials with failed conversions
                        const failedMaterials = [...new Set(aFailedConversions.map(row => row.conversionError))];

                        // 🚫 STEP 9: Show validation errors (if any) - but ALWAYS import rows
                        if (aErrors.length > 0) {
                            let errorMessage = "Validation errors:\n\n";
                            errorMessage += aErrors.join("\n");

                            // Add conversion error info if any
                            if (failedMaterials.length > 0) {
                                errorMessage += "\n\nContainer conversion errors:\n";
                                errorMessage += `Conversion not found for: ${failedMaterials.join(", ")}`;
                            }

                            sap.m.MessageBox.error(errorMessage);
                        } else if (failedMaterials.length > 0) {
                            // Only conversion errors, no validation errors
                            let warningMessage = `Import successful! However, container conversions failed for some materials:\n\n`;
                            warningMessage += `Conversion not found for: ${failedMaterials.join(", ")}\n\n`;
                            warningMessage += `${aSuccessfulConversions} rows had container conversions applied successfully.\n`;
                            warningMessage += `${failedMaterials.length} rows imported without container conversions.`;

                            sap.m.MessageBox.warning(warningMessage);
                        }

                        // ✅ STEP 10: ALWAYS Import Data (even with conversion errors)
                        const aExistingRows = oTabModel.getProperty("/Samples") || [];
                        const aCombined = aExistingRows.concat(aImportedRows);
                        oTabModel.setProperty("/Samples", aCombined);

                        // Show success message
                        let successMessage = `Imported ${aImportedRows.length} rows successfully.`;
                        if (aSuccessfulConversions > 0) {
                            successMessage += ` ${aSuccessfulConversions} rows had container conversions applied.`;
                        }
                        if (failedMaterials.length > 0) {
                            successMessage += ` ${failedMaterials.length} rows imported without container conversions.`;
                        }

                        sap.m.MessageToast.show(successMessage);

                    } catch (error) {
                        console.error("Validation error:", error);
                        sap.m.MessageBox.error("Validation failed. Please try again.");
                    }
                }








                // ✅ File input setup
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";
                fileInput.onchange = function (e) {
                    const file = e.target.files[0];
                    if (!file) return;
                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                };
                document.body.appendChild(fileInput);
                fileInput.click();
            },




            onExportExl: function () {
                const oView = this.getView();
                const oTable = oView.byId("idStockRequestTable");
                const oModel = oView.getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows (based on CheckBox binding)
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, otherwise export all
                const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // Define columns exactly matching your table model structure
                const aColumns = [
                    { label: "Material Code", property: "materialcode" },
                    { label: "Description", property: "description" },
                    { label: "Request Quantity", property: "reqqty" },
                    { label: "Issue Quantity", property: "issueqty" },
                    { label: "UOM", property: "uom" },
                    { label: "From Plant", property: "fromplant" },
                    { label: "From Storage Location", property: "fromstorageloc" },
                    { label: "To Plant", property: "toplant" },
                    { label: "To Storage Location", property: "tostoragelocation" },
                    { label: "No Containers", property: "nocontainers" },
                    // { label: "Texts", property: "texts" },
                    // { label: "Category", property: "category" },
                    // { label: "Request No", property: "requestno" }
                ];

                // Create spreadsheet export
                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: { sheetName: "StockRequestItems" }
                    },
                    dataSource: aExportData,
                    fileName: "Stock_Request_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed successfully.");
                    })
                    .catch((oError) => {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },


            // _getMaterialConversion: function (sMaterial) {
            //     const oODataModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

            //     return new Promise((resolve, reject) => {
            //         const aFilters = [
            //             new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
            //         ];

            //         oODataModel.read("/ZC_STOCK_CONTAINER", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 // Pick the row where AlternativeUnit != BaseUnit
            //                 const oConv = oData.results.find(
            //                     item => item.AlternativeUnit !== item.BaseUnit
            //                 );
            //                 if (oConv) {
            //                     resolve(oConv);
            //                 } else {
            //                     reject("No valid conversion row found");
            //                 }
            //             },
            //             error: reject
            //         });
            //     });
            // },
            // onContainerChange: function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oModel = this.getView().getModel("TabModel");
            //     const sPath = oContext.getPath();
            //     const oRow = oModel.getProperty(sPath);
            //     const sMaterial = oRow.materialcode;

            //     if (!sMaterial) {
            //         sap.m.MessageToast.show("Please select a material first.");
            //         return;
            //     }

            //     const iContainers = parseFloat(oRow.nocontainers);
            //     if (isNaN(iContainers)) return;

            //     this._getMaterialConversion(sMaterial)
            //         .then(oConv => {
            //             const num = parseFloat(oConv.QuantityNumerator);
            //             const den = parseFloat(oConv.QuantityDenominator);

            //             // Calculate quantity = containers * (numerator / denominator)
            //             const quantity = iContainers * (num / den);

            //             oModel.setProperty(sPath + "/quantity", quantity);
            //         })
            //         .catch(err => {
            //             console.error(err);
            //             sap.m.MessageToast.show("Conversion not found for " + sMaterial);
            //         });
            // },
            // onQuantityChange: function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oModel = this.getView().getModel("TabModel");
            //     const sPath = oContext.getPath();
            //     const oRow = oModel.getProperty(sPath);
            //     const sMaterial = oRow.materialcode;

            //     if (!sMaterial) {
            //         sap.m.MessageToast.show("Please select a material first.");
            //         return;
            //     }

            //     const iQuantity = parseFloat(oRow.quantity);
            //     if (isNaN(iQuantity)) return;

            //     this._getMaterialConversion(sMaterial)
            //         .then(oConv => {
            //             const num = parseFloat(oConv.QuantityNumerator);
            //             const den = parseFloat(oConv.QuantityDenominator);

            //             // Calculate containers = quantity * (denominator / numerator)
            //             const containers = iQuantity * (den / num);

            //             oModel.setProperty(sPath + "/nocontainers", containers);
            //         })
            //         .catch(err => {
            //             console.error(err);
            //             sap.m.MessageToast.show("Conversion not found for " + sMaterial);
            //         });
            // },




            // onContainerChange: async function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oModel = this.getView().getModel("TabModel");
            //     const sPath = oContext.getPath();
            //     const oRow = oModel.getProperty(sPath);
            //     const sMaterial = oRow.materialcode;

            //     if (!sMaterial) {
            //         sap.m.MessageToast.show("Please select a material first.");
            //         return;
            //     }

            //     // Force latest value from input (sometimes model doesn’t update instantly)
            //     const iContainers = parseFloat(oInput.getValue());
            //     if (isNaN(iContainers)) return;

            //     try {
            //         const oConv = await this._getMaterialConversion(sMaterial);
            //         const num = parseFloat(oConv.QuantityNumerator);
            //         const den = parseFloat(oConv.QuantityDenominator);
            //         const quantity = iContainers * (num / den);

            //         oModel.setProperty(sPath + "/quantity", quantity);
            //     } catch (err) {
            //         console.error(err);
            //         sap.m.MessageToast.show("Conversion not found for " + sMaterial);
            //     }
            // },

            // onQuantityChange: async function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oModel = this.getView().getModel("TabModel");
            //     const sPath = oContext.getPath();
            //     const oRow = oModel.getProperty(sPath);
            //     const sMaterial = oRow.materialcode;

            //     if (!sMaterial) {
            //         sap.m.MessageToast.show("Please select a material first.");
            //         return;
            //     }

            //     const iQuantity = parseFloat(oInput.getValue());
            //     if (isNaN(iQuantity)) return;

            //     try {
            //         const oConv = await this._getMaterialConversion(sMaterial);
            //         const num = parseFloat(oConv.QuantityNumerator);
            //         const den = parseFloat(oConv.QuantityDenominator);
            //         const containers = iQuantity * (den / num);

            //         oModel.setProperty(sPath + "/nocontainers", containers);
            //     } catch (err) {
            //         console.error(err);
            //         sap.m.MessageToast.show("Conversion not found for " + sMaterial);
            //     }
            // },








            // Utility function to generate UUID for new rows

            // generateReqNo: function () {
            //     return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            //         const r = Math.random() * 16 | 0,
            //             v = c === 'x' ? r : (r & 0x3 | 0x8);
            //         return v.toString(16);
            //     });
            // },

            // generateReqNo: function () {
            //     // Generates a 4-digit random number, always 4 digits (e.g. 0372, 5821)
            //     return Math.floor(1000 + Math.random() * 9000).toString();
            // },

            // onSavePress: async function () {
            //     const oView = this.getView();
            //     const oLocalModel = oView.getModel("TabModel");
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");

            //     const aData = oLocalModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available.");
            //         return;
            //     }

            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // Mandatory fields check (your existing code)...

            //     sap.ui.core.BusyIndicator.show(0);

            //     // ✅ Generate sequential request number
            //     let RequestorNumber;
            //     try {
            //         RequestorNumber = await this.generateReqNo();
            //         console.log("Generated Request No:", RequestorNumber);
            //     } catch (e) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Could not generate Request Number.");
            //         return;
            //     }

            //     // Post payloads (your existing code)...
            //     const aPromises = aSelectedRows.map(row => {
            //         const oPayload = {
            //             sap_uuid: this.generateUUID(),
            //             requestdate: oView.byId("idRequestDate").getDateValue() ?
            //                 new Date(oView.byId("idRequestDate").getDateValue().toLocaleDateString('en-CA'))
            //                 : null,
            //             requester: this.sUserId,
            //             plant: row.fromplant,
            //             requestno: RequestorNumber,
            //             materialcode: row.materialcode,
            //             description: row.description,
            //             quantity: String(row.quantity),
            //             uom: row.uom,
            //             fromplant: row.fromplant,
            //             fromstorgaeloc: row.fromstorgaeloc,
            //             toplant: row.toplant,
            //             tostoragelocation: row.tostoragelocation,
            //             nocontainers: row.nocontainers,
            //             batch: row.batch,
            //             texts: row.texts,
            //             screenname: "STOCK_TRANSFER",
            //             screencode: "ST01",
            //             gtsavedstatus: "GT",
            //             createdat: new Date(),
            //             createdby: sap.ushell.Container.getService("UserInfo").getId() || "USER"
            //         };

            //         return new Promise((resolve, reject) => {
            //             oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });
            //     });

            //     Promise.allSettled(aPromises).then(results => {
            //         sap.ui.core.BusyIndicator.hide();
            //         const aFailed = results.filter(r => r.status === "rejected");
            //         if (aFailed.length > 0) {
            //             sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post.`);
            //         } else {
            //             const aUpdatedData = oLocalModel.getProperty("/Samples");
            //             aUpdatedData.forEach(row => {
            //                 if (row.__selected) {
            //                     row.gtsavedstatus = "GT";
            //                     row.__selected = false;
            //                 }
            //             });
            //             oLocalModel.setProperty("/Samples", aUpdatedData);
            //             sap.m.MessageToast.show("All selected rows posted successfully!");
            //             this.refreshTableAfterSave();
            //         }
            //     });
            // },
            // onSavePress: function () {
            //     const oView = this.getView();
            //     const oLocalModel = oView.getModel("TabModel");       // Local JSON model
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT"); // Your OData Service
            //     const aData = oLocalModel.getProperty("/Samples");

            //     if (!aData || !Array.isArray(aData) || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available.");
            //         return;
            //     }

            //     // ✅ Check which rows were selected
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // ✅ Mandatory fields validation
            //     const aInvalidRows = [];

            //     aSelectedRows.forEach(row => {
            //         const missingFields = [];

            //         if (!row.materialcode) missingFields.push("Material Code");
            //         if (!row.quantity) missingFields.push("Quantity");
            //         if (!row.uom) missingFields.push("UOM");
            //         if (!row.fromplant) missingFields.push("From Plant");
            //         if (!row.toplant) missingFields.push("To Plant");
            //         if (!row.batch) missingFields.push("Batch")

            //         if (missingFields.length > 0) {
            //             const rowIndex = aData.indexOf(row) + 1;
            //             aInvalidRows.push(`Row ${rowIndex}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aInvalidRows.length > 0) {
            //         sap.m.MessageBox.error(
            //             "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
            //         );
            //         return;
            //     }


            //     // const RequestorNumber = this.generateReqNo
            //     const RequestorNumber = this.generateReqNo();
            //     // debugger

            //     // ✅ Fetch Header Field Values
            //     const oRequestDate = oView.byId("idRequestDate").getDateValue();
            //     // const sRequester = oView.byId("idRequester").getValue();
            //     // const sPlant = oView.byId("idPlant").getValue();
            //     // const sRequestNo = oView.byId("idRequestNo").getValue();
            //     // const sPostedStatus = oView.byId("idPostedStatus").getSelectedKey();

            //     // const RequestorNumber = this.generateReqNo
            //     // const sMatDoc = oView.byId("idMaterialDocNo").getValue();

            //     sap.ui.core.BusyIndicator.show(0);

            //     // ✅ POST each selected entry
            //     const aPromises = aSelectedRows.map(row => {

            //         const oPayload = {
            //             sap_uuid: this.generateUUID(),

            //             requestdate: oRequestDate ? new Date(oRequestDate.toLocaleDateString('en-CA')) : null,
            //             requester: this.sUserId,
            //             plant: row.fromplant,
            //             // requestno: this.generateReqNo(),
            //             requestno: RequestorNumber,
            //             // postedstatus: sPostedStatus,
            //             // materialdocumentno: sMatDoc,

            //             materialcode: row.materialcode,
            //             description: row.description,
            //             quantity: String(row.quantity),
            //             uom: row.uom,

            //             fromplant: row.fromplant,
            //             fromstorgaeloc: row.fromstorgaeloc,
            //             toplant: row.toplant,
            //             tostoragelocation: row.tostoragelocation,

            //             nocontainers: row.nocontainers,
            //             batch: row.batch,
            //             texts: row.texts,

            //             screenname: "STOCK_TRANSFER",
            //             screencode: "ST01",

            //             gtsavedstatus: "GT",

            //             createdat: new Date(),
            //             createdby: sap.ushell.Container.getService("UserInfo").getId() || "USER"
            //         };

            //         console.log("Posting payload:", oPayload);

            //         return new Promise((resolve, reject) => {
            //             oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });
            //     });

            //     let that = this;


            //     Promise.allSettled(aPromises).then(results => {
            //         sap.ui.core.BusyIndicator.hide();

            //         const aFailed = results.filter(r => r.status === "rejected");
            //         if (aFailed.length > 0) {
            //             sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post.`);
            //         } else {
            //             // ✅ Update local model immediately
            //             const aUpdatedData = oLocalModel.getProperty("/Samples");
            //             aUpdatedData.forEach(row => {
            //                 if (row.__selected) {
            //                     row.gtsavedstatus = "GT";
            //                     row.__selected = false;
            //                 }
            //             });
            //             oLocalModel.setProperty("/Samples", aUpdatedData);

            //             sap.m.MessageToast.show("All selected rows posted successfully!");

            //             // ✅ Refresh table using your dedicated function
            //             this.refreshTableAfterSave();
            //         }
            //     });
            // },


            _getMaterialConversion: async function (sMaterial) {
                const oODataModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
                    ];

                    // Set busy indicator while reading
                    sap.ui.core.BusyIndicator.show(0);

                    oODataModel.read("/ZC_STOCK_CONTAINER", {
                        filters: aFilters,
                        success: function (oData) {
                            sap.ui.core.BusyIndicator.hide();

                            const oConv = oData.results.find(
                                item => item.AlternativeUnit !== item.BaseUnit
                            );

                            if (oConv) {
                                resolve(oConv);
                            } else {
                                reject("No valid conversion row found");
                            }
                        },
                        error: function (err) {
                            sap.ui.core.BusyIndicator.hide();
                            reject(err);
                        }
                    });
                });
            },


            onContainerChange: async function (oEvent) {
                const oInput = oEvent.getSource();
                const oContext = oInput.getBindingContext("TabModel");
                const oModel = this.getView().getModel("TabModel");
                const sPath = oContext.getPath();
                const oRow = oModel.getProperty(sPath);
                const sMaterial = oRow.materialcode;

                if (!sMaterial) {
                    sap.m.MessageToast.show("Please select a material first.");
                    return;
                }

                const iContainers = parseFloat(oInput.getValue());
                if (isNaN(iContainers)) return;

                // --- Simple 3-second delay before fetching ---
                clearTimeout(this._containerTimer);
                this._containerTimer = setTimeout(async () => {
                    try {
                        const oConv = await this._getMaterialConversion(sMaterial);
                        const num = parseFloat(oConv.QuantityNumerator);
                        const den = parseFloat(oConv.QuantityDenominator);
                        const quantity = iContainers * (num / den);

                        oModel.setProperty(sPath + "/reqqty", quantity);
                    } catch (err) {
                        console.error(err);
                        sap.m.MessageToast.show("Conversion not found for " + sMaterial);
                    }
                }, 1800);
            },

            onQuantityChange: async function (oEvent) {
                const oInput = oEvent.getSource();
                const oContext = oInput.getBindingContext("TabModel");
                const oModel = this.getView().getModel("TabModel");
                const sPath = oContext.getPath();
                const oRow = oModel.getProperty(sPath);
                const sMaterial = oRow.materialcode;

                if (!sMaterial) {
                    sap.m.MessageToast.show("Please select a material first.");
                    return;
                }

                const iQuantity = parseFloat(oInput.getValue());
                if (isNaN(iQuantity)) return;

                // --- Simple 3-second delay before fetching ---
                clearTimeout(this._quantityTimer);
                this._quantityTimer = setTimeout(async () => {
                    try {
                        const oConv = await this._getMaterialConversion(sMaterial);
                        const num = parseFloat(oConv.QuantityNumerator);
                        const den = parseFloat(oConv.QuantityDenominator);
                        const containers = iQuantity * (den / num);

                        oModel.setProperty(sPath + "/nocontainers", containers);
                    } catch (err) {
                        console.error(err);
                        sap.m.MessageToast.show("Conversion not found for " + sMaterial);
                    }
                }, 1800);
            },





            generateUUID: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },


            // generateReqNo: function () {
            //     const oView = this.getView();
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");

            //     return new Promise((resolve, reject) => {
            //         // First, read the SINGLE row from ZC_REQUEST_NO
            //         oODataModel.read("/ZC_REQUEST_NO", {
            //             success: function (oData) {
            //                 let nextReqNo = 1; // Default to 1 if no record exists

            //                 if (oData.results && oData.results.length > 0) {
            //                     // Get the first (and should be only) record
            //                     const currentReqNo = oData.results[0].requestno;
            //                     console.log("Current request number found:", currentReqNo);

            //                     // Convert to number and increment
            //                     if (currentReqNo && !isNaN(currentReqNo)) {
            //                         nextReqNo = parseInt(currentReqNo) + 1;
            //                     } else if (typeof currentReqNo === 'string') {
            //                         const numericPart = currentReqNo.replace(/\D/g, '');
            //                         if (numericPart) {
            //                             nextReqNo = parseInt(numericPart) + 1;
            //                         }
            //                     }
            //                 } else {
            //                     console.log("No existing request number found, starting from 1");
            //                 }

            //                 // Format as 10-digit padded number
            //                 const paddedReqNo = nextReqNo.toString().padStart(10, '0');
            //                 console.log("Next request number:", paddedReqNo);

            //                 resolve(paddedReqNo);
            //             },
            //             error: function (err) {
            //                 console.error("Failed to read existing request number:", err);
            //                 reject("Failed to generate request number");
            //             }
            //         });
            //     });
            // },


            generateReqNo: function () {
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');

                const requestNo = `BIPLPR${year}${month}${day}${hours}${minutes}${seconds}`;
                console.log("Generated request number:", requestNo);
                return Promise.resolve(requestNo);
            },


            onSavePress: async function () {
                const oView = this.getView();
                const oLocalModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const aData = oLocalModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData) || aData.length === 0) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                // ✅ Check which rows were selected
                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                // 🔍 Validate Request Date (Mandatory)
                const oRequestDate = oView.byId("idRequestDate")?.getDateValue();
                if (!oRequestDate) {
                    sap.m.MessageBox.error("Request Date is a mandatory field. Please selected a date.");
                    return;
                }

                // ✅ Mandatory fields validation
                const aInvalidRows = [];
                aSelectedRows.forEach(row => {
                    const missingFields = [];
                    if (!row.materialcode) missingFields.push("Material Code");
                    if (!row.reqqty) missingFields.push("Request Quantity");
                    if (!row.uom) missingFields.push("UOM");
                    if (!row.fromplant) missingFields.push("From Plant");
                    if (!row.fromstorageloc) missingFields.push("From Storage Location");
                    if (!row.toplant) missingFields.push("To Plant");
                    if (!row.tostoragelocation) missingFields.push("To Storage Location");
                    if (!row.batch) missingFields.push("Batch");

                    if (missingFields.length > 0) {
                        const rowIndex = aData.indexOf(row) + 1;
                        aInvalidRows.push(`Row ${rowIndex}: ${missingFields.join(", ")}`);
                    }
                });

                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error(
                        "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
                    );
                    return;
                }

                // ... (validation code remains unchanged)

                sap.ui.core.BusyIndicator.show(0);

                try {
                    // ✅ Generate the request number (no table read)
                    const RequestorNumber = await this.generateReqNo();
                    console.log("Using request number:", RequestorNumber);

                    // ✅ POST each selected entry to ZC_STOCK_TRANSFER_GT with sequential item numbers
                    const aPromises = aSelectedRows.map((row, index) => {
                        const itemNumber = index + 1;

                        const oPayload = {
                            sap_uuid: this.generateUUID(),
                            requestdate: oView.byId("idRequestDate")?.getDateValue() ?
                                new Date(oView.byId("idRequestDate").getDateValue().toLocaleDateString('en-CA')) : null,
                            requester: this.sUserFullName,
                            plant: String(row.fromplant),
                            requestno: RequestorNumber,                     // ← new format
                            requestnoitem: String(itemNumber),
                            materialcode: row.materialcode,
                            isbatchmanagementrequired: String(row.isbatchmanagementrequired),
                            description: row.description,
                            reqqty: row.reqqty !== null && row.reqqty !== undefined
                                ? Number(row.reqqty).toFixed(3)
                                : null,
                            issueqty: row.issueqty ? String(row.issueqty) : null,
                            uom: row.uom,
                            fromplant: String(row.fromplant),
                            fromstorageloc: row.fromstorageloc,
                            toplant: String(row.toplant),
                            tostoragelocation: row.tostoragelocation,
                            batch: row.batch,
                            vendorbatch: row.vendorbatch,
                            Batchqty: row.Batchqty,
                            nocontainers: row.nocontainers !== undefined && row.nocontainers !== null ? String(row.nocontainers) : '',
                            category: row.category,
                            screenname: "STOCK_TRANSFER",
                            screencode: "ST01",
                            gtsavedstatus: "GT",
                            requestedby: this.sUserId,
                            createdat: new Date(),
                            createdby: this.sUserId,
                        };
                        // debugger

                        console.log(`Posting payload for item ${itemNumber}:`, JSON.stringify(oPayload, null, 2));

                        return new Promise((resolve, reject) => {
                            oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
                                success: function (data) {
                                    console.log(`Successfully created item ${itemNumber}:`, data);
                                    resolve(data);
                                },
                                error: function (err) {
                                    console.error(`Failed to create item ${itemNumber}:`, err);
                                    reject(err);
                                }
                            });
                        });
                    });

                    const results = await Promise.allSettled(aPromises);

                    // Check results
                    results.forEach((result, index) => {
                        const itemNumber = index + 1;
                        if (result.status === 'fulfilled') {
                            console.log(`Item ${itemNumber} created successfully:`, result.value);
                        } else {
                            console.error(`Item ${itemNumber} failed:`, result.reason);
                        }
                    });

                    const aFailed = results.filter(r => r.status === "rejected");
                    if (aFailed.length > 0) {
                        console.error("Failed creations:", aFailed);
                        sap.ui.core.BusyIndicator.hide();
                        const errorMessages = aFailed.map((failed, index) =>
                            `Item ${index + 1}: ${failed.reason?.message || 'Unknown error'}`
                        ).join('\n');
                        sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post. Errors:\n${errorMessages}\n\nRequest number ${RequestorNumber} was not saved.`);
                        return;
                    }

                    // ❌ REMOVED: All ZC_REQUEST_NO read/update/delete/create code

                    sap.ui.core.BusyIndicator.hide();

                    // Update local model
                    const aUpdatedData = oLocalModel.getProperty("/Samples");
                    aUpdatedData.forEach(row => {
                        if (row.__selected) {
                            row.gtsavedstatus = "GT";
                            row.__selected = false;
                        }
                    });
                    oLocalModel.setProperty("/Samples", aUpdatedData);

                    aSelectedRows.forEach((row, index) => {
                        row.requestnoitem = index + 1;
                    });

                    sap.m.MessageToast.show(`All selected rows posted successfully with request number: ${RequestorNumber}!`);
                    this.refreshTableAfterSave();

                } catch (error) {
                    sap.ui.core.BusyIndicator.hide();
                    console.error("Error in onSavePress:", error);
                    sap.m.MessageBox.error("Failed to save data: " + error.message);
                }
            },


            refreshTableAfterSave: function () {
                const oView = this.getView();
                const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const oLocalModel = oView.getModel("TabModel");

                const oRequestDate = oView.byId("idRequestDate").getDateValue();
                const oRequester = oView.byId("idRequester").getValue().trim();
                const oPlant = oView.byId("idPlant").getValue().trim();
                const oRequestNo = oView.byId("idRequestNo").getValue().trim();
                // const oPostedStatus = oView.byId("idPostedStatus").getSelectedKey();

                const aFilters = [];

                if (oRequestDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    aFilters.push(new sap.ui.model.Filter("requestdate", sap.ui.model.FilterOperator.EQ, oDateFormat.format(oRequestDate)));
                }
                if (oRequester) aFilters.push(new sap.ui.model.Filter("requester", sap.ui.model.FilterOperator.EQ, oRequester));
                if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
                if (oRequestNo) aFilters.push(new sap.ui.model.Filter("requestno", sap.ui.model.FilterOperator.EQ, oRequestNo));
                // if (oPostedStatus) aFilters.push(new sap.ui.model.Filter("postedstatus", sap.ui.model.FilterOperator.EQ, oPostedStatus));

                sap.ui.core.BusyIndicator.show(0);

                oODataModel.read("/ZC_STOCK_TRANSFER_GT", {
                    filters: aFilters,
                    // success: function (oData) {
                    //     sap.ui.core.BusyIndicator.hide();
                    //     oLocalModel.setProperty("/Samples", oData.results.map(item => Object.assign({}, item, { gtsavedstatus: "GT" })));
                    // },
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();

                        // Keep only rows without materialdocumentno
                        const aFiltered = oData.results.filter(item => !item.materialdocumentno);

                        // Update local model
                        oLocalModel.setProperty("/Samples", aFiltered);
                    },

                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        console.error("Error refreshing table:", oError);
                    }
                });
            },



            // onSavePress: async function () {
            //     const oView = this.getView();
            //     const oLocalModel = oView.getModel("TabModel");
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
            //     const aData = oLocalModel.getProperty("/Samples");

            //     if (!aData || !Array.isArray(aData) || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available.");
            //         return;
            //     }

            //     // ✅ Check which rows were selected
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     // 🔍 Validate Request Date (Mandatory)
            //     const oRequestDate = oView.byId("idRequestDate")?.getDateValue();
            //     if (!oRequestDate) {
            //         sap.m.MessageBox.error("Request Date is a mandatory field. Please selected a date.");
            //         return;
            //     }

            //     // ✅ Mandatory fields validation
            //     const aInvalidRows = [];
            //     aSelectedRows.forEach(row => {
            //         const missingFields = [];
            //         if (!row.materialcode) missingFields.push("Material Code");
            //         if (!row.reqqty) missingFields.push("Request Quantity");
            //         if (!row.uom) missingFields.push("UOM");
            //         if (!row.fromplant) missingFields.push("From Plant");
            //         if (!row.toplant) missingFields.push("To Plant");

            //         if (missingFields.length > 0) {
            //             const rowIndex = aData.indexOf(row) + 1;
            //             aInvalidRows.push(`Row ${rowIndex}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aInvalidRows.length > 0) {
            //         sap.m.MessageBox.error(
            //             "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
            //         );
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     try {
            //         // ✅ First, read the current record to get ALL fields (including the key)
            //         const currentRecords = await new Promise((resolve, reject) => {
            //             oODataModel.read("/ZC_REQUEST_NO", {
            //                 success: function (oData) {
            //                     resolve(oData.results || []);
            //                 },
            //                 error: function (err) {
            //                     reject(err);
            //                 }
            //             });
            //         });

            //         // ✅ Generate the NEXT request number
            //         const RequestorNumber = await this.generateReqNo();
            //         console.log("Using request number:", RequestorNumber);

            //         // ✅ POST each selected entry to ZC_STOCK_TRANSFER_GT with sequential item numbers
            //         const aPromises = aSelectedRows.map((row, index) => {
            //             const itemNumber = index + 1; // Start from 1 for the first item

            //             // First, let's check what fields the OData model expects
            //             const oPayload = {
            //                 sap_uuid: this.generateUUID(),
            //                 requestdate: oView.byId("idRequestDate")?.getDateValue() ?
            //                     new Date(oView.byId("idRequestDate").getDateValue().toLocaleDateString('en-CA')) : null,
            //                 requester: this.sUserFullName,
            //                 plant: String(row.fromplant),
            //                 requestno: RequestorNumber,
            //                 // Try different formats for requestnoitem
            //                 requestnoitem: String(itemNumber), // Try as number first
            //                 // requestnoitem: itemNumber.toString(), // Or as string
            //                 // requestnoitem: String(itemNumber).padStart(10, '0'), // Or as padded string
            //                 materialcode: row.materialcode,
            //                 isbatchmanagementrequired: String(row.isbatchmanagementrequired),
            //                 description: row.description,
            //                 reqqty: row.reqqty !== null && row.reqqty !== undefined
            //                     ? Number(row.reqqty).toFixed(3)
            //                     : null,
            //                 issueqty: row.issueqty ? String(row.issueqty) : null,
            //                 uom: row.uom,
            //                 fromplant: String(row.fromplant),
            //                 fromstorageloc: row.fromstorageloc,
            //                 toplant: String(row.toplant),
            //                 tostoragelocation: row.tostoragelocation,
            //                 batch: row.batch,
            //                 vendorbatch: row.vendorbatch,
            //                 Batchqty: row.Batchqty,
            //                 // nocontainers: String(row.nocontainers),
            //                 nocontainers: row.nocontainers !== undefined && row.nocontainers !== null ? String(row.nocontainers) : '',

            //                 category: row.category,
            //                 screenname: "STOCK_TRANSFER",
            //                 screencode: "ST01",
            //                 gtsavedstatus: "GT",
            //                 requestedby: this.sUserId,
            //                 createdat: new Date(),
            //                 createdby: this.sUserId,
            //             };

            //             console.log(`Posting payload for item ${itemNumber}:`, JSON.stringify(oPayload, null, 2));

            //             return new Promise((resolve, reject) => {
            //                 oODataModel.create("/ZC_STOCK_TRANSFER_GT", oPayload, {
            //                     success: function (data) {
            //                         console.log(`Successfully created item ${itemNumber}:`, data);
            //                         resolve(data);
            //                     },
            //                     error: function (err) {
            //                         console.error(`Failed to create item ${itemNumber}:`, err);
            //                         reject(err);
            //                     }
            //                 });
            //             });
            //         });

            //         const results = await Promise.allSettled(aPromises);

            //         // Check results more carefully
            //         results.forEach((result, index) => {
            //             const itemNumber = index + 1;
            //             if (result.status === 'fulfilled') {
            //                 console.log(`Item ${itemNumber} created successfully:`, result.value);
            //             } else {
            //                 console.error(`Item ${itemNumber} failed:`, result.reason);
            //             }
            //         });

            //         const aFailed = results.filter(r => r.status === "rejected");
            //         if (aFailed.length > 0) {
            //             console.error("Failed creations:", aFailed);
            //             sap.ui.core.BusyIndicator.hide();

            //             // Get more specific error details
            //             const errorMessages = aFailed.map((failed, index) =>
            //                 `Item ${index + 1}: ${failed.reason?.message || 'Unknown error'}`
            //             ).join('\n');

            //             sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post. Errors:\n${errorMessages}\n\nRequest number ${RequestorNumber} was not saved.`);
            //             return;
            //         }

            //         // ✅ Now update the ZC_REQUEST_NO table with the new request number
            //         if (currentRecords.length > 0) {
            //             // Get the first record (should be only one)
            //             const currentRecord = currentRecords[0];

            //             // Try different possible key field names
            //             let sPath;
            //             if (currentRecord.ID) {
            //                 sPath = `/ZC_REQUEST_NO(${currentRecord.ID})`;
            //             } else if (currentRecord.UUID) {
            //                 sPath = `/ZC_REQUEST_NO('${currentRecord.UUID}')`;
            //             } else if (currentRecord.requestno) {
            //                 // If requestno is the key, we need to delete and recreate
            //                 sPath = `/ZC_REQUEST_NO('${currentRecord.requestno}')`;

            //                 // Delete the old record first
            //                 await new Promise((resolve, reject) => {
            //                     oODataModel.remove(sPath, {
            //                         success: function () {
            //                             console.log("Deleted old request number:", currentRecord.requestno);
            //                             resolve();
            //                         },
            //                         error: function (oError) {
            //                             console.error("Failed to delete old request number:", oError);
            //                             reject(oError);
            //                         }
            //                     });
            //                 });

            //                 // Create new record with new request number
            //                 const oCreatePayload = {
            //                     requestno: RequestorNumber
            //                 };

            //                 await new Promise((resolve, reject) => {
            //                     oODataModel.create("/ZC_REQUEST_NO", oCreatePayload, {
            //                         success: function () {
            //                             console.log("Successfully created new request number:", RequestorNumber);
            //                             resolve();
            //                         },
            //                         error: function (oError) {
            //                             console.error("Failed to create new request number:", oError);
            //                             reject(oError);
            //                         }
            //                     });
            //                 });
            //             } else {
            //                 // If we can't determine the key, use a fallback approach
            //                 throw new Error("Cannot determine the key field for ZC_REQUEST_NO");
            //             }

            //             // Only update if we didn't do delete/create above
            //             if (!currentRecord.requestno) {
            //                 const oUpdatePayload = {
            //                     requestno: RequestorNumber
            //                 };

            //                 await new Promise((resolve, reject) => {
            //                     oODataModel.update(sPath, oUpdatePayload, {
            //                         success: function () {
            //                             console.log("Successfully updated request number to:", RequestorNumber);
            //                             resolve();
            //                         },
            //                         error: function (oError) {
            //                             console.error("Failed to update request number:", oError);
            //                             reject(oError);
            //                         }
            //                     });
            //                 });
            //             }
            //         } else {
            //             // Create new record if none exists
            //             const oCreatePayload = {
            //                 requestno: RequestorNumber
            //             };

            //             await new Promise((resolve, reject) => {
            //                 oODataModel.create("/ZC_REQUEST_NO", oCreatePayload, {
            //                     success: function () {
            //                         console.log("Successfully created request number:", RequestorNumber);
            //                         resolve();
            //                     },
            //                     error: function (oError) {
            //                         console.error("Failed to create request number:", oError);
            //                         reject(oError);
            //                     }
            //                 });
            //             });
            //         }

            //         sap.ui.core.BusyIndicator.hide();

            //         // ✅ Update local model immediately
            //         const aUpdatedData = oLocalModel.getProperty("/Samples");
            //         aUpdatedData.forEach(row => {
            //             if (row.__selected) {
            //                 row.gtsavedstatus = "GT";
            //                 row.__selected = false;
            //             }
            //         });
            //         oLocalModel.setProperty("/Samples", aUpdatedData);

            //         // Also update the requestnoitem in local model for debugging
            //         aSelectedRows.forEach((row, index) => {
            //             const itemNumber = index + 1;
            //             row.requestnoitem = itemNumber;
            //         });

            //         sap.m.MessageToast.show(`All selected rows posted successfully with request number: ${RequestorNumber}!`);
            //         this.refreshTableAfterSave();

            //     } catch (error) {
            //         sap.ui.core.BusyIndicator.hide();
            //         console.error("Error in onSavePress:", error);
            //         sap.m.MessageBox.error("Failed to save data: " + error.message);
            //     }
            // },

            // Function to initialize the request number table with starting value
            // initializeRequestNumber: function () {
            //     const oView = this.getView();
            //     const oODataModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");

            //     return new Promise((resolve, reject) => {
            //         // First check if record exists
            //         oODataModel.read("/ZC_REQUEST_NO", {
            //             success: function (oData) {
            //                 if (oData.results && oData.results.length === 0) {
            //                     // No record exists, create initial record
            //                     const oPayload = {
            //                         requestno: "0000000000" // Start from 0 so first save becomes 1
            //                     };

            //                     oODataModel.create("/ZC_REQUEST_NO", oPayload, {
            //                         success: function () {
            //                             console.log("Initialized request number table with 0000000000");
            //                             resolve();
            //                         },
            //                         error: function (oError) {
            //                             console.error("Failed to initialize request number:", oError);
            //                             reject(oError);
            //                         }
            //                     });
            //                 } else {
            //                     console.log("Request number table already initialized");
            //                     resolve();
            //                 }
            //             },
            //             error: function (err) {
            //                 console.error("Failed to check request number table:", err);
            //                 reject(err);
            //             }
            //         });
            //     });
            // },



            


            // onPrintPressAdobeform: function () {
            //     var oTable = this.byId("idStockRequestTable");

            //     // ✅ Find the selected row
            //     var oSelectedRow = oTable.getBinding("rows").getContexts().find(ctx => ctx.getObject().__selected);
            //     if (!oSelectedRow) {
            //         sap.m.MessageToast.show("Please select a row to print.");
            //         return;
            //     }

            //     var oRowData = oSelectedRow.getObject();

            //     // ✅ Validation
            //     if (!oRowData.materialcode) {
            //         sap.m.MessageToast.show("Material code not found in selected row.");
            //         return;
            //     }

            //     // ✅ Construct payload with row data
            //     var oPayload = {
            //         materialcode: oRowData.materialcode,
            //         description: oRowData.description || "",
            //         quantity: oRowData.quantity || "",
            //         uom: oRowData.uom || "",
            //         fromplant: oRowData.fromplant || "",
            //         toplant: oRowData.toplant || "",
            //         batch: oRowData.batch || "",
            //         requestno: oRowData.requestno || "",
            //         requester: oRowData.requester || "",
            //         requestdate: oRowData.requestdate || "",
            //         fromstorgaeloc: oRowData.fromstorgaeloc || "",
            //         tostoragelocation: oRowData.tostoragelocation || "",
            //         nocontainers: oRowData.nocontainers || ""
            //     };

            //     sap.ui.core.BusyIndicator.show(0);

            //     // ✅ Call backend via destination (no CORS)
            //     // Use relative path so it's routed through BTP destination
            //     fetch("/sap/bc/http/sap/Z_MAT_REQ", {
            //         method: "POST",
            //         headers: {
            //             "Content-Type": "application/json",
            //             "Accept": "application/pdf"
            //         },
            //         body: JSON.stringify(oPayload)
            //     })
            //         .then(response => {
            //             if (!response.ok) {
            //                 throw new Error("Backend returned status " + response.status);
            //             }
            //             return response.text(); // Backend returns base64 string
            //         })
            //         .then(base64Data => {
            //             if (!base64Data) {
            //                 throw new Error("No PDF data received from backend.");
            //             }

            //             // ✅ Decode Base64 string → PDF Blob
            //             const byteCharacters = atob(base64Data);
            //             const byteNumbers = new Array(byteCharacters.length);
            //             for (let i = 0; i < byteCharacters.length; i++) {
            //                 byteNumbers[i] = byteCharacters.charCodeAt(i);
            //             }
            //             const byteArray = new Uint8Array(byteNumbers);
            //             const blob = new Blob([byteArray], { type: "application/pdf" });

            //             // ✅ Create object URL & open PDF in new tab
            //             const pdfUrl = URL.createObjectURL(blob);
            //             window.open(pdfUrl, "_blank");

            //             sap.m.MessageToast.show("Adobe form generated successfully!");
            //         })
            //         .catch(err => {
            //             console.error("Error fetching PDF:", err);
            //             sap.m.MessageBox.error("Failed to load Adobe form: " + err.message);
            //         })
            //         .finally(() => {
            //             sap.ui.core.BusyIndicator.hide();
            //         });
            // },

            
            onPrintPressAdobeform: async function () {
                console.log("hi")
                const oTable = this.byId("idStockRequestTable");

                // Get all selected rows
                const aAllContexts = oTable.getBinding("rows").getContexts();
                const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

                if (!aSelectedRows.length) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                // Extract request numbers
                const aRequestNos = [...new Set(
                    aSelectedRows.map(ctx => ctx.getObject().requestno).filter(Boolean)
                )];

                console.log("Unique request numbers:", aRequestNos);

                // Make sure pdf-lib global is available
                if (!window.PDFLib) {
                    // Load the library script dynamically from your util folder
                    await new Promise((resolve, reject) => {
                        const script = document.createElement("script");
                        // ✅ Use sap.ui.require.toUrl to get the correct deployed path
                        script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
                        script.onload = resolve;
                        script.onerror = () => reject(new Error("Failed to load PDF library."));
                        document.head.appendChild(script);
                    });
                }

                sap.ui.core.BusyIndicator.show(0);
                const { PDFDocument } = window.PDFLib;
                const mergedPdf = await PDFDocument.create();

                for (const sRequestNo of aRequestNos) {
                    // const sUrl = "/sap/bc/http/sap/Z_MAT_REQ?requestno=" + encodeURIComponent(sRequestNo) + "&requestdby=" +this.sUserId;
                    const sUrl = "/sap/bc/http/sap/Z_MAT_REQ1?requestno="
                        + encodeURIComponent(sRequestNo)
                        + "&requestedby=" + encodeURIComponent(this.sUserId);

                    console.log("url:", sUrl)

                    try {
                        const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });
                        const base64Data = await response.text();

                        // Skip if backend returned HTML (error)
                        if (base64Data.startsWith("<!DOCTYPE html>")) {
                            console.error("Backend error for requestno:", sRequestNo);
                            continue;
                        }

                        // Convert Base64 → PDF
                        const pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
                        const pdfToMerge = await PDFDocument.load(pdfBytes);
                        const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
                        copiedPages.forEach(page => mergedPdf.addPage(page));
                    } catch (err) {
                        console.error("Error fetching/merging PDF for requestno:", sRequestNo, err);
                        sap.m.MessageToast.show("Error merging PDF for request: " + sRequestNo);
                    }
                }

                sap.ui.core.BusyIndicator.hide(0);

                // Save the merged PDF
                const mergedPdfBytes = await mergedPdf.save();
                const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
                const pdfUrl = URL.createObjectURL(blob);
                window.open(pdfUrl, "_blank");
            },



            onDeletePress: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                const oTabModel = oView.getModel("TabModel");
                const aData = oTabModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData)) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to delete.");
                    return;
                }
                if (aSelectedRows.some(row => !row.sap_uuid)) {
                    sap.m.MessageBox.warning("Row not saved to delete.");
                    return;
                }



                sap.m.MessageBox.confirm(
                    `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
                    {
                        title: "Confirm Deletion",
                        actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (oAction) {
                            if (oAction !== sap.m.MessageBox.Action.OK) return;

                            sap.ui.core.BusyIndicator.show(0);

                            const aDeletePromises = aSelectedRows.map(row => {
                                return new Promise((resolve, reject) => {
                                    if (!row.sap_uuid) {
                                        reject("Missing sap_uuid for deletion.");
                                        return;
                                    }

                                    const sKeyPath = `/ZC_STOCK_TRANSFER_GT(sap_uuid='${row.sap_uuid}')`;

                                    oModel.remove(sKeyPath, {
                                        success: resolve,
                                        error: reject
                                    });
                                });
                            });

                            Promise.allSettled(aDeletePromises).then(results => {
                                sap.ui.core.BusyIndicator.hide();

                                const aFailed = results.filter(r => r.status === "rejected");
                                const aSuccess = results.filter(r => r.status === "fulfilled");

                                // Remove deleted rows from TabModel local data
                                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                                oTabModel.setProperty("/Samples", aRemainingData);

                                if (aSuccess.length > 0) {
                                    sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                                }

                                if (aFailed.length > 0) {
                                    sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                                    console.error("Deletion errors:", aFailed);
                                }
                            });
                        }
                    }
                );
            },










            // ==============================================================================
            // ==============================================================================
            // ================ =FRAGMENT SECTION TO FETCH FIELDS ===========================
            // ==============================================================================
            // ==============================================================================






            onStockTransferMaterialValueHelp: function (oEvent) {
                this._oInputField = oEvent.getSource();
                var oView = this.getView();

                // Show loading
                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading materials...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                var that = this;

                // Read OData
                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    urlParameters: {
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        // Process data
                        var aAll = oData.results.map(function (item) {
                            return {
                                Product: (item.Product || "").trim(),
                                ProductName: item.ProductName || "",
                                BaseUnit: item.BaseUnit || "",
                                Plant: item.Plant || "",
                                IsBatchManagementRequired: item.IsBatchManagementRequired || false
                                // StorageLocation: item.StorageLocation || ""
                            };
                        });
                        console.log("Material Value Help Loaded:", aAll.length, "records");

                        // Create JSON model
                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            Products: aAll
                        });

                        // Load and configure ValueHelpDialog
                        that.loadFragment({
                            name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferMaterial"
                        }).then(function (oDialog) {
                            that._oStockTransferMaterialDialog = oDialog;
                            that.getView().addDependent(oDialog);

                            // Set the model for the dialog
                            oDialog.setModel(oJSONModel, "VHModel");

                            // Configure table binding
                            that._configureValueHelpDialogTable(oDialog, aAll);

                            oDialog.open();
                        }).catch(function (oError) {
                            that._oBusyDialog.close();
                            sap.m.MessageToast.show("Error loading value help dialog");
                            console.error(oError);
                        });
                    },
                    error: function () {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Error fetching materials from OData");
                    }
                });
            },

            // _configureValueHelpDialogTable: function (oDialog, aData) {
            //     oDialog.getTableAsync().then(function (oTable) {
            //         // Set model for the table
            //         var oModel = new sap.ui.model.json.JSONModel({ Products: aData });
            //         oTable.setModel(oModel, "VHModel");

            //         if (oTable.setGrowing) {
            //             oTable.setGrowing(false);
            //         }

            //         // For sap.ui.table.Table (Desktop)
            //         if (oTable.bindRows) {
            //             oTable.bindAggregation("rows", {
            //                 path: "VHModel>/Products"
            //             });

            //             // Define columns
            //             var aColumns = [
            //                 { label: "Material Code", template: new sap.m.Text({ text: "{VHModel>Product}" }) },
            //                 { label: "Description", template: new sap.m.Text({ text: "{VHModel>ProductName}" }) },
            //                 { label: "Base Unit", template: new sap.m.Text({ text: "{VHModel>BaseUnit}" }) },
            //                 { label: "Plant", template: new sap.m.Text({ text: "{VHModel>Plant}" }) },
            //                 { label: "Batch Managed", template: new sap.m.Text({ text: "{VHModel>IsBatchManagementRequired}" }) },
            //                 // { label: "Storage Location", template: new sap.m.Text({ text: "{VHModel>StorageLocation}" }) }
            //             ];

            //             aColumns.forEach(function (oColConfig) {
            //                 var oColumn = new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: oColConfig.label }),
            //                     template: oColConfig.template
            //                 });
            //                 oTable.addColumn(oColumn);
            //             });
            //         }

            //         // For sap.m.Table (Mobile)
            //         if (oTable.bindItems) {
            //             oTable.bindAggregation("items", {
            //                 path: "VHModel>/Products",
            //                 template: new sap.m.ColumnListItem({
            //                     cells: [
            //                         new sap.m.Text({ text: "{VHModel>Product}" }),
            //                         new sap.m.Text({ text: "{VHModel>ProductName}" }),
            //                         new sap.m.Text({ text: "{VHModel>BaseUnit}" }),
            //                         new sap.m.Text({ text: "{VHModel>Plant}" }),
            //                         new sap.m.Text({ text: "{VHModel>IsBatchManagementRequired}" }),
            //                         // new sap.m.Text({ text: "{VHModel>StorageLocation}" })
            //                     ]
            //                 })
            //             });

            //             // Add columns
            //             var aColumnHeaders = ["Material Code", "Description", "Base Unit", "Plant", "Batch Managed"];
            //             aColumnHeaders.forEach(function (sHeader) {
            //                 oTable.addColumn(new sap.m.Column({
            //                     header: new sap.m.Label({ text: sHeader })
            //                 }));
            //             });
            //         }
            //     });
            // },

            _configureValueHelpDialogTable: function (oDialog, aData) {
                oDialog.getTableAsync().then(function (oTable) {
                    // Set model for the table
                    var oModel = new sap.ui.model.json.JSONModel({ Products: aData });
                    oTable.setModel(oModel, "VHModel");

                    if (oTable.setGrowing) {
                        oTable.setGrowing(false);
                    }

                    // For sap.ui.table.Table (Desktop)
                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", {
                            path: "VHModel>/Products"
                        });

                        // Define columns - REMOVE Batch Managed column from display
                        var aColumns = [
                            {
                                label: "Material Code",
                                template: new sap.m.Text({ text: "{VHModel>Product}" })
                            },
                            {
                                label: "Description",
                                template: new sap.m.Text({ text: "{VHModel>ProductName}" })
                            },
                            {
                                label: "Base Unit",
                                template: new sap.m.Text({ text: "{VHModel>BaseUnit}" })
                            },
                            {
                                label: "Plant",
                                template: new sap.m.Text({ text: "{VHModel>Plant}" })
                            },
                            // Batch Managed field is now hidden but still in the data model
                            // { label: "Batch Managed", template: new sap.m.Text({ text: "{VHModel>IsBatchManagementRequired}" }) }
                        ];

                        aColumns.forEach(function (oColConfig) {
                            var oColumn = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: oColConfig.label }),
                                template: oColConfig.template
                            });
                            oTable.addColumn(oColumn);
                        });
                    }

                    // For sap.m.Table (Mobile)
                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", {
                            path: "VHModel>/Products",
                            template: new sap.m.ColumnListItem({
                                cells: [
                                    new sap.m.Text({ text: "{VHModel>Product}" }),
                                    new sap.m.Text({ text: "{VHModel>ProductName}" }),
                                    new sap.m.Text({ text: "{VHModel>BaseUnit}" }),
                                    new sap.m.Text({ text: "{VHModel>Plant}" }),
                                    // Batch Managed field is hidden but data is still bound
                                    // Remove this cell from display template
                                ]
                            })
                        });

                        // Add columns - REMOVE Batch Managed column from display
                        var aColumnHeaders = [
                            "Material Code",
                            "Description",
                            "Base Unit",
                            "Plant"
                            // "Batch Managed" - Removed from display
                        ];

                        aColumnHeaders.forEach(function (sHeader) {
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({ text: sHeader })
                            }));
                        });
                    }
                });
            },

            onStockTransferMaterialFilterSearch: function (oEvent) {
                var sSearchQuery = oEvent.getParameter("searchQuery"),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilterStrings = [];

                // Filter bar values
                aSelectionSet.forEach(function (oControl) {
                    var v = oControl.getValue();
                    if (v) {
                        aFilterStrings.push(`substringof('${v}', ${oControl.getName()})`);
                    }
                });

                // Global search
                if (sSearchQuery) {
                    aFilterStrings.push(
                        "(substringof('" + sSearchQuery + "', Product) or " +
                        " substringof('" + sSearchQuery + "', ProductName) or " +
                        " substringof('" + sSearchQuery + "', Plant) or " +
                        " substringof('" + sSearchQuery + "', BaseUnit))"
                    );
                }

                var sFilterQuery = aFilterStrings.join(" and ");

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                var that = this;

                this._oBusyDialog.open();

                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    urlParameters: {
                        "$filter": sFilterQuery,
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });

                        var oDialog = that._oStockTransferMaterialDialog;
                        oDialog.setModel(oJSON, "VHModel");

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(oJSON, "VHModel");

                            if (oTable.bindRows) {
                                oTable.bindRows("VHModel>/Products");
                            }
                            if (oTable.bindItems) {
                                oTable.bindItems({
                                    path: "VHModel>/Products",
                                    template: oTable.getBindingInfo("items").template
                                });
                            }
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        console.error(oError);
                        sap.m.MessageToast.show("Search failed.");
                    }
                });
            },

            onStockTransferMaterialOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");

                if (aTokens && aTokens.length > 0) {
                    var oSelectedItem = aTokens[0];
                    var sProduct = oSelectedItem.getKey();
                    var sProductName = oSelectedItem.getText();

                    // Extract ProductName if it's in "Description (Code)" format
                    let parts = sProductName.split("(");
                    let sDescription = parts[0].trim();

                    if (this._oInputField) {
                        var oRowCtx = this._oInputField.getBindingContext("TabModel");
                        if (oRowCtx) {
                            // Map the selected values back to your table row
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialcode", sProduct);
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/description", sDescription);
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/fromstorageloc", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/tostoragelocation", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/batch", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/vendorbatch", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/Batchqty", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/isbatchmanagementrequired", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/tostoragelocation", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/isbatchmanagementrequired", oData.IsBatchManagementRequired || false);
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/uom", oData.BaseUnit || "");


                            // Optional: If you need to fetch additional data like UOM, you can do it here
                            this._fetchAdditionalMaterialData(sProduct, oRowCtx);
                        }
                    }
                }

                this._oStockTransferMaterialDialog.close();
            },

            onStockTransferMaterialCancelPress: function () {
                if (this._oStockTransferMaterialDialog) {
                    this._oStockTransferMaterialDialog.close();
                }
            },

            onStockTransferMaterialAfterClose: function () {
                if (this._oStockTransferMaterialDialog) {
                    this._oStockTransferMaterialDialog.destroy();
                    this._oStockTransferMaterialDialog = null;
                }
            },

            // Optional: Method to fetch additional material data if needed
            _fetchAdditionalMaterialData: function (sMaterial, oRowCtx) {
                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    filters: [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
                    ],
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            var oMaterialData = oData.results[0];
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/uom", oMaterialData.BaseUnit || "");
                            // Set the batch management field
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/isbatchmanagementrequired", oMaterialData.IsBatchManagementRequired || false);
                        }
                    },
                    error: function () {
                        console.error("Error fetching additional material data");
                    }
                });
            },









            // onMaterialFragmentOpen: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     this.EventRowCollNo = oEvent.getSource().getParent();

            //     const input = oEvent.getSource(); // the input field
            //     const context = input.getBindingContext("TabModel");

            //     if (context) {
            //         const rowPath = context.getPath();
            //         const rowData = context.getObject();

            //         this.oEventModelRowDatas = rowData;
            //         this.oEventModelRowPath = rowPath;

            //         const that = this;

            //         this._oBasicSearchField = new sap.m.SearchField();

            //         this.loadFragment({
            //             name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferMaterial" // 👈 new fragment name
            //         }).then(function (oDialog) {
            //             that._oVHD_Product = oDialog;
            //             that.getView().addDependent(oDialog);

            //             // set key fields
            //             oDialog.setRangeKeyFields([{
            //                 label: "Product",
            //                 key: "Product",
            //                 type: "string",
            //                 typeInstance: new sap.ui.model.type.String({}, { maxLength: 18 })
            //             }]);

            //             const oFilterBar = oDialog.getFilterBar();
            //             oFilterBar.setBasicSearch(that._oBasicSearchField);
            //             oFilterBar.setFilterBarExpanded(false);

            //             that._oBasicSearchField.attachSearch(() => oFilterBar.search());

            //             oDialog.getTableAsync().then(function (oTable) {
            //                 // 👇 Bind to the new OData Model and entity set
            //                 oTable.setModel(that.getOwnerComponent().getModel("ZSB_STOCK_TRANSFER_F4"), "ZSB_STOCK_TRANSFER_F4");

            //                 if (oTable.bindRows) {
            //                     oTable.bindAggregation("rows", {
            //                         path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                         // filters: [plantFilter],
            //                         events: {
            //                             dataReceived: () => oDialog.update()
            //                         }
            //                     });

            //                     // Add columns
            //                     oTable.addColumn(new sap.ui.table.Column({
            //                         label: new sap.m.Label({ text: "Product" }),
            //                         template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" })
            //                     }));
            //                     oTable.addColumn(new sap.ui.table.Column({
            //                         label: new sap.m.Label({ text: "Product Name" }),
            //                         template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>ProductName}" })
            //                     }));
            //                     oTable.addColumn(new sap.ui.table.Column({
            //                         label: new sap.m.Label({ text: "Plant" }),
            //                         template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" })
            //                     }));
            //                     oTable.addColumn(new sap.ui.table.Column({
            //                         label: new sap.m.Label({ text: "Storage Location" }),
            //                         template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" })
            //                     }));
            //                     oTable.addColumn(new sap.ui.table.Column({
            //                         label: new sap.m.Label({ text: "Unit of measure" }),
            //                         template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>BaseUnit}" })
            //                     }));
            //                 }

            //                 // For mobile (sap.m.Table)
            //                 if (oTable.bindItems) {
            //                     oTable.bindAggregation("items", {
            //                         path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                         // filters: [plantFilter],
            //                         template: new sap.m.ColumnListItem({
            //                             cells: [
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>ProductName}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>BaseUnit}" })
            //                             ]
            //                         }),
            //                         events: {
            //                             dataReceived: () => oDialog.update()
            //                         }
            //                     });

            //                     oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product" }) }));
            //                     oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product Name" }) }));
            //                     oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
            //                     oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Storage Location" }) }));
            //                     oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Unit of measure" }) }));
            //                 }

            //                 oDialog.open();
            //                 sap.ui.core.BusyIndicator.hide();
            //             });
            //         });
            //     }
            // },
            // onValueHelpOkPress_Product: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     const aTokens = oEvent.getParameter("tokens");
            //     if (!aTokens || aTokens.length === 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const token = aTokens[0];
            //     const KeyVal = token.getKey();  // Product code
            //     const TextVal = token.getText();

            //     // Extract product name (before the '(')
            //     const parts = TextVal.split("(");
            //     const ProductName = parts[0].trim();
            //     const ProductCode = KeyVal;

            //     const mod01 = this.getView().getModel("TabModel");
            //     const rowObj = mod01.getProperty(this.oEventModelRowPath);

            //     // ✅ Get selected record from VHD table (the proper way)
            //     let oSelectedContext;

            //     const oTable = this._oVHD_Product.getTable();

            //     // sap.ui.table.Table (desktop)
            //     if (oTable.getSelectedIndex && oTable.getSelectedIndex() >= 0) {
            //         oSelectedContext = oTable.getContextByIndex(oTable.getSelectedIndex());
            //     }
            //     // sap.m.Table (mobile)
            //     else if (oTable.getSelectedItem) {
            //         const oItem = oTable.getSelectedItem();
            //         if (oItem) oSelectedContext = oItem.getBindingContext("ZSB_STOCK_TRANSFER_F4");
            //     }

            //     if (!oSelectedContext) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const selectedObj = oSelectedContext.getObject();

            //     // ✅ Fill values correctly
            //     rowObj.materialcode = ProductCode;
            //     rowObj.description = ProductName;
            //     // rowObj.fromplant = selectedObj.Plant || "";
            //     // rowObj.fromstorgaeloc = selectedObj.StorageLocation || "";
            //     rowObj.uom = selectedObj.BaseUnit || "";

            //     mod01.refresh(true);

            //     this._oVHD_Product.destroy();
            //     sap.ui.core.BusyIndicator.hide();
            // },





            // onFilterBarSearch_Product: function (oEvent) {
            //     console.log(oEvent);
            //     var sSearchQuery = this._oBasicSearchField.getValue(),
            //         aSelectionSet = oEvent.getParameter("selectionSet");

            //     // Construct filters for search and selection set values
            //     var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
            //         if (oControl.getValue()) {
            //             aResult.push(new sap.ui.model.Filter({
            //                 path: oControl.getName(),
            //                 operator: sap.ui.model.FilterOperator.Contains,
            //                 value1: oControl.getValue()
            //             }));
            //         }
            //         return aResult;
            //     }, []);

            //     aFilters.push(new sap.ui.model.Filter({
            //         filters: [
            //             new sap.ui.model.Filter({ path: "Product", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            //             new sap.ui.model.Filter({ path: "ProductName", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            //             new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            //             // new sap.ui.model.Filter({ path: "StandardPrice", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            //         ],
            //         and: false
            //     }));

            //     this._filterTable_Product(new sap.ui.model.Filter({
            //         filters: aFilters,
            //         and: true
            //     }));
            // },

            // _filterTable_Product: function (oFilter) {
            //     var oVHD = this._oVHD_Product;

            //     oVHD.getTableAsync().then(function (oTable) {
            //         if (oTable.bindRows) {
            //             oTable.getBinding("rows").filter(oFilter);
            //         }
            //         if (oTable.bindItems) {
            //             oTable.getBinding("items").filter(oFilter);
            //         }

            //         // Update the dialog after filtering
            //         oVHD.update();
            //     });
            // },

            // onValueHelpCancelPress_Product: function () {
            //     this._oVHD_Product.close(); // Close the value help dialog without making any changes
            // },
            // used till now
            // onStockTransferMaterialValueHelp: function (oEvent) {
            //     this._oInputField = oEvent.getSource();
            //     var oView = this.getView();

            //     // Lazy load fragment only once
            //     if (!this._oStockTransferMaterialDialog) {
            //         this._oStockTransferMaterialDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferMaterial",
            //             this
            //         );
            //         oView.addDependent(this._oStockTransferMaterialDialog);
            //     }

            //     var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
            //     var that = this;

            //     // ✅ Create busy dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading materials...",
            //             title: "Please wait"
            //         });
            //     }

            //     // Show loading
            //     this._oBusyDialog.open();

            //     // Read OData
            //     oModel.read("/ZC_STOCK_TRANSFER_F4", {
            //         urlParameters: {
            //             "$top": 9999
            //         },
            //         success: function (oData) {
            //             // ✅ Close loading
            //             that._oBusyDialog.close();

            //             // Fetch all records — no de-duplication
            //             var aAll = oData.results.map(function (item) {
            //                 return {
            //                     Product: (item.Product || "").trim(),
            //                     ProductName: item.ProductName || "",
            //                     BaseUnit: item.BaseUnit || "",
            //                     Plant: item.Plant || "",
            //                     StorageLocation: item.StorageLocation || "",
            //                     // ExternalProductGroup: item.ExternalProductGroup || ""
            //                 };
            //             });

            //             var oJSON = new sap.ui.model.json.JSONModel({ Products: aAll });
            //             that._oStockTransferMaterialDialog.setModel(oJSON, "VHModel");

            //             that._oStockTransferMaterialDialog.open();
            //         },
            //         error: function () {
            //             // ✅ Close loading on error
            //             that._oBusyDialog.close();
            //             sap.m.MessageToast.show("Error fetching materials from OData");
            //         }
            //     });
            // },



            // onStockTransferMaterialSearch: function (oEvent) {
            //     var sValue = oEvent.getParameter("newValue");

            //     if (!this._oStockTransferMaterialDialog || !this._oStockTransferMaterialDialog.isOpen()) {
            //         return;
            //     }

            //     var oTable = sap.ui.getCore().byId("idStockTransferMaterialTable");
            //     if (!oTable) {
            //         console.error("Table not found in fragment");
            //         return;
            //     }

            //     var oBinding = oTable.getBinding("items");

            //     if (sValue) {
            //         var aFilters = [
            //             new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
            //             new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue),
            //             new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
            //             new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue)
            //         ];

            //         oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
            //     } else {
            //         oBinding.filter([]);
            //     }
            // },

            // onStockTransferMaterialSelected: function (oEvent) {
            //     var oSelectedItem = oEvent.getSource();
            //     var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

            //     if (this._oInputField) {
            //         var oRowCtx = this._oInputField.getBindingContext("TabModel");

            //         // Map the selected values back to your table row
            //         oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialcode", oCtx.Product);
            //         oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/description", oCtx.ProductName);
            //         oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/uom", oCtx.BaseUnit);
            //         // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/category", oCtx.ExternalProductGroup);
            //         // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/plant", oCtx.Plant);
            //         // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/storagelocation", oCtx.StorageLocation);
            //     }

            //     this._oStockTransferMaterialDialog.close();
            // },

            // onStockTransferMaterialVHClose: function () {
            //     if (this._oStockTransferMaterialDialog) {
            //         this._oStockTransferMaterialDialog.close();
            //     }
            // },









            // plant


            onStockTransferPlantValueHelp: function (oEvent) {
                sap.ui.core.BusyIndicator.show();

                const oInput = oEvent.getSource();
                const oView = this.getView();
                const oContext = oInput.getBindingContext("TabModel");
                const that = this;

                // 🟩 Identify which field triggered (fromplant or toplant)
                this._sPlantField = oInput.getBindingInfo("value").parts[0].path;

                if (!oContext) {
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                const sRowPath = oContext.getPath();
                const oRowData = oContext.getObject();
                this._oEventModelRowPath = sRowPath;
                this._oEventModelRowData = oRowData;

                // 🟨 Require a material first
                if (!oRowData.materialcode) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🧩 Lazy load the Plant fragment only once
                if (!this._oStockTransferPlantDialog) {
                    this._oStockTransferPlantDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferPlant",
                        this
                    );
                    oView.addDependent(this._oStockTransferPlantDialog);
                }

                const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                const aFilters = [
                    new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.materialcode)
                ];

                // 🟦 Read all plant records for the selected material
                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        const aPlantData = oData.results.map(function (item) {
                            return {
                                Product: (item.Product || "").trim(),
                                Plant: item.Plant || "",
                                StorageLocation: item.StorageLocation || ""
                            };
                        });

                        // 🧠 Remove duplicates (optional)
                        // const aUnique = aPlantData.filter((v, i, a) => a.findIndex(t => t.Plant === v.Plant) === i);

                        const oJSON = new sap.ui.model.json.JSONModel({ Plants: aPlantData });
                        that._oStockTransferPlantDialog.setModel(oJSON, "VHModel");

                        that._oStockTransferPlantDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Plant data from OData");
                    }
                });
            },

            // 🔍 Search inside Plant dialog
            onStockTransferPlantSearch: function (oEvent) {
                const sValue = oEvent.getParameter("newValue");
                const oTable = sap.ui.getCore().byId("idStockTransferPlantTable");
                if (!oTable) return;

                const oBinding = oTable.getBinding("items");
                if (sValue) {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            // ✅ When user selects a plant
            onStockTransferPlantSelected: function (oEvent) {
                const oSelectedItem = oEvent.getSource();
                const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

                const oModel = this.getView().getModel("TabModel");
                const oRow = oModel.getProperty(this._oEventModelRowPath);

                // 🟢 Push selected values based on triggering field
                if (this._sPlantField === "fromplant") {
                    oRow.fromplant = oCtx.Plant;
                    // oRow.fromstorageloc = oCtx.StorageLocation;
                } else if (this._sPlantField === "toplant") {
                    oRow.toplant = oCtx.Plant;
                    // oRow.tostorageloc = oCtx.StorageLocation;
                }

                oModel.refresh(true);
                this._oStockTransferPlantDialog.close();
            },

            // ❌ Close dialog
            onStockTransferPlantVHClose: function () {
                if (this._oStockTransferPlantDialog) {
                    this._oStockTransferPlantDialog.close();
                }
            },





            // storage location
            // onStorageFragmentOpen: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     const input = oEvent.getSource();
            //     const context = input.getBindingContext("TabModel");

            //     this._sStorageField = input.getBindingInfo("value").parts[0].path;

            //     if (!context) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const rowPath = context.getPath();
            //     const rowData = context.getObject();
            //     this.oEventModelRowPath = rowPath;
            //     this.oEventModelRowDatas = rowData;

            //     if (!rowData.materialcode) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     // if (!rowData.fromplant) {
            //     //     sap.m.MessageBox.information("Please select a Plant first.");
            //     //     sap.ui.core.BusyIndicator.hide();
            //     //     return;
            //     // }

            //     // 🟩 Determine the relevant plant based on which column was clicked
            //     const relevantPlant =
            //         this._sStorageField === "fromstorgaeloc"
            //             ? rowData.fromplant
            //             : rowData.toplant;

            //     // 🟩 Dynamic validation message
            //     if (!relevantPlant) {
            //         const side = this._sStorageField === "fromstorgaeloc" ? "From" : "To";
            //         sap.m.MessageBox.information(`Please select a ${side} Plant first.`);
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const that = this;

            //     const matFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, rowData.materialcode);
            //     // const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.fromplant);
            //     const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, relevantPlant);


            //     this._oBasicSearchFieldStorage = new sap.m.SearchField();

            //     this.loadFragment({
            //         name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage"
            //     }).then(function (oDialog) {
            //         that._oVHD_Storage = oDialog;
            //         that.getView().addDependent(oDialog);

            //         const oFilterBar = oDialog.getFilterBar();
            //         oFilterBar.setBasicSearch(that._oBasicSearchFieldStorage);
            //         oFilterBar.setFilterBarExpanded(false);

            //         that._oBasicSearchFieldStorage.attachSearch(() => oFilterBar.search());

            //         oDialog.getTableAsync().then(function (oTable) {
            //             oTable.setModel(that.getOwnerComponent().getModel("ZSB_STOCK_TRANSFER_F4"), "ZSB_STOCK_TRANSFER_F4");

            //             const filters = [matFilter, plantFilter];

            //             if (oTable.bindRows) {
            //                 oTable.bindAggregation("rows", {
            //                     path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                     filters: filters,
            //                     events: { dataReceived: () => oDialog.update() }
            //                 });

            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Product" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" })
            //                 }));
            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Plant" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" })
            //                 }));
            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Storage Location" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" })
            //                 }));
            //             }

            //             if (oTable.bindItems) {
            //                 oTable.bindAggregation("items", {
            //                     path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                     filters: filters,
            //                     template: new sap.m.ColumnListItem({
            //                         cells: [
            //                             new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" }),
            //                             new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" }),
            //                             new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" })
            //                         ]
            //                     }),
            //                     events: { dataReceived: () => oDialog.update() }
            //                 });

            //                 oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product" }) }));
            //                 oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
            //                 oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Storage Location" }) }));
            //             }

            //             oDialog.open();
            //             sap.ui.core.BusyIndicator.hide();
            //         });
            //     });
            // },

            //             onStorageFragmentOpen: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     const input = oEvent.getSource();
            //     const context = input.getBindingContext("TabModel");
            //     this._sStorageField = input.getBindingInfo("value").parts[0].path;

            //     if (!context) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const rowData = context.getObject();
            //     this.oEventModelRowDatas = rowData;
            //     this.oEventModelRowPath = context.getPath();

            //     if (!rowData.materialcode) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const relevantPlant = this._sStorageField === "fromstorgaeloc" ? rowData.fromplant : rowData.toplant;
            //     if (!relevantPlant) {
            //         const side = this._sStorageField === "fromstorgaeloc" ? "From" : "To";
            //         sap.m.MessageBox.information(`Please select a ${side} Plant first.`);
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const matFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, rowData.materialcode);
            //     const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, relevantPlant);

            //     this._oBasicSearchFieldStorage = new sap.m.SearchField();

            //     const that = this;
            //     this.loadFragment({ name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage" })
            //         .then(function (oDialog) {
            //             that._oVHD_Storage = oDialog;
            //             that.getView().addDependent(oDialog);

            //             const oFilterBar = oDialog.getFilterBar();
            //             oFilterBar.setBasicSearch(that._oBasicSearchFieldStorage);
            //             oFilterBar.setFilterBarExpanded(false);

            //             that._oBasicSearchFieldStorage.attachSearch(() => oFilterBar.search());

            //             oDialog.getTableAsync().then(function (oTable) {
            //                 oTable.setModel(that.getOwnerComponent().getModel("ZSB_STOCK_TRANSFER_F4"), "ZSB_STOCK_TRANSFER_F4");

            //                 // Clear old columns to prevent duplication
            //                 oTable.removeAllColumns();

            //                 // Define columns **before binding**
            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Product" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" })
            //                 }));
            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Plant" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" })
            //                 }));
            //                 oTable.addColumn(new sap.ui.table.Column({
            //                     label: new sap.m.Label({ text: "Storage Location" }),
            //                     template: new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" })
            //                 }));

            //                 // Bind aggregation with filters
            //                 if (oTable.bindRows) {
            //                     oTable.bindAggregation("rows", {
            //                         path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                         filters: [matFilter, plantFilter],
            //                         events: { dataReceived: () => oDialog.update() }
            //                     });
            //                 } else if (oTable.bindItems) {
            //                     oTable.bindAggregation("items", {
            //                         path: "ZSB_STOCK_TRANSFER_F4>/ZC_STOCK_TRANSFER_F4",
            //                         filters: [matFilter, plantFilter],
            //                         template: new sap.m.ColumnListItem({
            //                             cells: [
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Product}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>Plant}" }),
            //                                 new sap.m.Text({ text: "{ZSB_STOCK_TRANSFER_F4>StorageLocation}" })
            //                             ]
            //                         }),
            //                         events: { dataReceived: () => oDialog.update() }
            //                     });
            //                 }

            //                 oDialog.open();
            //                 sap.ui.core.BusyIndicator.hide();
            //             });
            //         });
            // },

            // onStockTransferStorageValueHelp: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     const oInput = oEvent.getSource();
            //     const oView = this.getView();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const that = this;

            //     // 🟩 Determine which input triggered (fromstorgaeloc or tostoragelocation)
            //     this._sStorageField = oInput.getBindingInfo("value").parts[0].path;

            //     if (!oContext) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const sRowPath = oContext.getPath();
            //     const oRowData = oContext.getObject();
            //     this._oEventModelRowPath = sRowPath;
            //     this._oEventModelRowData = oRowData;

            //     // 🟩 Require material first
            //     if (!oRowData.materialcode) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     // 🟩 Get relevant plant based on which input triggered
            //     const sRelevantPlant =
            //         this._sStorageField === "fromstorageloc"
            //             ? oRowData.fromplant
            //             : oRowData.toplant;

            //     if (!sRelevantPlant) {
            //         const sSide =
            //             this._sStorageField === "fromstorageloc" ? "From" : "To";
            //         sap.m.MessageBox.information(`Please select a ${sSide} Plant first.`);
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     // 🟩 Define filters for OData call
            //     const oMatFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.materialcode);
            //     const oPlantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sRelevantPlant);

            //     // 🟩 Lazy load the fragment only once
            //     if (!this._oStockTransferStorageDialog) {
            //         this._oStockTransferStorageDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage",
            //             this
            //         );
            //         oView.addDependent(this._oStockTransferStorageDialog);
            //     }

            //     const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

            //     // 🟩 Read OData with both filters
            //     oModel.read("/ZC_STOCK_STORAGE_LOC", {
            //         filters: [oMatFilter, oPlantFilter],
            //         success: function (oData) {
            //             const aStorageLocs = oData.results.map(item => ({
            //                 Product: (item.Product || "").trim(),
            //                 Plant: item.Plant || "",
            //                 StorageLocation: item.StorageLocation || ""
            //             }));

            //             const oJSON = new sap.ui.model.json.JSONModel({ StorageLocs: aStorageLocs });
            //             that._oStockTransferStorageDialog.setModel(oJSON, "VHModel");

            //             that._oStockTransferStorageDialog.open();
            //             sap.ui.core.BusyIndicator.hide();
            //         },
            //         error: function () {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Error fetching Storage Location data from OData");
            //         }
            //     });
            // },

            onStockTransferStorageValueHelp: function (oEvent) {
                sap.ui.core.BusyIndicator.show();

                const oInput = oEvent.getSource();
                const oView = this.getView();
                const oContext = oInput.getBindingContext("TabModel");
                const that = this;

                // 🟩 Determine which input triggered (fromstorgaeloc or tostoragelocation)
                this._sStorageField = oInput.getBindingInfo("value").parts[0].path;

                if (!oContext) {
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                const sRowPath = oContext.getPath();
                const oRowData = oContext.getObject();
                this._oEventModelRowPath = sRowPath;
                this._oEventModelRowData = oRowData;

                // 🟩 Require material first
                if (!oRowData.materialcode) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🟩 Get relevant plant based on which input triggered
                const sRelevantPlant =
                    this._sStorageField === "fromstorageloc"
                        ? oRowData.fromplant
                        : oRowData.toplant;

                if (!sRelevantPlant) {
                    const sSide =
                        this._sStorageField === "fromstorageloc" ? "From" : "To";
                    sap.m.MessageBox.information(`Please select a ${sSide} Plant first.`);
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🟩 Define filters for OData call
                const oMatFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.materialcode);
                const oPlantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sRelevantPlant);

                // 🟩 Lazy load the fragment only once with proper cleanup
                if (!this._oStockTransferStorageDialog) {
                    // Use Fragment.load instead of sap.ui.xmlfragment for better lifecycle management
                    sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage",
                        controller: this
                    }).then(function (oDialog) {
                        that._oStockTransferStorageDialog = oDialog;
                        oView.addDependent(that._oStockTransferStorageDialog);

                        // Now proceed with data loading
                        that._loadStorageLocationData(oMatFilter, oPlantFilter);
                    }).catch(function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        console.error("Error loading fragment:", oError);
                    });
                } else {
                    // Fragment already exists, just load the data
                    this._loadStorageLocationData(oMatFilter, oPlantFilter);
                }
            },

            // 🔄 Helper function to load data
            _loadStorageLocationData: function (oMatFilter, oPlantFilter) {
                const that = this;
                const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                // 🟩 Read OData with both filters
                oModel.read("/ZC_STOCK_STORAGE_LOC", {
                    filters: [oMatFilter, oPlantFilter],
                    success: function (oData) {
                        const aStorageLocs = oData.results.map(item => ({
                            Product: (item.Product || "").trim(),
                            Plant: item.Plant || "",
                            StorageLocation: item.StorageLocation || ""
                        }));

                        const oJSON = new sap.ui.model.json.JSONModel({ StorageLocs: aStorageLocs });
                        that._oStockTransferStorageDialog.setModel(oJSON, "VHModel");

                        that._oStockTransferStorageDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Storage Location data from OData");
                    }
                });
            },

            // 🔍 Live Search inside fragment
            onStockTransferStorageSearch: function (oEvent) {
                const sValue = oEvent.getParameter("newValue");
                const oTable = sap.ui.getCore().byId("idStockTransferStorageTable");

                if (!oTable) return;

                const oBinding = oTable.getBinding("items");

                if (sValue) {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            // ✅ When user selects a storage location
            // onStockTransferStorageSelected: function (oEvent) {
            //     const oSelectedItem = oEvent.getSource();
            //     const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

            //     const oModel = this.getView().getModel("TabModel");
            //     const oRow = oModel.getProperty(this._oEventModelRowPath);

            //     // Dynamically assign based on which input triggered
            //     if (this._sStorageField === "fromstorageloc") {
            //         oRow.fromstorageloc = oCtx.StorageLocation;
            //     } else if (this._sStorageField === "tostoragelocation") {
            //         oRow.tostoragelocation = oCtx.StorageLocation;
            //     }

            //     oModel.refresh(true);
            //     this._oStockTransferStorageDialog.close();
            //     this._oStockTransferStorageDialog.destroy();
            //     this._oStockTransferStorageDialog = null;
            // },

            onStockTransferStorageSelected: function (oEvent) {
                const oSelectedItem = oEvent.getSource();
                const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();
                const sSelectedStorage = oCtx.StorageLocation;

                const oModel = this.getView().getModel("TabModel");
                const oRow = oModel.getProperty(this._oEventModelRowPath);

                // Store original values for comparison
                const sOriginalFrom = oRow.fromstorageloc;
                const sOriginalTo = oRow.tostoragelocation;

                // Check which field is being updated
                if (this._sStorageField === "fromstorageloc") {
                    // If the selected value is same as current 'to' value
                    if (sSelectedStorage && sSelectedStorage === sOriginalTo) {
                        // DON'T set the new value, keep field empty or show warning
                        sap.m.MessageBox.warning(
                            "Cannot select same storage location '" + sSelectedStorage +
                            "' for both From and To fields.\n\n" +
                            "Please select a different storage location.",
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Duplicate Storage Location"
                            }
                        );
                        // Optionally clear the field to ensure it's empty
                        oRow.fromstorageloc = "";
                    } else {
                        // Only set if not a duplicate
                        oRow.fromstorageloc = sSelectedStorage;
                    }
                } else if (this._sStorageField === "tostoragelocation") {
                    // If the selected value is same as current 'from' value
                    if (sSelectedStorage && sSelectedStorage === sOriginalFrom) {
                        // DON'T set the new value, keep field empty or show warning
                        sap.m.MessageBox.warning(
                            "Cannot select same storage location '" + sSelectedStorage +
                            "' for both From and To fields.\n\n" +
                            "Please select a different storage location.",
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Duplicate Storage Location"
                            }
                        );
                        // Optionally clear the field to ensure it's empty
                        oRow.tostoragelocation = "";
                    } else {
                        // Only set if not a duplicate
                        oRow.tostoragelocation = sSelectedStorage;
                    }
                }

                oModel.refresh(true);
                this._oStockTransferStorageDialog.close();
            },


            // 🚪 Close handler (like Plant one)
            // onStockTransferStorageVHClose: function () {
            //     if (this._oStockTransferStorageDialog) {
            //         this._oStockTransferStorageDialog.close();
            //     }
            // },
            onStockTransferStorageVHClose: function () {
                if (this._oStockTransferStorageDialog) {
                    this._oStockTransferStorageDialog.destroy();
                    this._oStockTransferStorageDialog = null;
                }
            },








            // onTypeStorageLocationtostoragelocation: function (oEvent) {
            //     // Get the input control
            //     var oInput = oEvent.getSource();

            //     // Get the typed value
            //     var sValue = oEvent.getParameter("value");

            //     // Convert it to uppercase
            //     var sUpperCaseValue = sValue.toUpperCase();

            //     // Set the value back to the input field
            //     oInput.setValue(sUpperCaseValue);

            //     // Optional: update the model if two-way binding isn't already handling it
            //     var oContext = oInput.getBindingContext("TabModel");
            //     if (oContext) {
            //         oContext.getModel().setProperty("tostoragelocation", sUpperCaseValue, oContext);
            //     }
            // },
            // onTypeStorageLocationfromstorgaeloc: function (oEvent) {
            //     // Get the input control
            //     var oInput = oEvent.getSource();

            //     // Get the typed value
            //     var sValue = oEvent.getParameter("value");

            //     // Convert it to uppercase
            //     var sUpperCaseValue = sValue.toUpperCase();

            //     // Set the value back to the input field
            //     oInput.setValue(sUpperCaseValue);

            //     // Optional: update the model if two-way binding isn't already handling it
            //     var oContext = oInput.getBindingContext("TabModel");
            //     if (oContext) {
            //         oContext.getModel().setProperty("fromstorageloc", sUpperCaseValue, oContext);
            //     }
            // },

            onTypeStorageLocationfromstorgaeloc: function (oEvent) {
                // Get the input control
                var oInput = oEvent.getSource();

                // Get the typed value
                var sValue = oEvent.getParameter("value");

                // Convert it to uppercase
                var sUpperCaseValue = sValue.toUpperCase();

                // Set the value back to the input field
                oInput.setValue(sUpperCaseValue);

                // Get the context and row data
                var oContext = oInput.getBindingContext("TabModel");
                if (oContext) {
                    var oRow = oContext.getObject();

                    // Check if typed value matches the 'to' storage location
                    if (sUpperCaseValue && sUpperCaseValue === oRow.tostoragelocation) {
                        // Show warning message
                        sap.m.MessageToast.show("Cannot use same storage location as To Storage Location");

                        // Clear the current input field
                        sUpperCaseValue = "";
                        oInput.setValue("");
                    }

                    // Update the model with the (potentially cleared) value
                    oContext.getModel().setProperty("fromstorageloc", sUpperCaseValue, oContext);
                }
            },

            onTypeStorageLocationtostoragelocation: function (oEvent) {
                // Get the input control
                var oInput = oEvent.getSource();

                // Get the typed value
                var sValue = oEvent.getParameter("value");

                // Convert it to uppercase
                var sUpperCaseValue = sValue.toUpperCase();

                // Set the value back to the input field
                oInput.setValue(sUpperCaseValue);

                // Get the context and row data
                var oContext = oInput.getBindingContext("TabModel");
                if (oContext) {
                    var oRow = oContext.getObject();

                    // Check if typed value matches the 'from' storage location
                    if (sUpperCaseValue && sUpperCaseValue === oRow.fromstorageloc) {
                        // Show warning message
                        sap.m.MessageToast.show("Cannot use same storage location as From Storage Location");

                        // Clear the current input field
                        sUpperCaseValue = "";
                        oInput.setValue("");
                    }

                    // Update the model with the (potentially cleared) value
                    oContext.getModel().setProperty("tostoragelocation", sUpperCaseValue, oContext);
                }
            },













            onBatchFragmentOpen: function (oEvent) {
                this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
                var oView = this.getView();
                var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
                var oRow = oCtx.getObject();

                // 🟩 Ensure material is selected first
                if (!oRow.materialcode) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    return;
                }

                // 🟩 Ensure Plant is selected if required
                if (!oRow.fromplant && !oRow.toplant) {
                    sap.m.MessageBox.information("Please select a Plant first.");
                    return;
                }
                // 🟩 Ensure Storage Location is selected if available
                if (!oRow.fromstorageloc) {
                    sap.m.MessageBox.information("Please select a Storage Location first.");
                    return;
                }

                // Lazy-load fragment
                if (!this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
                        this
                    );
                    oView.addDependent(this._oStockTransferBatchDialog);
                }

                // Load data before opening - using material, plant and storage location from current row
                this._loadStockTransferBatchData(oRow.materialcode, oRow.fromplant, oRow.fromstorageloc);
            },



            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     const oBatchModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB");
            //     const oStockModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }

            //     this._oBusyDialog.open();

            //     // Build filters for both services
            //     const aBatchFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     const aStockFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant)
            //     ];

            //     // Read from both OData services
            //     Promise.all([
            //         new Promise((resolve, reject) => {
            //             oBatchModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
            //                 filters: aBatchFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         }),
            //         new Promise((resolve, reject) => {
            //             oStockModel.read("/ZC_STOCK_BATCH", {
            //                 filters: aStockFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         })
            //     ]).then(function (results) {
            //         that._oBusyDialog.close();

            //         const oBatchData = results[0];
            //         const oStockData = results[1];

            //         console.log("✅ Batch data received:", oBatchData);
            //         console.log("✅ Stock data received:", oStockData);

            //         // Create a map of ALL properties from stock data keyed by Batch
            //         const oStockDataMap = {};
            //         oStockData.results.forEach(function (item) {
            //             if (item.Batch) {
            //                 // Store all properties from stock data for this batch
            //                 oStockDataMap[item.Batch] = {
            //                     ...item, // Spread all properties from stock data item
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             }
            //         });

            //         // 🛠 FILTER MANUALLY BY STORAGE LOCATION (Backend not filtering)
            //         const aFilteredBatchData = oBatchData.results.filter(function (batchItem) {
            //             return batchItem.StorageLocation === sStorageLoc;
            //         });

            //         console.log("🔍 Filtered batch data (Frontend Filter Applied):", aFilteredBatchData);

            //         // Merge batch data with ALL stock data properties
            //         const aMergedBatches = aFilteredBatchData.map(function (batchItem) {
            //             const stockItem = oStockDataMap[batchItem.Batch] || {};
            //             return {
            //                 ...batchItem,  // Batch data properties
            //                 ...stockItem   // Stock data properties (will override batch data if same property names)
            //             };
            //         });

            //         // Create JSON model from merged data
            //         const oJSONModel = new sap.ui.model.json.JSONModel({
            //             Batches: aMergedBatches
            //         });

            //         // Set model to the fragment dialog
            //         that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //         console.log("✅ Bound rows with merged data:", oJSONModel.getData());

            //         // Debug: Check if BatchBySupplier is in the merged data
            //         console.log("🔍 Sample merged item:", aMergedBatches.length > 0 ? aMergedBatches[0] : "No data");
            //         if (aMergedBatches.length > 0) {
            //             console.log("🔍 BatchBySupplier value in merged data:", aMergedBatches[0].BatchBySupplier);
            //         }

            //         // Open the dialog
            //         that._oStockTransferBatchDialog.open();

            //     }).catch(function (oError) {
            //         that._oBusyDialog.close();
            //         sap.m.MessageToast.show("Failed to load batch data.");
            //         console.error("❌ OData Error:", oError);
            //     });
            // },
            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     // Use the new single OData model
            //     const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }
            //     this._oBusyDialog.open();

            //     // Build filters for the new service (property names: Product, Plant, StorageLocation)
            //     const aFilters = [
            //         new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     // Read from the new entity set "/ZC_STOCK_BATCH_F4"
            //     oBatchModel.read("/ZC_STOCK_BATCH_F4", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             that._oBusyDialog.close();

            //             console.log("✅ Batch/Stock data received:", oData);

            //             // The response contains an array 'results'
            //             const aRawData = oData.results || [];

            //             // Prepare merged data (no merging needed, but map Supplier -> BatchBySupplier)
            //             const aMergedBatches = aRawData.map(function (item) {
            //                 return {
            //                     ...item,                           // keep all original fields
            //                     BatchBySupplier: item.Supplier || "",  // map Supplier to BatchBySupplier for fragment compatibility
            //                     // Ensure ShelfLifeExpirationDate is a Date object (if needed for sorting)
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             });

            //             // Create JSON model
            //             const oJSONModel = new sap.ui.model.json.JSONModel({
            //                 Batches: aMergedBatches
            //             });

            //             // Set model on the dialog
            //             that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //             console.log("✅ Bound rows with data:", oJSONModel.getData());

            //             // Open dialog
            //             that._oStockTransferBatchDialog.open();
            //         },
            //         error: function (oError) {
            //             that._oBusyDialog.close();
            //             sap.m.MessageToast.show("Failed to load batch data.");
            //             console.error("❌ OData Error:", oError);
            //         }
            //     });
            // },
            _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
                const that = this;

                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading batches...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                const aFilters = [
                    new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                oBatchModel.read("/ZC_STOCK_BATCH_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        that._oBusyDialog.close();

                        console.log("✅ Batch/Stock data received:", oData);

                        const aRawData = oData.results || [];

                        // 🔁 Deduplicate by Batch (keep first occurrence)
                        const uniqueMap = new Map();
                        for (const item of aRawData) {
                            if (!uniqueMap.has(item.Batch)) {
                                // Map fields for fragment compatibility
                                const mappedItem = {
                                    ...item,
                                    Material: item.Product || "",               // for column "Material"
                                    BatchBySupplier: item.Supplier || "",       // for column "BatchBySupplier"
                                    ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
                                        new Date(item.ShelfLifeExpirationDate) : null
                                };
                                uniqueMap.set(item.Batch, mappedItem);
                            }
                        }

                        // Convert map values back to array
                        const aUniqueBatches = Array.from(uniqueMap.values());

                        console.log(`✅ Deduplicated: ${aRawData.length} → ${aUniqueBatches.length} unique batches`);

                        const oJSONModel = new sap.ui.model.json.JSONModel({
                            Batches: aUniqueBatches
                        });

                        that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
                        that._oStockTransferBatchDialog.open();
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // Optional: Add search function for the new field
            onStockTransferBatchSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                var oTable = sap.ui.getCore().byId("idStockTransferBatchTable");
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");

                if (sValue) {
                    var aFilters = [
                        new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Batch", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("ShelfLifeExpirationDate", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            onStockTransferBatchSelected: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oCtx = oSelectedItem.getBindingContext("BatchModel").getObject();

                console.log("✅ Selected batch data:", oCtx);

                // FIX: use the correct source input field variable
                if (this._oBatchInputSource) {
                    var oRowCtx = this._oBatchInputSource.getBindingContext("TabModel");

                    // Update TabModel values
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/batch", oCtx.Batch);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/storagelocation", oCtx.StorageLocation);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/Batchqty", oCtx.MatlWrhsStkQtyInMatlBaseUnit);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/vendorbatch", oCtx.BatchBySupplier || "");


                    // Update the input field UI value
                    this._oBatchInputSource.setValue(oCtx.Batch);

                    console.log("✅ Updated TabModel with batch:", oCtx.Batch, "and storage location:", oCtx.StorageLocation);
                }

                // Close dialog
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },



            onStockTransferBatchVHClose: function () {
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },



















            onStockTransferRequestNoValueHelp: function (oEvent) {
                this._oInputField = oEvent.getSource();
                var oView = this.getView();

                // Show loading
                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading requests...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                var oModel = oView.getModel("ZSB_STOCK_TRANSFER_GT");
                var that = this;

                // Read OData from ZSB_STOCK_TRANSFER_GT service
                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    urlParameters: {
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        var oSeen = new Set();

                        var aAll = oData.results
                            .map(function (item) {
                                return (item.requestno || "").trim();
                            })
                            .filter(function (requestno) {
                                if (!requestno || oSeen.has(requestno)) {
                                    return false;
                                }
                                oSeen.add(requestno);
                                return true;
                            })
                            // Add sorting here - ascending order
                            .sort(function (a, b) {
                                // Compare as strings for alphanumeric values
                                return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
                            })
                            .map(function (requestno) {
                                return { requestno: requestno };
                            });

                        console.log("Request No Value Help Loaded:", aAll.length, "records");

                        // Create JSON model
                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            Requests: aAll
                        });

                        // Load and configure ValueHelpDialog
                        that.loadFragment({
                            name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferRequestNo"
                        }).then(function (oDialog) {
                            that._oStockTransferRequestNoDialog = oDialog;
                            that.getView().addDependent(oDialog);

                            // Set the model for the dialog
                            oDialog.setModel(oJSONModel, "VHModel");

                            // Configure table binding
                            that._configureRequestNoValueHelpDialogTable(oDialog, aAll);

                            oDialog.open();
                        }).catch(function (oError) {
                            that._oBusyDialog.close();
                            sap.m.MessageToast.show("Error loading value help dialog");
                            console.error(oError);
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Error fetching requests from OData");
                        console.error(oError);
                    }
                });
            },

            _configureRequestNoValueHelpDialogTable: function (oDialog, aData) {
                oDialog.getTableAsync().then(function (oTable) {
                    // Set model for the table
                    var oModel = new sap.ui.model.json.JSONModel({ Requests: aData });
                    oTable.setModel(oModel, "VHModel");

                    if (oTable.setGrowing) {
                        oTable.setGrowing(false);
                    }

                    // For sap.ui.table.Table (Desktop)
                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", {
                            path: "VHModel>/Requests"
                        });

                        // Define columns - only requestno
                        var aColumns = [
                            {
                                label: "Request No",
                                template: new sap.m.Text({ text: "{VHModel>requestno}" })
                            }
                        ];

                        aColumns.forEach(function (oColConfig) {
                            var oColumn = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: oColConfig.label }),
                                template: oColConfig.template,
                                width: "150px"
                            });
                            oTable.addColumn(oColumn);
                        });
                    }

                    // For sap.m.Table (Mobile)
                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", {
                            path: "VHModel>/Requests",
                            template: new sap.m.ColumnListItem({
                                cells: [
                                    new sap.m.Text({ text: "{VHModel>requestno}" })
                                ]
                            })
                        });

                        // Add column
                        oTable.addColumn(new sap.m.Column({
                            header: new sap.m.Label({ text: "Request No" })
                        }));
                    }
                });
            },

            onStockTransferRequestNoFilterSearch: function (oEvent) {
                var sSearchQuery = oEvent.getParameter("searchQuery"),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilterStrings = [];

                // Filter bar values
                aSelectionSet.forEach(function (oControl) {
                    var v = oControl.getValue();
                    if (v) {
                        aFilterStrings.push(`substringof('${v}', ${oControl.getName()})`);
                    }
                });

                // Global search
                if (sSearchQuery) {
                    aFilterStrings.push(
                        "substringof('" + sSearchQuery + "', requestno)"
                    );
                }

                var sFilterQuery = aFilterStrings.join(" and ");

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_GT"); // Use default model or specify your model name
                var that = this;

                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Searching...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                oModel.read("/ZC_STOCK_TRANSFER_GT", {
                    urlParameters: {
                        "$filter": sFilterQuery,
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        // var oJSON = new sap.ui.model.json.JSONModel({ Requests: oData.results });
                        var oSeen = new Set();

                        var aUnique = oData.results
                            .map(function (item) {
                                return (item.requestno || "").trim();
                            })
                            .filter(function (requestno) {
                                if (!requestno || oSeen.has(requestno)) {
                                    return false;
                                }
                                oSeen.add(requestno);
                                return true;
                            })
                            .map(function (requestno) {
                                return { requestno: requestno };
                            });

                        var oJSON = new sap.ui.model.json.JSONModel({ Requests: aUnique });

                        var oDialog = that._oStockTransferRequestNoDialog;
                        oDialog.setModel(oJSON, "VHModel");

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(oJSON, "VHModel");

                            if (oTable.bindRows) {
                                oTable.bindRows("VHModel>/Requests");
                            }
                            if (oTable.bindItems) {
                                oTable.bindItems({
                                    path: "VHModel>/Requests",
                                    template: oTable.getBindingInfo("items").template
                                });
                            }
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        console.error(oError);
                        sap.m.MessageToast.show("Search failed.");
                    }
                });
            },

            onStockTransferRequestNoOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");

                if (aTokens && aTokens.length > 0) {
                    var oSelectedItem = aTokens[0];
                    var sRequestNo = oSelectedItem.getKey();

                    if (this._oInputField) {
                        this._oInputField.setValue(sRequestNo);

                        // Optional: Trigger change event or additional logic
                        this._oInputField.fireChange({
                            value: sRequestNo
                        });
                    }
                }

                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.close();
                }
            },

            onStockTransferRequestNoCancelPress: function () {
                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.close();
                }
            },

            onStockTransferRequestNoAfterClose: function () {
                // Clean up if needed
                if (this._oStockTransferRequestNoDialog) {
                    this._oStockTransferRequestNoDialog.destroy();
                    this._oStockTransferRequestNoDialog = null;
                }
                this._oInputField = null;
            },





        });
    });