sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/IconPool",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Component",
    "sap/ui/core/UIComponent",
    "sap/m/routing/Router",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "sap/m/PDFViewer",
    "bando/util/jspdf/html2canvasmin",
    "bando/util/jspdf/jspdfmin",
    "bando/util/importfile/importexcelfile",
  ],
  function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
    "use strict";

    return BaseController.extend("bando.controller.belts_production.FGProcessPlan", {
      onInit: function () {
        this._fetchPostedData(); // Initial load


        var TabModel = new sap.ui.model.json.JSONModel({
          Samples: [

          ]

        });
        this.getView().setModel(TabModel, "TabModel");


        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }

        });

        this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");


        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.getRoute("FGProcessPlan").attachMatched(this._onRouteMatched, this); // Re-fetch on return
      },




      _onRouteMatched: function () {
        this._fetchPostedData(); // Always refresh from backend on route match
      },


      // _fetchPostedData: function () {
      //   var oView = this.getView();

      //   var Tab_SelectAll = new sap.ui.model.json.JSONModel({
      //     Samples: {
      //       selectall: false
      //     }
      //   });
      //   oView.setModel(Tab_SelectAll, "Tab_SelectAll");

      //   // Safely get the backend model
      //   var oModel = this.getOwnerComponent().getModel("ZSB_FG_PROCESS_PLAN");
      //   if (!oModel) {
      //     sap.m.MessageBox.error("Model 'ZSB_FG_PROCESS_PLAN' not found.");
      //     return;
      //   }

      //   // Show busy indicator during loading
      //   oView.setBusy(true);

      //   var prodordFilter = new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '');

      //   // Call the read function
      //   oModel.read("/ZC_FG_PROCESS_PLAN", {
      //     filters: [prodordFilter],

      //     success: function (oData) {
      //       // Create a new JSON model and set the data
      //       var oJSONModel = new sap.ui.model.json.JSONModel();
      //       oJSONModel.setData({
      //         Samples: oData.results
      //       });

      //       // Attach to view with name 'TabModel'
      //       oView.setModel(oJSONModel, "TabModel");

      //       // ✅ Call ComboBox loader after data is set
      //       this._loadMachineComboBox();

      //       oView.setBusy(false);
      //       oModel.refresh();
      //     }.bind(this), // ✅ BIND the controller context here

      //     error: function (oError) {
      //       oView.setBusy(false);
      //       sap.m.MessageBox.error("Failed to retrieve Mixing Plan data.");
      //       console.error("OData read error:", oError);
      //     }
      //   });
      // },




      _fetchPostedData: function () {
        var oView = this.getView();

        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }
        });
        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

        // Safely get the backend model
        var oModel = this.getOwnerComponent().getModel("ZSB_FG_PROCESS_PLAN");
        if (!oModel) {
          sap.m.MessageBox.error("Model 'ZSB_FG_PROCESS_PLAN' not found.");
          return;
        }

        // Show busy indicator during loading
        oView.setBusy(true);

        var prodordFilter = new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '');

        // Call the read function with increased limit
        oModel.read("/ZC_FG_PROCESS_PLAN", {
          filters: [prodordFilter],
          urlParameters: {
            "$top": 10000  // Increased from default to 10,000 records
          },
          success: function (oData) {
            // Create a new JSON model and set the data
            var oJSONModel = new sap.ui.model.json.JSONModel();
            oJSONModel.setData({
              Samples: oData.results
            });

            // Attach to view with name 'TabModel'
            oView.setModel(oJSONModel, "TabModel");

            // ✅ Call ComboBox loader after data is set
            this._loadMachineComboBox();

            oView.setBusy(false);
            oModel.refresh();

            // Optional: Log how many records were loaded
            console.log("Loaded " + (oData.results ? oData.results.length : 0) + " records");
          }.bind(this), // ✅ BIND the controller context here

          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Failed to retrieve FGProcess Plan data.");
            console.error("OData read error:", oError);
          }
        });
      },

      _loadMachineComboBox: function () {
        var oView = this.getView();
        var oTabModel = oView.getModel("TabModel");
        var aSamples = oTabModel.getProperty("/Samples") || [];

        // Get unique machine numbers
        var aUniqueMachineNumbers = [...new Set(aSamples.map(item => item.machinenumber))];

        // Convert to ComboBox item format
        var aComboBoxItems = aUniqueMachineNumbers.map(function (sMachineNumber) {
          return {
            key: sMachineNumber,
            text: sMachineNumber
          };
        });

        // Create JSON model for ComboBox
        var oMachineModel = new sap.ui.model.json.JSONModel({
          MachineNumbers: aComboBoxItems
        });

        // Set the model to the view
        oView.setModel(oMachineModel, "MachineModel");

        // Clear selection in ComboBox (optional)
        var oComboBox = oView.byId("inputMachineNumberFilter");
        if (oComboBox) {
          oComboBox.setSelectedKey("");
        }
      },


      onSelectAll: function (oEvent) {
        const bSelected = oEvent.getParameter("selected");
        const oTableModel = this.getView().getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples") || [];

        aRows.forEach(row => {
          row.__selected = bSelected;
        });

        oTableModel.setProperty("/Samples", aRows);
      },



      onAddRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        // Create a blank row (add fields as required)
        var oNewRow = {
          sap_uuid: "",
          plant: "1200",

          // Auto-generated
          bipllotno: "",

          // User input
          shift: "",
          slabno: "",
          speccode: "",
          lotno: "",

          // Material data (from value help)
          materialcode: "",
          description: "",

          // Production details
          machinenumber: "",
          productionorderqty: "",
          productionordstartdate: "",

          // Lot / Batch
          // lotbatchno: "",
          storagelocation: "",

          // Order info
          productionorderno: "",
          // statusOfProdOrd: "",

          // Status flags
          savedstatus: "",
          __selected: false
        };


        aData.push(oNewRow);
        oModel.setProperty("/Samples", aData);
      },



      onRemoveRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        var aRowsToKeep = [];
        var bAnyDeleted = false;
        var bAnyBlocked = false;

        aData.forEach(function (row) {
          if (row.__selected) {
            if (!row.sap_uuid || row.sap_uuid.trim() === "") {
              // Deletable row — skip adding to keep list
              bAnyDeleted = true;
            } else {
              // Selected but not deletable — keep it
              aRowsToKeep.push(row);
              bAnyBlocked = true;
            }
          } else {
            // Not selected — keep it
            aRowsToKeep.push(row);
          }
        });

        oModel.setProperty("/Samples", aRowsToKeep);

        // Show appropriate message
        if (bAnyDeleted && bAnyBlocked) {
          sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
        } else if (bAnyBlocked && !bAnyDeleted) {
          sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
        } else if (bAnyDeleted) {
          sap.m.MessageBox.success("Selected rows removed successfully.");
        } else {
          sap.m.MessageBox.information("No rows were selected for deletion.");
        }
      },


      // onNumericLiveChange: function (oEvent) {
      //     var sValue = oEvent.getParameter("value");

      //     // Remove any non-numeric characters (except decimal if needed)
      //     var sCleanedValue = sValue.replace(/[^\d]/g, ""); // only digits allowed

      //     // Optional: allow decimals
      //     // var sCleanedValue = sValue.replace(/[^0-9.]/g, "");

      //     if (sValue !== sCleanedValue) {
      //         oEvent.getSource().setValue(sCleanedValue);
      //     }
      // },
      onNumericLiveChange: function (oEvent) {
        var sValue = oEvent.getParameter("value");

        // Allow digits, commas, and periods
        var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

        // Optional (if you want to normalize double dots or commas)
        // Limit to only one dot and one comma max
        var hasDot = false;
        var hasComma = false;
        sCleanedValue = sCleanedValue
          .split("")
          .filter(char => {
            if (char === "." && !hasDot) {
              hasDot = true;
              return true;
            } else if (char === "," && !hasComma) {
              hasComma = true;
              return true;
            } else if (/\d/.test(char)) {
              return true;
            }
            return false;
          })
          .join("");

        // Set the cleaned value back if changed
        if (sValue !== sCleanedValue) {
          oEvent.getSource().setValue(sCleanedValue);
        }
      },













      onBeforeRendering: function () {
        var oUserInfo = sap.ushell.Container.getService("UserInfo");
        this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
      },


      onFilterProdStart: function () {
        const oView = this.getView();
        const oDatePicker = oView.byId("dpFilterProdStart");
        const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // ODataModel
        const oTabModel = oView.getModel("TabModel");      // Local JSONModel for table binding

        // Get selected date
        const oDate = oDatePicker.getDateValue();

        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '') // Only empty production order
        ];

        if (oDate) {
          // Format date to yyyy-MM-dd
          const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          const sSelectedDate = oDateFormat.format(oDate);

          // Add date filter
          aFilters.push(new sap.ui.model.Filter("productionordstartdate", sap.ui.model.FilterOperator.EQ, sSelectedDate));
        }

        sap.ui.core.BusyIndicator.show(0);

        // Perform OData read with combined filters
        oModel.read("/ZC_FG_PROCESS_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []); // No results
              sap.m.MessageToast.show("No records found for selected criteria");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend");
          }
        });
      },
      onFilterMachineNumber: function () {
        const oView = this.getView();
        const oComboBox = oView.byId("inputMachineNumberFilter");
        const sSelectedMachine = oComboBox.getSelectedKey();

        const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // Your ODataModel
        const oTabModel = oView.getModel("TabModel");      // Your table model

        // Validate selection
        if (!sSelectedMachine) {
          // Reload full dataset
          this._fetchPostedData();
          return;
        }


        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, ''), // Only empty prod orders
          new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, sSelectedMachine)
        ];

        // Show loading indicator
        sap.ui.core.BusyIndicator.show(0);

        // Perform filtered read
        oModel.read("/ZC_FG_PROCESS_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []);
              sap.m.MessageToast.show("No records found for selected Machine Number");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend.");
          }
        });
      },
















      // onImportExl: function () {

      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("calplantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //       // 🚨 Collect all errors during mapping
      //       const allErrors = [];
      //       const mapped = jsonData.map((row, rowIndex) => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // 🔹 Handle Excel numeric serial date
      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               const utcValue = utcDays * 86400; // seconds
      //               rawValue = new Date(utcValue * 1000); // convert to JS Date
      //             }

      //             // 🔹 Handle Excel text date in dd-MM-yyyy format
      //             else if (field.toLowerCase().includes("date") && typeof rawValue === "string") {
      //               const parts = rawValue.split("-");
      //               if (parts.length === 3) {
      //                 const [dd, mm, yyyy] = parts.map(p => parseInt(p, 10));
      //                 if (!isNaN(dd) && !isNaN(mm) && !isNaN(yyyy)) {
      //                   rawValue = new Date(yyyy, mm - 1, dd);
      //                 }
      //               }
      //             }
      //             // 🔹 Handle shift field - only 1 character & only A, B, or C
      //             else if (field === "shift") {
      //               // If shift is missing
      //               if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               let value = String(rawValue).trim().toUpperCase();

      //               // If more than one character → invalid
      //               if (value.length !== 1) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               // Only allow A, B, C
      //               if (!["A", "B", "C"].includes(value)) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               rawValue = value; // Assign cleaned value
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });

      //       // 🚨 Check if we have any errors during mapping
      //       if (allErrors.length > 0) {
      //         // Show all mapping errors at once
      //         const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // 🧠 STEP 1: Gather all unique material codes and descriptions
      //       const aUniqueMaterials = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.materialcode || "").trim())
      //           .filter(Boolean)
      //       )];

      //       const aUniqueDescriptions = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.description || "").trim())
      //           .filter(Boolean)
      //       )];

      //       if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
      //         sap.m.MessageBox.error("No material data found in the Excel file.");
      //         return;
      //       }

      //       // 🧠 STEP 2: Build filters for both code and description
      //       const filters = [];
      //       if (aUniqueMaterials.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
      //           and: false
      //         }));
      //       }
      //       if (aUniqueDescriptions.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
      //           and: false
      //         }));
      //       }

      //       // 🧠 STEP 3: Fetch material master data
      //       const oMaterialResults = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters,
      //           success: data => resolve(data.results || []),
      //           error: reject
      //         });
      //       });

      //       // 🆕 Build lookup maps with ExternalProductGroup information
      //       const codeMap = {}; // Key: Product
      //       const nameMap = {}; // Key: ProductName

      //       oMaterialResults.forEach(entry => {
      //         const code = String(entry.Product).trim();
      //         const name = String(entry.ProductName).trim();
      //         const extProdGroup = String(entry.ExternalProductGroup || "").trim();

      //         codeMap[code] = {
      //           Product: code,
      //           ProductName: name,
      //           ExternalProductGroup: extProdGroup
      //         };

      //         nameMap[name] = {
      //           Product: code,
      //           ProductName: name,
      //           ExternalProductGroup: extProdGroup
      //         };
      //       });

      //       // 🧠 STEP 4: Validate & enrich each row
      //       aSelectedRows.forEach((row, idx) => {
      //         const code = String(row.materialcode || "").trim();
      //         const desc = String(row.description || "").trim();
      //         const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //         // 🆕 Set default plant to 1200 if not entered by user
      //         if (!row.plant || String(row.plant || "").trim() === "") {
      //           row.plant = "1200";
      //         }

      //         if (!code && !desc) {
      //           aErrors.push(`Row ${rowNumber}: Material code and description both missing.`);
      //           return;
      //         }

      //         if (code && !desc) {
      //           // Only code provided
      //           const material = codeMap[code];
      //           if (material) {
      //             // 🆕 Check if it's a CALENDER material
      //             if (material.ExternalProductGroup !== "CALENDER") {
      //               aErrors.push(`Row ${rowNumber}: Material "${code}" is not a CALENDER material.`);
      //             } else {
      //               row.description = material.ProductName;
      //             }
      //           } else {
      //             aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
      //           }
      //         } else if (!code && desc) {
      //           // Only description provided
      //           const material = nameMap[desc];
      //           if (material) {
      //             // 🆕 Check if it's a CALENDER material
      //             if (material.ExternalProductGroup !== "CALENDER") {
      //               aErrors.push(`Row ${rowNumber}: Material "${desc}" is not a CALENDER material.`);
      //             } else {
      //               row.materialcode = material.Product;
      //             }
      //           } else {
      //             aErrors.push(`Row ${rowNumber}: Description "${desc}" not found in material master.`);
      //           }
      //         } else if (code && desc) {
      //           // Both code and description provided
      //           const material = codeMap[code];
      //           if (!material) {
      //             aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
      //           } else if (material.ProductName !== desc) {
      //             aErrors.push(
      //               `Row ${rowNumber}: Description "${desc}" does not match material "${code}" (expected "${material.ProductName}").`
      //             );
      //           } else if (material.ExternalProductGroup !== "CALENDER") {
      //             // 🆕 Check if it's a CALENDER material
      //             aErrors.push(`Row ${rowNumber}: Material "${code}" ("${desc}") is not a CALENDER material.`);
      //           }
      //         }

      //         // 🚨 Validate shift field again during validation phase
      //         if (row.shift) {
      //           const shiftValue = String(row.shift).trim().toUpperCase();
      //           if (!["A", "B", "C"].includes(shiftValue)) {
      //             aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: A, B, C`);
      //           } else if (shiftValue.length !== 1) {
      //             aErrors.push(`Row ${rowNumber}: Shift value must be exactly 1 character.`);
      //           }
      //         } else {
      //           aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //         }

      //         const finalDesc = String(row.description || "").trim();
      //         if (finalDesc) {
      //           const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //           row.compoundcode = base;
      //         }

      //         // 🆕 Set default values if productionorderqty or baseunit are missing
      //         if (!row.productionorderqty || String(row.productionorderqty || "").trim() === "") {
      //           row.productionorderqty = "0.000";
      //         }
      //         if (!row.baseunit || String(row.baseunit || "").trim() === "") {
      //           row.baseunit = "";
      //         }
      //       });

      //       // 🧠 STEP 5: Validate Machine Combinations
      //       const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //       if (rowsWithMachine.length > 0) {
      //         const comboFilters = new sap.ui.model.Filter({
      //           filters: rowsWithMachine.map(row =>
      //             new sap.ui.model.Filter({
      //               filters: [
      //                 new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //                 new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //                 new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //               ],
      //               and: true
      //             })
      //           ),
      //           and: false
      //         });

      //         const validCombos = await new Promise((resolve, reject) => {
      //           oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //             filters: [comboFilters],
      //             success: data => resolve(
      //               (data.results || []).map(
      //                 r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //               )
      //             ),
      //             error: reject
      //           });
      //         });

      //         const invalidCombos = rowsWithMachine
      //           .map((row, idx) => {
      //             const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //             if (!validCombos.includes(key)) {
      //               const trueIdx = aSelectedRows.indexOf(row);
      //               return `Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
      //             }
      //             return null;
      //           })
      //           .filter(Boolean);

      //         if (invalidCombos.length > 0) {
      //           aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
      //         }
      //       }

      //       // 🚫 STEP 6: Show all accumulated errors together
      //       if (aErrors.length > 0) {
      //         const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       // ✅ STEP 7: Import Validated & Enriched Data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(aSelectedRows);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");

      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }

      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },





      //final export code 





      // onImportExl: function () {
      //   const that = this;

      //   // Helper function to generate BIPL LOT NO for a row
      //   function generateBiplLotNoForRow(row) {
      //     var productionDate = row.productionordstartdate;
      //     var slabNo = row.slabno;
      //     var specCode = row.speccode;

      //     if (!productionDate || !slabNo || !specCode) {
      //       return "";
      //     }

      //     try {
      //       var dateStr;

      //       // Handle different date formats
      //       if (productionDate instanceof Date) {
      //         var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //           pattern: "yyyy-MM-dd"
      //         });
      //         dateStr = oDateFormat.format(productionDate);
      //       } else {
      //         dateStr = productionDate;
      //       }

      //       // Ensure dateStr has the right format
      //       if (dateStr.length < 10) {
      //         return "";
      //       }

      //       // Extract components
      //       var year = dateStr.substring(2, 4); // Last 2 digits of year
      //       var month = dateStr.substring(5, 7); // Month
      //       var day = dateStr.substring(8, 10); // Day

      //       // Pad slabNo to 4 digits with leading zeros if not already done
      //       var paddedSlabNo = slabNo;
      //       if (slabNo && slabNo.length < 4) {
      //         paddedSlabNo = ("0000" + slabNo).slice(-4);
      //       }

      //       // Build the BIPL LOT NO
      //       var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //       return biplLotNo;

      //     } catch (error) {
      //       console.error("Error generating BIPL LOT NO:", error);
      //       return "";
      //     }
      //   }

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("FGProcessPlantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //       // Collect all errors during mapping
      //       const allErrors = [];
      //       const mapped = jsonData.map((row, rowIndex) => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // Handle Excel numeric serial date for productionordstartdate
      //             if (field === "productionordstartdate") {
      //               // Excel already gives Date object when cellDates:true
      //               if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                 rawValue = rawValue;
      //               }
      //               // Excel numeric date
      //               else if (typeof rawValue === "number") {
      //                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //               }
      //               // Excel text date
      //               else if (typeof rawValue === "string" && rawValue) {
      //                 const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                 const oParsed = oParse.parse(rawValue);
      //                 rawValue = oParsed || null;
      //               }
      //             }
      //             // Handle slabno field - pad to 4 digits
      //             else if (field === "slabno") {
      //               if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                 let sValue = String(rawValue).trim();
      //                 // Pad to 4 digits with leading zeros
      //                 if (sValue.length < 4) {
      //                   rawValue = ("0000" + sValue).slice(-4);
      //                 } else {
      //                   rawValue = sValue;
      //                 }
      //               }
      //             }
      //             // Handle speccode field - pad to 4 digits
      //             else if (field === "speccode") {
      //               if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                 let sValue = String(rawValue).trim();
      //                 // Pad to 4 digits with leading zeros
      //                 if (sValue.length < 4) {
      //                   rawValue = ("0000" + sValue).slice(-4);
      //                 } else {
      //                   rawValue = sValue;
      //                 }
      //               }
      //             }
      //             // Handle shift field - only 1 character & only A, B, or C
      //             else if (field === "shift") {
      //               // If shift is missing
      //               if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                 rawValue = "";
      //                 return;
      //               }

      //               let value = String(rawValue).trim().toUpperCase();

      //               // If more than one character → invalid
      //               if (value.length !== 1) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = "";
      //                 return;
      //               }

      //               // Only allow A, B, C
      //               if (!["A", "B", "C"].includes(value)) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = "";
      //                 return;
      //               }

      //               rawValue = value;
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });

      //       // Check if we have any errors during mapping
      //       if (allErrors.length > 0) {
      //         const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //       const excelCombinationMap = new Map();
      //       aSelectedRows.forEach((row, idx) => {
      //         const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //         // Format the date from Excel
      //         let dateValue = row.productionordstartdate;
      //         let dateString = "";

      //         if (dateValue) {
      //           if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //             const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //             dateString = oFmt.format(dateValue);
      //           } else if (typeof dateValue === "string") {
      //             // Try to parse the string date
      //             const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //             const oParsed = oParse.parse(dateValue);
      //             if (oParsed) {
      //               const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //               dateString = oFmt.format(oParsed);
      //             }
      //           }
      //         }

      //         const slabValue = (row.slabno || "").toString().trim();

      //         // Only check if both values are present
      //         if (dateString && slabValue) {
      //           const combinationKey = `${dateString}|${slabValue}`;

      //           if (excelCombinationMap.has(combinationKey)) {
      //             const firstRow = excelCombinationMap.get(combinationKey);
      //             aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //           } else {
      //             excelCombinationMap.set(combinationKey, rowNumber);
      //           }
      //         }
      //       });

      //       // 🆕 STEP 2: Check for past dates in imported data
      //       const oToday = new Date();
      //       oToday.setHours(0, 0, 0, 0);

      //       aSelectedRows.forEach((row, idx) => {
      //         const rowNumber = idx + 2;
      //         let dateValue = row.productionordstartdate;

      //         if (dateValue) {
      //           let selectedDate = null;

      //           if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //             selectedDate = new Date(dateValue);
      //             selectedDate.setHours(0, 0, 0, 0);
      //           } else if (typeof dateValue === "string") {
      //             const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //             const oParsed = oParse.parse(dateValue);
      //             if (oParsed) {
      //               selectedDate = new Date(oParsed);
      //               selectedDate.setHours(0, 0, 0, 0);
      //             }
      //           }

      //           // Check if date is in the past
      //           if (selectedDate && selectedDate < oToday) {
      //             const formattedDate = that._formatToModelDateString(selectedDate);
      //             aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
      //           }
      //         }
      //       });

      //       // 🆕 STEP 3: Gather all unique spec codes and materials
      //       const aUniqueSpecCodes = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.speccode || "").trim())
      //           .filter(code => code && code.length >= 4)
      //       )];

      //       const aUniqueMaterials = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.materialcode || "").trim())
      //           .filter(Boolean)
      //       )];

      //       const aUniqueDescriptions = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.description || "").trim())
      //           .filter(Boolean)
      //       )];

      //       // 🆕 STEP 4: First, process rows with spec code to fetch material data
      //       if (aUniqueSpecCodes.length > 0) {
      //         const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //           return new Promise((resolve) => {
      //             // For each spec code, we need to find the material
      //             // Since we don't have plant in the initial data, we'll use default or ask user
      //             // We'll handle this in the row-by-row processing below
      //             resolve({ specCode, materials: [] });
      //           });
      //         });

      //         await Promise.all(specCodePromises);
      //       }

      //       // 🧠 STEP 5: Process each row for material validation and enrichment
      //       for (let i = 0; i < aSelectedRows.length; i++) {
      //         const row = aSelectedRows[i];
      //         const rowNumber = i + 2;
      //         const specCode = String(row.speccode || "").trim();
      //         const materialCode = String(row.materialcode || "").trim();
      //         const description = String(row.description || "").trim();
      //         const plant = row.plant || "1200"; // Default plant

      //         // 🆕 Set default plant to 1200 if not entered by user
      //         if (!row.plant || String(row.plant || "").trim() === "") {
      //           row.plant = "1200";
      //         }

      //         // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //         if (specCode && specCode.length >= 4) {
      //           try {
      //             const materialData = await new Promise((resolve, reject) => {
      //               const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //               const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //               const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //               oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                 success: function (oData) {
      //                   resolve(oData.results || []);
      //                 },
      //                 error: function (oError) {
      //                   reject(oError);
      //                 }
      //               });
      //             });

      //             if (materialData.length === 0) {
      //               aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //             } else if (materialData.length === 1) {
      //               // Single material found - auto-fill
      //               const material = materialData[0];
      //               row.materialcode = material.Product;
      //               row.description = material.ProductName;

      //               // Check if it's a FG BELT material
      //               if (material.ExternalProductGroup !== "FG BELT") {
      //                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //               }
      //             } else {
      //               // Multiple materials found
      //               aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //             }
      //           } catch (error) {
      //             aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //           }
      //         }
      //         // If no spec code but material code or description is provided
      //         else if (materialCode || description) {
      //           // Build filters for material validation
      //           const filters = [];
      //           if (materialCode) {
      //             filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //           }
      //           if (description) {
      //             filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //           }

      //           if (filters.length > 0) {
      //             const combinedFilter = new sap.ui.model.Filter({
      //               filters: filters,
      //               and: false
      //             });

      //             try {
      //               const materialData = await new Promise((resolve, reject) => {
      //                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                   filters: [combinedFilter],
      //                   success: function (oData) {
      //                     resolve(oData.results || []);
      //                   },
      //                   error: function (oError) {
      //                     reject(oError);
      //                   }
      //                 });
      //               });

      //               if (materialData.length === 0) {
      //                 if (materialCode && description) {
      //                   aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                 } else if (materialCode) {
      //                   aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                 } else {
      //                   aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                 }
      //               } else {
      //                 const material = materialData[0];
      //                 // Fill missing fields
      //                 if (!materialCode && description) {
      //                   row.materialcode = material.Product;
      //                 }
      //                 if (!description && materialCode) {
      //                   row.description = material.ProductName;
      //                 }

      //                 // Check if it's a FG BELT material
      //                 if (material.ExternalProductGroup !== "FG BELT") {
      //                   aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                 }
      //               }
      //             } catch (error) {
      //               aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //             }
      //           }
      //         } else {
      //           aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //         }

      //         // 🚨 Validate shift field
      //         if (row.shift) {
      //           const shiftValue = String(row.shift).trim().toUpperCase();
      //           if (!["A", "B", "C"].includes(shiftValue)) {
      //             aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: A, B, C`);
      //           } else if (shiftValue.length !== 1) {
      //             aErrors.push(`Row ${rowNumber}: Shift value must be exactly 1 character.`);
      //           }
      //         } else {
      //           aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //         }

      //         // Set compound code based on description
      //         const finalDesc = String(row.description || "").trim();
      //         if (finalDesc) {
      //           const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //           row.compoundcode = base;
      //         }
      //       }

      //       // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //       aSelectedRows.forEach((row, idx) => {
      //         row.bipllotno = generateBiplLotNoForRow(row);
      //       });

      //       // 🧠 STEP 7: Validate Machine Combinations
      //       const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //       if (rowsWithMachine.length > 0) {
      //         const comboFilters = new sap.ui.model.Filter({
      //           filters: rowsWithMachine.map(row =>
      //             new sap.ui.model.Filter({
      //               filters: [
      //                 new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //                 new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //                 new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //               ],
      //               and: true
      //             })
      //           ),
      //           and: false
      //         });

      //         const validCombos = await new Promise((resolve, reject) => {
      //           oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //             filters: [comboFilters],
      //             success: data => resolve(
      //               (data.results || []).map(
      //                 r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //               )
      //             ),
      //             error: reject
      //           });
      //         });

      //         const invalidCombos = rowsWithMachine
      //           .map((row, idx) => {
      //             const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //             if (!validCombos.includes(key)) {
      //               const trueIdx = aSelectedRows.indexOf(row);
      //               return `Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
      //             }
      //             return null;
      //           })
      //           .filter(Boolean);

      //         if (invalidCombos.length > 0) {
      //           aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
      //         }
      //       }

      //       // 🆕 STEP 8: Check storage location (if needed)
      //       // Add storage location validation here if required
      //       // For now, we'll just ensure it's present if needed
      //       aSelectedRows.forEach((row, idx) => {
      //         if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //           // You can add error or set default storage location here
      //           // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //         }
      //       });

      //       // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //       if (aErrors.length === 0) {
      //         const oTabModel = oView.getModel("TabModel");
      //         const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //         const aExistingRows = oExistingRowsInfo.array;

      //         // Build a map of existing combinations
      //         const existingCombinationMap = new Map();
      //         aExistingRows.forEach((row, index) => {
      //           const dateString = that._formatToModelDateString(row.productionordstartdate);
      //           const slabValue = (row.slabno || "").toString().trim();

      //           if (dateString && slabValue) {
      //             const combinationKey = `${dateString}|${slabValue}`;
      //             existingCombinationMap.set(combinationKey, index + 1);
      //           }
      //         });

      //         // Check imported rows against existing data
      //         aSelectedRows.forEach((row, idx) => {
      //           const rowNumber = idx + 2;

      //           // Format the date
      //           let dateString = "";
      //           if (row.productionordstartdate) {
      //             dateString = that._formatToModelDateString(row.productionordstartdate);
      //           }

      //           const slabValue = (row.slabno || "").toString().trim();

      //           // Only check if both values are present
      //           if (dateString && slabValue) {
      //             const combinationKey = `${dateString}|${slabValue}`;

      //             if (existingCombinationMap.has(combinationKey)) {
      //               const existingRowIndex = existingCombinationMap.get(combinationKey);
      //               aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //             }
      //           }
      //         });
      //       }

      //       // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //       if (aErrors.length === 0) {
      //         // Group rows by date to optimize database queries
      //         const dateGroups = new Map();

      //         aSelectedRows.forEach((row, idx) => {
      //           const dateString = that._formatToModelDateString(row.productionordstartdate);
      //           const slabValue = (row.slabno || "").toString().trim();

      //           if (dateString && slabValue) {
      //             if (!dateGroups.has(dateString)) {
      //               dateGroups.set(dateString, []);
      //             }
      //             dateGroups.get(dateString).push({
      //               rowIndex: idx,
      //               dateString: dateString,
      //               slabValue: slabValue,
      //               rowNumber: idx + 2
      //             });
      //           }
      //         });

      //         // Check each date group against database
      //         for (const [dateString, rows] of dateGroups) {
      //           try {
      //             const aSavedRecords = await that._fetchSavedRecords(dateString);

      //             // Create a map of saved records for this date
      //             const savedSlabMap = new Set();
      //             aSavedRecords.forEach(record => {
      //               if (record.slabno) {
      //                 savedSlabMap.add(record.slabno);
      //               }
      //             });

      //             // Check each row in this date group
      //             rows.forEach(rowData => {
      //               if (savedSlabMap.has(rowData.slabValue)) {
      //                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //               }
      //             });
      //           } catch (error) {
      //             console.error(`Error fetching saved records for date ${dateString}:`, error);
      //             // Continue with import even if database check fails
      //           }
      //         }
      //       }

      //       // 🚫 STEP 11: Show all accumulated errors together
      //       if (aErrors.length > 0) {
      //         const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //       const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //       if (rowsWithMachineNumber.length > 0) {
      //         const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //         if (oProdVersionModel) {
      //           // Create filters for all rows with machine number
      //           const prodVersionPromises = rowsWithMachineNumber.map(row =>
      //             new Promise((resolve, reject) => {
      //               const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //               const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumber);

      //               oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                 filters: [materialFilter, prodVersionFilter],
      //                 success: function (oData) {
      //                   if (oData.results && oData.results.length > 0) {
      //                     let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity;
      //                     resolve({
      //                       material: row.materialcode,
      //                       productionVersion: row.machinenumber,
      //                       maxLotSize: maxLotSize
      //                     });
      //                   } else {
      //                     resolve({
      //                       material: row.materialcode,
      //                       productionVersion: row.machinenumber,
      //                       maxLotSize: "0.000"
      //                     });
      //                   }
      //                 },
      //                 error: function (err) {
      //                   console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                   resolve({
      //                     material: row.materialcode,
      //                     productionVersion: row.machinenumber,
      //                     maxLotSize: "0.000"
      //                   });
      //                 }
      //               });
      //             })
      //           );

      //           const prodVersionResults = await Promise.all(prodVersionPromises);

      //           // Create a map for quick lookup
      //           const prodQtyMap = {};
      //           prodVersionResults.forEach(result => {
      //             const key = `${result.material}_${result.productionVersion}`;
      //             prodQtyMap[key] = result.maxLotSize;
      //           });

      //           // Assign production order quantity to rows with machine number
      //           aSelectedRows.forEach(row => {
      //             if (row.machinenumber) {
      //               const key = `${row.materialcode}_${row.machinenumber}`;
      //               row.productionorderqty = prodQtyMap[key] || "0.000";
      //             } else {
      //               // For rows without machine number, set productionorderqty to 0.000
      //               row.productionorderqty = "0.000";
      //             }
      //           });
      //         } else {
      //           console.error("ZSB_PRODUCTVERSION model not found");
      //           aSelectedRows.forEach(row => {
      //             row.productionorderqty = "0.000";
      //           });
      //         }
      //       } else {
      //         aSelectedRows.forEach(row => {
      //           row.productionorderqty = "0.000";
      //         });
      //       }

      //       // ✅ STEP 13: Import Validated & Enriched Data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(aSelectedRows);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");

      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }

      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },


      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else {
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary" });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {
      //                             // Excel already gives Date object when cellDates:true
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 rawValue = rawValue;
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                                 const oParsed = oParse.parse(rawValue);
      //                                 rawValue = oParsed || null;
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //                 // Format the date from Excel
      //                 let dateValue = row.productionordstartdate;
      //                 let dateString = "";

      //                 if (dateValue) {
      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         dateString = oFmt.format(dateValue);
      //                     } else if (typeof dateValue === "string") {
      //                         // Try to parse the string date
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                             dateString = oFmt.format(oParsed);
      //                         }
      //                     }
      //                 }

      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         selectedDate = new Date(dateValue);
      //                         selectedDate.setHours(0, 0, 0, 0);
      //                     } else if (typeof dateValue === "string") {
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         const formattedDate = that._formatToModelDateString(selectedDate);
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             const aUniqueMaterials = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.materialcode || "").trim())
      //                     .filter(Boolean)
      //             )];

      //             const aUniqueDescriptions = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.description || "").trim())
      //                     .filter(Boolean)
      //             )];

      //             // 🆕 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 const comboFilters = new sap.ui.model.Filter({
      //                     filters: rowsWithMachine.map(row =>
      //                         new sap.ui.model.Filter({
      //                             filters: [
      //                                 new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //                                 new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //                                 new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //                             ],
      //                             and: true
      //                         })
      //                     ),
      //                     and: false
      //                 });

      //                 const validCombos = await new Promise((resolve, reject) => {
      //                     oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                         filters: [comboFilters],
      //                         success: data => resolve(
      //                             (data.results || []).map(
      //                                 r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //                             )
      //                         ),
      //                         error: reject
      //                     });
      //                 });

      //                 const invalidCombos = rowsWithMachine
      //                     .map((row, idx) => {
      //                         const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //                         if (!validCombos.includes(key)) {
      //                             const trueIdx = aSelectedRows.indexOf(row);
      //                             return `Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
      //                         }
      //                         return null;
      //                     })
      //                     .filter(Boolean);

      //                 if (invalidCombos.length > 0) {
      //                     aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     const dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 // Group rows by date to optimize database queries
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     const dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number
      //                     const prodVersionPromises = rowsWithMachineNumber.map(row =>
      //                         new Promise((resolve, reject) => {
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                             const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumber);

      //                             oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                 filters: [materialFilter, prodVersionFilter],
      //                                 success: function (oData) {
      //                                     if (oData.results && oData.results.length > 0) {
      //                                         let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity;
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumber,
      //                                             maxLotSize: maxLotSize
      //                                         });
      //                                     } else {
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 },
      //                                 error: function (err) {
      //                                     console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                     resolve({
      //                                         material: row.materialcode,
      //                                         productionVersion: row.machinenumber,
      //                                         maxLotSize: "0.000"
      //                                     });
      //                                 }
      //                             });
      //                         })
      //                     );

      //                     const prodVersionResults = await Promise.all(prodVersionPromises);

      //                     // Create a map for quick lookup
      //                     const prodQtyMap = {};
      //                     prodVersionResults.forEach(result => {
      //                         const key = `${result.material}_${result.productionVersion}`;
      //                         prodQtyMap[key] = result.maxLotSize;
      //                     });

      //                     // Assign production order quantity to rows with machine number
      //                     aSelectedRows.forEach(row => {
      //                         if (row.machinenumber) {
      //                             const key = `${row.materialcode}_${row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         } else {
      //                             // For rows without machine number, set productionorderqty to 0.000
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     aSelectedRows.forEach(row => {
      //                         row.productionorderqty = "0.000";
      //                     });
      //                 }
      //             } else {
      //                 aSelectedRows.forEach(row => {
      //                     row.productionorderqty = "0.000";
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },




      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else {
      //                 // If it's already a string in yyyy-MM-dd format
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary" });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 // Format date to yyyy-MM-dd string
      //                                 const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                     pattern: "yyyy-MM-dd"
      //                                 });
      //                                 rawValue = oDateFormat.format(rawValue);
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 const date = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //                                 const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                     pattern: "yyyy-MM-dd"
      //                                 });
      //                                 rawValue = oDateFormat.format(date);
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Try to parse various date formats
      //                                 let parsedDate = null;

      //                                 // Try yyyy-MM-dd format first
      //                                 const oDateFormat1 = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                                 parsedDate = oDateFormat1.parse(rawValue);

      //                                 // Try dd-MM-yyyy format
      //                                 if (!parsedDate) {
      //                                     const oDateFormat2 = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                                     parsedDate = oDateFormat2.parse(rawValue);
      //                                 }

      //                                 if (parsedDate) {
      //                                     const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                         pattern: "yyyy-MM-dd"
      //                                     });
      //                                     rawValue = oDateFormat.format(parsedDate);
      //                                 } else {
      //                                     rawValue = rawValue; // Keep as-is
      //                                 }
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }
      //                         // Handle productionorderqty - ensure it's a string with proper formatting
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 // Convert to string and format to 3 decimal places
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     rawValue = numValue.toFixed(3);
      //                                 } else {
      //                                     rawValue = "0.000";
      //                                 }
      //                             } else {
      //                                 rawValue = "0.000";
      //                             }
      //                         }
      //                         // Handle machinenumber - we need to store both visible and hidden
      //                         else if (field === "machinenumber") {
      //                             // Just store the value as-is for now
      //                             // We'll handle machinenumberhidden in validation phase
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //                 // Date is already in yyyy-MM-dd string format from mapping
      //                 let dateString = row.productionordstartdate;
      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     // Parse the yyyy-MM-dd string date
      //                     if (typeof dateValue === "string") {
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${dateValue}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText || 
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     const dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         dateString = row.productionordstartdate; // Already in yyyy-MM-dd format
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 // Group rows by date to optimize database queries
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     const dateString = row.productionordstartdate; // Already in yyyy-MM-dd format
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             // But only if productionorderqty is not already set from Excel
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row => 
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },



      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else if (typeof productionDate === "string") {
      //                 // If it's already a string in yyyy-MM-dd format
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary" });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 // Format date to yyyy-MM-dd string (this is what the table expects)
      //                                 const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                     pattern: "yyyy-MM-dd"
      //                                 });
      //                                 rawValue = oDateFormat.format(rawValue);
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 const date = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //                                 const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                     pattern: "yyyy-MM-dd"
      //                                 });
      //                                 rawValue = oDateFormat.format(date);
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Try to parse various date formats
      //                                 let parsedDate = null;

      //                                 // Remove any time portion if present
      //                                 rawValue = rawValue.split('T')[0].split(' ')[0];

      //                                 // Try different date patterns
      //                                 const datePatterns = [
      //                                     "yyyy-MM-dd",
      //                                     "dd-MM-yyyy",
      //                                     "dd/MM/yyyy",
      //                                     "MM/dd/yyyy",
      //                                     "yyyy/MM/dd",
      //                                     "dd.MM.yyyy",
      //                                     "MM.dd.yyyy"
      //                                 ];

      //                                 for (let pattern of datePatterns) {
      //                                     try {
      //                                         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: pattern });
      //                                         parsedDate = oDateFormat.parse(rawValue);
      //                                         if (parsedDate) {
      //                                             // Format to yyyy-MM-dd
      //                                             const oOutputFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                                 pattern: "yyyy-MM-dd"
      //                                             });
      //                                             rawValue = oOutputFormat.format(parsedDate);
      //                                             break;
      //                                         }
      //                                     } catch (e) {
      //                                         // Try next pattern
      //                                     }
      //                                 }

      //                                 // If still not parsed, try JavaScript Date parsing as last resort
      //                                 if (!parsedDate) {
      //                                     const jsDate = new Date(rawValue);
      //                                     if (!isNaN(jsDate.getTime())) {
      //                                         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                             pattern: "yyyy-MM-dd"
      //                                         });
      //                                         rawValue = oDateFormat.format(jsDate);
      //                                     } else {
      //                                         allErrors.push(`Row ${rowIndex + 2}: Invalid date format for Production Order Start Date: "${rawValue}". Please use format yyyy-MM-dd, dd-MM-yyyy, or similar.`);
      //                                         rawValue = "";
      //                                     }
      //                                 }
      //                             } else if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 // Empty date - leave as empty string
      //                                 rawValue = "";
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }
      //                         // Handle productionorderqty - ensure it's a string with proper formatting
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 // Convert to string and format to 3 decimal places
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     rawValue = numValue.toFixed(3);
      //                                 } else {
      //                                     rawValue = "0.000";
      //                                 }
      //                             } else {
      //                                 rawValue = "0.000";
      //                             }
      //                         }
      //                         // Handle machinenumber - we need to store both visible and hidden
      //                         else if (field === "machinenumber") {
      //                             // Just store the value as-is for now
      //                             // We'll handle machinenumberhidden in validation phase
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //                 // Date is already in yyyy-MM-dd string format from mapping
      //                 let dateString = row.productionordstartdate;
      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     // Parse the yyyy-MM-dd string date
      //                     if (typeof dateValue === "string") {
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${dateValue}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText || 
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     // Format date to string for comparison
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         if (row.productionordstartdate instanceof Date) {
      //                             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                 pattern: "yyyy-MM-dd"
      //                             });
      //                             dateString = oDateFormat.format(row.productionordstartdate);
      //                         } else if (typeof row.productionordstartdate === "string") {
      //                             dateString = row.productionordstartdate;
      //                         }
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         dateString = row.productionordstartdate; // Already in yyyy-MM-dd format
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 // Group rows by date to optimize database queries
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     const dateString = row.productionordstartdate; // Already in yyyy-MM-dd format
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             // But only if productionorderqty is not already set from Excel
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row => 
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },



      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else if (typeof productionDate === "string") {
      //                 // If it's already a string in yyyy-MM-dd format
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary" });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {
      //                             // Excel already gives Date object when cellDates:true
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 rawValue = rawValue; // ✅ Keep as Date object
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000)); // ✅ Convert to Date object
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Remove any time portion if present
      //                                 const cleanValue = rawValue.split('T')[0].split(' ')[0];

      //                                 // Try different date patterns
      //                                 const datePatterns = [
      //                                     "yyyy-MM-dd",
      //                                     "dd-MM-yyyy",
      //                                     "dd/MM/yyyy",
      //                                     "MM/dd/yyyy",
      //                                     "yyyy/MM/dd",
      //                                     "dd.MM.yyyy",
      //                                     "MM.dd.yyyy"
      //                                 ];

      //                                 let parsedDate = null;
      //                                 for (let pattern of datePatterns) {
      //                                     try {
      //                                         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: pattern });
      //                                         parsedDate = oDateFormat.parse(cleanValue);
      //                                         if (parsedDate) {
      //                                             rawValue = parsedDate; // ✅ Store as Date object
      //                                             break;
      //                                         }
      //                                     } catch (e) {
      //                                         // Try next pattern
      //                                     }
      //                                 }

      //                                 // If still not parsed, try JavaScript Date parsing as last resort
      //                                 if (!parsedDate) {
      //                                     const jsDate = new Date(cleanValue);
      //                                     if (!isNaN(jsDate.getTime())) {
      //                                         rawValue = jsDate; // ✅ Store as Date object
      //                                     } else {
      //                                         allErrors.push(`Row ${rowIndex + 2}: Invalid date format for Production Order Start Date: "${rawValue}". Please use format yyyy-MM-dd, dd-MM-yyyy, or similar.`);
      //                                         rawValue = null; // ✅ Use null instead of empty string
      //                                     }
      //                                 }
      //                             } else if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 rawValue = null; // ✅ Use null instead of empty string
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }
      //                         // Handle productionorderqty - ensure it's a string with proper formatting
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 // Convert to string and format to 3 decimal places
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     rawValue = numValue.toFixed(3);
      //                                 } else {
      //                                     rawValue = "0.000";
      //                                 }
      //                             } else {
      //                                 rawValue = "0.000";
      //                             }
      //                         }
      //                         // Handle machinenumber - we need to store both visible and hidden
      //                         else if (field === "machinenumber") {
      //                             // Just store the value as-is for now
      //                             // We'll handle machinenumberhidden in validation phase
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;

      //                 // Format the date from Excel
      //                 let dateValue = row.productionordstartdate;
      //                 let dateString = "";

      //                 if (dateValue) {
      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         dateString = oFmt.format(dateValue);
      //                     } else if (typeof dateValue === "string") {
      //                         // Try to parse the string date
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                             dateString = oFmt.format(oParsed);
      //                         }
      //                     }
      //                 }

      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     // Handle different date formats
      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         selectedDate = new Date(dateValue);
      //                         selectedDate.setHours(0, 0, 0, 0);
      //                     } else if (typeof dateValue === "string") {
      //                         // Parse the string date
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const formattedDate = oFmt.format(selectedDate);
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText ||
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     // Format date to string for comparison
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         if (row.productionordstartdate instanceof Date && !isNaN(row.productionordstartdate.getTime())) {
      //                             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                 pattern: "yyyy-MM-dd"
      //                             });
      //                             dateString = oDateFormat.format(row.productionordstartdate);
      //                         } else if (typeof row.productionordstartdate === "string") {
      //                             dateString = row.productionordstartdate;
      //                         }
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date for comparison
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         if (row.productionordstartdate instanceof Date && !isNaN(row.productionordstartdate.getTime())) {
      //                             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                 pattern: "yyyy-MM-dd"
      //                             });
      //                             dateString = oDateFormat.format(row.productionordstartdate);
      //                         } else if (typeof row.productionordstartdate === "string") {
      //                             dateString = row.productionordstartdate;
      //                         }
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 // Group rows by date to optimize database queries
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     // Format date for database comparison
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         if (row.productionordstartdate instanceof Date && !isNaN(row.productionordstartdate.getTime())) {
      //                             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                                 pattern: "yyyy-MM-dd"
      //                             });
      //                             dateString = oDateFormat.format(row.productionordstartdate);
      //                         } else if (typeof row.productionordstartdate === "string") {
      //                             dateString = row.productionordstartdate;
      //                         }
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             // But only if productionorderqty is not already set from Excel
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row =>
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },


      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else if (typeof productionDate === "string") {
      //                 // If it's already a string in yyyy-MM-dd format
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary", cellDates: true }); // Ensure cellDates is true
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate - DO NOT CONVERT TO STRING HERE
      //                         if (field === "productionordstartdate") {
      //                             // Keep as Date object initially, just like in the working code
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 // Keep as Date object, don't format to string yet
      //                                 rawValue = rawValue;
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Try to parse the string date
      //                                 const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                                 const oParsed = oParse.parse(rawValue);
      //                                 rawValue = oParsed || null;
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }
      //                         // Handle productionorderqty - ensure it's a string with proper formatting
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 // Convert to string and format to 3 decimal places
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     rawValue = numValue.toFixed(3);
      //                                 } else {
      //                                     rawValue = "0.000";
      //                                 }
      //                             } else {
      //                                 rawValue = "0.000";
      //                             }
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //                 // Format the date from Excel - use helper function to format date
      //                 let dateString = "";
      //                 if (row.productionordstartdate) {
      //                     dateString = that._formatToModelDateString(row.productionordstartdate);
      //                 }

      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     // Handle different date formats
      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         selectedDate = new Date(dateValue);
      //                         selectedDate.setHours(0, 0, 0, 0);
      //                     } else if (typeof dateValue === "string") {
      //                         // Try to parse the string date
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         const formattedDate = that._formatToModelDateString(selectedDate);
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText || 
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     // Format date to string for comparison
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date
      //                     let dateString = "";
      //                     if (row.productionordstartdate) {
      //                         dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     }

      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 // Group rows by date to optimize database queries
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     const dateString = that._formatToModelDateString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             // But only if productionorderqty is not already set from Excel
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row => 
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },


      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr;

      //             // Handle different date formats
      //             if (productionDate instanceof Date) {
      //                 var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                     pattern: "yyyy-MM-dd"
      //                 });
      //                 dateStr = oDateFormat.format(productionDate);
      //             } else if (typeof productionDate === "string") {
      //                 // If it's already a string in yyyy-MM-dd format
      //                 dateStr = productionDate;
      //             }

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary" });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];

      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // 🔹 Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {

      //                             // Excel already gives Date object when cellDates:true
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 rawValue = rawValue; // ✅ Keep as Date object - DO NOT CONVERT TO STRING
      //                             }

      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000)); // ✅ Create Date object
      //                             }

      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Remove any time portion if present
      //                                 const cleanValue = rawValue.split('T')[0].split(' ')[0];

      //                                 // Try different date patterns
      //                                 const datePatterns = [
      //                                     "yyyy-MM-dd",
      //                                     "dd-MM-yyyy",
      //                                     "dd/MM/yyyy",
      //                                     "MM/dd/yyyy",
      //                                     "yyyy/MM/dd",
      //                                     "dd.MM.yyyy",
      //                                     "MM.dd.yyyy"
      //                                 ];

      //                                 let parsedDate = null;
      //                                 for (let pattern of datePatterns) {
      //                                     try {
      //                                         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: pattern });
      //                                         parsedDate = oDateFormat.parse(cleanValue);
      //                                         if (parsedDate) {
      //                                             rawValue = parsedDate; // ✅ Store as Date object - DO NOT CONVERT TO STRING
      //                                             break;
      //                                         }
      //                                     } catch (e) {
      //                                         // Try next pattern
      //                                     }
      //                                 }

      //                                 // If still not parsed, try JavaScript Date parsing as last resort
      //                                 if (!parsedDate) {
      //                                     const jsDate = new Date(cleanValue);
      //                                     if (!isNaN(jsDate.getTime())) {
      //                                         rawValue = jsDate; // ✅ Store as Date object
      //                                     } else {
      //                                         allErrors.push(`Row ${rowIndex + 2}: Invalid date format for Production Order Start Date: "${rawValue}". Please use format yyyy-MM-dd, dd-MM-yyyy, or similar.`);
      //                                         rawValue = null; // Use null for invalid dates
      //                                     }
      //                                 }
      //                             } else if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 rawValue = null; // Empty date stays null
      //                             }
      //                         }
      //                         // ... rest of your field handling (slabno, speccode, shift, etc.)

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             function formatDateToString(dateValue) {
      //             if (!dateValue) return "";

      //             if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                 const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                 return oFmt.format(dateValue);
      //             } else if (typeof dateValue === "string") {
      //                 // If already a string, validate and return
      //                 return dateValue;
      //             }
      //             return "";
      //         }


      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;

      //                 // Format the date from Excel (Date object to string)
      //                 const dateString = formatDateToString(row.productionordstartdate);
      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateValue = row.productionordstartdate;

      //                 if (dateValue) {
      //                     let selectedDate = null;

      //                     // Handle different date formats
      //                     if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
      //                         selectedDate = new Date(dateValue);
      //                         selectedDate.setHours(0, 0, 0, 0);
      //                     } else if (typeof dateValue === "string") {
      //                         // Parse the string date
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateValue);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         const formattedDate = formatDateToString(selectedDate);
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText ||
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     // Format date to string for comparison
      //                     const dateString = formatDateToString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Format the date for comparison
      //                     const dateString = formatDateToString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🆕 STEP 10: Check for duplicate combinations with saved records in database (using slabno)
      //             if (aErrors.length === 0) {
      //                 const dateGroups = new Map();

      //                 aSelectedRows.forEach((row, idx) => {
      //                     // Format date for database comparison
      //                     const dateString = formatDateToString(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         if (!dateGroups.has(dateString)) {
      //                             dateGroups.set(dateString, []);
      //                         }
      //                         dateGroups.get(dateString).push({
      //                             rowIndex: idx,
      //                             dateString: dateString,
      //                             slabValue: slabValue,
      //                             rowNumber: idx + 2
      //                         });
      //                     }
      //                 });

      //                 // Check each date group against database
      //                 for (const [dateString, rows] of dateGroups) {
      //                     try {
      //                         const aSavedRecords = await that._fetchSavedRecords(dateString);

      //                         // Create a map of saved records for this date
      //                         const savedSlabMap = new Set();
      //                         aSavedRecords.forEach(record => {
      //                             if (record.slabno) {
      //                                 savedSlabMap.add(record.slabno);
      //                             }
      //                         });

      //                         // Check each row in this date group
      //                         rows.forEach(rowData => {
      //                             if (savedSlabMap.has(rowData.slabValue)) {
      //                                 aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${rowData.slabValue}) already exists in the saved records.`);
      //                             }
      //                         });
      //                     } catch (error) {
      //                         console.error(`Error fetching saved records for date ${dateString}:`, error);
      //                         // Continue with import even if database check fails
      //                     }
      //                 }
      //             }

      //             // 🚫 STEP 11: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 12: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             // But only if productionorderqty is not already set from Excel
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row =>
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 13: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];
      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },


      // best except date not importing
      // onImportExl: function () {
      //     const that = this;

      //     // Helper function to format date to yyyy-MM-dd string
      //     function formatDateToString(date) {
      //         if (!date) return "";

      //         if (date instanceof Date && !isNaN(date.getTime())) {
      //             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //             return oDateFormat.format(date);
      //         }

      //         // If it's already a string in the right format, return it
      //         if (typeof date === "string" && date.match(/^\d{4}-\d{2}-\d{2}$/)) {
      //             return date;
      //         }

      //         return "";
      //     }

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             var dateStr = formatDateToString(productionDate);

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;
      //             const workbook = XLSX.read(data, { type: "binary", cellDates: true });
      //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields that might not be in table columns but are in export
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //             // Collect all errors during mapping
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 headers.forEach((hdr, idx) => {
      //                     const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //                     if (field) {
      //                         let rawValue = row[Object.keys(row)[idx]];

      //                         // Handle Excel numeric serial date for productionordstartdate
      //                         if (field === "productionordstartdate") {
      //                             // Convert to Date object first
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 // Keep as Date object - will convert to string later
      //                                 rawValue = rawValue;
      //                             }
      //                             // Excel numeric date
      //                             else if (typeof rawValue === "number") {
      //                                 rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
      //                             }
      //                             // Excel text date
      //                             else if (typeof rawValue === "string" && rawValue) {
      //                                 // Try to parse the string date (most common formats)
      //                                 let parsedDate = null;

      //                                 // Remove any time portion if present
      //                                 rawValue = rawValue.split('T')[0].split(' ')[0];

      //                                 // Try different date patterns that might be in Excel
      //                                 const datePatterns = [
      //                                     "yyyy-MM-dd",
      //                                     "dd-MM-yyyy",
      //                                     "dd/MM/yyyy",
      //                                     "MM/dd/yyyy",
      //                                     "yyyy/MM/dd"
      //                                 ];

      //                                 for (let pattern of datePatterns) {
      //                                     try {
      //                                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: pattern });
      //                                         parsedDate = oParse.parse(rawValue);
      //                                         if (parsedDate) {
      //                                             rawValue = parsedDate; // Store as Date object
      //                                             break;
      //                                         }
      //                                     } catch (e) {
      //                                         // Try next pattern
      //                                     }
      //                                 }

      //                                 // If still not parsed, try JavaScript Date parsing as last resort
      //                                 if (!parsedDate) {
      //                                     const jsDate = new Date(rawValue);
      //                                     if (!isNaN(jsDate.getTime())) {
      //                                         rawValue = jsDate;
      //                                     } else {
      //                                         allErrors.push(`Row ${rowIndex + 2}: Invalid date format for Production Order Start Date: "${rawValue}". Please use format yyyy-MM-dd, dd-MM-yyyy, or similar.`);
      //                                         rawValue = null;
      //                                     }
      //                                 }
      //                             } else if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 // Empty date - leave as null
      //                                 rawValue = null;
      //                             }

      //                             // Convert Date object to string in yyyy-MM-dd format for the table
      //                             if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //                                 rawValue = formatDateToString(rawValue);
      //                             }
      //                         }
      //                         // Handle slabno field - pad to 4 digits
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle speccode field - pad to 4 digits
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 // Pad to 4 digits with leading zeros
      //                                 if (sValue.length < 4) {
      //                                     rawValue = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     rawValue = sValue;
      //                                 }
      //                             }
      //                         }
      //                         // Handle shift field - accepts "Shift-A", "Shift-B", "Shift-C" or just "A", "B", "C"
      //                         else if (field === "shift") {
      //                             // If shift is missing
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             let value = String(rawValue).trim();

      //                             // Accept both "Shift-A" format and just "A"
      //                             let isValid = false;

      //                             if (value.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(value)) {
      //                                 // Single letter A/B/C is acceptable
      //                                 isValid = true;
      //                             } else if (["Shift-A", "Shift-B", "Shift-C", "shift-a", "shift-b", "shift-c"].includes(value)) {
      //                                 // Full format is acceptable
      //                                 isValid = true;
      //                             }

      //                             if (!isValid) {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                                 rawValue = "";
      //                                 return;
      //                             }

      //                             // Store the value as-is for now, will be normalized in validation phase
      //                             rawValue = value;
      //                         }
      //                         // Handle productionorderqty - ensure it's a string with proper formatting
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 // Convert to string and format to 3 decimal places
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     rawValue = numValue.toFixed(3);
      //                                 } else {
      //                                     rawValue = "0.000";
      //                                 }
      //                             } else {
      //                                 rawValue = "0.000";
      //                             }
      //                         }

      //                         obj[field] = rawValue;
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check if we have any errors during mapping
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // 🆕 STEP 1: Check for duplicate Slab No + Date combinations within Excel file itself
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //                 // Date is already in yyyy-MM-dd string format from mapping
      //                 let dateString = row.productionordstartdate;
      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 // Only check if both values are present
      //                 if (dateString && slabValue) {
      //                     const combinationKey = `${dateString}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 2: Check for past dates in imported data
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 let dateString = row.productionordstartdate;

      //                 if (dateString) {
      //                     // Parse the yyyy-MM-dd string date
      //                     let selectedDate = null;
      //                     if (typeof dateString === "string") {
      //                         const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //                         const oParsed = oParse.parse(dateString);
      //                         if (oParsed) {
      //                             selectedDate = new Date(oParsed);
      //                             selectedDate.setHours(0, 0, 0, 0);
      //                         }
      //                     }

      //                     // Check if date is in the past
      //                     if (selectedDate && selectedDate < oToday) {
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${dateString}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // 🆕 STEP 3: Gather all unique spec codes and materials
      //             const aUniqueSpecCodes = [...new Set(
      //                 aSelectedRows
      //                     .map(r => String(r.speccode || "").trim())
      //                     .filter(code => code && code.length >= 4)
      //             )];

      //             // 🧠 STEP 4: First, process rows with spec code to fetch material data
      //             if (aUniqueSpecCodes.length > 0) {
      //                 const specCodePromises = aUniqueSpecCodes.map(specCode => {
      //                     return new Promise((resolve) => {
      //                         // For each spec code, we need to find the material
      //                         // Since we don't have plant in the initial data, we'll use default or ask user
      //                         // We'll handle this in the row-by-row processing below
      //                         resolve({ specCode, materials: [] });
      //                     });
      //                 });

      //                 await Promise.all(specCodePromises);
      //             }

      //             // 🧠 STEP 5: Process each row for material validation and enrichment
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200"; // Default plant

      //                 // 🆕 Set default plant to 1200 if not entered by user
      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 // 🆕 If spec code is provided (4 digits), fetch material based on spec code
      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             // Single material found - auto-fill
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             // Check if it's a FG BELT material
      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             // Multiple materials found
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 // If no spec code but material code or description is provided
      //                 else if (materialCode || description) {
      //                     // Build filters for material validation
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 // Fill missing fields
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 // Check if it's a FG BELT material
      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // 🚨 Validate shift field
      //                 if (row.shift) {
      //                     const shiftValue = String(row.shift).trim();

      //                     // Convert Excel input to proper format if needed
      //                     let normalizedShift = shiftValue;

      //                     // If user entered just "A", "B", or "C", convert to "Shift-A", "Shift-B", "Shift-C"
      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     // If user entered "shift-a", "shift-b", "shift-c" (lowercase), convert to proper case
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     // Validate the normalized shift value
      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         // Update the row with normalized shift value
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code based on description
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // 🆕 STEP 6: Generate BIPL LOT NO for each row
      //             aSelectedRows.forEach((row, idx) => {
      //                 // Note: generateBiplLotNoForRow expects the date to be a string in yyyy-MM-dd format
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // 🧠 STEP 7: Validate Machine Combinations and set machinenumberhidden
      //             const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachine.length > 0) {
      //                 try {
      //                     // Group by plant and material to reduce number of requests
      //                     const groupedRows = {};
      //                     rowsWithMachine.forEach(row => {
      //                         const key = `${row.plant}_${row.materialcode}`;
      //                         if (!groupedRows[key]) {
      //                             groupedRows[key] = [];
      //                         }
      //                         groupedRows[key].push(row);
      //                     });

      //                     // Process each group
      //                     for (const groupKey in groupedRows) {
      //                         const rowsInGroup = groupedRows[groupKey];
      //                         const firstRow = rowsInGroup[0];

      //                         // Fetch production versions for this plant and material
      //                         const prodVersions = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
      //                             const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

      //                             oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //                                 filters: [plantFilter, materialFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         // Create a map for quick lookup of ProductionVersion by ProductionVersionText
      //                         const prodVersionMap = {};
      //                         prodVersions.forEach(pv => {
      //                             const key = `${pv.ProductionVersionText}`;
      //                             prodVersionMap[key] = pv.ProductionVersion;
      //                         });

      //                         // Validate each row in the group
      //                         rowsInGroup.forEach((row, idx) => {
      //                             const machineText = row.machinenumber;
      //                             if (prodVersionMap[machineText]) {
      //                                 // Set the hidden machine number (ProductionVersion code)
      //                                 row.machinenumberhidden = prodVersionMap[machineText];
      //                             } else {
      //                                 // Try to find partial match (if user entered just the code like "LNE1")
      //                                 let found = false;
      //                                 for (const pv of prodVersions) {
      //                                     if (pv.ProductionVersion === machineText || 
      //                                         pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
      //                                         row.machinenumber = pv.ProductionVersionText; // Set visible text
      //                                         row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
      //                                         found = true;
      //                                         break;
      //                                     }
      //                                 }

      //                                 if (!found) {
      //                                     const trueIdx = aSelectedRows.indexOf(row);
      //                                     aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
      //                                 }
      //                             }
      //                         });
      //                     }
      //                 } catch (error) {
      //                     console.error("Error validating machine combinations:", error);
      //                     // Don't fail the import if machine validation fails
      //                     // Just log error and continue without machine number validation
      //                 }
      //             }

      //             // 🆕 STEP 8: Check storage location (if needed)
      //             // Add storage location validation here if required
      //             // For now, we'll just ensure it's present if needed
      //             aSelectedRows.forEach((row, idx) => {
      //                 if (!row.storagelocation || String(row.storagelocation || "").trim() === "") {
      //                     // You can add error or set default storage location here
      //                     // aErrors.push(`Row ${idx + 2}: Storage location is required.`);
      //                 }
      //             });

      //             // 🆕 STEP 9: Check for duplicate combinations with existing table data (using slabno instead of bipllotno)
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 // Build a map of existing combinations
      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     // Date is already stored as string in the table model
      //                     let dateString = row.productionordstartdate || "";
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 // Check imported rows against existing data
      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;

      //                     // Date is already in yyyy-MM-dd format from mapping
      //                     let dateString = row.productionordstartdate || "";
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     // Only check if both values are present
      //                     if (dateString && slabValue) {
      //                         const combinationKey = `${dateString}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // 🚫 STEP 10: Show all accumulated errors together
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // 🔥 STEP 11: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
      //             const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //             if (rowsWithMachineNumber.length > 0) {
      //                 const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

      //                 if (oProdVersionModel) {
      //                     // Create filters for all rows with machine number that don't have productionorderqty set
      //                     const rowsToFetch = rowsWithMachineNumber.filter(row => 
      //                         !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
      //                     );

      //                     if (rowsToFetch.length > 0) {
      //                         const prodVersionPromises = rowsToFetch.map(row =>
      //                             new Promise((resolve, reject) => {
      //                                 const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
      //                                 const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

      //                                 oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //                                     filters: [materialFilter, prodVersionFilter],
      //                                     success: function (oData) {
      //                                         if (oData.results && oData.results.length > 0) {
      //                                             let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: maxLotSize
      //                                             });
      //                                         } else {
      //                                             resolve({
      //                                                 material: row.materialcode,
      //                                                 productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                                 maxLotSize: "0.000"
      //                                             });
      //                                         }
      //                                     },
      //                                     error: function (err) {
      //                                         console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
      //                                         resolve({
      //                                             material: row.materialcode,
      //                                             productionVersion: row.machinenumberhidden || row.machinenumber,
      //                                             maxLotSize: "0.000"
      //                                         });
      //                                     }
      //                                 });
      //                             })
      //                         );

      //                         const prodVersionResults = await Promise.all(prodVersionPromises);

      //                         // Create a map for quick lookup
      //                         const prodQtyMap = {};
      //                         prodVersionResults.forEach(result => {
      //                             const key = `${result.material}_${result.productionVersion}`;
      //                             prodQtyMap[key] = result.maxLotSize;
      //                         });

      //                         // Assign production order quantity to rows with machine number
      //                         rowsToFetch.forEach(row => {
      //                             const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
      //                             row.productionorderqty = prodQtyMap[key] || "0.000";
      //                         });
      //                     }
      //                 } else {
      //                     console.error("ZSB_PRODUCTVERSION model not found");
      //                     // Set productionorderqty to 0.000 for rows that don't have it
      //                     aSelectedRows.forEach(row => {
      //                         if (!row.productionorderqty || row.productionorderqty === "") {
      //                             row.productionorderqty = "0.000";
      //                         }
      //                     });
      //                 }
      //             } else {
      //                 // For rows without machine number, ensure productionorderqty is set
      //                 aSelectedRows.forEach(row => {
      //                     if (!row.productionorderqty || row.productionorderqty === "") {
      //                         row.productionorderqty = "0.000";
      //                     }
      //                 });
      //             }

      //             // ✅ STEP 12: Import Validated & Enriched Data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];

      //             // Ensure all dates are properly formatted as strings before adding to the table
      //             aSelectedRows.forEach(row => {
      //                 if (row.productionordstartdate && typeof row.productionordstartdate === "string") {
      //                     // Already in the right format
      //                 } else if (row.productionordstartdate) {
      //                     // Convert to string format if needed
      //                     row.productionordstartdate = formatDateToString(row.productionordstartdate);
      //                 }
      //             });

      //             const updatedData = existingData.concat(aSelectedRows);
      //             oModel.setProperty("/Samples", updatedData);

      //             sap.m.MessageToast.show("Data imported and validated successfully.");

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },



      // onImportExl: function () {
      //     const that = this;

      //     // FIXED: Simple date parsing that returns a valid Date object or null
      //     function parseExcelDateToDate(rawValue) {
      //         if (!rawValue && rawValue !== 0) {
      //             return null;
      //         }

      //         let dateObj = null;

      //         // CASE 1: Already a valid Date object
      //         if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
      //             return rawValue;
      //         }

      //         // CASE 2: Excel serial number
      //         if (typeof rawValue === 'number') {
      //             try {
      //                 // Excel's epoch is December 30, 1899
      //                 const excelEpoch = new Date(1899, 11, 30);
      //                 const date = new Date(excelEpoch.getTime() + rawValue * 86400000);
      //                 if (!isNaN(date.getTime())) {
      //                     // Create a date without timezone issues
      //                     dateObj = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      //                 }
      //             } catch (e) {
      //                 console.warn("Error parsing Excel serial date:", rawValue, e);
      //             }
      //         }
      //         // CASE 3: String value
      //         else if (typeof rawValue === 'string') {
      //             const trimmed = rawValue.trim();
      //             if (!trimmed) return null;

      //             try {
      //                 // Try yyyy-MM-dd format (as specified)
      //                 if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
      //                     const parts = trimmed.split("-");
      //                     const year = parseInt(parts[0], 10);
      //                     const month = parseInt(parts[1], 10) - 1;
      //                     const day = parseInt(parts[2], 10);

      //                     if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
      //                         dateObj = new Date(year, month, day);
      //                         // Verify it's a valid date
      //                         if (dateObj.getFullYear() !== year || 
      //                             dateObj.getMonth() !== month || 
      //                             dateObj.getDate() !== day ||
      //                             isNaN(dateObj.getTime())) {
      //                             dateObj = null;
      //                         }
      //                     }
      //                 }
      //                 // Try dd/MM/yyyy format
      //                 else if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
      //                     const parts = trimmed.split("/");
      //                     const day = parseInt(parts[0], 10);
      //                     const month = parseInt(parts[1], 10) - 1;
      //                     const year = parseInt(parts[2], 10);

      //                     if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
      //                         dateObj = new Date(year, month, day);
      //                         if (isNaN(dateObj.getTime())) dateObj = null;
      //                     }
      //                 }
      //                 // Try general date parsing
      //                 else {
      //                     const tempDate = new Date(trimmed);
      //                     if (!isNaN(tempDate.getTime())) {
      //                         // Create date without time component
      //                         dateObj = new Date(tempDate.getFullYear(), tempDate.getMonth(), tempDate.getDate());
      //                     }
      //                 }
      //             } catch (e) {
      //                 console.warn("Error parsing date string:", trimmed, e);
      //             }
      //         }

      //         return dateObj;
      //     }

      //     // Format date to yyyy-MM-dd string for storage
      //     function formatDateToYYYYMMDD(date) {
      //         if (!date) return "";

      //         if (date instanceof Date && !isNaN(date.getTime())) {
      //             const year = date.getFullYear();
      //             const month = String(date.getMonth() + 1).padStart(2, '0');
      //             const day = String(date.getDate()).padStart(2, '0');
      //             return `${year}-${month}-${day}`;
      //         }

      //         // If it's already a string in yyyy-MM-dd format
      //         if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      //             return date;
      //         }

      //         return "";
      //     }

      //     // Helper function to generate BIPL LOT NO for a row
      //     function generateBiplLotNoForRow(row) {
      //         var productionDate = row.productionordstartdate;
      //         var slabNo = row.slabno;
      //         var specCode = row.speccode;

      //         if (!productionDate || !slabNo || !specCode) {
      //             return "";
      //         }

      //         try {
      //             // Convert to string if it's a Date object
      //             var dateStr = formatDateToYYYYMMDD(productionDate);

      //             // Ensure dateStr has the right format
      //             if (!dateStr || dateStr.length < 10) {
      //                 return "";
      //             }

      //             // Extract components
      //             var year = dateStr.substring(2, 4); // Last 2 digits of year
      //             var month = dateStr.substring(5, 7); // Month
      //             var day = dateStr.substring(8, 10); // Day

      //             // Pad slabNo to 4 digits with leading zeros if not already done
      //             var paddedSlabNo = slabNo;
      //             if (slabNo && slabNo.length < 4) {
      //                 paddedSlabNo = ("0000" + slabNo).slice(-4);
      //             }

      //             // Build the BIPL LOT NO
      //             var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

      //             return biplLotNo;

      //         } catch (error) {
      //             console.error("Error generating BIPL LOT NO:", error);
      //             return "";
      //         }
      //     }

      //     function ensureXLSX(cb) {
      //         if (window.XLSX) return cb();

      //         const script = document.createElement("script");
      //         script.src = importexcelfile;
      //         script.onload = cb;
      //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //         document.head.appendChild(script);
      //     }

      //     function doImport(file) {
      //         const reader = new FileReader();
      //         reader.onload = function (e) {
      //             const data = e.target.result;

      //             let jsonData = [];
      //             try {
      //                 // Try with raw: true first to get the raw values
      //                 const workbook = XLSX.read(data, { 
      //                     type: "binary", 
      //                     raw: true,
      //                     cellDates: false
      //                 });

      //                 const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //                 jsonData = XLSX.utils.sheet_to_json(sheet, { 
      //                     defval: "", 
      //                     raw: true
      //                 });
      //             } catch (error) {
      //                 console.error("Error reading Excel:", error);
      //                 sap.m.MessageToast.show("Error reading Excel file. Please check the format.");
      //                 return;
      //             }

      //             if (!jsonData.length) {
      //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
      //                 return;
      //             }

      //             // Get field names from table
      //             const table = that.byId("FGProcessPlantabl");
      //             const columns = table.getColumns();
      //             const fieldNames = columns.map(col => {
      //                 const template = col.getTemplate();
      //                 const bindInfo =
      //                     template.getBindingInfo("value") ||
      //                     template.getBindingInfo("text") ||
      //                     template.getBindingInfo("selected") ||
      //                     template.getBindingInfo("selectedKey");
      //                 return bindInfo?.parts?.[0]?.path || null;
      //             }).filter(Boolean);

      //             // Add additional fields
      //             const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
      //             additionalFields.forEach(field => {
      //                 if (!fieldNames.includes(field)) {
      //                     fieldNames.push(field);
      //                 }
      //             });

      //             // Map Excel data to model fields
      //             const allErrors = [];
      //             const mapped = jsonData.map((row, rowIndex) => {
      //                 const obj = {};
      //                 const rowKeys = Object.keys(row);

      //                 rowKeys.forEach((key) => {
      //                     const hdr = key.trim().toLowerCase().replace(/\s+/g, "");
      //                     const field = fieldNames.find(f => {
      //                         const fLower = f.toLowerCase();
      //                         // Common date field variations
      //                         if (hdr.includes("date") && fLower.includes("productionordstartdate")) return true;
      //                         if (hdr.includes("start") && fLower.includes("productionordstartdate")) return true;
      //                         if (fLower === hdr) return true;
      //                         return false;
      //                     });

      //                     if (field) {
      //                         let rawValue = row[key];

      //                         // Handle date field
      //                         if (field === "productionordstartdate") {
      //                             // Parse the date
      //                             const dateObj = parseExcelDateToDate(rawValue);
      //                             if (dateObj) {
      //                                 // Store as Date object for the model
      //                                 obj.productionordstartdate = dateObj;
      //                             } else if (rawValue !== undefined && rawValue !== null && rawValue !== "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Invalid date format: "${rawValue}". Please use yyyy-MM-dd format.`);
      //                                 obj.productionordstartdate = null;
      //                             } else {
      //                                 obj.productionordstartdate = null;
      //                             }
      //                         }
      //                         // Handle slabno
      //                         else if (field === "slabno") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 if (sValue.length < 4) {
      //                                     obj.slabno = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     obj.slabno = sValue;
      //                                 }
      //                             } else {
      //                                 obj.slabno = "";
      //                             }
      //                         }
      //                         // Handle speccode
      //                         else if (field === "speccode") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 let sValue = String(rawValue).trim();
      //                                 if (sValue.length < 4) {
      //                                     obj.speccode = ("0000" + sValue).slice(-4);
      //                                 } else {
      //                                     obj.speccode = sValue;
      //                                 }
      //                             } else {
      //                                 obj.speccode = "";
      //                             }
      //                         }
      //                         // Handle shift
      //                         else if (field === "shift") {
      //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                                 obj.shift = "";
      //                             } else {
      //                                 obj.shift = String(rawValue).trim();
      //                             }
      //                         }
      //                         // Handle productionorderqty
      //                         else if (field === "productionorderqty") {
      //                             if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
      //                                 const numValue = parseFloat(rawValue);
      //                                 if (!isNaN(numValue)) {
      //                                     obj.productionorderqty = numValue.toFixed(3);
      //                                 } else {
      //                                     obj.productionorderqty = "0.000";
      //                                 }
      //                             } else {
      //                                 obj.productionorderqty = "0.000";
      //                             }
      //                         }
      //                         // Handle other fields
      //                         else {
      //                             obj[field] = rawValue !== undefined && rawValue !== null ? rawValue : "";
      //                         }
      //                     }
      //                 });
      //                 return obj;
      //             });

      //             // Check for errors
      //             if (allErrors.length > 0) {
      //                 const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // Ensure all mapped objects have required fields
      //             mapped.forEach((row) => {
      //                 if (!row.productionordstartdate) {
      //                     row.productionordstartdate = null;
      //                 }
      //                 if (!row.slabno) {
      //                     row.slabno = "";
      //                 }
      //                 if (!row.speccode) {
      //                     row.speccode = "";
      //                 }
      //                 if (!row.shift) {
      //                     row.shift = "";
      //                 }
      //                 if (!row.productionorderqty) {
      //                     row.productionorderqty = "0.000";
      //                 }
      //             });

      //             validateAndImport(mapped);
      //         };

      //         reader.onerror = function () {
      //             sap.m.MessageToast.show("Error reading Excel file.");
      //         };

      //         reader.readAsBinaryString(file);
      //     }

      //     async function validateAndImport(mapped) {
      //         const oView = that.getView();
      //         const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //         const aSelectedRows = mapped;

      //         try {
      //             const aErrors = [];

      //             // STEP 1: Check for duplicate Slab No + Date combinations
      //             const excelCombinationMap = new Map();
      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;

      //                 const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
      //                 const slabValue = (row.slabno || "").toString().trim();

      //                 if (dateStr && slabValue) {
      //                     const combinationKey = `${dateStr}|${slabValue}`;

      //                     if (excelCombinationMap.has(combinationKey)) {
      //                         const firstRow = excelCombinationMap.get(combinationKey);
      //                         aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateStr}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
      //                     } else {
      //                         excelCombinationMap.set(combinationKey, rowNumber);
      //                     }
      //                 }
      //             });

      //             // STEP 2: Check for past dates
      //             const oToday = new Date();
      //             oToday.setHours(0, 0, 0, 0);

      //             aSelectedRows.forEach((row, idx) => {
      //                 const rowNumber = idx + 2;
      //                 const dateObj = row.productionordstartdate;

      //                 if (dateObj && dateObj instanceof Date && !isNaN(dateObj.getTime())) {
      //                     const selectedDate = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
      //                     selectedDate.setHours(0, 0, 0, 0);

      //                     if (selectedDate < oToday) {
      //                         const dateStr = formatDateToYYYYMMDD(dateObj);
      //                         aErrors.push(`Row ${rowNumber}: Cannot select a past date (${dateStr}). Please select today's date or a future date.`);
      //                     }
      //                 }
      //             });

      //             // STEP 3: Process each row for material validation
      //             for (let i = 0; i < aSelectedRows.length; i++) {
      //                 const row = aSelectedRows[i];
      //                 const rowNumber = i + 2;
      //                 const specCode = String(row.speccode || "").trim();
      //                 const materialCode = String(row.materialcode || "").trim();
      //                 const description = String(row.description || "").trim();
      //                 const plant = row.plant || "1200";

      //                 if (!row.plant || String(row.plant || "").trim() === "") {
      //                     row.plant = "1200";
      //                 }

      //                 if (specCode && specCode.length >= 4) {
      //                     try {
      //                         const materialData = await new Promise((resolve, reject) => {
      //                             const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
      //                             const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
      //                             const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);

      //                             oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                 filters: [plantFilter, productGroupFilter, specCodeFilter],
      //                                 success: function (oData) {
      //                                     resolve(oData.results || []);
      //                                 },
      //                                 error: function (oError) {
      //                                     reject(oError);
      //                                 }
      //                             });
      //                         });

      //                         if (materialData.length === 0) {
      //                             aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
      //                         } else if (materialData.length === 1) {
      //                             const material = materialData[0];
      //                             row.materialcode = material.Product;
      //                             row.description = material.ProductName;

      //                             if (material.ExternalProductGroup !== "FG BELT") {
      //                                 aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                             }
      //                         } else {
      //                             aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
      //                         }
      //                     } catch (error) {
      //                         aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
      //                     }
      //                 }
      //                 else if (materialCode || description) {
      //                     const filters = [];
      //                     if (materialCode) {
      //                         filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
      //                     }
      //                     if (description) {
      //                         filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
      //                     }

      //                     if (filters.length > 0) {
      //                         const combinedFilter = new sap.ui.model.Filter({
      //                             filters: filters,
      //                             and: false
      //                         });

      //                         try {
      //                             const materialData = await new Promise((resolve, reject) => {
      //                                 oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //                                     filters: [combinedFilter],
      //                                     success: function (oData) {
      //                                         resolve(oData.results || []);
      //                                     },
      //                                     error: function (oError) {
      //                                         reject(oError);
      //                                     }
      //                                 });
      //                             });

      //                             if (materialData.length === 0) {
      //                                 if (materialCode && description) {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
      //                                 } else if (materialCode) {
      //                                     aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
      //                                 } else {
      //                                     aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
      //                                 }
      //                             } else {
      //                                 const material = materialData[0];
      //                                 if (!materialCode && description) {
      //                                     row.materialcode = material.Product;
      //                                 }
      //                                 if (!description && materialCode) {
      //                                     row.description = material.ProductName;
      //                                 }

      //                                 if (material.ExternalProductGroup !== "FG BELT") {
      //                                     aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
      //                                 }
      //                             }
      //                         } catch (error) {
      //                             aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
      //                         }
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
      //                 }

      //                 // Validate shift
      //                 if (row.shift && row.shift.trim() !== "") {
      //                     const shiftValue = String(row.shift).trim();

      //                     let normalizedShift = shiftValue;

      //                     if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
      //                         normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
      //                     }
      //                     else if (shiftValue.toLowerCase().startsWith("shift-")) {
      //                         const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
      //                         if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
      //                             normalizedShift = `Shift-${shiftLetter}`;
      //                         }
      //                     }

      //                     if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
      //                         aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
      //                     } else {
      //                         row.shift = normalizedShift;
      //                     }
      //                 } else {
      //                     aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //                 }

      //                 // Set compound code
      //                 const finalDesc = String(row.description || "").trim();
      //                 if (finalDesc) {
      //                     const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //                     row.compoundcode = base;
      //                 }
      //             }

      //             // Generate BIPL LOT NO
      //             aSelectedRows.forEach((row) => {
      //                 row.bipllotno = generateBiplLotNoForRow(row);
      //             });

      //             // STEP 4: Check for duplicates with existing table data
      //             if (aErrors.length === 0) {
      //                 const oTabModel = oView.getModel("TabModel");
      //                 const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
      //                 const aExistingRows = oExistingRowsInfo.array;

      //                 const existingCombinationMap = new Map();
      //                 aExistingRows.forEach((row, index) => {
      //                     const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateStr && slabValue) {
      //                         const combinationKey = `${dateStr}|${slabValue}`;
      //                         existingCombinationMap.set(combinationKey, index + 1);
      //                     }
      //                 });

      //                 aSelectedRows.forEach((row, idx) => {
      //                     const rowNumber = idx + 2;
      //                     const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
      //                     const slabValue = (row.slabno || "").toString().trim();

      //                     if (dateStr && slabValue) {
      //                         const combinationKey = `${dateStr}|${slabValue}`;

      //                         if (existingCombinationMap.has(combinationKey)) {
      //                             const existingRowIndex = existingCombinationMap.get(combinationKey);
      //                             aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateStr}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
      //                         }
      //                     }
      //                 });
      //             }

      //             // Show errors if any
      //             if (aErrors.length > 0) {
      //                 const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //                 sap.m.MessageBox.error(errorMessage);
      //                 return;
      //             }

      //             // STEP 5: Import data
      //             const oModel = oView.getModel("TabModel");
      //             const existingData = oModel.getProperty("/Samples") || [];

      //             // IMPORTANT: Ensure all dates are valid Date objects
      //             aSelectedRows.forEach((row) => {
      //                 if (row.productionordstartdate && !(row.productionordstartdate instanceof Date)) {
      //                     // Try to convert to Date object if it's a string
      //                     const dateStr = row.productionordstartdate;
      //                     if (typeof dateStr === "string" && /^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      //                         const parts = dateStr.split("-");
      //                         const year = parseInt(parts[0], 10);
      //                         const month = parseInt(parts[1], 10) - 1;
      //                         const day = parseInt(parts[2], 10);
      //                         row.productionordstartdate = new Date(year, month, day);
      //                     } else {
      //                         row.productionordstartdate = null;
      //                     }
      //                 }

      //                 // Also store as formatted string for display if needed
      //                 if (row.productionordstartdate instanceof Date && !isNaN(row.productionordstartdate.getTime())) {
      //                     row.productionordstartdateFormatted = formatDateToYYYYMMDD(row.productionordstartdate);
      //                 } else {
      //                     row.productionordstartdate = null;
      //                     row.productionordstartdateFormatted = "";
      //                 }
      //             });

      //             const updatedData = existingData.concat(aSelectedRows);

      //             // Set the data
      //             oModel.setProperty("/Samples", updatedData);

      //             // IMPORTANT: Refresh the model to update bindings
      //             oModel.refresh(true);

      //             sap.m.MessageToast.show(`Successfully imported ${aSelectedRows.length} row(s).`);

      //         } catch (error) {
      //             console.error("Validation error:", error);
      //             sap.m.MessageBox.error("Validation failed. Please try again.");
      //         }
      //     }

      //     const fileInput = document.createElement("input");
      //     fileInput.type = "file";
      //     fileInput.accept = ".xlsx,.xls";
      //     fileInput.style.display = "none";

      //     fileInput.addEventListener("change", function (e) {
      //         const file = e.target.files[0];
      //         if (!file) return;
      //         ensureXLSX(() => doImport(file));
      //         document.body.removeChild(fileInput);
      //     });

      //     document.body.appendChild(fileInput);
      //     fileInput.click();
      // },




      onImportExl: function () {
        const that = this;

        // FIXED: Simple date parsing that returns a valid Date object or null
        function parseExcelDateToDate(rawValue) {
          if (!rawValue && rawValue !== 0) {
            return null;
          }

          let dateObj = null;

          // CASE 1: Already a valid Date object
          if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
            return rawValue;
          }

          // CASE 2: Excel serial number
          if (typeof rawValue === 'number') {
            try {
              // Excel's epoch is December 30, 1899
              const excelEpoch = new Date(1899, 11, 30);
              const date = new Date(excelEpoch.getTime() + rawValue * 86400000);
              if (!isNaN(date.getTime())) {
                // Create a date without timezone issues
                dateObj = new Date(date.getFullYear(), date.getMonth(), date.getDate());
              }
            } catch (e) {
              console.warn("Error parsing Excel serial date:", rawValue, e);
            }
          }
          // CASE 3: String value
          else if (typeof rawValue === 'string') {
            const trimmed = rawValue.trim();
            if (!trimmed) return null;

            try {
              // Try yyyy-MM-dd format (as specified)
              if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
                const parts = trimmed.split("-");
                const year = parseInt(parts[0], 10);
                const month = parseInt(parts[1], 10) - 1;
                const day = parseInt(parts[2], 10);

                if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                  dateObj = new Date(year, month, day);
                  // Verify it's a valid date
                  if (dateObj.getFullYear() !== year ||
                    dateObj.getMonth() !== month ||
                    dateObj.getDate() !== day ||
                    isNaN(dateObj.getTime())) {
                    dateObj = null;
                  }
                }
              }
              // Try dd/MM/yyyy format
              else if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                const parts = trimmed.split("/");
                const day = parseInt(parts[0], 10);
                const month = parseInt(parts[1], 10) - 1;
                const year = parseInt(parts[2], 10);

                if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                  dateObj = new Date(year, month, day);
                  if (isNaN(dateObj.getTime())) dateObj = null;
                }
              }
              // Try general date parsing
              else {
                const tempDate = new Date(trimmed);
                if (!isNaN(tempDate.getTime())) {
                  // Create date without time component
                  dateObj = new Date(tempDate.getFullYear(), tempDate.getMonth(), tempDate.getDate());
                }
              }
            } catch (e) {
              console.warn("Error parsing date string:", trimmed, e);
            }
          }

          return dateObj;
        }

        // Format date to yyyy-MM-dd string for storage
        function formatDateToYYYYMMDD(date) {
          if (!date) return "";

          if (date instanceof Date && !isNaN(date.getTime())) {
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
          }

          // If it's already a string in yyyy-MM-dd format
          if (typeof date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
            return date;
          }

          return "";
        }

        // Helper function to generate BIPL LOT NO for a row
        function generateBiplLotNoForRow(row) {
          var productionDate = row.productionordstartdate;
          var slabNo = row.slabno;
          var specCode = row.speccode;

          if (!productionDate || !slabNo || !specCode) {
            return "";
          }

          try {
            // Convert to string if it's a Date object
            var dateStr = formatDateToYYYYMMDD(productionDate);

            // Ensure dateStr has the right format
            if (!dateStr || dateStr.length < 10) {
              return "";
            }

            // Extract components
            var year = dateStr.substring(2, 4); // Last 2 digits of year
            var month = dateStr.substring(5, 7); // Month
            var day = dateStr.substring(8, 10); // Day

            // Pad slabNo to 4 digits with leading zeros if not already done
            var paddedSlabNo = slabNo;
            if (slabNo && slabNo.length < 4) {
              paddedSlabNo = ("0000" + slabNo).slice(-4);
            }

            // Build the BIPL LOT NO
            var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

            return biplLotNo;

          } catch (error) {
            console.error("Error generating BIPL LOT NO:", error);
            return "";
          }
        }

        function ensureXLSX(cb) {
          if (window.XLSX) return cb();

          const script = document.createElement("script");
          script.src = importexcelfile;
          script.onload = cb;
          script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
          document.head.appendChild(script);
        }

        function doImport(file) {
          const reader = new FileReader();
          reader.onload = function (e) {
            const data = e.target.result;

            let jsonData = [];
            try {
              // Try with raw: true first to get the raw values
              const workbook = XLSX.read(data, {
                type: "binary",
                raw: true,
                cellDates: false
              });

              const sheet = workbook.Sheets[workbook.SheetNames[0]];
              jsonData = XLSX.utils.sheet_to_json(sheet, {
                defval: "",
                raw: true
              });
            } catch (error) {
              console.error("Error reading Excel:", error);
              sap.m.MessageToast.show("Error reading Excel file. Please check the format.");
              return;
            }

            if (!jsonData.length) {
              sap.m.MessageToast.show("No data found in the Excel sheet.");
              return;
            }

            // Get field names from table
            const table = that.byId("FGProcessPlantabl");
            const columns = table.getColumns();
            const fieldNames = columns.map(col => {
              const template = col.getTemplate();
              const bindInfo =
                template.getBindingInfo("value") ||
                template.getBindingInfo("text") ||
                template.getBindingInfo("selected") ||
                template.getBindingInfo("selectedKey");
              return bindInfo?.parts?.[0]?.path || null;
            }).filter(Boolean);

            // Add additional fields
            const additionalFields = ["productionorderqty", "productionorderno", "bipllotno", "lotno"];
            additionalFields.forEach(field => {
              if (!fieldNames.includes(field)) {
                fieldNames.push(field);
              }
            });

            // Map Excel data to model fields
            const allErrors = [];
            const mapped = jsonData.map((row, rowIndex) => {
              const obj = {};
              const rowKeys = Object.keys(row);

              rowKeys.forEach((key) => {
                const hdr = key.trim().toLowerCase().replace(/\s+/g, "");
                const field = fieldNames.find(f => {
                  const fLower = f.toLowerCase();
                  // Common date field variations
                  if (hdr.includes("date") && fLower.includes("productionordstartdate")) return true;
                  if (hdr.includes("start") && fLower.includes("productionordstartdate")) return true;
                  if (fLower === hdr) return true;
                  return false;
                });

                if (field) {
                  let rawValue = row[key];

                  // Handle date field
                  if (field === "productionordstartdate") {
                    // Parse the date
                    const dateObj = parseExcelDateToDate(rawValue);
                    if (dateObj) {
                      // Store as Date object for the model
                      obj.productionordstartdate = dateObj;
                    } else if (rawValue !== undefined && rawValue !== null && rawValue !== "") {
                      allErrors.push(`Row ${rowIndex + 2}: Invalid date format: "${rawValue}". Please use yyyy-MM-dd format.`);
                      obj.productionordstartdate = null;
                    } else {
                      obj.productionordstartdate = null;
                    }
                  }
                  // Handle slabno
                  else if (field === "slabno") {
                    if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
                      let sValue = String(rawValue).trim();
                      if (sValue.length < 4) {
                        obj.slabno = ("0000" + sValue).slice(-4);
                      } else {
                        obj.slabno = sValue;
                      }
                    } else {
                      obj.slabno = "";
                    }
                  }
                  // Handle speccode
                  else if (field === "speccode") {
                    if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
                      let sValue = String(rawValue).trim();
                      if (sValue.length < 4) {
                        obj.speccode = ("0000" + sValue).slice(-4);
                      } else {
                        obj.speccode = sValue;
                      }
                    } else {
                      obj.speccode = "";
                    }
                  }
                  // Handle shift
                  else if (field === "shift") {
                    if (rawValue === null || rawValue === undefined || rawValue === "") {
                      allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
                      obj.shift = "";
                    } else {
                      obj.shift = String(rawValue).trim();
                    }
                  }
                  // Handle productionorderqty
                  else if (field === "productionorderqty") {
                    if (rawValue !== null && rawValue !== undefined && rawValue !== "") {
                      const numValue = parseFloat(rawValue);
                      if (!isNaN(numValue)) {
                        obj.productionorderqty = numValue.toFixed(3);
                      } else {
                        obj.productionorderqty = "0.000";
                      }
                    } else {
                      obj.productionorderqty = "0.000";
                    }
                  }
                  // Handle other fields
                  else {
                    obj[field] = rawValue !== undefined && rawValue !== null ? rawValue : "";
                  }
                }
              });
              return obj;
            });

            // Check for errors
            if (allErrors.length > 0) {
              const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
              sap.m.MessageBox.error(errorMessage);
              return;
            }

            // Ensure all mapped objects have required fields
            mapped.forEach((row) => {
              if (!row.productionordstartdate) {
                row.productionordstartdate = null;
              }
              if (!row.slabno) {
                row.slabno = "";
              }
              if (!row.speccode) {
                row.speccode = "";
              }
              if (!row.shift) {
                row.shift = "";
              }
              if (!row.productionorderqty) {
                row.productionorderqty = "0.000";
              }
            });

            validateAndImport(mapped);
          };

          reader.onerror = function () {
            sap.m.MessageToast.show("Error reading Excel file.");
          };

          reader.readAsBinaryString(file);
        }

        async function validateAndImport(mapped) {
          const oView = that.getView();
          const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
          const aSelectedRows = mapped;

          try {
            const aErrors = [];

            // STEP 1: Check for duplicate Slab No + Date combinations
            const excelCombinationMap = new Map();
            aSelectedRows.forEach((row, idx) => {
              const rowNumber = idx + 2;

              const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
              const slabValue = (row.slabno || "").toString().trim();

              if (dateStr && slabValue) {
                const combinationKey = `${dateStr}|${slabValue}`;

                if (excelCombinationMap.has(combinationKey)) {
                  const firstRow = excelCombinationMap.get(combinationKey);
                  aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateStr}) and Slab No (${slabValue}). First occurrence at row ${firstRow}.`);
                } else {
                  excelCombinationMap.set(combinationKey, rowNumber);
                }
              }
            });

            // STEP 2: Check for past dates
            const oToday = new Date();
            oToday.setHours(0, 0, 0, 0);

            aSelectedRows.forEach((row, idx) => {
              const rowNumber = idx + 2;
              const dateObj = row.productionordstartdate;

              if (dateObj && dateObj instanceof Date && !isNaN(dateObj.getTime())) {
                const selectedDate = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
                selectedDate.setHours(0, 0, 0, 0);

                if (selectedDate < oToday) {
                  const dateStr = formatDateToYYYYMMDD(dateObj);
                  aErrors.push(`Row ${rowNumber}: Cannot select a past date (${dateStr}). Please select today's date or a future date.`);
                }
              }
            });

            // STEP 3: Process each row for material validation
            for (let i = 0; i < aSelectedRows.length; i++) {
              const row = aSelectedRows[i];
              const rowNumber = i + 2;
              const specCode = String(row.speccode || "").trim();
              const materialCode = String(row.materialcode || "").trim();
              const description = String(row.description || "").trim();
              const plant = row.plant || "1200";

              if (!row.plant || String(row.plant || "").trim() === "") {
                row.plant = "1200";
              }

              if (specCode && specCode.length >= 4) {
                try {
                  const materialData = await new Promise((resolve, reject) => {
                    const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, row.plant);
                    const productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
                    const specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, specCode);
                    const deletionFilter = new sap.ui.model.Filter(
                        "IsMarkedForDeletion",
                        sap.ui.model.FilterOperator.EQ,
                        false
                    );

                    oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
                      filters: [plantFilter, productGroupFilter, specCodeFilter,deletionFilter],
                      success: function (oData) {
                        resolve(oData.results || []);
                      },
                      error: function (oError) {
                        reject(oError);
                      }
                    });
                  });

                  if (materialData.length === 0) {
                    aErrors.push(`Row ${rowNumber}: No material found for spec code: ${specCode} in plant: ${row.plant}`);
                  } else if (materialData.length === 1) {
                    const material = materialData[0];
                    row.materialcode = material.Product;
                    row.description = material.ProductName;

                    if (material.ExternalProductGroup !== "FG BELT") {
                      aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
                    }
                  } else {
                    aErrors.push(`Row ${rowNumber}: Multiple materials found for spec code ${specCode}. Please provide material code and description manually.`);
                  }
                } catch (error) {
                  aErrors.push(`Row ${rowNumber}: Error fetching material for spec code ${specCode}: ${error.message}`);
                }
              }
              else if (materialCode || description) {
                const filters = [];
                if (materialCode) {
                  filters.push(new sap.ui.model.Filter("Product", "EQ", materialCode));
                }
                if (description) {
                  filters.push(new sap.ui.model.Filter("ProductName", "EQ", description));
                }

                if (filters.length > 0) {
                  const combinedFilter = new sap.ui.model.Filter({
                    filters: filters,
                    and: false
                  });

                  try {
                    const materialData = await new Promise((resolve, reject) => {
                      oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
                        filters: [combinedFilter],
                        success: function (oData) {
                          resolve(oData.results || []);
                        },
                        error: function (oError) {
                          reject(oError);
                        }
                      });
                    });

                    if (materialData.length === 0) {
                      if (materialCode && description) {
                        aErrors.push(`Row ${rowNumber}: Material "${materialCode}" with description "${description}" not found.`);
                      } else if (materialCode) {
                        aErrors.push(`Row ${rowNumber}: Material code "${materialCode}" not found.`);
                      } else {
                        aErrors.push(`Row ${rowNumber}: Description "${description}" not found.`);
                      }
                    } else {
                      const material = materialData[0];
                      if (!materialCode && description) {
                        row.materialcode = material.Product;
                      }
                      if (!description && materialCode) {
                        row.description = material.ProductName;
                      }

                      if (material.ExternalProductGroup !== "FG BELT") {
                        aErrors.push(`Row ${rowNumber}: Material "${material.Product}" is not a FG BELT material.`);
                      }
                    }
                  } catch (error) {
                    aErrors.push(`Row ${rowNumber}: Error validating material: ${error.message}`);
                  }
                }
              } else {
                aErrors.push(`Row ${rowNumber}: Either spec code or material code/description must be provided.`);
              }

              // Validate shift
              if (row.shift && row.shift.trim() !== "") {
                const shiftValue = String(row.shift).trim();

                let normalizedShift = shiftValue;

                if (shiftValue.length === 1 && ["A", "B", "C", "a", "b", "c"].includes(shiftValue)) {
                  normalizedShift = `Shift-${shiftValue.toUpperCase()}`;
                }
                else if (shiftValue.toLowerCase().startsWith("shift-")) {
                  const shiftLetter = shiftValue.split("-")[1]?.toUpperCase();
                  if (shiftLetter && ["A", "B", "C"].includes(shiftLetter)) {
                    normalizedShift = `Shift-${shiftLetter}`;
                  }
                }

                if (!["Shift-A", "Shift-B", "Shift-C"].includes(normalizedShift)) {
                  aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: Shift-A, Shift-B, Shift-C (or just A, B, C)`);
                } else {
                  row.shift = normalizedShift;
                }
              } else {
                aErrors.push(`Row ${rowNumber}: Shift is missing.`);
              }

              // Set compound code
              const finalDesc = String(row.description || "").trim();
              if (finalDesc) {
                const base = finalDesc.split("(")[0]?.trim() || finalDesc;
                row.compoundcode = base;
              }
            }

            // Generate BIPL LOT NO
            aSelectedRows.forEach((row) => {
              row.bipllotno = generateBiplLotNoForRow(row);
            });

            // STEP 4: Validate Machine Combinations and set machinenumberhidden
            const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

            if (rowsWithMachine.length > 0) {
              try {
                // Group by plant and material to reduce number of requests
                const groupedRows = {};
                rowsWithMachine.forEach(row => {
                  const key = `${row.plant}_${row.materialcode}`;
                  if (!groupedRows[key]) {
                    groupedRows[key] = [];
                  }
                  groupedRows[key].push(row);
                });

                // Process each group
                for (const groupKey in groupedRows) {
                  const rowsInGroup = groupedRows[groupKey];
                  const firstRow = rowsInGroup[0];

                  // Fetch production versions for this plant and material
                  const prodVersions = await new Promise((resolve, reject) => {
                    const plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, firstRow.plant);
                    const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, firstRow.materialcode);

                    oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
                      filters: [plantFilter, materialFilter],
                      success: function (oData) {
                        resolve(oData.results || []);
                      },
                      error: function (oError) {
                        reject(oError);
                      }
                    });
                  });

                  // Create a map for quick lookup of ProductionVersion by ProductionVersionText
                  const prodVersionMap = {};
                  prodVersions.forEach(pv => {
                    const key = `${pv.ProductionVersionText}`;
                    prodVersionMap[key] = pv.ProductionVersion;
                  });

                  // Validate each row in the group
                  rowsInGroup.forEach((row, idx) => {
                    const machineText = row.machinenumber;
                    if (prodVersionMap[machineText]) {
                      // Set the hidden machine number (ProductionVersion code)
                      row.machinenumberhidden = prodVersionMap[machineText];
                    } else {
                      // Try to find partial match (if user entered just the code like "LNE1")
                      let found = false;
                      for (const pv of prodVersions) {
                        if (pv.ProductionVersion === machineText ||
                          pv.ProductionVersionText.toLowerCase().includes(machineText.toLowerCase())) {
                          row.machinenumber = pv.ProductionVersionText; // Set visible text
                          row.machinenumberhidden = pv.ProductionVersion; // Set hidden code
                          found = true;
                          break;
                        }
                      }

                      if (!found) {
                        const trueIdx = aSelectedRows.indexOf(row);
                        aErrors.push(`Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`);
                      }
                    }
                  });
                }
              } catch (error) {
                console.error("Error validating machine combinations:", error);
                // Don't fail the import if machine validation fails
                // Just log error and continue without machine number validation
              }
            }

            // STEP 5: Check for duplicate combinations with existing table data
            if (aErrors.length === 0) {
              const oTabModel = oView.getModel("TabModel");
              const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
              const aExistingRows = oExistingRowsInfo.array;

              const existingCombinationMap = new Map();
              aExistingRows.forEach((row, index) => {
                const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
                const slabValue = (row.slabno || "").toString().trim();

                if (dateStr && slabValue) {
                  const combinationKey = `${dateStr}|${slabValue}`;
                  existingCombinationMap.set(combinationKey, index + 1);
                }
              });

              aSelectedRows.forEach((row, idx) => {
                const rowNumber = idx + 2;
                const dateStr = formatDateToYYYYMMDD(row.productionordstartdate);
                const slabValue = (row.slabno || "").toString().trim();

                if (dateStr && slabValue) {
                  const combinationKey = `${dateStr}|${slabValue}`;

                  if (existingCombinationMap.has(combinationKey)) {
                    const existingRowIndex = existingCombinationMap.get(combinationKey);
                    aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateStr}) and Slab No (${slabValue}) already exists in the table at row ${existingRowIndex}.`);
                  }
                }
              });
            }

            // Show errors if any
            if (aErrors.length > 0) {
              const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
              sap.m.MessageBox.error(errorMessage);
              return;
            }

            // STEP 6: Fetch Production Quantity from ZSB_PRODUCTVERSION for rows with machine number
            const rowsWithMachineNumber = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

            if (rowsWithMachineNumber.length > 0) {
              const oProdVersionModel = oView.getModel("ZSB_PRODUCTVERSION");

              if (oProdVersionModel) {
                // Create filters for all rows with machine number that don't have productionorderqty set
                const rowsToFetch = rowsWithMachineNumber.filter(row =>
                  !row.productionorderqty || row.productionorderqty === "0.000" || row.productionorderqty === ""
                );

                if (rowsToFetch.length > 0) {
                  const prodVersionPromises = rowsToFetch.map(row =>
                    new Promise((resolve, reject) => {
                      const materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, row.materialcode);
                      const prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, row.machinenumberhidden || row.machinenumber);

                      oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
                        filters: [materialFilter, prodVersionFilter],
                        success: function (oData) {
                          if (oData.results && oData.results.length > 0) {
                            let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity || "0.000";
                            resolve({
                              material: row.materialcode,
                              productionVersion: row.machinenumberhidden || row.machinenumber,
                              maxLotSize: maxLotSize
                            });
                          } else {
                            resolve({
                              material: row.materialcode,
                              productionVersion: row.machinenumberhidden || row.machinenumber,
                              maxLotSize: "0.000"
                            });
                          }
                        },
                        error: function (err) {
                          console.error("Failed to fetch MaterialMinLotSizeQuantity for", row.materialcode, row.machinenumber, err);
                          resolve({
                            material: row.materialcode,
                            productionVersion: row.machinenumberhidden || row.machinenumber,
                            maxLotSize: "0.000"
                          });
                        }
                      });
                    })
                  );

                  const prodVersionResults = await Promise.all(prodVersionPromises);

                  // Create a map for quick lookup
                  const prodQtyMap = {};
                  prodVersionResults.forEach(result => {
                    const key = `${result.material}_${result.productionVersion}`;
                    prodQtyMap[key] = result.maxLotSize;
                  });

                  // Assign production order quantity to rows with machine number
                  rowsToFetch.forEach(row => {
                    const key = `${row.materialcode}_${row.machinenumberhidden || row.machinenumber}`;
                    row.productionorderqty = prodQtyMap[key] || "0.000";
                  });
                }
              } else {
                console.error("ZSB_PRODUCTVERSION model not found");
                // Set productionorderqty to 0.000 for rows that don't have it
                aSelectedRows.forEach(row => {
                  if (!row.productionorderqty || row.productionorderqty === "") {
                    row.productionorderqty = "0.000";
                  }
                });
              }
            } else {
              // For rows without machine number, ensure productionorderqty is set
              aSelectedRows.forEach(row => {
                if (!row.productionorderqty || row.productionorderqty === "") {
                  row.productionorderqty = "0.000";
                }
              });
            }

            // STEP 7: Import data
            const oModel = oView.getModel("TabModel");
            const existingData = oModel.getProperty("/Samples") || [];

            // IMPORTANT: Ensure all dates are valid Date objects
            aSelectedRows.forEach((row) => {
              if (row.productionordstartdate && !(row.productionordstartdate instanceof Date)) {
                // Try to convert to Date object if it's a string
                const dateStr = row.productionordstartdate;
                if (typeof dateStr === "string" && /^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
                  const parts = dateStr.split("-");
                  const year = parseInt(parts[0], 10);
                  const month = parseInt(parts[1], 10) - 1;
                  const day = parseInt(parts[2], 10);
                  row.productionordstartdate = new Date(year, month, day);
                } else {
                  row.productionordstartdate = null;
                }
              }

              // Also store as formatted string for display if needed
              if (row.productionordstartdate instanceof Date && !isNaN(row.productionordstartdate.getTime())) {
                row.productionordstartdateFormatted = formatDateToYYYYMMDD(row.productionordstartdate);
              } else {
                row.productionordstartdate = null;
                row.productionordstartdateFormatted = "";
              }
            });

            const updatedData = existingData.concat(aSelectedRows);

            // Set the data
            oModel.setProperty("/Samples", updatedData);

            // IMPORTANT: Refresh the model to update bindings
            oModel.refresh(true);

            sap.m.MessageToast.show(`Successfully imported ${aSelectedRows.length} row(s).`);

          } catch (error) {
            console.error("Validation error:", error);
            sap.m.MessageBox.error("Validation failed. Please try again.");
          }
        }

        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".xlsx,.xls";
        fileInput.style.display = "none";

        fileInput.addEventListener("change", function (e) {
          const file = e.target.files[0];
          if (!file) return;
          ensureXLSX(() => doImport(file));
          document.body.removeChild(fileInput);
        });

        document.body.appendChild(fileInput);
        fileInput.click();
      },


      onExportExl: function () {
        const oModel = this.getView().getModel("TabModel");
        const aData = oModel.getProperty("/Samples") || [];

        // 🔹 Sort the data in the same sequence as the table
        // First by productionordstartdate (descending), then by slabno (ascending)
        const aSortedData = aData.sort((a, b) => {
          // First sort by productionordstartdate (descending)
          const dateA = new Date(a.productionordstartdate);
          const dateB = new Date(b.productionordstartdate);

          if (dateA > dateB) return -1;  // Descending order
          if (dateA < dateB) return 1;   // Descending order

          // If dates are equal, sort by slabno (ascending)
          const slabA = a.slabno || "";
          const slabB = b.slabno || "";
          if (slabA < slabB) return -1;
          if (slabA > slabB) return 1;

          return 0;
        });

        // 🔹 Format function for yyyy-MM-dd
        const fnFormatDate = (date) => {
          if (!date) return "";
          const oDate = new Date(date);
          const year = oDate.getFullYear();
          const month = String(oDate.getMonth() + 1).padStart(2, '0');
          const day = String(oDate.getDate()).padStart(2, '0');
          return `${year}-${month}-${day}`;
        };

        // 🔹 Clone + format dates before export
        const aExportData = aSortedData.length > 0
          ? aSortedData.map(item => ({
            ...item,
            productionordstartdate: fnFormatDate(item.productionordstartdate)
          }))
          : [{}]; // dummy row to avoid "unknown number of rows"

        // 🔹 Define columns
        const aColumns = [
          { label: "Plant", property: "plant" },
          { label: "Production Order Start Date", property: "productionordstartdate" },
          { label: "Slab No", property: "slabno" },
          { label: "Spec Code", property: "speccode" },
          { label: "Lot No", property: "lotno" },
          { label: "Shift", property: "shift" },
          { label: "Machine Number", property: "machinenumber" },
          { label: "Production Order Qty", property: "productionorderqty" },
          { label: "BIPL Lot No", property: "bipllotno" },
          { label: "Material Code", property: "materialcode" },
          { label: "Description", property: "description" },
          { label: "Storage Location", property: "storagelocation" },
          { label: "Production Order No", property: "productionorderno" }
        ];

        // 🔹 Create spreadsheet
        const oSpreadsheet = new sap.ui.export.Spreadsheet({
          workbook: {
            columns: aColumns,
            context: { sheetName: "FGProcess Plan" }
          },
          dataSource: aExportData,
          fileName: "FGProcess_Plan_Export.xlsx"
        });

        oSpreadsheet.build()
          .then(() => {
            sap.m.MessageToast.show("Export completed.");
          })
          .catch((oError) => {
            sap.m.MessageBox.error("Export failed: " + oError.message);
          });
      },




      // onExportExl: function () {
      //   var oModel = this.getView().getModel("TabModel");
      //   var aData = oModel.getProperty("/Samples") || [];

      //   // Always export at least headers
      //   var aSafeData = aData.length > 0 ? aData : [{}];

      //   var aColumns = [
      //     { label: "Plant", property: "plant" },
      //     { label: "Production Order Start Date", property: "productionordstartdate"},
      //     { label: "Slab No", property: "slabno" },
      //     { label: "Spec Code", property: "speccode" },
      //     { label: "Lot No", property: "lotno" },
      //     { label: "Shift", property: "shift" },
      //     { label: "Machine Number", property: "machinenumber" },
      //     { label: "Production Order Qty", property: "productionorderqty" },
      //     { label: "BIPL Lot No", property: "bipllotno" },
      //     { label: "Material Code", property: "materialcode" },
      //     { label: "Description", property: "description" },
      //     { label: "Storage Location", property: "storagelocation" },
      //     { label: "Production Order No", property: "productionorderno" }
      //   ];

      //   var oSpreadsheet = new sap.ui.export.Spreadsheet({
      //     workbook: {
      //       columns: aColumns,
      //       context: {
      //         sheetName: "FGProcess Plan"
      //       }
      //     },
      //     dataSource: aSafeData,
      //     fileName: "FGProcess_Plan_Export.xlsx"
      //   });

      //   oSpreadsheet.build()
      //     .then(function () {
      //       sap.m.MessageToast.show("Export completed.");
      //     })
      //     .catch(function (oError) {
      //       sap.m.MessageBox.error("Export failed: " + oError.message);
      //     });
      // },













      // onBiplChange: function (oEvent) {
      //         const oInput = oEvent.getSource();
      //         let sBiplVal = (oInput.getValue() || "").toString().trim();
      //         const oContext = oInput.getBindingContext("TabModel");
      //         const sCurrentPath = oContext ? oContext.getPath() : null;
      //         const oTabModel = this.getView().getModel("TabModel");

      //         // If user cleared value, update model and return
      //         if (!sBiplVal) {
      //           if (sCurrentPath) {
      //             oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //           }
      //           return;
      //         }

      //         // Optionally normalize bipl (uppercase) if needed
      //         sBiplVal = sBiplVal.toUpperCase();
      //         oInput.setValue(sBiplVal);

      //         // Get the date value in this row (may be Date, or yyyy-MM-dd string, or empty)
      //         const vDate = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
      //         const sDateStr = this._formatToModelDateString(vDate);

      //         // If either field missing, can't be duplicate — just set model
      //         if (!sDateStr) {
      //           if (sCurrentPath) {
      //             oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
      //           }
      //           return;
      //         }

      //         // Now check duplicate combination
      //         if (sCurrentPath && this._isDuplicateCombination(oTabModel, sDateStr, sBiplVal, sCurrentPath)) {
      //           sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
      //           // Clear model fields for this row
      //           oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //           oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //           // Clear UI input value (binding usually handles it)
      //           oInput.setValue("");
      //           // If there is a DatePicker in the same row, its binding will pick up the cleared model value.
      //           return;
      //         }

      //         // No duplicate -> persist bipllotno in model
      //         if (sCurrentPath) {
      //           oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
      //         }
      //       },




      onFetchMixingPlanData: function (plannedOrderNo) {
        var that = this;

        if (plannedOrderNo !== null) {
          var oModel = this.getView().getModel("TabModel");
          var aData = oModel.getProperty("/Samples");
          console.log("processOrderNo not found");
          return new Promise(function (resolve, reject) {
            try {
              // ✅ Show busy indicator
              // sap.ui.core.BusyIndicator.show(0);

              var oFilter = new sap.ui.model.Filter("plannedorderno", sap.ui.model.FilterOperator.EQ, plannedOrderNo);
              var oModel2 = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

              oModel2.read("/ZC_FG_PROCESS_PLAN", {
                filters: [oFilter],
                success: function (oData) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  var aItems = oData.results;
                  console.log("aItems:", aItems);

                  var oTarget = aData.find(function (item) {
                    return item.processOrderNo === plannedOrderNo;
                  });

                  if (oTarget) {
                    if (aItems.length > 0) {
                      oTarget.machinenumber = aItems[0].machinenumber || null;
                      oTarget.productionOrderQty = aItems[0].productionorderqty || null;
                      oTarget.balanceQty = aItems[0].balanceqty || null;
                      oTarget.LotBatchNo = aItems[0].lotbatchno || null;
                      oTarget.ManufacturingDate = aItems[0].manufacturingdate || null;
                      oTarget.ExpiryDate = aItems[0].expirydate || null;
                      oTarget.batchweight = aItems[0].batchweight || null;
                      oTarget.Operator = aItems[0].operator || null;
                      oTarget.Inspector = aItems[0].inspector || null;
                      oTarget.savedstatus = aItems[0].status || null;
                    } else {
                      oTarget.machinenumber = null;
                      oTarget.productionOrderQty = null;
                      oTarget.balanceQty = null;
                      oTarget.LotBatchNo = null;
                      oTarget.ManufacturingDate = null;
                      oTarget.ExpiryDate = null;
                      oTarget.batchweight = null;
                      oTarget.Operator = null;
                      oTarget.Inspector = null;
                      oTarget.savedstatus = null;
                    }

                    oModel.refresh();
                  } else {
                    console.log("processOrderNo not found");
                  }

                  resolve(aItems.length > 0 ? (aItems[0].machinenumber || null) : null);
                },
                error: function (oError) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  console.error("Error reading data: ", oError);
                  reject(oError);
                }
              });
            } catch (e) {
              // ✅ Hide busy indicator in case of unexpected error
              sap.ui.core.BusyIndicator.hide();

              console.error("Unexpected error: ", e);
              reject(e);
            }
          });
        }
      },










      // _getTabRowsArray: function (oTabModel) {
      //   const oData = oTabModel.getProperty("/");
      //   if (Array.isArray(oData)) {
      //     return { array: oData, basePath: "/" };
      //   }
      //   if (oData && Array.isArray(oData.results)) {
      //     return { array: oData.results, basePath: "/results" };
      //   }
      //   // fallback: find first array property in root object
      //   if (oData && typeof oData === "object") {
      //     for (const k of Object.keys(oData)) {
      //       if (Array.isArray(oData[k])) {
      //         return { array: oData[k], basePath: `/${k}` };
      //       }
      //     }
      //   }
      //   // Nothing found -> return empty array and root path
      //   return { array: [], basePath: "/" };
      // },


      // _formatToModelDateString: function (vDateOrString) {
      //   if (!vDateOrString) {
      //     return "";
      //   }
      //   // If it's already a string in yyyy-MM-dd, quick return
      //   if (typeof vDateOrString === "string") {
      //     // naive check for yyyy-MM-dd
      //     if (/^\d{4}-\d{2}-\d{2}$/.test(vDateOrString)) {
      //       return vDateOrString;
      //     }
      //     // try parsing common formats
      //     const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //     const oParsed = oParse.parse(vDateOrString);
      //     if (oParsed) {
      //       const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       return oFmt.format(oParsed);
      //     }
      //     // fallback: try Date constructor
      //     const d = new Date(vDateOrString);
      //     if (!isNaN(d.getTime())) {
      //       const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       return oFmt.format(d);
      //     }
      //     return "";
      //   }
      //   // If Date object
      //   if (vDateOrString instanceof Date && !isNaN(vDateOrString.getTime())) {
      //     const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //     return oFmt.format(vDateOrString);
      //   }
      //   return "";
      // },


      // _isDuplicateCombination: function (oTabModel, sDateString, sBiplValue, sCurrentPath) {
      //   sDateString = sDateString || "";
      //   sBiplValue = (sBiplValue || "").toString().trim();

      //   // find rows array
      //   const oRowsInfo = this._getTabRowsArray(oTabModel);
      //   const aRows = oRowsInfo.array;

      //   // If no rows, can't be duplicate
      //   if (!aRows || aRows.length === 0) {
      //     return false;
      //   }

      //   // Normalize currentPath to compare (remove trailing index part)
      //   // sCurrentPath might be like "/results/3" or "/3" or "/items/5"
      //   const sCurrentRowIndexPath = sCurrentPath; // compare exact path to exclude same row
      //   // Walk rows and compare each's date + bipl. But model entries shape may differ:
      //   for (let i = 0; i < aRows.length; i++) {
      //     const oRow = aRows[i];
      //     // build candidate date and bipl from row
      //     const sRowDate = this._formatToModelDateString(oRow.productionordstartdate);
      //     const sRowBipl = (oRow.bipllotno || "").toString().trim();

      //     // We need to determine the binding path for this array item to skip the same row.
      //     // Candidate row path = basePath + "/" + i
      //     const sCandidatePath = `${oRowsInfo.basePath}/${i}`;

      //     // Skip the current row itself
      //     if (sCandidatePath === sCurrentRowIndexPath) {
      //       continue;
      //     }

      //     if (sRowDate === sDateString && sRowBipl === sBiplValue && sDateString !== "" && sBiplValue !== "") {
      //       return true;
      //     }
      //   }
      //   return false;
      // },



      // onSlabNoChange: function (oEvent) {
      //   var oInput = oEvent.getSource();
      //   var sValue = oInput.getValue();
      //   var oContext = oInput.getBindingContext("TabModel");

      //   if (!oContext) {
      //     return;
      //   }

      //   // Pad with leading zeros if needed (for display consistency)
      //   if (sValue && sValue.length < 4) {
      //     var paddedValue = ("0000" + sValue).slice(-4);
      //     if (paddedValue !== sValue) {
      //       oInput.setValue(paddedValue);
      //       sValue = paddedValue;
      //     }
      //   }

      //   // Update model
      //   var oModel = this.getView().getModel("TabModel");
      //   oModel.setProperty(oContext.getPath() + "/slabno", sValue);

      //   // Generate BIPL LOT NO
      //   this.updateBiplLotNo(oContext);
      // },



      // onProductionDateChange: function (oEvent) {
      //   const oDatePicker = oEvent.getSource();
      //   const oSelectedDate = oDatePicker.getDateValue();
      //   const oContext = oDatePicker.getBindingContext("TabModel");
      //   const sCurrentPath = oContext ? oContext.getPath() : null;
      //   const oTabModel = this.getView().getModel("TabModel");

      //   // Get current date (without time part for comparison)
      //   const oToday = new Date();
      //   oToday.setHours(0, 0, 0, 0);

      //   // Create copy of selected date without time part
      //   const oSelectedDateNoTime = oSelectedDate ? new Date(oSelectedDate) : null;
      //   if (oSelectedDateNoTime) {
      //     oSelectedDateNoTime.setHours(0, 0, 0, 0);
      //   }

      //   // If date is cleared, allow it and clear model value
      //   if (!oSelectedDate) {
      //     if (sCurrentPath) {
      //       oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //       // Also clear BIPL LOT NO when date is cleared
      //       this.updateBiplLotNo(oContext);
      //     }
      //     return;
      //   }

      //   // Check if selected date is in the past
      //   if (oSelectedDateNoTime < oToday) {
      //     sap.m.MessageBox.error("Cannot select a past date. Please select today's date or a future date.");
      //     // restore current model value (if any)
      //     const sCurrentValue = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
      //     if (sCurrentValue) {
      //       const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       const oCurrentDate = oDateFormat.parse(sCurrentValue);
      //       oDatePicker.setDateValue(oCurrentDate);
      //     } else {
      //       oDatePicker.setValue("");
      //     }
      //     return;
      //   }

      //   // Format selected date to model string (yyyy-MM-dd)
      //   const oFmtModel = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //   const sSelectedDateStr = this._formatToModelDateString(oSelectedDate);

      //   // Read current bipl value from model for this row (may be empty if user hasn't typed yet)
      //   const sCurrentBipl = sCurrentPath ? (oTabModel.getProperty(sCurrentPath + "/bipllotno") || "").toString().trim() : "";

      //   // Check for duplicate combination (exclude current row)
      //   if (sCurrentPath && this._isDuplicateCombination(oTabModel, sSelectedDateStr, sCurrentBipl, sCurrentPath)) {
      //     // Duplicate found — clear the fields user just added in this row
      //     sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
      //     // Clear model fields for this row (both date and bipl)
      //     oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //     oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //     // Also clear the DatePicker UI (binding update should handle it, but do explicitly)
      //     oDatePicker.setValue("");
      //     return;
      //   }

      //   // No duplicate -> update model explicitly to normalized format
      //   if (sCurrentPath) {
      //     // Update the production order start date in the model
      //     oTabModel.setProperty(sCurrentPath + "/productionordstartdate", oSelectedDate);

      //     // Generate and update BIPL LOT NO after setting date
      //     this.updateBiplLotNo(oContext);
      //   }
      //   // Two-way binding will keep UI in sync
      // },


      _getTabRowsArray: function (oTabModel) {
        const oData = oTabModel.getProperty("/");
        if (Array.isArray(oData)) {
          return { array: oData, basePath: "/" };
        }
        if (oData && Array.isArray(oData.results)) {
          return { array: oData.results, basePath: "/results" };
        }
        // fallback: find first array property in root object
        if (oData && typeof oData === "object") {
          for (const k of Object.keys(oData)) {
            if (Array.isArray(oData[k])) {
              return { array: oData[k], basePath: `/${k}` };
            }
          }
        }
        // Nothing found -> return empty array and root path
        return { array: [], basePath: "/" };
      },

      _formatToModelDateString: function (vDateOrString) {
        if (!vDateOrString) {
          return "";
        }
        // If it's already a string in yyyy-MM-dd, quick return
        if (typeof vDateOrString === "string") {
          // naive check for yyyy-MM-dd
          if (/^\d{4}-\d{2}-\d{2}$/.test(vDateOrString)) {
            return vDateOrString;
          }
          // try parsing common formats
          const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
          const oParsed = oParse.parse(vDateOrString);
          if (oParsed) {
            const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            return oFmt.format(oParsed);
          }
          // fallback: try Date constructor
          const d = new Date(vDateOrString);
          if (!isNaN(d.getTime())) {
            const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            return oFmt.format(d);
          }
          return "";
        }
        // If Date object
        if (vDateOrString instanceof Date && !isNaN(vDateOrString.getTime())) {
          const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          return oFmt.format(vDateOrString);
        }
        return "";
      },

      // NEW: Method to fetch saved records from ZSB_FG_PROCESS_PLAN service
      _fetchSavedRecordsForDateAndSlab: function (sDateString) {
        return new Promise((resolve, reject) => {
          // Check if we have a date string to filter by
          if (!sDateString || sDateString.trim() === "") {
            resolve([]);
            return;
          }

          // Use the ZSB_FG_PROCESS_PLAN model
          const oModel = this.getView().getModel("ZSB_FG_PROCESS_PLAN");
          if (!oModel) {
            console.error("ZSB_FG_PROCESS_PLAN model not found");
            resolve([]);
            return;
          }

          // Create filter for the specific date
          const oFilter = new sap.ui.model.Filter("productionordstartdate",
            sap.ui.model.FilterOperator.EQ,
            sDateString
          );

          oModel.read("/ZC_FG_PROCESS_PLAN", {
            filters: [oFilter],
            urlParameters: {
              "$select": "productionordstartdate,slabno"
            },
            success: (oData) => {
              const aRecords = oData.results || [];
              // Format dates and slab numbers
              const aFormattedRecords = aRecords.map(record => {
                // Convert the OData date format to string
                let formattedDate = "";
                if (record.productionordstartdate) {
                  // Handle OData date format (could be string or object)
                  if (typeof record.productionordstartdate === 'string') {
                    formattedDate = record.productionordstartdate;
                  } else if (record.productionordstartdate.__edmType === "Edm.DateTime") {
                    // Handle OData DateTime format
                    const dateStr = record.productionordstartdate;
                    if (dateStr) {
                      formattedDate = this._formatToModelDateString(new Date(dateStr));
                    }
                  }
                }

                // Pad slabno to 4 digits if it's stored as a number
                let slabNo = record.slabno || "";
                if (slabNo && slabNo.toString().length < 4) {
                  slabNo = ("0000" + slabNo).slice(-4);
                }

                return {
                  productionordstartdate: formattedDate,
                  slabno: slabNo.toString()
                };
              });
              resolve(aFormattedRecords);
            },
            error: (oError) => {
              console.error("Error fetching saved records from ZSB_FG_PROCESS_PLAN:", oError);
              // Don't reject, just return empty array to allow user to continue
              resolve([]);
            }
          });
        });
      },

      // UPDATED: Method to check for duplicate date + slabno combination
      _isDuplicateDateSlabCombination: async function (oTabModel, sDateString, sSlabNo, sCurrentPath) {
        sDateString = sDateString || "";
        sSlabNo = (sSlabNo || "").toString().trim();

        // Pad slabno to 4 digits for comparison
        if (sSlabNo && sSlabNo.length < 4) {
          sSlabNo = ("0000" + sSlabNo).slice(-4);
        }

        // If either field is empty, can't be duplicate
        if (!sDateString || !sSlabNo) {
          return false;
        }

        // Check 1: Current table model
        const oRowsInfo = this._getTabRowsArray(oTabModel);
        const aRows = oRowsInfo.array;

        // Normalize currentPath to compare
        const sCurrentRowIndexPath = sCurrentPath;

        // Check in current table model
        for (let i = 0; i < aRows.length; i++) {
          const oRow = aRows[i];
          // Get date and slabno from row
          const sRowDate = this._formatToModelDateString(oRow.productionordstartdate);
          let sRowSlab = (oRow.slabno || "").toString().trim();

          // Pad row slabno for comparison
          if (sRowSlab && sRowSlab.length < 4) {
            sRowSlab = ("0000" + sRowSlab).slice(-4);
          }

          // We need to determine the binding path for this array item to skip the same row
          const sCandidatePath = `${oRowsInfo.basePath}/${i}`;

          // Skip the current row itself
          if (sCandidatePath === sCurrentRowIndexPath) {
            continue;
          }

          if (sRowDate === sDateString && sRowSlab === sSlabNo) {
            return true;
          }
        }

        // Check 2: Saved records in ZSB_FG_PROCESS_PLAN database
        try {
          const aSavedRecords = await this._fetchSavedRecordsForDateAndSlab(sDateString);

          // Check against saved records
          for (const oSavedRecord of aSavedRecords) {
            let savedSlabNo = oSavedRecord.slabno || "";
            // Ensure saved slabno is also padded for comparison
            if (savedSlabNo && savedSlabNo.length < 4) {
              savedSlabNo = ("0000" + savedSlabNo).slice(-4);
            }

            if (savedSlabNo === sSlabNo) {
              return true;
            }
          }
        } catch (error) {
          // If there's an error fetching saved records, log it but continue
          console.error("Error checking saved records for date+slab duplicates:", error);
          // Return false to not block user input due to network/backend issues
        }

        return false;
      },

      // UPDATED: onSlabNoChange with async duplicate check for date + slabno
      onSlabNoChange: async function (oEvent) {
        var oInput = oEvent.getSource();
        var sValue = oInput.getValue();
        var oContext = oInput.getBindingContext("TabModel");

        if (!oContext) {
          return;
        }

        var oModel = this.getView().getModel("TabModel");
        var sCurrentPath = oContext.getPath();

        // If user cleared value, update model and return
        if (!sValue || sValue.trim() === "") {
          oModel.setProperty(sCurrentPath + "/slabno", "");
          // Clear BIPL LOT NO when slabno is cleared
          this.updateBiplLotNo(oContext);
          return;
        }

        // Pad with leading zeros if needed (for display consistency)
        var paddedValue = sValue;
        if (sValue && sValue.length < 4) {
          paddedValue = ("0000" + sValue).slice(-4);
          if (paddedValue !== sValue) {
            oInput.setValue(paddedValue);
            sValue = paddedValue;
          }
        }

        // Get the date value in this row
        const vDate = sCurrentPath ? oModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
        const sDateStr = this._formatToModelDateString(vDate);

        // If either field missing, can't be duplicate — just set model
        if (!sDateStr) {
          oModel.setProperty(sCurrentPath + "/slabno", sValue);
          // Generate BIPL LOT NO (will be empty if other fields missing)
          this.updateBiplLotNo(oContext);
          return;
        }

        // Now check duplicate combination of date + slabno
        const bIsDuplicate = await this._isDuplicateDateSlabCombination(oModel, sDateStr, sValue, sCurrentPath);

        if (bIsDuplicate) {
          sap.m.MessageBox.error("This Production Start Date and Slab No combination already exists in the table. The values you entered have been cleared.");
          // Clear model fields for this row (date, slabno, and bipllotno)
          oModel.setProperty(sCurrentPath + "/productionordstartdate", "");
          oModel.setProperty(sCurrentPath + "/slabno", "");
          oModel.setProperty(sCurrentPath + "/bipllotno", "");
          // Clear UI input value
          oInput.setValue("");
          return;
        }

        // No duplicate -> update model
        oModel.setProperty(sCurrentPath + "/slabno", sValue);

        // Generate BIPL LOT NO
        this.updateBiplLotNo(oContext);
      },

      // UPDATED: onProductionDateChange with async duplicate check for date + slabno
      onProductionDateChange: async function (oEvent) {
        const oDatePicker = oEvent.getSource();
        const oSelectedDate = oDatePicker.getDateValue();
        const oContext = oDatePicker.getBindingContext("TabModel");
        const sCurrentPath = oContext ? oContext.getPath() : null;
        const oTabModel = this.getView().getModel("TabModel");

        // Get current date (without time part for comparison)
        const oToday = new Date();
        oToday.setHours(0, 0, 0, 0);

        // Create copy of selected date without time part
        const oSelectedDateNoTime = oSelectedDate ? new Date(oSelectedDate) : null;
        if (oSelectedDateNoTime) {
          oSelectedDateNoTime.setHours(0, 0, 0, 0);
        }

        // If date is cleared, allow it and clear model value
        if (!oSelectedDate) {
          if (sCurrentPath) {
            oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
            // Also clear BIPL LOT NO when date is cleared
            this.updateBiplLotNo(oContext);
          }
          return;
        }

        // Check if selected date is in the past
        if (oSelectedDateNoTime < oToday) {
          sap.m.MessageBox.error("Cannot select a past date. Please select today's date or a future date.");
          // restore current model value (if any)
          const sCurrentValue = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
          if (sCurrentValue) {
            const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            const oCurrentDate = oDateFormat.parse(sCurrentValue);
            oDatePicker.setDateValue(oCurrentDate);
          } else {
            oDatePicker.setValue("");
          }
          return;
        }

        // Format selected date to model string (yyyy-MM-dd)
        const sSelectedDateStr = this._formatToModelDateString(oSelectedDate);

        // Get current slabno value from model for this row
        const sCurrentSlabNo = sCurrentPath ? (oTabModel.getProperty(sCurrentPath + "/slabno") || "").toString().trim() : "";

        // If slabno is not empty, check for duplicate combination
        if (sCurrentSlabNo) {
          // Check for duplicate combination of date + slabno
          const bIsDuplicate = await this._isDuplicateDateSlabCombination(oTabModel, sSelectedDateStr, sCurrentSlabNo, sCurrentPath);

          if (bIsDuplicate) {
            // Duplicate found — clear the fields user just added in this row
            sap.m.MessageBox.error("This Production Start Date and Slab No combination already exists in the table. The values you entered have been cleared.");
            // Clear model fields for this row (date, slabno, and bipllotno)
            oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
            oTabModel.setProperty(sCurrentPath + "/slabno", "");
            oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
            // Also clear the DatePicker UI
            oDatePicker.setValue("");
            return;
          }
        }

        // No duplicate (or slabno not set yet) -> update model
        if (sCurrentPath) {
          // Update the production order start date in the model
          oTabModel.setProperty(sCurrentPath + "/productionordstartdate", oSelectedDate);

          // Generate and update BIPL LOT NO after setting date
          this.updateBiplLotNo(oContext);
        }
        // Two-way binding will keep UI in sync
      },



      onSpecCodeChange: function (oEvent) {
        var sValue = oEvent.getSource().getValue();
        var oInput = oEvent.getSource();

        // Check if value is 4 digits
        if (sValue.length !== 4) {
          return; // Don't do anything if not 4 digits
        }

        // Get the current row context
        var oContext = oInput.getBindingContext("TabModel");
        if (!oContext) {
          return;
        }

        var rowData = oContext.getObject();
        var rowPath = oContext.getPath();

        // Check if plant is filled
        if (!rowData.plant || rowData.plant === "") {
          sap.m.MessageBox.information("Please enter the plant before entering spec code");
          oInput.setValue(""); // Clear the spec code
          return;
        }

        // Show busy indicator
        sap.ui.core.BusyIndicator.show();

        var that = this;

        // Create filters
        var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);
        var productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");
        var specCodeFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue);

        // Get the OData model
        var oODataModel = this.getView().getModel("ZSB_MATERIALMASTER1");

        // Read material data based on spec code
        oODataModel.read("/ZC_MATERIALMASTER1", {
          filters: [plantFilter, productGroupFilter, specCodeFilter],
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              // Found material(s)
              if (oData.results.length === 1) {
                // Single material found - auto-fill
                var material = oData.results[0];
                that._fillMaterialData(material, rowPath, rowData, sValue);
                // Generate BIPL LOT NO after setting spec code
                that.updateBiplLotNo(oContext);
              } else {
                // Multiple materials found - show value help dialog (reusing onMaterialFragmentOpen logic)
                that._openMaterialValueHelpForSpecCode(oContext, sValue, oData.results);
              }
            } else {
              // No material found
              sap.m.MessageBox.warning("No material found for spec code: " + sValue + " in plant: " + rowData.plant);

              // Clear spec code and update BIPL LOT NO
              oInput.setValue("");
              var oModel = that.getView().getModel("TabModel");
              oModel.setProperty(rowPath + "/speccode", "");
              that.updateBiplLotNo(oContext);
            }
          },
          error: function (oError) {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Error fetching material data: " + oError.message);
            console.error("Error fetching material by spec code:", oError);
          }
        });
      },

      // Helper function to open value help dialog for multiple materials found via spec code
      _openMaterialValueHelpForSpecCode: function (oContext, sSpecCode, aMaterials) {
        sap.ui.core.BusyIndicator.show();

        var that = this;
        var rowData = oContext.getObject();
        var rowPath = oContext.getPath();

        // Store the row context for later use in onValueHelpOkPress_Product
        this.oEventModelRowDatas = rowData;
        this.oEventModelRowPath = rowPath;
        this._selectedSpecCode = sSpecCode; // Store spec code for later use

        // Check if plant is filled
        if (rowData.plant === "") {
          sap.m.MessageBox.information("Please enter the plant...");
          sap.ui.core.BusyIndicator.hide();
          return;
        }

        // Create filters
        var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);
        var productGroupFilter = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT");

        this._oBasicSearchField = new sap.m.SearchField();

        this.loadFragment({
          name: "bando.view.CommonFragments.PlanScreens.materialmaster"
        }).then(function (oDialog) {
          var oFilterBar = oDialog.getFilterBar(),
            oColumnProductCode, oColumnProductName, oColumnPlant;

          this._oVHD_Product = oDialog;
          this.getView().addDependent(oDialog);

          // Set key fields for filtering in the Define Conditions Tab
          oDialog.setRangeKeyFields([{
            label: "Product",
            key: "Product",
            type: "string",
            typeInstance: new sap.ui.model.type.String({}, {
              maxLength: 10
            })
          }]);

          // Set Basic Search for FilterBar
          oFilterBar.setFilterBarExpanded(false);
          oFilterBar.setBasicSearch(this._oBasicSearchField);

          // Pre-fill the search field with the spec code
          this._oBasicSearchField.setValue(sSpecCode);

          // Trigger filter bar search when the basic search is fired
          this._oBasicSearchField.attachSearch(function () {
            oFilterBar.search();
          });

          oDialog.getTableAsync().then(function (oTable) {
            // Get the model for the products
            var oModel = new sap.ui.model.json.JSONModel({
              results: aMaterials
            });

            // For Desktop and tablet, the default table is sap.ui.table.Table
            if (oTable.bindRows) {
              // Bind rows to the local model with the pre-filtered materials
              oTable.setModel(oModel, "local");
              oTable.bindAggregation("rows", {
                path: "local>/results",
                events: {
                  dataReceived: function () {
                    oDialog.update();
                  }
                }
              });

              // Define columns for the table
              oColumnProductCode = new sap.ui.table.Column({
                label: new sap.m.Label({ text: "Product" }),
                template: new sap.m.Text({ wrapping: false, text: "{local>Product}" })
              });

              oColumnProductName = new sap.ui.table.Column({
                label: new sap.m.Label({ text: "ProductName" }),
                template: new sap.m.Text({ wrapping: false, text: "{local>ProductName}" })
              });

              oColumnPlant = new sap.ui.table.Column({
                label: new sap.m.Label({ text: "Plant" }),
                template: new sap.m.Text({ wrapping: false, text: "{local>Plant}" })
              });

              oTable.addColumn(oColumnProductCode);
              oTable.addColumn(oColumnProductName);
              oTable.addColumn(oColumnPlant);
            }

            // For Mobile, the default table is sap.m.Table
            if (oTable.bindItems) {
              // Bind items to the local model
              oTable.setModel(oModel, "local");
              oTable.bindAggregation("items", {
                path: "local>/results",
                template: new sap.m.ColumnListItem({
                  cells: [
                    new sap.m.Label({ text: "{local>Product}" }),
                    new sap.m.Label({ text: "{local>ProductName}" }),
                    new sap.m.Label({ text: "{local>Plant}" }),
                  ]
                }),
                events: {
                  dataReceived: function () {
                    oDialog.update();
                  }
                }
              });

              // Add columns for mobile/table view
              oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product" }) }));
              oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "ProductName" }) }));
              oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
            }

            // Open the dialog
            oDialog.open();
            sap.ui.core.BusyIndicator.hide();
          }.bind(this));
        }.bind(this));
      },

      // Helper function to fill material data
      _fillMaterialData: function (material, rowPath, rowData, specCode) {
        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(rowPath);

        // Fill material details
        ItemTableModel.materialcode = material.Product;
        ItemTableModel.description = material.ProductName;
        ItemTableModel.speccode = specCode; // Set the spec code

        // Update batch weight and compound code
        // this._fetchAdditionalMaterialData(material.Product, rowPath);

        mod01.refresh();
      },

      // Modify the onValueHelpOkPress_Product to handle selection from spec code flow
      onValueHelpOkPress_Product: async function (oEvent) {
        sap.ui.core.BusyIndicator.show();

        var aTokens = oEvent.getParameter("tokens");
        let KeyVal = aTokens[0].getKey();   // Product Code
        let TextVal = aTokens[0].getText();

        let parts = TextVal.split("(");
        let ProductCode = KeyVal;
        let ProductName = parts[0].trim();

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(this.oEventModelRowPath);

        // Fill basic material details
        ItemTableModel.materialcode = ProductCode;
        ItemTableModel.description = ProductName;

        // If we came from spec code flow, set the spec code
        if (this._selectedSpecCode) {
          ItemTableModel.speccode = this._selectedSpecCode;
          this._selectedSpecCode = null; // Clear the stored spec code
        }

        var oODataModel = this.getView().getModel("ZSB_MATERIALMASTER1");

        // Fetch BatchWeight with additional filters
        oODataModel.read("/ZC_BATCHWEIGHT", {
          filters: [
            new sap.ui.model.Filter({
              filters: [
                new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode),
                new sap.ui.model.Filter("ClassType", sap.ui.model.FilterOperator.EQ, "001"),
                new sap.ui.model.Filter("CharcInternalID", sap.ui.model.FilterOperator.EQ, "0000000833")
              ],
              and: true
            })
          ],
          success: function (oData) {
            if (oData.results && oData.results.length > 0) {
              let batchWeight = oData.results[0].Batchweight;
              ItemTableModel.batchweight = batchWeight;
            } else {
              ItemTableModel.batchweight = "";
            }
            mod01.refresh();

            // Generate BIPL LOT NO after setting material
            var oContext = this.getView().getModel("TabModel").getContext(this.oEventModelRowPath);
            this.updateBiplLotNo(oContext);
          }.bind(this),
          error: function (oError) {
            console.error("Batch weight fetch failed", oError);
            ItemTableModel.batchweight = "";
            mod01.refresh();

            // Still generate BIPL LOT NO even if batch weight fails
            var oContext = this.getView().getModel("TabModel").getContext(this.oEventModelRowPath);
            this.updateBiplLotNo(oContext);
          }.bind(this)
        });

        // Fetch CompoundCode
        oODataModel.read("/ZC_COMPOUNDCODE", {
          filters: [
            new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode)
          ],
          success: function (oData) {
            if (oData.results && oData.results.length > 0) {
              let compoundCode = oData.results[0].CompoundCode;
              ItemTableModel.compoundcode = compoundCode;
            } else {
              ItemTableModel.compoundcode = "";
            }
            mod01.refresh();
          },
          error: function (oError) {
            console.error("Compound code fetch failed", oError);
            ItemTableModel.compoundcode = "";
            mod01.refresh();
          }
        });

        // Close/destroy dialog
        this._oVHD_Product.destroy();
        sap.ui.core.BusyIndicator.hide();
      },














      generateBiplLotNo: function (oContext) {
        var oModel = this.getView().getModel("TabModel");
        var oData = oContext.getObject();

        // Get values from the model
        var productionDate = oData.productionordstartdate; // Could be Date object or string
        var slabNo = oData.slabno;
        var specCode = oData.speccode;

        // Check if all required fields are filled
        if (!productionDate || !slabNo || !specCode) {
          return ""; // Return empty if any field is missing
        }

        try {
          var dateStr;

          // Handle different date formats
          if (productionDate instanceof Date) {
            // If it's a Date object, format it
            var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
              pattern: "yyyy-MM-dd"
            });
            dateStr = oDateFormat.format(productionDate);
          } else {
            // If it's already a string
            dateStr = productionDate;
          }

          // Ensure dateStr has the right format
          if (dateStr.length < 10) {
            return "";
          }

          // Extract components
          var year = dateStr.substring(2, 4); // Last 2 digits of year
          var month = dateStr.substring(5, 7); // Month
          var day = dateStr.substring(8, 10); // Day

          // Pad slabNo to 4 digits with leading zeros
          var paddedSlabNo = ("0000" + slabNo).slice(-4);

          // Build the BIPL LOT NO
          var biplLotNo = year + month + day + paddedSlabNo + specCode + "1";

          return biplLotNo;

        } catch (error) {
          console.error("Error generating BIPL LOT NO:", error);
          return "";
        }
      },


      /**
       * Updates BIPL LOT NO in the model for the given context
       */
      updateBiplLotNo: function (oContext) {
        if (!oContext) {
          return;
        }

        var oModel = this.getView().getModel("TabModel");
        var biplLotNo = this.generateBiplLotNo(oContext);

        // Update the BIPL LOT NO in the model
        oModel.setProperty(oContext.getPath() + "/bipllotno", biplLotNo);
      },











      // onValueHelpOkPress_ProdVer: async function (oEvent) {
      //   sap.ui.core.BusyIndicator.show();

      //   var aTokens = oEvent.getParameter("tokens");
      //   let KeyVal = aTokens[0].getKey(); // Get the ProductionVersion code (e.g., "LNE1")
      //   let TextVal = aTokens[0].getText(); // Get the full text (e.g., "Line-1 (LNE1)")

      //   console.log("Full Text from dialog:", TextVal);
      //   console.log("Key value:", KeyVal);

      //   // Extract only the text before parentheses (ProductionVersionText)
      //   let ProductionVersionText = TextVal.split('(')[0].trim();
      //   console.log("Extracted ProductionVersionText:", ProductionVersionText);

      //   var mod01 = this.getView().getModel("TabModel");
      //   var ItemTableModel = mod01.getProperty(this.oEventModelRowPath);

      //   // Store ProductionVersionText in machine number (visible field)
      //   ItemTableModel.machinenumber = ProductionVersionText; // Gets "line-1"

      //   // Store ProductionVersion code in machine number hidden field
      //   ItemTableModel.machinenumberhidden = KeyVal; // Gets "LNE1"

      //   mod01.refresh();

      //   this._ProdVer.destroy();
      //   sap.ui.core.BusyIndicator.hide();
      // },



      onProductVersionFrag: function (oEvent) {
        sap.ui.core.BusyIndicator.show();
        this.EventRowCollNo = oEvent.getSource().getParent();

        var mod01 = this.getView().getModel("TabModel");
        const input = oEvent.getSource();
        const context = input.getBindingContext("TabModel");

        if (context) {
          const rowPath = context.getPath();
          const rowData = context.getObject();

          this.oEventModelRowDatas = rowData;
          this.oEventModelRowPath = rowPath;

          if (rowData.plant === "") {
            sap.m.MessageBox.information("Please enter the plant...");
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          if (rowData.materialcode === "") {
            sap.m.MessageBox.information("Please enter the Spec Code...");
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          var that = this;

          var MaterialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, rowData.materialcode);
          var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);

          this._oBasicSearchField = new sap.m.SearchField();

          this.loadFragment({
            name: "bando.view.CommonFragments.PlanScreens.productionversion"
          }).then(function (oDialog) {
            var oFilterBar = oDialog.getFilterBar(),
              oColumnProductionVersion, oColumnProductionVersionText, oColumnMaterial, oColumnPlant;

            this._ProdVer = oDialog;
            this.getView().addDependent(oDialog);

            // Set key fields for filtering
            oDialog.setRangeKeyFields([{
              label: "Production Version",
              key: "ProductionVersion",
              type: "string",
              typeInstance: new sap.ui.model.type.String({}, {
                maxLength: 4
              })
            }]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            this._oBasicSearchField.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.getTableAsync().then(function (oTable) {
              oTable.setModel(this.oProductsModel);

              // For Desktop and tablet
              if (oTable.bindRows) {
                oTable.bindAggregation("rows", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter, MaterialFilter],
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Define columns - Added ProductionVersionText column
                oColumnProductionVersion = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Production Version" }),
                  template: new sap.m.Text({
                    wrapping: false,
                    text: "{ZSB_MATERIALMASTER1>ProductionVersion}"
                  })
                });
                oColumnProductionVersion.data({
                  fieldName: "ProductionVersion"
                });

                oColumnProductionVersionText = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Production Version Text" }),
                  template: new sap.m.Text({
                    wrapping: false,
                    text: "{ZSB_MATERIALMASTER1>ProductionVersionText}"
                  })
                });
                oColumnProductionVersionText.data({
                  fieldName: "ProductionVersionText"
                });

                oColumnMaterial = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Material" }),
                  template: new sap.m.Text({
                    wrapping: false,
                    text: "{ZSB_MATERIALMASTER1>Material}"
                  })
                });
                oColumnMaterial.data({
                  fieldName: "Material"
                });

                oColumnPlant = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Plant" }),
                  template: new sap.m.Text({
                    wrapping: false,
                    text: "{ZSB_MATERIALMASTER1>Plant}"
                  })
                });
                oColumnPlant.data({
                  fieldName: "Plant"
                });

                oTable.addColumn(oColumnProductionVersion);
                oTable.addColumn(oColumnProductionVersionText); // Added
                oTable.addColumn(oColumnMaterial);
                oTable.addColumn(oColumnPlant);
              }

              // For Mobile
              if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter, MaterialFilter],
                  template: new sap.m.ColumnListItem({
                    cells: [
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductionVersion}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductionVersionText}" }), // Added
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Material}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Plant}" }),
                    ]
                  }),
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Production Version" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Production Version Text" }) })); // Added
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Material" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
              }

              oDialog.open();
              sap.ui.core.BusyIndicator.hide();
            }.bind(this));
          }.bind(this));
        }
      },


      // onValueHelpOkPress_ProdVer: async function (oEvent) {
      //   sap.ui.core.BusyIndicator.show();

      //   console.log("this.oEventModelDatas", this.oEventModelRowDatas)
      //   console.log("this.oEventModelRowPath", this.oEventModelRowPath)

      //   var aTokens = oEvent.getParameter("tokens");
      //   let ProductionVersion = aTokens[0].getKey(); // Get the key of the selected token
      //   let TextVal = aTokens[0].getText();

      //   let parts = TextVal.split("(")
      //   let ProductName = parts[0];

      //   var mod01 = this.getView().getModel("TabModel");
      //   var ItemTableModel = mod01.getProperty(this.oEventModelRowPath)

      //   // Set the selected production version
      //   ItemTableModel.machinenumber = ProductionVersion

      //   // 🔥 Fetch MaterialMinLotSizeQuantity from ZSB_PRODUCTVERSION service
      //   var oProdVersionModel = this.getView().getModel("ZSB_PRODUCTVERSION");

      //   if (oProdVersionModel) {
      //     // Create filters for Material and ProductionVersion
      //     var materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, this.oEventModelRowDatas.materialcode);
      //     var prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, ProductionVersion);

      //     oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
      //       filters: [materialFilter, prodVersionFilter],
      //       success: function (oData) {
      //         if (oData.results && oData.results.length > 0) {
      //           let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity;

      //           // Set the production order quantity to MaterialMinLotSizeQuantity
      //           ItemTableModel.productionorderqty = maxLotSize;

      //           // Optional: Also set base unit if available in the response
      //           // ItemTableModel.baseunit = oData.results[0].MaterialBaseUnit || "";

      //           console.log("Fetched MaterialMinLotSizeQuantity:", maxLotSize);
      //         } else {
      //           ItemTableModel.productionorderqty = "";
      //           console.warn("No production version data found for Material:",
      //             this.oEventModelRowDatas.materialcode,
      //             "and ProductionVersion:", ProductionVersion);
      //         }
      //         mod01.refresh();
      //       }.bind(this),
      //       error: function (oError) {
      //         console.error("Failed to fetch MaterialMinLotSizeQuantity", oError);
      //         ItemTableModel.productionorderqty = "";
      //         mod01.refresh();
      //       }
      //     });
      //   } else {
      //     console.error("ZSB_PRODUCTVERSION model not found");
      //     ItemTableModel.productionorderqty = "";
      //     mod01.refresh();
      //   }

      //   this._ProdVer.destroy(); // Destroy the value help dialog
      //   sap.ui.core.BusyIndicator.hide();
      // },
      onValueHelpOkPress_ProdVer: async function (oEvent) {
        sap.ui.core.BusyIndicator.show();

        console.log("this.oEventModelDatas", this.oEventModelRowDatas);
        console.log("this.oEventModelRowPath", this.oEventModelRowPath);

        var aTokens = oEvent.getParameter("tokens");
        let KeyVal = aTokens[0].getKey(); // Get the key of the selected token
        let TextVal = aTokens[0].getText();

        let ProductionVersionText = "";
        let ProductionVersionCode = "";

        // Check if text is in "Text (Key)" format
        if (TextVal.includes("(") && TextVal.includes(")")) {
          // Format: "ProductName (VersionKey)"
          let parts = TextVal.split("(");
          ProductionVersionText = parts[0].trim();
          ProductionVersionCode = KeyVal;
        } else {
          // Format: Separate key and text fields
          // In this case, KeyVal should be the ProductionVersion code
          // And TextVal should be the ProductionVersionText
          ProductionVersionCode = KeyVal;
          ProductionVersionText = TextVal;

          // If TextVal is actually the key (check if it matches your key pattern)
          // You might need to adjust this based on your actual data
          console.log("Token format - Key:", KeyVal, "Text:", TextVal);
        }

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(this.oEventModelRowPath);

        // Store ProductionVersionText in machine number (visible field)
        ItemTableModel.machinenumber = ProductionVersionText; // Gets "line-1"

        // Store ProductionVersion code in machine number hidden field
        ItemTableModel.machinenumberhidden = ProductionVersionCode; // Gets "LNE1"

        // 🔥 Fetch MaterialMinLotSizeQuantity from ZSB_PRODUCTVERSION service
        var oProdVersionModel = this.getView().getModel("ZSB_PRODUCTVERSION");

        if (oProdVersionModel) {
          // Create filters for Material and ProductionVersion
          var materialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, this.oEventModelRowDatas.materialcode);
          var prodVersionFilter = new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.EQ, ProductionVersionCode);

          oProdVersionModel.read("/ZI_PRODUCTIONVERSION", {
            filters: [materialFilter, prodVersionFilter],
            success: function (oData) {
              if (oData.results && oData.results.length > 0) {
                let maxLotSize = oData.results[0].MaterialMinLotSizeQuantity;

                // Set the production order quantity to MaterialMinLotSizeQuantity
                ItemTableModel.productionorderqty = maxLotSize;

                console.log("Fetched MaterialMinLotSizeQuantity:", maxLotSize);
              } else {
                ItemTableModel.productionorderqty = "";
                console.warn("No production version data found for Material:",
                  this.oEventModelRowDatas.materialcode,
                  "and ProductionVersion:", ProductionVersionCode);
              }
              mod01.refresh();
            }.bind(this),
            error: function (oError) {
              console.error("Failed to fetch MaterialMinLotSizeQuantity", oError);
              ItemTableModel.productionorderqty = "";
              mod01.refresh();
            }
          });
        } else {
          console.error("ZSB_PRODUCTVERSION model not found");
          ItemTableModel.productionorderqty = "";
          mod01.refresh();
        }

        this._ProdVer.destroy(); // Destroy the value help dialog
        sap.ui.core.BusyIndicator.hide();
      },

      onFilterBarSearch_ProdVer: function (oEvent) {
        var sSearchQuery = this._oBasicSearchField.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet");

        // Construct filters for search and selection set values
        var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(new sap.ui.model.Filter({
              path: oControl.getName(),
              operator: sap.ui.model.FilterOperator.Contains,
              value1: oControl.getValue()
            }));
          }
          return aResult;
        }, []);

        aFilters.push(new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter({ path: "ProductionVersion", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "ProductionVersionText", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }), // Added
            new sap.ui.model.Filter({ path: "Material", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
          ],
          and: false
        }));

        this._filterTable_ProdVer(new sap.ui.model.Filter({
          filters: aFilters,
          and: true
        }));
      },


      onValueHelpCancelPress_ProdVer: function () {
        this._ProdVer.close(); // Close the value help dialog without making any changes
      },


      _filterTable_ProdVer: function (oFilter) {
        var oVHD = this._ProdVer;

        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }

          // Update the dialog after filtering
          oVHD.update();
        });
      },



      // =====================================================================================
      // =====================================================================================
      // =====================================================================================





      onStorageLocationFragmentOpen: function (oEvent) {
        sap.ui.core.BusyIndicator.show();

        const input = oEvent.getSource();
        const context = input.getBindingContext("TabModel");

        if (context) {
          const rowPath = context.getPath();
          const rowData = context.getObject();

          // Store current row context for later use
          this.currentStorageLocationRowPath = rowPath;
          this.currentStorageLocationRowData = rowData;

          // Check if material is selected
          if (!rowData.materialcode) {
            sap.m.MessageBox.error("Please select a material first");
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          var that = this;

          this._oBasicSearchField_Storage = new sap.m.SearchField();

          this.loadFragment({
            name: "bando.view.CommonFragments.PlanScreens.StorageLocation"
          }).then(function (oDialog) {
            var oFilterBar = oDialog.getFilterBar(),
              oColumnProduct, oColumnStorageLocation;

            this._oVHD_StorageLocation = oDialog;
            this.getView().addDependent(oDialog);

            // Set the product field to show current material (readonly)
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField_Storage);

            // Set product value in filter bar
            var oProductFilter = oFilterBar.getFilterGroupItems().find(function (item) {
              return item.getName() === "Product";
            });
            if (oProductFilter) {
              oProductFilter.getControl().setValue(rowData.materialcode);
            }

            this._oBasicSearchField_Storage.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.getTableAsync().then(function (oTable) {
              var oMaterialModel = this.getView().getModel("ZSB_MATERIALMASTER1");
              oTable.setModel(oMaterialModel);

              // Create filter for product
              var productFilter = new sap.ui.model.Filter(
                "Product",
                sap.ui.model.FilterOperator.EQ,
                rowData.materialcode
              );

              // For Desktop and tablet (sap.ui.table.Table)
              // if (oTable.bindRows) {
              //     oTable.bindAggregation("rows", {
              //         path: "ZSB_MATERIALMASTER1>/ZC_STORAGE_LOCATION",
              //         filters: [productFilter],
              //         events: {
              //             dataReceived: function() {
              //                 oDialog.update();
              //                 sap.ui.core.BusyIndicator.hide();
              //             }
              //         }
              //     });

              //     // Define columns
              //     oColumnProduct = new sap.ui.table.Column({
              //         label: new sap.m.Label({ text: "Product" }),
              //         template: new sap.m.Text({ 
              //             wrapping: false, 
              //             text: "{ZSB_MATERIALMASTER1>Product}" 
              //         })
              //     });

              //     oColumnStorageLocation = new sap.ui.table.Column({
              //         label: new sap.m.Label({ text: "Storage Location" }),
              //         template: new sap.m.Text({ 
              //             wrapping: false, 
              //             text: "{ZSB_MATERIALMASTER1>StorageLocation}" 
              //         })
              //     });

              //     oTable.addColumn(oColumnProduct);
              //     oTable.addColumn(oColumnStorageLocation);
              // }
              if (oTable.bindRows) {

                var oMaterialModel = this.getView().getModel("ZSB_MATERIALMASTER1");

                oMaterialModel.read("/ZC_STORAGE_LOCATION", {
                  filters: [productFilter],
                  success: function (oData) {

                    // 🔹 Remove duplicate StorageLocation
                    var oSeen = {};
                    var aUniqueResults = [];

                    oData.results.forEach(function (oItem) {
                      if (!oSeen[oItem.StorageLocation]) {
                        oSeen[oItem.StorageLocation] = true;
                        aUniqueResults.push(oItem);
                      }
                    });

                    // 🔹 Create JSON model with unique rows
                    var oJsonModel = new sap.ui.model.json.JSONModel({
                      results: aUniqueResults
                    });

                    oTable.setModel(oJsonModel);
                    oTable.bindRows("/results");

                    // 🔹 Define columns ONCE
                    oTable.removeAllColumns();

                    oTable.addColumn(new sap.ui.table.Column({
                      label: new sap.m.Label({ text: "Product" }),
                      template: new sap.m.Text({ text: "{Product}" })
                    }));

                    oTable.addColumn(new sap.ui.table.Column({
                      label: new sap.m.Label({ text: "Storage Location" }),
                      template: new sap.m.Text({ text: "{StorageLocation}" })
                    }));

                    oDialog.update();
                    sap.ui.core.BusyIndicator.hide();
                  },
                  error: function () {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageBox.error("Failed to load storage locations");
                  }
                });
              }



              // For Mobile (sap.m.Table)
              if (oTable.bindItems) {
                oTable.bindAggregation("items", {
                  path: "ZSB_MATERIALMASTER1>/ZC_STORAGE_LOCATION",
                  filters: [productFilter],
                  template: new sap.m.ColumnListItem({
                    cells: [
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Product}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>StorageLocation}" })
                    ]
                  }),
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                      sap.ui.core.BusyIndicator.hide();
                    }
                  }
                });

                oTable.addColumn(new sap.m.Column({
                  header: new sap.m.Label({ text: "Product" })
                }));
                oTable.addColumn(new sap.m.Column({
                  header: new sap.m.Label({ text: "Storage Location" })
                }));
              }

              oDialog.open();
            }.bind(this));
          }.bind(this));
        }
      },

      onValueHelpOkPress_StorageLocation: function (oEvent) {
        var aTokens = oEvent.getParameter("tokens");

        if (aTokens && aTokens.length > 0) {
          let storageLocation = aTokens[0].getKey();

          // Update the current row with selected storage location
          var mod01 = this.getView().getModel("TabModel");
          var rowData = mod01.getProperty(this.currentStorageLocationRowPath);

          rowData.storagelocation = storageLocation;
          mod01.refresh();
        }

        this._oVHD_StorageLocation.destroy();
      },

      onFilterBarSearch_StorageLocation: function (oEvent) {
        var sSearchQuery = this._oBasicSearchField_Storage.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet");

        // Construct filters
        var aFilters = [];

        // Always filter by the current product
        if (this.currentStorageLocationRowData && this.currentStorageLocationRowData.materialcode) {
          aFilters.push(new sap.ui.model.Filter(
            "Product",
            sap.ui.model.FilterOperator.EQ,
            this.currentStorageLocationRowData.materialcode
          ));
        }

        // Add search query filter for StorageLocation
        if (sSearchQuery) {
          aFilters.push(new sap.ui.model.Filter({
            path: "StorageLocation",
            operator: sap.ui.model.FilterOperator.Contains,
            value1: sSearchQuery
          }));
        }

        // Add filters from filter bar controls
        if (aSelectionSet) {
          aSelectionSet.forEach(function (oControl) {
            if (oControl.getName() === "StorageLocation" && oControl.getValue()) {
              aFilters.push(new sap.ui.model.Filter({
                path: "StorageLocation",
                operator: sap.ui.model.FilterOperator.Contains,
                value1: oControl.getValue()
              }));
            }
          });
        }

        this._filterTable_StorageLocation(new sap.ui.model.Filter({
          filters: aFilters,
          and: true
        }));
      },

      _filterTable_StorageLocation: function (oFilter) {
        var oVHD = this._oVHD_StorageLocation;

        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }

          oVHD.update();
        });
      },

      onValueHelpCancelPress_StorageLocation: function () {
        this._oVHD_StorageLocation.close();
      },

      onValueHelpAfterClose_StorageLocation: function () {
        this._oVHD_StorageLocation.destroy();
      },











      generateUUID: function () {
        return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          const r = Math.random() * 16 | 0,
            v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
      },


      onSavePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
        const aData = oView.getModel("TabModel").getProperty("/Samples");

        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
          return;
        }


        // save scene
        const alreadySavedRows = aSelectedRows.filter(row =>
          row.sap_uuid !== null &&
          row.sap_uuid !== undefined &&
          row.sap_uuid !== ""
        );

        if (alreadySavedRows.length > 0) {
          const savedIndexes = alreadySavedRows.map(row => aData.indexOf(row) + 1);
          sap.m.MessageBox.error(
            "Cannot save. The following selected row(s) are already saved:\n\n" +
            savedIndexes.join(", ")
          );
          return;
        }


        // ✅ Validate that all required fields are filled for selected rows
        const aInvalidRows = [];

        aSelectedRows.forEach((row, index) => {
          const missingFields = [];

          // Check all required fields as per your column definitions
          if (!row.plant) missingFields.push("Plant");
          if (!row.productionordstartdate) missingFields.push("Production order start Date");
          if (!row.slabno) missingFields.push("Slab no");
          if (!row.speccode) missingFields.push("Spec code");
          if (!row.lotno) missingFields.push("Lot no");
          if (!row.shift) missingFields.push("Shift");
          if (!row.machinenumber) missingFields.push("Machine Number");
          if (!row.productionorderqty) missingFields.push("Production order qty");
          if (!row.bipllotno) missingFields.push("Bipl lot no");
          if (!row.materialcode) missingFields.push("Material code");
          if (!row.description) missingFields.push("Description");
          if (!row.storagelocation) missingFields.push("Storage Location");
          // Note: Storage Location has required="false" in the column, so it's not mandatory

          if (missingFields.length > 0) {
            const rowIndex = aData.indexOf(row) + 1;
            aInvalidRows.push(`Row ${rowIndex} is missing: ${missingFields.join(", ")}`);
          }
        });

        if (aInvalidRows.length > 0) {
          sap.m.MessageBox.error(
            "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
          );
          return;
        }

        // ✅ Additional validation: Check for duplicate production order numbers or other business rules
        const duplicateSlabNos = {};
        const duplicateSlabRows = [];

        aSelectedRows.forEach(row => {
          if (row.slabno) {
            if (duplicateSlabNos[row.slabno]) {
              duplicateSlabRows.push(row.slabno);
            } else {
              duplicateSlabNos[row.slabno] = true;
            }
          }
        });

        if (duplicateSlabRows.length > 0) {
          sap.m.MessageBox.error(
            "Duplicate slab numbers found in selected rows:\n" +
            duplicateSlabRows.join(", ") + "\n\nPlease correct them before saving."
          );
          return;
        }

        sap.ui.core.BusyIndicator.show(0);

        const aPromises = aSelectedRows.map(row => {
          const oPayload = {
            sap_uuid: this.generateUUID(),
            plant: String(row.plant) || "1200",
            productionordstartdate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
            slabno: row.slabno || "",
            speccode: row.speccode || "",
            lotno: row.lotno || "",
            shift: row.shift,

            machinenumber: row.machinenumber,
            machinenumberhidden: row.machinenumberhidden,
            productionorderqty: String(row.productionorderqty) || "0",

            bipllotno: String(row.bipllotno) || "",

            materialcode: row.materialcode,
            description: row.description,



            storagelocation: row.storagelocation || "",

            productionorderno: row.productionorderno || null,
            status: "GT",
            screenname: "FGPROCESS",
            screencode: "MP01",
            createdat: new Date(),
            createdby: this.sUserId // Make sure sUserId is defined in your controller
          };

          console.log("Posting payload for row:", row, oPayload);

          return new Promise((resolve, reject) => {
            oModel.create("/ZC_FG_PROCESS_PLAN", oPayload, {
              success: (data) => {
                console.log("Successfully created record:", data);
                resolve(data);
              },
              error: (error) => {
                console.error("Error creating record:", error);
                reject(error);
              }
            });
          });
        });

        var that = this;

        Promise.allSettled(aPromises).then(async results => {
          sap.ui.core.BusyIndicator.hide();

          const aFailed = results.filter(r => r.status === "rejected");
          const aSuccess = results.filter(r => r.status === "fulfilled");

          if (aFailed.length > 0) {
            const errorMessages = aFailed.map(failed => failed.reason?.message || "Unknown error").join("\n");
            sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post:\n\n${errorMessages}`);

            // Optional: Log all errors for debugging
            aFailed.forEach((failed, index) => {
              console.error(`Failed row ${index + 1}:`, failed.reason);
            });
          }

          if (aSuccess.length > 0) {
            that._fetchPostedData();
            sap.m.MessageBox.success(`${aSuccess.length} row(s) posted successfully.`, {
              onClose: () => {
                oModel.refresh(true); // Reloads all bindings

                // Optional: Clear selections after successful save
                const oTabModel = oView.getModel("TabModel");
                const aCurrentData = oTabModel.getProperty("/Samples");
                aCurrentData.forEach(item => {
                  item.__selected = false;
                });
                oTabModel.refresh();
              }
            });
          }
        }).catch(error => {
          sap.ui.core.BusyIndicator.hide();
          console.error("Unexpected error in Promise.allSettled:", error);
          sap.m.MessageBox.error("An unexpected error occurred while saving.");
        });
      },




      onDeletePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
        const oTabModel = oView.getModel("TabModel");
        const aData = oTabModel.getProperty("/Samples");

        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row to delete.");
          return;
        }
        if (aSelectedRows.some(row => !row.sap_uuid)) {
          sap.m.MessageBox.warning("Row not saved to delete.");
          return;
        }

        if (aSelectedRows.some(row => row.productionorderno && row.productionorderno !== "0")) {
          sap.m.MessageBox.error("Cannot delete rows that already have a Production order No.");
          return;
        }

        sap.m.MessageBox.confirm(
          `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
          {
            title: "Confirm Deletion",
            actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
            onClose: function (oAction) {
              if (oAction !== sap.m.MessageBox.Action.OK) return;

              sap.ui.core.BusyIndicator.show(0);

              const aDeletePromises = aSelectedRows.map(row => {
                return new Promise((resolve, reject) => {
                  if (!row.sap_uuid) {
                    reject("Missing sap_uuid for deletion.");
                    return;
                  }

                  const sKeyPath = `/ZC_FG_PROCESS_PLAN(sap_uuid='${row.sap_uuid}')`;

                  oModel.remove(sKeyPath, {
                    success: resolve,
                    error: reject
                  });
                });
              });

              Promise.allSettled(aDeletePromises).then(results => {
                sap.ui.core.BusyIndicator.hide();

                const aFailed = results.filter(r => r.status === "rejected");
                const aSuccess = results.filter(r => r.status === "fulfilled");

                // Remove deleted rows from TabModel local data
                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                oTabModel.setProperty("/Samples", aRemainingData);

                if (aSuccess.length > 0) {
                  sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                }

                if (aFailed.length > 0) {
                  sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                  console.error("Deletion errors:", aFailed);
                }
              });
            }
          }
        );
      },













      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oSewingModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Save the selected row first");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }

      //   const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
      //     // First sort by productionordstartdate (descending)
      //     const dateA = a.productionordstartdate;
      //     const dateB = b.productionordstartdate;

      //     if (dateA && dateB) {
      //       if (dateA > dateB) return -1;
      //       if (dateA < dateB) return 1;
      //     }

      //     // Then sort by bipllotno (ascending)
      //     const lotA = a.bipllotno || "";
      //     const lotB = b.bipllotno || "";

      //     if (lotA < lotB) return -1;
      //     if (lotA > lotB) return 1;

      //     return 0;
      //   });
      //   // aSortedSelectedRows


      //   // const oSelectedRow = aRowsWithUUID[0];
      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSortedSelectedRows.length; i++) {
      //     const row = aSortedSelectedRows[i];

      //     const oPayload = {
      //       Material: row.materialcode,
      //       Productionplant: row.plant,
      //       Manufacturingordertype: "ZFG1",
      //       Productionversion: row.machinenumberhidden,
      //       Totalquantity: row.productionorderqty,
      //       Mfgorderplannedstartdate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       Basicschedulingtype: "1",
      //       Storagelocation: row.storagelocation
      //     };
      //     console.log("payload:", oPayload)

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD2", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       // const sStorageLoc = oPostData.StorageLocation;
      //       if (!sProdOrder) continue;



      //       const sKeyPath = `/ZC_FG_PROCESS_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         // lotbatchno: sBatchNo,
      //         // storagelocation: sStorageLoc
      //       };

      //       await new Promise((resolve, reject) => {
      //         oSewingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         // lotbatchno: sBatchNo,
      //         // storagelocation: sStorageLoc,
      //         productionordstartdate: row.productionordstartdate,
      //         plant: row.plant,
      //         materialcode: row.materialcode
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //     }
      //   }

      //   // 🔄 Update TabModel
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       Object.assign(aData[idx], updated);
      //     }
      //   });
      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");

      //   // ✅ Now Generate QR PDF
      //   // this._generateQRPdf(aUpdatedRows);
      // },





      onApiPostButton: async function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oSewingModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
        const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");

        const aData = oTabModel.getProperty("/Samples");
        const aSelectedRows = aData.filter(row => row.__selected);

        // --- 🚫 BLOCKER VALIDATION (cannot proceed)
        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        // Check for saved rows (sap_uuid)
        const aRowsWithoutUUID = aSelectedRows.filter(row => !row.sap_uuid);
        if (aRowsWithoutUUID.length > 0) {
          const sRowNumbers = aRowsWithoutUUID
            .map((row, index) => `Row ${index + 1}`)
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed for the following rows:\n\n${sRowNumbers}: Please save the row first`
          );
          return;
        }

        // Check for existing production orders
        const aRowsWithProdOrder = aSelectedRows.filter(row => {
          const val = row.productionorderno;
          return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
        });

        if (aRowsWithProdOrder.length > 0) {
          const sProdOrders = aRowsWithProdOrder
            .map(row => row.productionorderno || "(No Production Order)")
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed due to the following issues:\n\nProduction Order(s) ${sProdOrders}: Already have valid Production Order Number assigned`
          );
          return;
        }

        // --- 🧪 VALIDATION (field completeness)
        let aValidationErrors = [];

        aSelectedRows.forEach((row, index) => {
          let missingFields = [];

          if (!row.materialcode || row.materialcode.trim() === "") {
            missingFields.push("Material Code");
          }
          if (!row.plant || row.plant.trim() === "") {
            missingFields.push("Plant");
          }
          if (!row.productionorderqty || row.productionorderqty <= 0) {
            missingFields.push("Production Order Quantity");
          }
          if (!row.productionordstartdate) {
            missingFields.push("Production Order Start Date");
          }
          // Note: Original code uses machinenumberhidden, not machinenumber
          if (!row.machinenumberhidden || row.machinenumberhidden.trim() === "") {
            missingFields.push("Machine Number");
          }

          if (missingFields.length > 0) {
            const sRowId = `Row ${index + 1}`;
            aValidationErrors.push(`${sRowId}: ${missingFields.join(", ")}`);
          }
        });

        if (aValidationErrors.length > 0) {
          sap.m.MessageBox.error(
            "Missing required fields:\n\n" + aValidationErrors.join("\n")
          );
          return;
        }

        // --- ✅ PROCESSING (all validations passed)
        sap.ui.core.BusyIndicator.show(0);

        // Sort selected rows
        const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
          // First sort by productionordstartdate (descending)
          const dateA = a.productionordstartdate;
          const dateB = b.productionordstartdate;

          if (dateA && dateB) {
            if (dateA > dateB) return -1;
            if (dateA < dateB) return 1;
          }

          // Then sort by bipllotno (ascending)
          const lotA = a.bipllotno || "";
          const lotB = b.bipllotno || "";

          if (lotA < lotB) return -1;
          if (lotA > lotB) return 1;

          return 0;
        });

        // Arrays to collect results
        const aSuccessResults = [];
        const aErrorResults = [];

        for (let i = 0; i < aSortedSelectedRows.length; i++) {
          const row = aSortedSelectedRows[i];
          const sRowId = `Row ${i + 1}`;

          // Use the CORRECT payload structure from original code
          const oPayload = {
            Material: row.materialcode,
            Productionplant: row.plant,  // lowercase in original
            Manufacturingordertype: "ZFG1",  // lowercase in original
            Productionversion: row.machinenumberhidden,  // lowercase in original
            Totalquantity: row.productionorderqty,  // lowercase in original
            Mfgorderplannedstartdate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,  // lowercase in original
            Basicschedulingtype: "1",  // lowercase in original
            Storagelocation: row.storagelocation  // lowercase in original
          };
          console.log("payload:", oPayload);

          try {
            // 1. CREATE Operation - Production Order
            // const oPostData = await new Promise((resolve, reject) => {
            //   oPostModel.create("/ZC_PRODUCT_ORD2", oPayload, {  // CORRECT endpoint
            //     success: function (odata) {
            //       console.log("CREATE Success - Production Order:", odata);

            //       // Check if production order was created successfully
            //       if (!odata.Productionorder) {
            //         let errorMessage = "No production order returned";
            //         if (odata.errorresponse) {
            //           try {
            //             const errorObj = JSON.parse(odata.errorresponse);
            //             errorMessage = errorObj.error?.message?.value || errorObj.error?.message || odata.errorresponse;
            //           } catch (e) {
            //             errorMessage = odata.errorresponse;
            //           }
            //         }
            //         reject(new Error(errorMessage));
            //       } else {
            //         resolve(odata);
            //       }
            //     },
            //     error: reject
            //   });
            // });


            const oPostData = await new Promise((resolve, reject) => {
              oPostModel.create("/ZC_PRODUCT_ORD2", oPayload, {
                success: function (odata) {
                  console.log("CREATE Success - Production Order:", odata);

                  // Check if production order was actually created
                  if (odata.Productionorder && odata.Productionorder !== "") {
                    // Success: order created
                    resolve(odata);
                  } else {
                    // Business error: extract message from Errorresponse
                    let errorMessage = "No production order returned";
                    if (odata.Errorresponse) {  // note capital 'E'
                      try {
                        const errorObj = JSON.parse(odata.Errorresponse);
                        // Navigate to the most descriptive message
                        errorMessage = errorObj.error?.message?.value ||
                          errorObj.error?.message ||
                          odata.Errorresponse;
                      } catch (e) {
                        // If parsing fails, keep the raw string
                        errorMessage = odata.Errorresponse;
                      }
                    }
                    reject(new Error(errorMessage));
                  }
                },
                error: function (err) {
                  // Handle HTTP/network errors (e.g., 400, 500)
                  reject(err);
                }
              });
            });

            const sProdOrder = oPostData.Productionorder;
            // const sStorageLoc = oPostData.StorageLocation; // Original code doesn't have this

            const sKeyPath = `/ZC_FG_PROCESS_PLAN(sap_uuid='${row.sap_uuid}')`;  // CORRECT entity name
            const oUpdatePayload = {
              productionorderno: sProdOrder,
              // Original code doesn't update lotbatchno or storagelocation
            };

            // 3. UPDATE Operation - FG Process Plan
            await new Promise((resolve, reject) => {
              oSewingModel.update(sKeyPath, oUpdatePayload, {
                merge: true,
                success: function (odata) {
                  console.log("UPDATE Success - FG Process Plan:", odata);
                  resolve(odata);
                },
                error: reject
              });
            });

            // Add to success list WITH sap_uuid for proper matching
            aSuccessResults.push({
              rowId: sRowId,
              sap_uuid: row.sap_uuid,
              productionOrder: sProdOrder,
              materialCode: row.materialcode
            });

          } catch (oError) {
            console.error(`❌ API Post Failed for ${sRowId}:`, oError);

            // Extract error message
            let sErrorMessage = oError.message || "Unknown error";

            // For OData errors
            if (oError.responseText) {
              try {
                const oErrorResponse = JSON.parse(oError.responseText);
                if (oErrorResponse.error && oErrorResponse.error.message) {
                  sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                }
              } catch (e) {
                sErrorMessage = oError.responseText;
              }
            }

            // Add to error list WITH sap_uuid
            aErrorResults.push({
              rowId: sRowId,
              sap_uuid: row.sap_uuid,
              error: sErrorMessage
            });
          }
        }

        // CORRECTED: Update the model with processed rows using sap_uuid
        aSuccessResults.forEach(result => {
          // Find the row in aData by sap_uuid
          const idx = aData.findIndex(row => row.sap_uuid === result.sap_uuid);
          if (idx !== -1) {
            Object.assign(aData[idx], {
              productionorderno: result.productionOrder,
              // Don't update lotbatchno or storagelocation as original code doesn't
            });
            console.log(`✅ Updated row with UUID: ${result.sap_uuid}`, {
              productionOrder: result.productionOrder
            });
          } else {
            console.error(`❌ Could not find row with UUID: ${result.sap_uuid}`);
          }
        });

        oTabModel.setProperty("/Samples", aData);
        oTabModel.refresh();
        sap.ui.core.BusyIndicator.hide();

        // Show summary message
        this.showPostSummary(aSuccessResults, aErrorResults);
      },

      showPostSummary: function (aSuccessResults, aErrorResults) {
        const sTotal = aSuccessResults.length + aErrorResults.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `API Post process completed for ${sTotal} row(s).\n\n`;
        let bHasSuccess = aSuccessResults.length > 0;
        let bHasFailed = aErrorResults.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
          aSuccessResults.forEach(result => {
            sMessage += `   - ${result.rowId}`;
            if (result.productionOrder) {
              sMessage += ` (Prod. Order: ${result.productionOrder})`;
            }
            sMessage += `\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
          aErrorResults.forEach(result => {
            sMessage += `   - ${result.rowId}: ${result.error}\n`;
          });
        }

        // Always show MessageBox for all cases
        setTimeout(() => {
          if (bHasFailed) {
            // Show detailed error dialog with summary
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.ERROR,
                title: "API Post Process Summary",
                actions: [sap.m.MessageBox.Action.OK],
                details: aErrorResults.map(f =>
                  `${f.rowId}\nError: ${f.error}`
                ).join('\n\n')
              }
            );
          } else {
            // Show success dialog
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.SUCCESS,
                title: "API Post Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          }
        }, 100);
      },








      generateProdOrderNo: function () {
        const oView = this.getView();
        const oODataModel = oView.getModel("ZSB_PROD_HEAD_ITEM2");

        return new Promise((resolve, reject) => {
          // First, read the SINGLE row from ZC_PROD_ORD_TEMP2
          oODataModel.read("/ZC_PROD_ORD_TEMP2", {
            success: function (oData) {
              let nextProdOrderNo = 1; // Default to 1 if no record exists

              if (oData.results && oData.results.length > 0) {
                // Get the first (and should be only) record
                const currentProdOrderNo = oData.results[0].Productionorders;
                console.log("Current production order number found:", currentProdOrderNo);

                // Convert to number and increment
                if (currentProdOrderNo && !isNaN(currentProdOrderNo)) {
                  nextProdOrderNo = parseInt(currentProdOrderNo) + 1;
                } else if (typeof currentProdOrderNo === 'string') {
                  const numericPart = currentProdOrderNo.replace(/\D/g, '');
                  if (numericPart) {
                    nextProdOrderNo = parseInt(numericPart) + 1;
                  }
                }
              } else {
                console.log("No existing production order number found, starting from 1");
              }

              // Format as 12-digit padded number (based on your EntityType definition)
              const paddedProdOrderNo = nextProdOrderNo.toString().padStart(12, '0');
              console.log("Next production order number:", paddedProdOrderNo);

              resolve(paddedProdOrderNo);
            },
            error: function (err) {
              console.error("Failed to read existing production order number:", err);
              reject("Failed to generate production order number");
            }
          });
        });
      },

      initializeProdOrderNumber: function () {
        const oView = this.getView();
        const oODataModel = oView.getModel("ZSB_PROD_HEAD_ITEM2");

        return new Promise((resolve, reject) => {
          // First check if record exists
          oODataModel.read("/ZC_PROD_ORD_TEMP2", {
            success: function (oData) {
              if (oData.results && oData.results.length === 0) {
                // No record exists, create initial record
                const oPayload = {
                  Productionorders: "000000000000" // Start from 0 so first save becomes 1
                };

                oODataModel.create("/ZC_PROD_ORD_TEMP2", oPayload, {
                  success: function () {
                    console.log("Initialized production order number table with 000000000000");
                    resolve();
                  },
                  error: function (oError) {
                    console.error("Failed to initialize production order number:", oError);
                    reject(oError);
                  }
                });
              } else {
                console.log("Production order number table already initialized");
                resolve();
              }
            },
            error: function (err) {
              console.error("Failed to check production order number table:", err);
              reject(err);
            }
          });
        });
      },

      onApiPostButtonbatch: async function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oTableSaveModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
        const oProdHeadItemModel = oView.getModel("ZSB_PROD_HEAD_ITEM2");

        const aData = oTabModel.getProperty("/Samples");
        const aSelectedRows = aData.filter(row => row.__selected);

        // --- 🚫 BLOCKER VALIDATION (cannot proceed)
        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        // Check for saved rows (sap_uuid)
        const aRowsWithoutUUID = aSelectedRows.filter(row => !row.sap_uuid);
        if (aRowsWithoutUUID.length > 0) {
          const sRowNumbers = aRowsWithoutUUID
            .map((row, index) => `Row ${index + 1}`)
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed for the following rows:\n\n${sRowNumbers}: Please save the row first`
          );
          return;
        }

        // Check for existing production orders
        const aRowsWithProdOrder = aSelectedRows.filter(row => {
          const val = row.productionorderno;
          return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
        });

        if (aRowsWithProdOrder.length > 0) {
          const sProdOrders = aRowsWithProdOrder
            .map(row => row.productionorderno || "(No Production Order)")
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed due to the following issues:\n\nProduction Order(s) ${sProdOrders}: Already have valid Production Order Number assigned`
          );
          return;
        }

        // --- 🧪 VALIDATION (field completeness)
        let aValidationErrors = [];

        aSelectedRows.forEach((row, index) => {
          let missingFields = [];

          if (!row.materialcode || row.materialcode.trim() === "") {
            missingFields.push("Material Code");
          }
          if (!row.plant || row.plant.trim() === "") {
            missingFields.push("Plant");
          }
          if (!row.productionorderqty || row.productionorderqty <= 0) {
            missingFields.push("Production Order Quantity");
          }
          if (!row.productionordstartdate) {
            missingFields.push("Production Order Start Date");
          }
          if (!row.machinenumber || row.machinenumber.trim() === "") {
            missingFields.push("Machine Number");
          }

          if (missingFields.length > 0) {
            const sRowId = `Row ${index + 1}`;
            aValidationErrors.push(`${sRowId}: ${missingFields.join(", ")}`);
          }
        });

        if (aValidationErrors.length > 0) {
          sap.m.MessageBox.error(
            "Missing required fields:\n\n" + aValidationErrors.join("\n")
          );
          return;
        }

        // --- ✅ PROCESSING (all validations passed)
        sap.ui.core.BusyIndicator.show(0);

        // Sort selected rows
        const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
          const dateA = a.productionordstartdate;
          const dateB = b.productionordstartdate;

          if (dateA && dateB) {
            if (dateA > dateB) return -1;
            if (dateA < dateB) return 1;
          }

          const lotA = parseInt(a.bipllotno, 10) || 0;
          const lotB = parseInt(b.bipllotno, 10) || 0;
          return lotA - lotB;
        });

        // Arrays to collect results
        const aSuccessResults = [];
        const aErrorResults = [];
        let ProductionOrderNumber = null;
        let currentRecords = null;

        try {
          // ✅ First, read the current record from ZC_PROD_ORD_TEMP2
          currentRecords = await new Promise((resolve, reject) => {
            oProdHeadItemModel.read("/ZC_PROD_ORD_TEMP2", {
              success: function (oData) {
                resolve(oData.results || []);
              },
              error: function (err) {
                console.error("Failed to read current production order number:", err);
                reject(err);
              }
            });
          });

          // ✅ Generate the NEXT production order number
          ProductionOrderNumber = await this.generateProdOrderNo();
          console.log("Using production order number:", ProductionOrderNumber);

          // Prepare payload for ZSB_PROD_HEAD_ITEM2
          const oPayload = {
            productionorders: ProductionOrderNumber,
            toitem: aSortedSelectedRows.map((row, index) => ({
              id: row.sap_uuid,
              Material: row.materialcode,
              Productionplant: row.plant,
              Manufacturingordertype: "ZFG1",
              Productionversion: row.machinenumberhidden,
              Totalquantity: row.productionorderqty,
              Uom: row.uom,
              Mfgorderplannedstartdate: row.productionordstartdate ?
                new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
              Basicschedulingtype: "1",
              Storagelocation: row.storagelocation
            }))
          };


          console.log("Payload for ZSB_PROD_HEAD_ITEM2:", JSON.stringify(oPayload, null, 2));

          // 1. Create Production Orders using ZSB_PROD_HEAD_ITEM2 service
          const oResponse = await new Promise((resolve, reject) => {
            oProdHeadItemModel.create("/header", oPayload, {
              success: function (odata) {
                console.log("Production Order Creation Success:", odata);
                resolve(odata);
              },
              error: function (oError) {
                console.error("Production Order Creation Error:", oError);
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                  try {
                    const oErrorResponse = JSON.parse(oError.responseText);
                    if (oErrorResponse.error && oErrorResponse.error.message) {
                      sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                    }
                  } catch (e) {
                    sErrorMessage = oError.responseText;
                  }
                }
                reject(new Error(sErrorMessage));
              }
            });
          });

          // ✅ Update the ZC_PROD_ORD_TEMP2 table with the new production order number
          if (currentRecords.length > 0) {
            const currentRecord = currentRecords[0];
            const sPath = `/ZC_PROD_ORD_TEMP2('${currentRecord.Productionorders}')`;

            await new Promise((resolve, reject) => {
              oProdHeadItemModel.remove(sPath, {
                success: function () {
                  console.log("Deleted old production order number:", currentRecord.Productionorders);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to delete old production order number:", oError);
                  reject(oError);
                }
              });
            });

            const oCreatePayload = { Productionorders: ProductionOrderNumber };
            await new Promise((resolve, reject) => {
              oProdHeadItemModel.create("/ZC_PROD_ORD_TEMP2", oCreatePayload, {
                success: function () {
                  console.log("Successfully created new production order number:", ProductionOrderNumber);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to create new production order number:", oError);
                  reject(oError);
                }
              });
            });
          } else {
            const oCreatePayload = { Productionorders: ProductionOrderNumber };
            await new Promise((resolve, reject) => {
              oProdHeadItemModel.create("/ZC_PROD_ORD_TEMP2", oCreatePayload, {
                success: function () {
                  console.log("Successfully created production order number:", ProductionOrderNumber);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to create production order number:", oError);
                  reject(oError);
                }
              });
            });
          }

          // Check response structure
          if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            throw new Error("Invalid response format: missing toitem results");
          }

          // Process each item response
          for (let i = 0; i < oResponse.toitem.results.length; i++) {
            const itemResponse = oResponse.toitem.results[i];
            const originalIndex = i;
            const originalRow = aSortedSelectedRows[originalIndex];
            const sRowId = `Row ${originalIndex + 1}`;
            const sBiplLotNo = originalRow.bipllotno || "(no bipl lot)";

            try {
              // Check for backend error first
              if (itemResponse.Errorresponse && itemResponse.Errorresponse.trim() !== "") {
                throw new Error(itemResponse.Errorresponse);
              }

              const sProdOrder = itemResponse.productionorder;
              // const sStorageLoc = itemResponse.Storagelocation || "";

              if (!sProdOrder) {
                throw new Error("No production order returned in item response");
              }

              console.log(`Processing item ${i + 1}: Production Order = ${sProdOrder}`);

              // 2. READ Operation - Batch Creation
              // const batchKey = `00${sProdOrder}`;
              // console.log(`Calling batch creation for key: ${batchKey}`);

              // const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");
              // const oBatchData = await new Promise((resolve, reject) => {
              //   oBatchModel.read(`/ZC_BATCH_CREATE('${batchKey}')`, {
              //     success: function (odata) {
              //       console.log("READ Success - Batch Creation:", odata);
              //       if (!odata.Batch) {
              //         reject(new Error("No batch number returned"));
              //       } else {
              //         resolve(odata);
              //       }
              //     },
              //     error: function (oError) {
              //       console.error("Batch creation failed:", oError);
              //       reject(oError);
              //     }
              //   });
              // });

              // const sBatchNo = oBatchData.Batch;
              // console.log(`Generated batch number: ${sBatchNo} for production order: ${sProdOrder}`);

              // 3. UPDATE Operation - Mixing Plan
              const sKeyPath = `/ZC_FG_PROCESS_PLAN(sap_uuid='${originalRow.sap_uuid}')`;
              const oUpdatePayload = {
                productionorderno: sProdOrder,
                // lotbatchno: sBatchNo,
                // storagelocation: sStorageLoc
              };

              console.log(`Updating mixing plan with key: ${sKeyPath}`, oUpdatePayload);

              await new Promise((resolve, reject) => {
                oTableSaveModel.update(sKeyPath, oUpdatePayload, {
                  merge: true,
                  success: function (odata) {
                    console.log("UPDATE Success - Mixing Plan:", odata);
                    resolve(odata);
                  },
                  error: function (oError) {
                    console.error("Mixing plan update failed:", oError);
                    reject(oError);
                  }
                });
              });

              // Add to success list
              aSuccessResults.push({
                rowId: sRowId,
                bipllotno: sBiplLotNo,
                sap_uuid: originalRow.sap_uuid,
                productionOrder: sProdOrder,
                // batchNo: sBatchNo,
                // storageLocation: sStorageLoc,
                materialCode: originalRow.materialcode
              });

            } catch (oError) {
              console.error(`❌ Processing Failed for ${sRowId} (Bipl: ${sBiplLotNo}):`, oError);

              let sErrorMessage = oError.message || "Unknown error";
              if (oError.responseText) {
                try {
                  const oErrorResponse = JSON.parse(oError.responseText);
                  if (oErrorResponse.error && oErrorResponse.error.message) {
                    sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                  }
                } catch (e) {
                  sErrorMessage = oError.responseText;
                }
              }

              aErrorResults.push({
                rowId: sRowId,
                bipllotno: sBiplLotNo,
                sap_uuid: originalRow.sap_uuid,
                error: sErrorMessage
              });
            }
          }

          // ✅ Update the local TabModel with successful rows
          aSuccessResults.forEach(result => {
            const idx = aData.findIndex(row => row.sap_uuid === result.sap_uuid);
            if (idx !== -1) {
              Object.assign(aData[idx], {
                productionorderno: result.productionOrder,
                // lotbatchno: result.batchNo,
                // storagelocation: result.storageLocation
              });
              console.log(`✅ Updated row with UUID: ${result.sap_uuid}`, {
                productionOrder: result.productionOrder,
                // batchNo: result.batchNo,
                // storageLocation: result.storageLocation
              });
            } else {
              console.error(`❌ Could not find row with UUID: ${result.sap_uuid}`);
            }
          });

          // Clear selection
          aSelectedRows.forEach(row => {
            row.__selected = false;
          });

          oTabModel.setProperty("/Samples", aData);
          oTabModel.refresh();

        } catch (oError) {
          console.error("❌ Production order creation failed:", oError);

          let sErrorMessage = oError.message || "Unknown error";
          if (oError.responseText) {
            try {
              const oErrorResponse = JSON.parse(oError.responseText);
              if (oErrorResponse.error && oErrorResponse.error.message) {
                sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
              }
            } catch (e) {
              sErrorMessage = oError.responseText;
            }
          }

          sap.m.MessageBox.error(`Production order creation failed: ${sErrorMessage}`);
          sap.ui.core.BusyIndicator.hide();
          return;
        }

        sap.ui.core.BusyIndicator.hide();

        // Show summary using the dedicated function
        this.showPostSummaryBatch(aSuccessResults, aErrorResults);
      },

      showPostSummaryBatch: function (aSuccessResults, aErrorResults) {
        const sTotal = aSuccessResults.length + aErrorResults.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `API Post process completed for ${sTotal} row(s).\n\n`;
        let bHasSuccess = aSuccessResults.length > 0;
        let bHasFailed = aErrorResults.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
          aSuccessResults.forEach(result => {
            sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno})`;
            if (result.productionOrder) {
              sMessage += ` → Prod. Order: ${result.productionOrder}`;
              // if (result.batchNo) {
              //   sMessage += `, Batch: ${result.batchNo}`;
              // }
              // if (result.storageLocation) {
              //   sMessage += `, Storage: ${result.storageLocation}`;
              // }
            }
            sMessage += `\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
          aErrorResults.forEach(result => {
            sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}): ${result.error}\n`;
          });
        }

        // Show appropriate dialog
        setTimeout(() => {
          if (bHasFailed && !bHasSuccess) {
            // All failed
            sap.m.MessageBox.error(sMessage, {
              title: "API Post Process Failed"
            });
          } else if (bHasFailed && bHasSuccess) {
            // Partial success
            sap.m.MessageBox.warning(sMessage, {
              title: "API Post Process Partial Success",
              details: aErrorResults.map(f =>
                `${f.rowId} (Bipl: ${f.bipllotno})\nError: ${f.error}`
              ).join('\n\n')
            });
          } else {
            // All success
            sap.m.MessageBox.success(sMessage, {
              title: "API Post Process Successful"
            });
          }
        }, 100);
      },








    });
  }
);

