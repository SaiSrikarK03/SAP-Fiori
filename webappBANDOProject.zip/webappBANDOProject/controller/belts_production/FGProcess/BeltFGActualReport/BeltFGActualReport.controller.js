sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library",
    "sap/ui/core/Fragment"
], function (
    Controller,
    JSONModel,
    ODataModel,
    MessageToast,
    MessageBox,
    Filter,
    FilterOperator,
    Spreadsheet,
    exportLibrary,
    Fragment
) {
    "use strict";

    return Controller.extend("bando.controller.belts_production.BeltFGActualReport", {

         /* ================= INIT ================= */
        onInit: function () {
            this.getView().setModel(new JSONModel({ ItemData: [] }), "TabModel");
            this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL/"), "ZSB_REQ_ACTUAL");
            this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_REQ_MOVEMENT_TYPE/"), "ZSB_REQ_MOVEMENT_TYPE");
            this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_ORDER_TYPE/"), "ZSB_ORDER_TYPE");
            this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_FG_PROCESS_PLAN/"), "ZSB_FG_PROCESS_PLAN");
        },

        formatDate: function (vDate) {
            if (!vDate) return "";
            var oDate = vDate instanceof Date ? vDate : new Date(vDate);
            if (isNaN(oDate.getTime())) return "";
            return sap.ui.core.format.DateFormat
                .getDateInstance({ pattern: "dd/MM/yyyy" })
                .format(oDate);
        },

        /* ================= HELPERS ================= */
        _normalizeOrder: function (s) {
            return s ? s.replace(/^0+/, "") : "";
        },

        _formatProductionOrder: function (s) {
            return s ? s.padStart(12, "0") : "";
        },

        _fetchAllData: function (oModel, sEntity, aFilters, skip, top, res, ok, err) {
            oModel.read(sEntity, {
                filters: aFilters,
                urlParameters: { "$skip": skip, "$top": top },
                success: function (d) {
                    res = res.concat(d.results || []);
                    if (d.results && d.results.length === top) {
                        this._fetchAllData(oModel, sEntity, aFilters, skip + top, top, res, ok, err);
                    } else {
                        ok(res);
                    }
                }.bind(this),
                error: err
            });
        },

        
                GoStockReqTableOpen: function () {
            var view = this.getView();
            var tabModel = view.getModel("TabModel");                                       
            var tabModel = view.getModel("TabModel");
            var oModel = view.getModel("ZSB_REQ_ACTUAL");
            var oMixPlanModel = view.getModel("ZSB_FG_PROCESS_PLAN");
            var oStatusModel = view.getModel("ZSB_PRODUCT_ORD1"); // Status check model

            var oDate = view.byId("MIXBEL").getDateValue();
            if (!oDate) {
                MessageToast.show("Please select a date");
                return;
            }

            var aTokens = view.byId("idmaterialdocumentBEL")?.getTokens() || [];
            var sMaterialInput = view.byId("idMaterial_BEL")?.getValue()?.trim();
            var sMachineInput = view.byId("idMachineNum_BEL")?.getValue()?.trim().toUpperCase();

            var sDate = oDate.getFullYear() + "-" +
                String(oDate.getMonth() + 1).padStart(2, "0") + "-" +
                String(oDate.getDate()).padStart(2, "0");

            view.setBusy(true);

            // STEP 1: Fetch Mix Plan using Date
            this._fetchAllData(oMixPlanModel, "/ZC_FG_PROCESS_PLAN", [new Filter("productionordstartdate", "EQ", sDate)], 0, 1000, [], function (allMixData) {
                
                // STEP 2: Filter out RELEASED orders locally first
                var unreleasedOrders = (allMixData || []).filter(o => !o.releasestatus || o.releasestatus.trim() === "");

                if (unreleasedOrders.length === 0) {
                    view.setBusy(false);
                    tabModel.setProperty("/ItemData", []);
                    MessageToast.show("No unreleased orders found for this date.");
                    return;
                }

                // STEP 2.5: Check for TECO (I0045) Status in ZSB_PRODUCT_ORD1
                var aOrderCheckFilters = unreleasedOrders.map(o => {
                    return new Filter("ManufacturingOrder", "EQ", this._formatProductionOrder(o.productionorderno));
                });

                var oTecoQueryFilter = new Filter({
                    filters: [
                        new Filter({ filters: aOrderCheckFilters, and: false }), // Match any of our POs
                        new Filter("StatusCode", "EQ", "I0045"),                 // AND status is TECO
                        new Filter("StatusIsActive", "EQ", true)                 // AND it is active
                    ],
                    and: true
                });

                this._fetchAllData(oStatusModel, "/ZC_ORDER_CREATION1", [oTecoQueryFilter], 0, 1000, [], function (tecoResults) {
                    
                    // Create a lookup Set of order numbers that are TECO'd
                    var setTecoOrders = new Set(tecoResults.map(t => this._normalizeOrder(t.ManufacturingOrder)));

                    // Keep only orders that are NOT in the TECO set
                    var finalCandidateOrders = unreleasedOrders.filter(o => !setTecoOrders.has(this._normalizeOrder(o.productionorderno)));

                    if (finalCandidateOrders.length === 0) {
                        view.setBusy(false);
                        tabModel.setProperty("/ItemData", []);
                        MessageToast.show("Remaining orders are already Technically Completed (TECO).");
                        return;
                    }

                    // Prepare maps for the join
                    var aJoinFilters = [], machineMap = {}, orderDateMap = {}; 
                    finalCandidateOrders.forEach(o => {
                        var sPaddedPO = this._formatProductionOrder(o.productionorderno);
                        machineMap[sPaddedPO] = o.machinenumber || "";
                        orderDateMap[sPaddedPO] = o.productionordstartdate; 
                        aJoinFilters.push(new Filter({
                            filters: [
                                new Filter("productionorder", "EQ", sPaddedPO),
                                new Filter("BillOfOperationsMaterial", "EQ", o.materialcode)
                            ],
                            and: true
                        }));
                    });

                    // STEP 3: Fetch Stock
                    this._fetchAllData(oModel, "/ZC_REQ_ACT_srorage_loc", [], 0, 5000, [], function (stockResults) {
                        var systemStockMap = {};
                        stockResults.forEach(s => {
                            var sKey = this._normalizeOrder(s.Product) + "|" + (s.Batch || "") + "|" + s.StorageLocation;
                            systemStockMap[sKey] = +s.MatlWrhsStkQtyInMatlBaseUnit || 0;
                        });

                        // STEP 4: Fetch Requirements for final filtered orders
                        this._fetchAllData(oModel, "/ZCE_REQ_ACTUAL", [new Filter({ filters: aJoinFilters, and: false })], 0, 5000, [], function (aResults) {
                            var finalData = [], curKey = "", totals = {};
                            var materialInitialStock = {}, materialRunningBalance = {}; 
                            var groupProcessedBatches = {}, processedReqItems = {};

                            // PASS 1: Totals & Balance Initialization
                            aResults.forEach(function (o) {
                                var sNormPO = this._normalizeOrder(o.productionorder);
                                var sMatNorm = this._normalizeOrder(o.Material);
                                var groupKey = sNormPO + "_" + sMatNorm;
                                var sBatch = o.Batch || "";

                                if (!totals[groupKey]) {
                                    totals[groupKey] = { req: 0, avb: 0, avbAlt: 0 };
                                    groupProcessedBatches[groupKey] = new Set();
                                }

                                var reqKey = sNormPO + "|" + sMatNorm + "|" + (o.RESERVATION || "") + "|" + (o.RESERVATIONITEM || "");
                                if (!processedReqItems[reqKey]) {
                                    totals[groupKey].req += (+o.RequiredQuantity || 0);
                                    processedReqItems[reqKey] = true;
                                }

                                var k1 = sMatNorm + "|" + sBatch + "|" + (o.storagelocation || "");
                                var k2 = sMatNorm + "|" + sBatch + "|" + (o.ProductionInvtryManagedLoc || "");
                                if (!groupProcessedBatches[groupKey].has(sBatch)) {
                                    totals[groupKey].avb += (systemStockMap[k1] || 0);
                                    totals[groupKey].avbAlt += (systemStockMap[k2] || 0);
                                    groupProcessedBatches[groupKey].add(sBatch);
                                }

                                if (materialInitialStock[sMatNorm] === undefined) {
                                    var totalStock = 0, stockSeen = new Set();
                                    aResults.forEach(r => {
                                        if (this._normalizeOrder(r.Material) === sMatNorm) {
                                            var sk = sMatNorm + "|" + (r.Batch || "") + "|" + (r.storagelocation || "");
                                            if (!stockSeen.has(sk)) { totalStock += (systemStockMap[sk] || 0); stockSeen.add(sk); }
                                        }
                                    });
                                    materialInitialStock[sMatNorm] = totalStock;
                                    materialRunningBalance[sMatNorm] = totalStock;
                                }
                            }.bind(this));

                            // PASS 2: Assemble Rows
                            var usedBatchesInPO = new Set();
                            aResults.forEach(function (o) {
                                var sPaddedPO = o.productionorder;
                                var sNormPO = this._normalizeOrder(sPaddedPO);
                                var sMatNorm = this._normalizeOrder(o.Material);
                                var groupKey = sNormPO + "_" + sMatNorm;
                                var sBatch = o.Batch || "";
                                var isFirstInGrp = (groupKey !== curKey);

                                if (isFirstInGrp) usedBatchesInPO.clear();
                                if (usedBatchesInPO.has(sBatch)) return;

                                var sloc1 = o.storagelocation || "";
                                var sloc2 = o.ProductionInvtryManagedLoc || "";
                                var dq1 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1].toFixed(4) : "";
                                var dq2 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2].toFixed(4) : "";

                                if (!dq1 && !dq2) return;

                                if (isFirstInGrp) materialRunningBalance[sMatNorm] -= totals[groupKey].req;
                                if (curKey && isFirstInGrp) finalData.push(this._createSummaryRow(curKey, totals, finalData));

                                curKey = groupKey;
                                usedBatchesInPO.add(sBatch);

                                finalData.push({
                                    ...o,
                                    productionordstartdate: orderDateMap[sPaddedPO] || "", 
                                    productionorderDisp: sNormPO,
                                    machinenumber: machineMap[sPaddedPO] || "",
                                    RequiredQuantity: isFirstInGrp ? totals[groupKey].req.toFixed(4) : "",
                                    col2: dq1,
                                    BatchForCol2: dq1 ? sBatch : "",
                                    storagelocation: dq1 ? sloc1 : "",
                                    MatlWrhsStkQtyInMatlBase1: dq2,
                                    BatchForMatlWrhs: dq2 ? sBatch : "",
                                    ProductionInvtryManagedLoc: dq2 ? sloc2 : "",
                                    BalanceQuantity: isFirstInGrp ? materialRunningBalance[sMatNorm].toFixed(4) : "",
                                    isSumRow: false
                                });
                            }.bind(this));

                            if (curKey) finalData.push(this._createSummaryRow(curKey, totals, finalData));

                            // STEP 5: FINAL UI FILTER
                            var filteredResults = finalData.filter(function (row, idx, arr) {
                                if (!sMachineInput && !sMaterialInput && aTokens.length === 0) return true;
                                var match = (r) => {
                                    var mMachine = !sMachineInput || (r.machinenumber || "").toUpperCase() === sMachineInput;
                                    var mMaterial = !sMaterialInput || this._normalizeOrder(r.Material) === this._normalizeOrder(sMaterialInput);
                                    var mPO = aTokens.length === 0 || aTokens.some(t => this._normalizeOrder(t.getKey() || t.getText()) === this._normalizeOrder(r.productionorder));
                                    return mMachine && mMaterial && mPO;
                                };
                                if (!row.isSumRow) return match(row);
                                var groupMatched = false;
                                for (var i = idx - 1; i >= 0; i--) {
                                    if (arr[i].isSumRow) break;
                                    if (match(arr[i])) { groupMatched = true; break; }
                                }
                                return groupMatched;
                            }.bind(this));

                            tabModel.setProperty("/ItemData", filteredResults);
                            view.setBusy(false);

                        }.bind(this), () => view.setBusy(false));
                    }.bind(this), () => view.setBusy(false));

                }.bind(this), () => view.setBusy(false)); // Error in TECO check
            }.bind(this), () => view.setBusy(false)); // Error in Mixing Plan
        },

        _createSummaryRow: function (key, totals, finalData) {
            var lastBal = "";
            for (var i = finalData.length - 1; i >= 0; i--) {
                if (finalData[i].BalanceQuantity) { lastBal = finalData[i].BalanceQuantity; break; }
            }
            return {
                Material: "Total",
                RequiredQuantity: totals[key].req.toFixed(4),
                col2: totals[key].avb > 0 ? totals[key].avb.toFixed(4) : "",
                MatlWrhsStkQtyInMatlBase1: totals[key].avbAlt > 0 ? totals[key].avbAlt.toFixed(4) : "",
                BatchForCol2: "",
                storagelocation: "",
                BatchForMatlWrhs: "",
                ProductionInvtryManagedLoc: "",
                BalanceQuantity: lastBal,
                isSumRow: true
            };
        },


  onDownload_reqMat_Bel: function () {

    var oTable = this.byId("_idREQ_VS_ACTBel");
    var oBinding = oTable.getBinding("rows");

    var sDate = this._sMixDate || this.getView().byId("MIXBEL").getValue() || "";
    if (!sDate) {
        sap.m.MessageToast.show("Please fetch data before downloading.");
        return;
    }

    // Format date
    var aDateParts = sDate.split("-");
    var sDate_ = aDateParts.length === 3
        ? aDateParts[2].padStart(2, "0") + "-" +
          aDateParts[1].padStart(2, "0") + "-" +
          aDateParts[0]
        : sDate;

    if (!oBinding) {
        sap.m.MessageToast.show("No data available");
        return;
    }

    var aContexts = oBinding.getContexts(0, oBinding.getLength());
    if (!aContexts.length) {
        sap.m.MessageToast.show("No data after filtering");
        return;
    }

    // ===============================
    // 🔥 Aggregation (Correct Logic)
    // ===============================
    var oMap = {};

    aContexts.forEach(function (oCtx) {
        var o = oCtx.getObject();
        if (!o || o.Material === "Total") return;

        var sStorage = o.storagelocation || "";
        var sKey = o.Material + "_" + sStorage;

        if (!oMap[sKey]) {
            oMap[sKey] = {
                Material: o.Material,
                ProductDescription: o.productdescription || "",
                RequiredStorageLocation: sStorage,
                AvailableStorageLocation: o.ProductionInvtryManagedLoc || "",
                TotalRequiredQuantity: 0,
                TotalAvailableReqLoc: 0,
                TotalAvailable12RM: 0
            };
        }

        // ✅ Sum Required Qty
        oMap[sKey].TotalRequiredQuantity += parseFloat(o.RequiredQuantity) || 0;

        // ✅ Sum Available Qty (Req Location)
        oMap[sKey].TotalAvailableReqLoc += parseFloat(o.col2) || 0;

        // ✅ Sum Available Qty (Other Location like 12RM)
        oMap[sKey].TotalAvailable12RM += parseFloat(o.MatlWrhsStkQtyInMatlBase1) || 0;

        // Fill missing descriptive fields if empty
        if (!oMap[sKey].ProductDescription && o.productdescription) {
            oMap[sKey].ProductDescription = o.productdescription;
        }

        if (!oMap[sKey].AvailableStorageLocation && o.ProductionInvtryManagedLoc) {
            oMap[sKey].AvailableStorageLocation = o.ProductionInvtryManagedLoc;
        }

    });

    // ===============================
    // 📦 Prepare Export Data
    // ===============================
    var aExportData = Object.values(oMap).map(function (o) {
        var fBalance = o.TotalAvailableReqLoc - o.TotalRequiredQuantity;

        return {
            Material: o.Material,
            ProductDescription: o.ProductDescription,
            TotalRequiredQuantity: o.TotalRequiredQuantity.toFixed(4),
            RequiredStorageLocation: o.RequiredStorageLocation,
            TotalAvailableReqLoc: o.TotalAvailableReqLoc.toFixed(4),
            TotalAvailable12RM: o.TotalAvailable12RM.toFixed(4),
            AvailableStorageLocation: o.AvailableStorageLocation,
            TotalBalance: fBalance.toFixed(4)
        };
    });

    // ===============================
    // 🧮 Grand Total
    // ===============================
    var fReq = 0, fReqLoc = 0, f12RM = 0, fBal = 0;

    aExportData.forEach(function (o) {
        fReq += parseFloat(o.TotalRequiredQuantity);
        fReqLoc += parseFloat(o.TotalAvailableReqLoc);
        f12RM += parseFloat(o.TotalAvailable12RM);
        fBal += parseFloat(o.TotalBalance);
    });

    aExportData.push({
        Material: "Grand Total",
        ProductDescription: "",
        TotalRequiredQuantity: fReq.toFixed(4),
        RequiredStorageLocation: "",
        TotalAvailableReqLoc: fReqLoc.toFixed(4),
        TotalAvailable12RM: f12RM.toFixed(4),
        AvailableStorageLocation: "",
        TotalBalance: fBal.toFixed(4)
    });

    // ===============================
    // 📊 Excel Columns
    // ===============================
    var EdmType = sap.ui.export.EdmType;

    var aColumns = [
        { label: "Material", property: "Material", type: EdmType.String },
        { label: "Product Description", property: "ProductDescription", type: EdmType.String },
        { label: "Req Qty", property: "TotalRequiredQuantity", type: EdmType.Number, scale: 4 },
        { label: "Required Storage Loc", property: "RequiredStorageLocation", type: EdmType.String },
        { label: "Avl QTY (Req Loc)", property: "TotalAvailableReqLoc", type: EdmType.Number, scale: 4 },
        { label: "Avl QTY (Avl Loc)", property: "TotalAvailable12RM", type: EdmType.Number, scale: 4 },
        { label: "Available Storage Loc", property: "AvailableStorageLocation", type: EdmType.String },
        { label: "Balance", property: "TotalBalance", type: EdmType.Number, scale: 4 }
    ];

    // ===============================
    // 📁 Export
    // ===============================
    var oSettings = {
        workbook: { columns: aColumns },
        dataSource: aExportData,
        fileName: "BeltFG_Req_Material_QTY_" + sDate_ + ".xlsx"
    };

    var oSheet = new sap.ui.export.Spreadsheet(oSettings);

    oSheet.build().finally(function () {
        oSheet.destroy();
    });
},

        /* ================= EXPORT TO EXCEL ================= */
        onDownload: function () {
            var aData = this.getView().getModel("TabModel").getProperty("/ItemData") || [];
            if (!aData.length) {
                MessageToast.show("No data to export");
                return;
            }

            var aExportData = aData.map(o => Object.assign({}, o, {
                ProductionOrder: this._normalizeOrder(o.productionorder),
                BalanceQuantity: parseFloat(o.BalanceQuantity || 0).toFixed(4),
                BatchForCol2: o.BatchForCol2 || "",
                BatchForMatlWrhs: o.BatchForMatlWrhs || ""
            }));

            var aCols = this.createColumns();
            var oSettings = { workbook: { columns: aCols }, dataSource: aExportData, fileName: "BeltFGReport.xlsx" };

            var oSheet = new Spreadsheet(oSettings);
            oSheet.build().finally(function () { oSheet.destroy(); });
        },

        createColumns: function () {
            var EdmType = exportLibrary.EdmType;
            return [
                { label: "Date", property: "MatlCompRequirementDate", type: EdmType.Date },
                { label: "Production Order", property: "ProductionOrder", type: EdmType.String },
                { label: "Material", property: "Material", type: EdmType.String },
                { label: "Product Description", property: "productdescription", type: EdmType.String },
                { label: "Bill Of Operation Material", property: "BillOfOperationsMaterial", type: EdmType.String },
                { label: "Production Order Operation", property: "PRODUCTIONORDEROPERATION", type: EdmType.String },
                { label: "Reservation Item", property: "RESERVATIONITEM", type: EdmType.String },
                { label: "Plant", property: "Plant", type: EdmType.String },
                { label: "Required Quantity", property: "RequiredQuantity", type: EdmType.Decimal, scale: 4 },
                { label: "Base Unit", property: "BaseUnit", type: EdmType.String },
                { label: "Required Storage Location", property: "storagelocation", type: EdmType.String },
                { label: "Batch (Req Loc)", property: "BatchForCol2", type: EdmType.String },
                { label: "Available Qty Req Loc", property: "col2", type: EdmType.Decimal, scale: 4 },
                { label: "Available Qty Avl Loc", property: "MatlWrhsStkQtyInMatlBase1", type: EdmType.Decimal, scale: 4 },
                { label: "Avaliable storage location", property: "ProductionInvtryManagedLoc", type: EdmType.String },
                { label: "Batch (Avl Loc)", property: "BatchForMatlWrhs", type: EdmType.String },
                { label: "Material Base Unit", property: "BaseUnit", type: EdmType.String },
                { label: "Balance Quantity", property: "BalanceQuantity", type: EdmType.Decimal, scale: 4 }
            ];
        },

        onValueHelpRequest: function (oEvent) {

            this._oMultiInput = oEvent.getSource();

            // var Date = this.getView().byId("Dates_").getValue();

            var Date = "";

            // console.log(Date)
            if (Date || Date.length == 0) {
                sap.ui.core.BusyIndicator.show();

                //   var oFilters1 = new sap.ui.model.Filter("Createdat", sap.ui.model.FilterOperator.EQ, Date);
                // Retrieve the model from the view
                var oModel = this.getView().getModel("ZSB_FG_PROCESS_PLAN");

                // Check if the model is valid
                if (!oModel) {
                    console.error("OData model is not properly initialized.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                //   var oFilters = [oFilters1];
                var that = this;
                var aAllItems = []; // Array to hold all retrieved items

                // Function to fetch data recursively
                function fetchData(skipCount) {
                    // var that = this;
                    // var oModel = that.getView().getModel();
                    // that.getView().setModel(oModel);
                    oModel.read("/ZC_FG_PROCESS_PLAN", {
                        //   filters: oFilters,
                        urlParameters: {
                            $top: 5000,  // Request a chunk of 5000 records
                            $skip: skipCount  // Start from the skipCount position
                        },
                        success: function (oData) {
                            var aItems = oData.results;
                            aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                            // Check if there are more records to fetch
                            if (oData.results.length >= 5000) {
                                // If there are more records, fetch next chunk
                                fetchData(skipCount + 5000);
                            } else {
                                // If no more records, all data is fetched
                                finishFetching();
                            }
                        },
                        error: function (oError) {
                            console.error("Error reading data: ", oError);
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });
                }

                function finishFetching() {


                    // Once all data is fetched, proceed to display it
                    that.oJSONModel = new sap.ui.model.json.JSONModel({
                        Datas: aAllItems
                    });
                    that.getView().setModel(that.oJSONModel, "oJSONModel");
                    console.log("that.oJSONModel:", that.oJSONModel)

                    // Load the value help dialog fragment
                    that._oBasicSearchField = new sap.m.SearchField();
                    that.loadFragment({
                        name: "bando.view.belts_production.FGProcess.BeltFGActualReport.fragment.BeltFGActualReport",
                    }).then(function (oDialog) {
                        var oFilterBar = oDialog.getFilterBar();

                        var oColumnProductCode, oColumnPostingDate, oColumnCompanyCode;
                        that._oVHD = oDialog;
                        that.getView().addDependent(oDialog);

                        // Set key fields for filtering in the Define Conditions Tab
                        oDialog.setRangeKeyFields([{
                            label: "Production No.",
                            key: "productionorderno",
                            type: "string",
                            typeInstance: new sap.ui.model.type.String({}, {
                                maxLength: 10
                            })
                        }]);

                        // Set Basic Search for FilterBar
                        oFilterBar.setFilterBarExpanded(false);
                        oFilterBar.setBasicSearch(that._oBasicSearchField);

                        // Trigger filter bar search when the basic search is fired
                        that._oBasicSearchField.attachSearch(function () {
                            oFilterBar.search();
                        });

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(that.oJSONModel);

                            // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                            if (oTable.bindRows) {
                                // Desktop/Table scenario (sap.ui.table.Table)
                                oTable.bindAggregation("rows", {
                                    path: "oJSONModel>/Datas",
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                // Define columns for sap.ui.table.Table
                                oColumnProductCode = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "Production No." }),
                                    template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>productionorderno}" })
                                });
                                oColumnProductCode.data({
                                    fieldName: "productionorder"
                                });

                                oTable.addColumn(oColumnProductCode);


                            } else if (oTable.bindItems) {
                                // Mobile scenario (sap.m.Table)
                                oTable.bindAggregation("items", {
                                    path: "oJSONModel>/Datas",
                                    template: new sap.m.ColumnListItem({
                                        cells: [
                                            new sap.m.Text({ text: "{oJSONModel>productionorderno}" }),

                                        ]
                                    }),
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                // Define columns for sap.m.Table (if necessary)
                                oTable.addColumn(new sap.m.Column({
                                    header: new sap.m.Label({ text: "Production No." })
                                }));

                            }

                            oDialog.update();
                            sap.ui.core.BusyIndicator.hide();
                        });

                        oDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    });
                }

                // Start fetching data from the beginning
                fetchData(0);
            } else {
                //   sap.m.MessageBox.error("Please check Company Code / Fiscal Year");
                sap.ui.core.BusyIndicator.hide();
            }
        },

        onValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            console.log("aTokens:", aTokens);

            if (!this._oMultiInput) {
                console.error("MultiInput not defined!");
                return;
            }

            if (aTokens.length <= 10) {
                this._oMultiInput.setTokens(aTokens); // now safe
                this._oVHD.close();
            } else {
                sap.m.MessageBox.error("Please select max 15 items only!");
            }
        },

        onValueHelpCancelPress: function () {
            this._oVHD.close();
        },

        onValueHelpAfterClose: function () {
            this._oVHD.destroy();
        },

        onFilterBarSearch: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "productionorderno", operator: sap.ui.model.FilterOperator.EQ, value1: sSearchQuery })

                ],
                and: false
            }));

            this._filterTable(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },

        _filterTable: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },

        // Connect to the OData service and fetch suggestions
        OnSuggest_User: function (oEvent) {
            // Store the source MultiInput
            this._oMultiInput = oEvent.getSource();

            var sTerm = oEvent.getParameter("suggestValue");

            this._connectToODataProductSearchService(sTerm)
                .then(function (aSuggestions) {
                    // Clear previous suggestions
                    this.destroySuggestionItems();

                    // Add new suggestions to the input field
                    for (var i = 0; i < aSuggestions.length; i++) {
                        this.addSuggestionItem(new sap.ui.core.Item({
                            text: aSuggestions[i]
                        }));
                    }
                }.bind(oEvent.getSource())); // bind the input
        },


        _connectToODataProductSearchService: function (sTerm) {
            var oModel = this.getView().getModel('ZSB_FG_PROCESS_PLAN'); // OData Model
            var aFilters = [
                new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sTerm) // Search based on Name
            ];

            return new Promise(function (fnResolve, fnReject) {
                // Perform OData read request
                oModel.read("/ZC_FG_PROCESS_PLAN", {  // Replace "/ProductSet" with your OData entity set
                    filters: aFilters,
                    urlParameters: {
                        "$top": 5000
                    },
                    success: function (oData) {
                        var aResults = oData.results.map(function (mProduct) {
                            return mProduct.productionorderno;  // Assuming Name is the field you're interested in
                        });

                        // Resolve with the list of suggestions
                        fnResolve(aResults);
                    },
                    error: function (oError) {
                        console.error("Error fetching suggestions from OData service:", oError);
                        fnReject(oError);
                    }
                });
            });
        },

        ondocumentsuggestselected: function (oEvent) {
            sap.ui.core.BusyIndicator.show();

            var oSelectedItem = oEvent.getParameter("selectedItem");

            if (oSelectedItem) {
                var sSelectedText = oSelectedItem.getText();

                if (!this._oMultiInput) {
                    console.error("MultiInput not defined!");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // Set value into the stored MultiInput
                this._oMultiInput.setValue(sSelectedText);
            }

            sap.ui.core.BusyIndicator.hide();
        },

    });
});
