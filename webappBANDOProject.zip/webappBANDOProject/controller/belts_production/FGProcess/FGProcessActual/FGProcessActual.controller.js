sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",
        "bando/util/jspdf/html2canvasmin",
        "bando/util/jspdf/jspdfmin",
        "bando/util/importfile/importexcelfile",
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
        "use strict";

        return BaseController.extend("bando.controller.belts_production.FGProcessActual", {
            onInit: function () {


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");

                this._selectedProductionOrders = [];
                this._selectedMaterials = [];



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("FGProcessActual").attachMatched(this._onRouteMatched, this);

            },

            // _onRouteMatched: function () {
            //     // Clear filters
            //     // this.byId("idDateRange").setDateValue(null);
            //     // this.byId("idDateRange").setSecondDateValue(null);
            //     // this.byId("idPlant").setValue("");
            //     // this.byId("idMaterial").setValue("");
            //     // this.byId("idProductGroup").setValue("");

            //     // Optionally: clear or re-fetch table data
            //     this.getView().getModel("TabModel").setProperty("/Samples", []);
            //     this.HeaderModel = new sap.ui.model.json.JSONModel({

            //         HeaderData: {
            //             idDateRange: "",
            //             idPlant: "",
            //             idMaterial: "",
            //             // idProductGroup: "",
            //             idProductionorderno: "",

            //         }
            //     })

            //     this.getView().setModel(this.HeaderModel, "HeaderModel");
            // },


            _onRouteMatched: function () {
                // Clear table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);

                // Reset header model (if needed)
                this.HeaderModel = new sap.ui.model.json.JSONModel({
                    HeaderData: {
                        idDateRange: "",
                        idPlant: "",
                        // idMaterial: "",
                        idProductionorderno: "",
                    }
                });
                this.getView().setModel(this.HeaderModel, "HeaderModel");

                // 🔥 CLEAR INPUT FIELDS BY ID (this is what fixes your issue)
                this.byId("idDateRange").setDateValue(null);
                this.byId("idDateRange").setSecondDateValue(null);

                this.byId("idPlant").setValue("");

                // this.byId("idMaterial").setValue("");
                // var oMaterialInput = this.byId("idMaterial");
                // oMaterialInput.setValue("");  // Clear the value
                // oMaterialInput.removeAllTokens();  // Clear all tokens

                // this.byId("idProductionorderno").setValue("");
                var oPOInput = this.byId("idProductionorderno");
                oPOInput.setValue("");  // Clear the value
                oPOInput.removeAllTokens();  // Clear all tokens
            },



            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },





// used till 15-07-2026

            // GoFGProcessActual: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oShiftComboBox = oView.byId("idshift");
            //     const sSelectedShift = oShiftComboBox.getSelectedKey();
            //     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
            //     const oSpecCode = oView.byId("idSpecCode").getValue().trim();

            //     // Production Order tokens
            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     // if (!oStartDate && !oEndDate && !oPlant && !oMachineNumber && !oSpecCode && aProductionOrders.length === 0 && !sSelectedShift) {
            //     //     sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //     //     return;
            //     // }
            //     if (!oStartDate) {
            //         sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
            //         oDateRange.setValueState("Error");
            //         oDateRange.setValueStateText("Please select Production Order Start Date.");
            //         return;
            //     } else {
            //         oDateRange.setValueState("None");
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant filter (even though visible=false)
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }

            //     // Machine Number filter
            //     if (oMachineNumber) {
            //         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
            //     }

            //     // Spec Code filter
            //     if (oSpecCode) {
            //         aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
            //     }

            //     // Shift filter (if a shift is selected)
            //     if (sSelectedShift) {
            //         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
            //     }

            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idFGProcessActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Call the read function with increased limit
            //     oModel.read("/ZC_FG_PROCESS_PLAN", {
            //         filters: aFilters,
            //         urlParameters: {
            //             "$top": 10000,
            //         },
            //         success: function (oData) {
            //             // Debug point 1 - we're in the first success callback
            //             // debugger;
            //             console.log("First OData call successful, processing results...");

            //             // First filter: Remove rows with invalid production order numbers
            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             // Log all production orders that were loaded
            //             const allProductionOrders = aFiltered.map(row => row.productionorderno);
            //             console.log("All loaded production orders:", {
            //                 allloadedprodorders: [...new Set(allProductionOrders)],
            //                 totalRows: aFiltered.length,
            //                 uniqueOrders: [...new Set(allProductionOrders)].length
            //             });

            //             // If no rows after initial filtering, show empty table
            //             if (aFiltered.length === 0) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 oTabModel.setProperty("/Samples", []);
            //                 oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                 if (callback && typeof callback === 'function') {
            //                     callback([]);
            //                 }
            //                 return;
            //             }

            //             // Get all unique production order numbers
            //             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

            //             const aOrderFilters = aUniqueOrders.map(order =>
            //                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            //             );
            //             const oOrderOrFilter = new sap.ui.model.Filter({
            //                 filters: aOrderFilters,
            //                 and: false // OR logic
            //             });

            //             // Combine with AND conditions for I0045 and active status
            //             const aFinalFilters = [
            //                 oOrderOrFilter,
            //                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
            //                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            //             ];

            //             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
            //             console.log("Unique orders being checked:", {
            //                 uniqueOrders: aUniqueOrders,
            //                 count: aUniqueOrders.length
            //             });

            //             // Make the second OData call – now returns only orders with active I0045
            //             oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //                 filters: aFinalFilters,
            //                 urlParameters: {
            //                     "$top": 10000  // still safe – only active I0045 records are returned
            //                 },
            //                 success: function (oStatusData) {
            //                     // The result contains only orders that have active I0045 status
            //                     const ordersWithActiveI0045 = new Set(
            //                         oStatusData.results.map(item => item.ManufacturingOrder)
            //                     );

            //                     console.log("Orders with active I0045 (to be excluded):", {
            //                         statusfilteredout: Array.from(ordersWithActiveI0045),
            //                         count: ordersWithActiveI0045.size
            //                     });

            //                     // Filter out rows belonging to those orders
            //                     const aFilteredByStatus = aFiltered.filter(row =>
            //                         !ordersWithActiveI0045.has(row.productionorderno)
            //                     );

            //                     // Log final results
            //                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
            //                     console.log("Final production orders after filtering:", {
            //                         remainingprodorders: [...new Set(finalProductionOrders)],
            //                         totalRemainingRows: aFilteredByStatus.length,
            //                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
            //                     });

            //                     // Summary log
            //                     console.log("=== SUMMARY ===");
            //                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
            //                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
            //                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

            //                     sap.ui.core.BusyIndicator.hide();

            //                     oTabModel.setProperty("/Samples", aFilteredByStatus);
            //                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
            //                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFilteredByStatus);
            //                     }
            //                 },
            //                 error: function (oError) {
            //                     // Debug point 3 - second OData call error
            //                     // debugger;
            //                     sap.ui.core.BusyIndicator.hide();
            //                     console.error("Error checking order status:", oError);

            //                     // If there's an error checking status, show all rows (don't filter)
            //                     oTabModel.setProperty("/Samples", aFiltered);
            //                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFiltered);
            //                     }
            //                 }
            //             });
            //         },
            //         error: function (oError) {
            //             // Debug point 4 - first OData call error
            //             // debugger;
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Call callback with empty array on error
            //             if (callback && typeof callback === 'function') {
            //                 callback([]);
            //             }
            //         }
            //     });
            // },
GoFGProcessActual: function (callback) {
    const oView = this.getView();
    const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
    const oTabModel = oView.getModel("TabModel");
    const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

    // --- Collect filters -------------------------------------------------
    const oDateRange = oView.byId("idDateRange");
    const oPlant = oView.byId("idPlant").getValue().trim();
    const oShiftComboBox = oView.byId("idshift");
    const sSelectedShift = oShiftComboBox.getSelectedKey();
    const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
    const oSpecCode = oView.byId("idSpecCode").getValue().trim();

    const oMI = oView.byId("idProductionorderno");
    const aTokens = oMI.getTokens();
    const aProductionOrders = aTokens.map(t => t.getKey());

    const oStartDate = oDateRange.getDateValue();
    const oEndDate = oDateRange.getSecondDateValue();

    if (!oStartDate) {
        sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
        oDateRange.setValueState("Error");
        oDateRange.setValueStateText("Please select Production Order Start Date.");
        return;
    } else {
        oDateRange.setValueState("None");
    }

    // Build filter array for the first read
    const aFilters = [];
    if (oStartDate && oEndDate) {
        const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
        const sStartDate = oDateFormat.format(oStartDate);
        const sEndDate = oDateFormat.format(oEndDate);
        aFilters.push(new sap.ui.model.Filter({
            path: "productionordstartdate",
            operator: sap.ui.model.FilterOperator.BT,
            value1: sStartDate,
            value2: sEndDate
        }));
    }
    if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
    if (oMachineNumber) aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
    if (oSpecCode) aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
    if (sSelectedShift) aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
    if (aProductionOrders.length > 0) {
        const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
        aFilters.push(new sap.ui.model.Filter({ filters: aPOFilters, and: false }));
    }

    const oDynamicPage = this.byId("idFGProcessActualDynamic");
    if (oDynamicPage) oDynamicPage.setShowFooter(true);

    sap.ui.core.BusyIndicator.show(0);

    // ---------- Helper: fetch all pages from an OData entity ----------
    function fetchAllPages(oModel, sEntitySet, aFilters, iPageSize = 1000) {
        const deferred = $.Deferred();
        let allResults = [];
        let iSkip = 0;

        function fetchPage() {
            oModel.read(sEntitySet, {
                filters: aFilters,
                urlParameters: {
                    "$top": iPageSize,
                    "$skip": iSkip
                },
                success: function (oData) {
                    const aPage = oData.results || [];
                    allResults = allResults.concat(aPage);
                    if (aPage.length < iPageSize) {
                        deferred.resolve(allResults);
                    } else {
                        iSkip += iPageSize;
                        fetchPage();
                    }
                },
                error: function (oError) {
                    deferred.reject(oError);
                }
            });
        }

        fetchPage();
        return deferred.promise();
    }

    // ---------- Helper: fetch TECO status for a list of orders using chunked OR ----------
    function fetchTecoForOrders(oModel, aOrderNumbers, iChunkSize = 500) {
        const deferred = $.Deferred();
        const allTecoOrders = [];
        const aChunks = [];

        // Split order numbers into chunks
        for (let i = 0; i < aOrderNumbers.length; i += iChunkSize) {
            aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
        }

        // If no orders, resolve with empty set
        if (aChunks.length === 0) {
            deferred.resolve(new Set());
            return deferred.promise();
        }

        // Function to process one chunk
        function processChunk(chunk, index) {
            const aOrderFilters = chunk.map(order =>
                new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            );
            const oOrFilter = new sap.ui.model.Filter({ filters: aOrderFilters, and: false });

            // Combine with TECO status filters
            const aCombinedFilters = [
                oOrFilter,
                new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            ];

            const oDeferred = $.Deferred();
            oModel.read("/ZC_ORDER_CREATION1", {
                filters: aCombinedFilters,
                urlParameters: { "$top": chunk.length * 2 }, // safety margin
                success: function (oData) {
                    const aResults = oData.results || [];
                    // Extract ManufacturingOrder values
                    const aTecoOrders = aResults.map(item => item.ManufacturingOrder);
                    oDeferred.resolve(aTecoOrders);
                },
                error: function (oError) {
                    oDeferred.reject(oError);
                }
            });
            return oDeferred.promise();
        }

        // Process all chunks in parallel using Promise.all (or sequential to reduce load)
        // We'll do sequential to avoid overwhelming the server with many concurrent requests
        // but parallel (Promise.all) may be faster. Choose based on server capacity.
        // Here we use sequential processing for safety.
        function processSequentially(index) {
            if (index >= aChunks.length) {
                deferred.resolve(new Set(allTecoOrders));
                return;
            }
            processChunk(aChunks[index], index)
                .then(function (aTecoOrders) {
                    allTecoOrders.push(...aTecoOrders);
                    processSequentially(index + 1);
                })
                .catch(function (oError) {
                    deferred.reject(oError);
                });
        }

        processSequentially(0);
        return deferred.promise();
    }

    // ---------- Step 1: Fetch all rows from the main entity ----------
    fetchAllPages(oModel, "/ZC_FG_PROCESS_PLAN", aFilters, 1000)
        .then(function (aAllRows) {
            console.log("Total rows fetched from main entity:", aAllRows.length);

            // Filter out invalid production order numbers
            const aFiltered = aAllRows.filter(row => {
                const prodOrder = row.productionorderno;
                return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            });
            console.log("After removing invalid production order numbers:", aFiltered.length);

            if (aFiltered.length === 0) {
                sap.ui.core.BusyIndicator.hide();
                oTabModel.setProperty("/Samples", []);
                oView.byId("idFGProcessActualtablescreen").setVisible(true);
                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                if (callback && typeof callback === 'function') {
                    callback([]);
                }
                return;
            }

            // Unique production orders
            const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];
            console.log("Unique production orders to check for TECO:", aUniqueOrders.length);

            // ---------- Step 2: Fetch TECO status only for these orders (chunked) ----------
            return fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
                .then(function (tecoSet) {
                    console.log("TECO orders found among the queried list:", tecoSet.size);

                    // Filter out rows whose production order is in the TECO set
                    const aFinal = aFiltered.filter(row => !tecoSet.has(row.productionorderno));
                    console.log("Rows after removing TECO orders:", aFinal.length);

                    sap.ui.core.BusyIndicator.hide();
                    oTabModel.setProperty("/Samples", aFinal);
                    oView.byId("idFGProcessActualtablescreen").setVisible(true);
                    const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                    oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    if (callback && typeof callback === 'function') {
                        callback(aFinal);
                    }
                }.bind(this));
        }.bind(this))
        .catch(function (oError) {
            sap.ui.core.BusyIndicator.hide();
            console.error("Error in data fetching:", oError);
            sap.m.MessageBox.error("Error fetching data. Please try again.");
            oTabModel.setProperty("/Samples", []);
            oView.byId("idFGProcessActualtablescreen").setVisible(true);
            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            if (callback && typeof callback === 'function') {
                callback([]);
            }
        }.bind(this));
},
            // GoFGProcessActualfilter: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oShiftComboBox = oView.byId("idshift");
            //     const sSelectedShift = oShiftComboBox.getSelectedKey();
            //     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
            //     const oSpecCode = oView.byId("idSpecCode").getValue().trim();

            //     // Production Order tokens
            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     if (!oStartDate && !oEndDate && !oPlant && !oMachineNumber && !oSpecCode && aProductionOrders.length === 0 && !sSelectedShift) {
            //         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant filter (even though visible=false)
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }

            //     // Machine Number filter
            //     if (oMachineNumber) {
            //         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
            //     }

            //     // Spec Code filter
            //     if (oSpecCode) {
            //         aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
            //     }

            //     // Shift filter (if a shift is selected)
            //     if (sSelectedShift) {
            //         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
            //     }

            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idFGProcessActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Call the read function with increased limit
            //     oModel.read("/ZC_FG_PROCESS_PLAN", {
            //         filters: aFilters,
            //         urlParameters: {
            //             "$top": 10000,
            //         },
            //         success: function (oData) {
            //             // Debug point 1 - we're in the first success callback
            //             // debugger;
            //             console.log("First OData call successful, processing results...");

            //             // First filter: Remove rows with invalid production order numbers
            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             // Log all production orders that were loaded
            //             const allProductionOrders = aFiltered.map(row => row.productionorderno);
            //             console.log("All loaded production orders:", {
            //                 allloadedprodorders: [...new Set(allProductionOrders)],
            //                 totalRows: aFiltered.length,
            //                 uniqueOrders: [...new Set(allProductionOrders)].length
            //             });

            //             // If no rows after initial filtering, show empty table
            //             if (aFiltered.length === 0) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 oTabModel.setProperty("/Samples", []);
            //                 oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                 if (callback && typeof callback === 'function') {
            //                     callback([]);
            //                 }
            //                 return;
            //             }

            //             // Get all unique production order numbers
            //             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

            //             const aOrderFilters = aUniqueOrders.map(order =>
            //                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            //             );
            //             const oOrderOrFilter = new sap.ui.model.Filter({
            //                 filters: aOrderFilters,
            //                 and: false // OR logic
            //             });

            //             // Combine with AND conditions for I0045 and active status
            //             const aFinalFilters = [
            //                 oOrderOrFilter,
            //                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
            //                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            //             ];

            //             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
            //             console.log("Unique orders being checked:", {
            //                 uniqueOrders: aUniqueOrders,
            //                 count: aUniqueOrders.length
            //             });

            //             // Make the second OData call – now returns only orders with active I0045
            //             oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //                 filters: aFinalFilters,
            //                 urlParameters: {
            //                     "$top": 10000  // still safe – only active I0045 records are returned
            //                 },
            //                 success: function (oStatusData) {
            //                     // The result contains only orders that have active I0045 status
            //                     const ordersWithActiveI0045 = new Set(
            //                         oStatusData.results.map(item => item.ManufacturingOrder)
            //                     );

            //                     console.log("Orders with active I0045 (to be excluded):", {
            //                         statusfilteredout: Array.from(ordersWithActiveI0045),
            //                         count: ordersWithActiveI0045.size
            //                     });

            //                     // Filter out rows belonging to those orders
            //                     const aFilteredByStatus = aFiltered.filter(row =>
            //                         !ordersWithActiveI0045.has(row.productionorderno)
            //                     );

            //                     // Log final results
            //                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
            //                     console.log("Final production orders after filtering:", {
            //                         remainingprodorders: [...new Set(finalProductionOrders)],
            //                         totalRemainingRows: aFilteredByStatus.length,
            //                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
            //                     });

            //                     // Summary log
            //                     console.log("=== SUMMARY ===");
            //                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
            //                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
            //                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

            //                     sap.ui.core.BusyIndicator.hide();

            //                     oTabModel.setProperty("/Samples", aFilteredByStatus);
            //                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
            //                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFilteredByStatus);
            //                     }
            //                 },
            //                 error: function (oError) {
            //                     // Debug point 3 - second OData call error
            //                     // debugger;
            //                     sap.ui.core.BusyIndicator.hide();
            //                     console.error("Error checking order status:", oError);

            //                     // If there's an error checking status, show all rows (don't filter)
            //                     oTabModel.setProperty("/Samples", aFiltered);
            //                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFiltered);
            //                     }
            //                 }
            //             });
            //         },
            //         error: function (oError) {
            //             // Debug point 4 - first OData call error
            //             // debugger;
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Call callback with empty array on error
            //             if (callback && typeof callback === 'function') {
            //                 callback([]);
            //             }
            //         }
            //     });
            // },

GoFGProcessActualfilter: function (callback) {
    const oView = this.getView();
    const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
    const oTabModel = oView.getModel("TabModel");
    const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

    // --- Collect filters -------------------------------------------------
    const oDateRange = oView.byId("idDateRange");
    const oPlant = oView.byId("idPlant").getValue().trim();
    const oShiftComboBox = oView.byId("idshift");
    const sSelectedShift = oShiftComboBox.getSelectedKey();
    const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
    const oSpecCode = oView.byId("idSpecCode").getValue().trim();

    const oMI = oView.byId("idProductionorderno");
    const aTokens = oMI.getTokens();
    const aProductionOrders = aTokens.map(t => t.getKey());

    const oStartDate = oDateRange.getDateValue();
    const oEndDate = oDateRange.getSecondDateValue();

    // Original validation: at least one filter criterion must be provided
    if (!oStartDate && !oEndDate && !oPlant && !oMachineNumber && !oSpecCode && aProductionOrders.length === 0 && !sSelectedShift) {
        sap.m.MessageBox.warning("Please enter at least one filter criteria.");
        return;
    }

    // Build filter array for the first read
    const aFilters = [];
    if (oStartDate && oEndDate) {
        const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
        const sStartDate = oDateFormat.format(oStartDate);
        const sEndDate = oDateFormat.format(oEndDate);
        aFilters.push(new sap.ui.model.Filter({
            path: "productionordstartdate",
            operator: sap.ui.model.FilterOperator.BT,
            value1: sStartDate,
            value2: sEndDate
        }));
    }
    if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
    if (oMachineNumber) aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
    if (oSpecCode) aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
    if (sSelectedShift) aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
    if (aProductionOrders.length > 0) {
        const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
        aFilters.push(new sap.ui.model.Filter({ filters: aPOFilters, and: false }));
    }

    const oDynamicPage = this.byId("idFGProcessActualDynamic");
    if (oDynamicPage) oDynamicPage.setShowFooter(true);

    sap.ui.core.BusyIndicator.show(0);

    // ---------- Helper: fetch all pages from an OData entity ----------
    function fetchAllPages(oModel, sEntitySet, aFilters, iPageSize = 1000) {
        const deferred = $.Deferred();
        let allResults = [];
        let iSkip = 0;

        function fetchPage() {
            oModel.read(sEntitySet, {
                filters: aFilters,
                urlParameters: {
                    "$top": iPageSize,
                    "$skip": iSkip
                },
                success: function (oData) {
                    const aPage = oData.results || [];
                    allResults = allResults.concat(aPage);
                    if (aPage.length < iPageSize) {
                        deferred.resolve(allResults);
                    } else {
                        iSkip += iPageSize;
                        fetchPage();
                    }
                },
                error: function (oError) {
                    deferred.reject(oError);
                }
            });
        }

        fetchPage();
        return deferred.promise();
    }

    // ---------- Helper: fetch TECO status for a list of orders using chunked OR ----------
    function fetchTecoForOrders(oModel, aOrderNumbers, iChunkSize = 500) {
        const deferred = $.Deferred();
        const allTecoOrders = [];
        const aChunks = [];

        // Split order numbers into chunks
        for (let i = 0; i < aOrderNumbers.length; i += iChunkSize) {
            aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
        }

        // If no orders, resolve with empty set
        if (aChunks.length === 0) {
            deferred.resolve(new Set());
            return deferred.promise();
        }

        // Function to process one chunk
        function processChunk(chunk) {
            const aOrderFilters = chunk.map(order =>
                new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            );
            const oOrFilter = new sap.ui.model.Filter({ filters: aOrderFilters, and: false });

            const aCombinedFilters = [
                oOrFilter,
                new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            ];

            const oDeferred = $.Deferred();
            oModel.read("/ZC_ORDER_CREATION1", {
                filters: aCombinedFilters,
                urlParameters: { "$top": chunk.length * 2 },
                success: function (oData) {
                    const aResults = oData.results || [];
                    const aTecoOrders = aResults.map(item => item.ManufacturingOrder);
                    oDeferred.resolve(aTecoOrders);
                },
                error: function (oError) {
                    oDeferred.reject(oError);
                }
            });
            return oDeferred.promise();
        }

        // Process chunks sequentially to avoid server overload
        function processSequentially(index) {
            if (index >= aChunks.length) {
                deferred.resolve(new Set(allTecoOrders));
                return;
            }
            processChunk(aChunks[index])
                .then(function (aTecoOrders) {
                    allTecoOrders.push(...aTecoOrders);
                    processSequentially(index + 1);
                })
                .catch(function (oError) {
                    deferred.reject(oError);
                });
        }

        processSequentially(0);
        return deferred.promise();
    }

    // ---------- Step 1: Fetch all rows from the main entity ----------
    fetchAllPages(oModel, "/ZC_FG_PROCESS_PLAN", aFilters, 1000)
        .then(function (aAllRows) {
            console.log("Total rows fetched from main entity:", aAllRows.length);

            // Filter out invalid production order numbers
            const aFiltered = aAllRows.filter(row => {
                const prodOrder = row.productionorderno;
                return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            });
            console.log("After removing invalid production order numbers:", aFiltered.length);

            if (aFiltered.length === 0) {
                sap.ui.core.BusyIndicator.hide();
                oTabModel.setProperty("/Samples", []);
                oView.byId("idFGProcessActualtablescreen").setVisible(true);
                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                if (callback && typeof callback === 'function') {
                    callback([]);
                }
                return;
            }

            // Unique production orders
            const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];
            console.log("Unique production orders to check for TECO:", aUniqueOrders.length);

            // ---------- Step 2: Fetch TECO status only for these orders (chunked) ----------
            return fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
                .then(function (tecoSet) {
                    console.log("TECO orders found among the queried list:", tecoSet.size);

                    const aFinal = aFiltered.filter(row => !tecoSet.has(row.productionorderno));
                    console.log("Rows after removing TECO orders:", aFinal.length);

                    sap.ui.core.BusyIndicator.hide();
                    oTabModel.setProperty("/Samples", aFinal);
                    oView.byId("idFGProcessActualtablescreen").setVisible(true);
                    const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                    oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    if (callback && typeof callback === 'function') {
                        callback(aFinal);
                    }
                }.bind(this));
        }.bind(this))
        .catch(function (oError) {
            sap.ui.core.BusyIndicator.hide();
            console.error("Error in data fetching:", oError);
            sap.m.MessageBox.error("Error fetching data. Please try again.");
            oTabModel.setProperty("/Samples", []);
            oView.byId("idFGProcessActualtablescreen").setVisible(true);
            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            if (callback && typeof callback === 'function') {
                callback([]);
            }
        }.bind(this));
},
// new version commented

// GoFGProcessActual: function (callback) {
//     const oView = this.getView();
//     const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // OData model
//     const oTabModel = oView.getModel("TabModel");     // Local model
//     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

//     // Get filter inputs
//     const oDateRange = oView.byId("idDateRange");
//     const oPlant = oView.byId("idPlant").getValue().trim();
//     const oShiftComboBox = oView.byId("idshift");
//     const sSelectedShift = oShiftComboBox.getSelectedKey();
//     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
//     const oSpecCode = oView.byId("idSpecCode").getValue().trim();

//     // Production Order tokens
//     const oMI = oView.byId("idProductionorderno");
//     const aTokens = oMI.getTokens(); // array of sap.m.Token
//     const aProductionOrders = aTokens.map(t => t.getKey());

//     const oStartDate = oDateRange.getDateValue();
//     const oEndDate = oDateRange.getSecondDateValue();

//     // Validate date
//     if (!oStartDate) {
//         sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
//         oDateRange.setValueState("Error");
//         oDateRange.setValueStateText("Please select Production Order Start Date.");
//         return;
//     } else {
//         oDateRange.setValueState("None");
//     }

//     const aFilters = [];

//     // Date range filter
//     if (oStartDate && oEndDate) {
//         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
//         const sStartDate = oDateFormat.format(oStartDate);
//         const sEndDate = oDateFormat.format(oEndDate);

//         aFilters.push(new sap.ui.model.Filter({
//             path: "productionordstartdate",
//             operator: sap.ui.model.FilterOperator.BT,
//             value1: sStartDate,
//             value2: sEndDate
//         }));
//     }

//     // Plant filter (even though visible=false)
//     if (oPlant) {
//         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
//     }

//     // Machine Number filter
//     if (oMachineNumber) {
//         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
//     }

//     // Spec Code filter
//     if (oSpecCode) {
//         aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
//     }

//     // Shift filter (if a shift is selected)
//     if (sSelectedShift) {
//         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
//     }

//     // Production order filter (multiple POs handled as OR)
//     if (aProductionOrders.length > 0) {
//         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
//         const oPOCombinedFilter = new sap.ui.model.Filter({
//             filters: aPOFilters,
//             and: false // OR logic
//         });
//         aFilters.push(oPOCombinedFilter);
//     }

//     const oDynamicPage = this.byId("idFGProcessActualDynamic");
//     if (oDynamicPage) {
//         oDynamicPage.setShowFooter(true);
//     }

//     sap.ui.core.BusyIndicator.show(0);

//     // ------------------------------
//     // PAGINATION HELPER (fetch all pages)
//     // ------------------------------
//     function fetchAllPages(model, entitySet, filters, pageSize) {
//         return new Promise(function (resolve, reject) {
//             let allResults = [];
//             let skip = 0;
//             let totalCount = null;

//             function readPage() {
//                 model.read(entitySet, {
//                     filters: filters,
//                     urlParameters: {
//                         "$top": pageSize,
//                         "$skip": skip,
//                         "$inlinecount": "allpages"   // optional but useful
//                     },
//                     success: function (oData) {
//                         const results = oData.results || [];
//                         allResults = allResults.concat(results);

//                         // Determine if we have more data
//                         let hasMore = false;
//                         if (oData.__count !== undefined) {
//                             totalCount = parseInt(oData.__count, 10);
//                             hasMore = (skip + pageSize) < totalCount;
//                         } else {
//                             // Fallback: if this page has exactly 'pageSize' rows, assume there is more
//                             hasMore = (results.length === pageSize);
//                         }

//                         if (hasMore) {
//                             skip += pageSize;
//                             readPage(); // fetch next page
//                         } else {
//                             resolve(allResults);
//                         }
//                     },
//                     error: function (oError) {
//                         reject(oError);
//                     }
//                 });
//             }

//             readPage();
//         });
//     }

//     // Use the helper to fetch all rows with pagination (page size = 1000)
//     fetchAllPages(oModel, "/ZC_FG_PROCESS_PLAN", aFilters, 1000)
//         .then(function (allRows) {
//             console.log("Total rows fetched (all pages):", allRows.length);

//             // First filter: Remove rows with invalid production order numbers
//             const aFiltered = allRows.filter(row => {
//                 const prodOrder = row.productionorderno;
//                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
//             });

//             // Log all production orders that were loaded
//             const allProductionOrders = aFiltered.map(row => row.productionorderno);
//             console.log("All loaded production orders:", {
//                 allloadedprodorders: [...new Set(allProductionOrders)],
//                 totalRows: aFiltered.length,
//                 uniqueOrders: [...new Set(allProductionOrders)].length
//             });

//             // If no rows after initial filtering, show empty table
//             if (aFiltered.length === 0) {
//                 sap.ui.core.BusyIndicator.hide();
//                 oTabModel.setProperty("/Samples", []);
//                 oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                 if (callback && typeof callback === 'function') {
//                     callback([]);
//                 }
//                 return;
//             }

//             // Get all unique production order numbers
//             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

//             // ----- OPTIMIZED STATUS CHECK (with pagination) -----
//             // Build an OR filter for all unique orders
//             const aOrderFilters = aUniqueOrders.map(order =>
//                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
//             );
//             const oOrderOrFilter = new sap.ui.model.Filter({
//                 filters: aOrderFilters,
//                 and: false // OR logic
//             });

//             // Combine with AND conditions for I0045 and active status
//             const aFinalFilters = [
//                 oOrderOrFilter,
//                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
//                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
//             ];

//             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
//             console.log("Unique orders being checked:", {
//                 uniqueOrders: aUniqueOrders,
//                 count: aUniqueOrders.length
//             });

//             // Use pagination for the status check as well
//             fetchAllPages(oOrderCreationModel, "/ZC_ORDER_CREATION1", aFinalFilters, 1000)
//                 .then(function (statusRows) {
//                     // The result contains only orders that have active I0045 status
//                     const ordersWithActiveI0045 = new Set(
//                         statusRows.map(item => item.ManufacturingOrder)
//                     );

//                     console.log("Orders with active I0045 (to be excluded):", {
//                         statusfilteredout: Array.from(ordersWithActiveI0045),
//                         count: ordersWithActiveI0045.size
//                     });

//                     // Filter out rows belonging to those orders
//                     const aFilteredByStatus = aFiltered.filter(row =>
//                         !ordersWithActiveI0045.has(row.productionorderno)
//                     );

//                     // Log final results
//                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
//                     console.log("Final production orders after filtering:", {
//                         remainingprodorders: [...new Set(finalProductionOrders)],
//                         totalRemainingRows: aFilteredByStatus.length,
//                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
//                     });

//                     // Summary log
//                     console.log("=== SUMMARY ===");
//                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
//                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
//                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

//                     sap.ui.core.BusyIndicator.hide();

//                     oTabModel.setProperty("/Samples", aFilteredByStatus);
//                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
//                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

//                     if (callback && typeof callback === 'function') {
//                         callback(aFilteredByStatus);
//                     }
//                 })
//                 .catch(function (oError) {
//                     // Error in status check
//                     sap.ui.core.BusyIndicator.hide();
//                     console.error("Error checking order status:", oError);

//                     // If there's an error checking status, show all rows (don't filter)
//                     oTabModel.setProperty("/Samples", aFiltered);
//                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

//                     if (callback && typeof callback === 'function') {
//                         callback(aFiltered);
//                     }
//                 });
//         })
//         .catch(function (oError) {
//             // Error in the first OData call (fetching FG process plan)
//             sap.ui.core.BusyIndicator.hide();
//             sap.m.MessageBox.error("Error fetching data. Please try again.");
//             console.error("OData read error (pagination):", oError);

//             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//             if (callback && typeof callback === 'function') {
//                 callback([]);
//             }
//         });
// },

// GoFGProcessActualfilter: function (callback) {
//     const oView = this.getView();
//     const oModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // OData model
//     const oTabModel = oView.getModel("TabModel");     // Local model
//     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

//     // Get filter inputs
//     const oDateRange = oView.byId("idDateRange");
//     const oPlant = oView.byId("idPlant").getValue().trim();
//     const oShiftComboBox = oView.byId("idshift");
//     const sSelectedShift = oShiftComboBox.getSelectedKey();
//     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();
//     const oSpecCode = oView.byId("idSpecCode").getValue().trim();

//     // Production Order tokens
//     const oMI = oView.byId("idProductionorderno");
//     const aTokens = oMI.getTokens(); // array of sap.m.Token
//     const aProductionOrders = aTokens.map(t => t.getKey());

//     const oStartDate = oDateRange.getDateValue();
//     const oEndDate = oDateRange.getSecondDateValue();

//     // At least one filter is required
//     if (!oStartDate && !oEndDate && !oPlant && !oMachineNumber && !oSpecCode && aProductionOrders.length === 0 && !sSelectedShift) {
//         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
//         return;
//     }

//     const aFilters = [];

//     // Date range filter
//     if (oStartDate && oEndDate) {
//         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
//         const sStartDate = oDateFormat.format(oStartDate);
//         const sEndDate = oDateFormat.format(oEndDate);

//         aFilters.push(new sap.ui.model.Filter({
//             path: "productionordstartdate",
//             operator: sap.ui.model.FilterOperator.BT,
//             value1: sStartDate,
//             value2: sEndDate
//         }));
//     }

//     // Plant filter (even though visible=false)
//     if (oPlant) {
//         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
//     }

//     // Machine Number filter
//     if (oMachineNumber) {
//         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
//     }

//     // Spec Code filter
//     if (oSpecCode) {
//         aFilters.push(new sap.ui.model.Filter("speccode", sap.ui.model.FilterOperator.EQ, oSpecCode));
//     }

//     // Shift filter (if a shift is selected)
//     if (sSelectedShift) {
//         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
//     }

//     // Production order filter (multiple POs handled as OR)
//     if (aProductionOrders.length > 0) {
//         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
//         const oPOCombinedFilter = new sap.ui.model.Filter({
//             filters: aPOFilters,
//             and: false // OR logic
//         });
//         aFilters.push(oPOCombinedFilter);
//     }

//     const oDynamicPage = this.byId("idFGProcessActualDynamic");
//     if (oDynamicPage) {
//         oDynamicPage.setShowFooter(true);
//     }

//     sap.ui.core.BusyIndicator.show(0);

//     // ------------------------------
//     // PAGINATION HELPER (fetch all pages)
//     // ------------------------------
//     function fetchAllPages(model, entitySet, filters, pageSize) {
//         return new Promise(function (resolve, reject) {
//             let allResults = [];
//             let skip = 0;
//             let totalCount = null;

//             function readPage() {
//                 model.read(entitySet, {
//                     filters: filters,
//                     urlParameters: {
//                         "$top": pageSize,
//                         "$skip": skip,
//                         "$inlinecount": "allpages"   // optional but useful
//                     },
//                     success: function (oData) {
//                         const results = oData.results || [];
//                         allResults = allResults.concat(results);

//                         // Determine if we have more data
//                         let hasMore = false;
//                         if (oData.__count !== undefined) {
//                             totalCount = parseInt(oData.__count, 10);
//                             hasMore = (skip + pageSize) < totalCount;
//                         } else {
//                             // Fallback: if this page has exactly 'pageSize' rows, assume there is more
//                             hasMore = (results.length === pageSize);
//                         }

//                         if (hasMore) {
//                             skip += pageSize;
//                             readPage(); // fetch next page
//                         } else {
//                             resolve(allResults);
//                         }
//                     },
//                     error: function (oError) {
//                         reject(oError);
//                     }
//                 });
//             }

//             readPage();
//         });
//     }

//     // Use the helper to fetch all rows with pagination (page size = 1000)
//     fetchAllPages(oModel, "/ZC_FG_PROCESS_PLAN", aFilters, 1000)
//         .then(function (allRows) {
//             console.log("Total rows fetched (all pages):", allRows.length);

//             // First filter: Remove rows with invalid production order numbers
//             const aFiltered = allRows.filter(row => {
//                 const prodOrder = row.productionorderno;
//                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
//             });

//             // Log all production orders that were loaded
//             const allProductionOrders = aFiltered.map(row => row.productionorderno);
//             console.log("All loaded production orders:", {
//                 allloadedprodorders: [...new Set(allProductionOrders)],
//                 totalRows: aFiltered.length,
//                 uniqueOrders: [...new Set(allProductionOrders)].length
//             });

//             // If no rows after initial filtering, show empty table
//             if (aFiltered.length === 0) {
//                 sap.ui.core.BusyIndicator.hide();
//                 oTabModel.setProperty("/Samples", []);
//                 oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                 if (callback && typeof callback === 'function') {
//                     callback([]);
//                 }
//                 return;
//             }

//             // Get all unique production order numbers
//             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

//             // ----- OPTIMIZED STATUS CHECK (with pagination) -----
//             // Build an OR filter for all unique orders
//             const aOrderFilters = aUniqueOrders.map(order =>
//                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
//             );
//             const oOrderOrFilter = new sap.ui.model.Filter({
//                 filters: aOrderFilters,
//                 and: false // OR logic
//             });

//             // Combine with AND conditions for I0045 and active status
//             const aFinalFilters = [
//                 oOrderOrFilter,
//                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
//                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
//             ];

//             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
//             console.log("Unique orders being checked:", {
//                 uniqueOrders: aUniqueOrders,
//                 count: aUniqueOrders.length
//             });

//             // Use pagination for the status check as well
//             fetchAllPages(oOrderCreationModel, "/ZC_ORDER_CREATION1", aFinalFilters, 1000)
//                 .then(function (statusRows) {
//                     // The result contains only orders that have active I0045 status
//                     const ordersWithActiveI0045 = new Set(
//                         statusRows.map(item => item.ManufacturingOrder)
//                     );

//                     console.log("Orders with active I0045 (to be excluded):", {
//                         statusfilteredout: Array.from(ordersWithActiveI0045),
//                         count: ordersWithActiveI0045.size
//                     });

//                     // Filter out rows belonging to those orders
//                     const aFilteredByStatus = aFiltered.filter(row =>
//                         !ordersWithActiveI0045.has(row.productionorderno)
//                     );

//                     // Log final results
//                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
//                     console.log("Final production orders after filtering:", {
//                         remainingprodorders: [...new Set(finalProductionOrders)],
//                         totalRemainingRows: aFilteredByStatus.length,
//                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
//                     });

//                     // Summary log
//                     console.log("=== SUMMARY ===");
//                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
//                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
//                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

//                     sap.ui.core.BusyIndicator.hide();

//                     oTabModel.setProperty("/Samples", aFilteredByStatus);
//                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
//                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

//                     if (callback && typeof callback === 'function') {
//                         callback(aFilteredByStatus);
//                     }
//                 })
//                 .catch(function (oError) {
//                     // Error in status check
//                     sap.ui.core.BusyIndicator.hide();
//                     console.error("Error checking order status:", oError);

//                     // If there's an error checking status, show all rows (don't filter)
//                     oTabModel.setProperty("/Samples", aFiltered);
//                     oView.byId("idFGProcessActualtablescreen").setVisible(true);

//                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

//                     if (callback && typeof callback === 'function') {
//                         callback(aFiltered);
//                     }
//                 });
//         })
//         .catch(function (oError) {
//             // Error in the first OData call (fetching FG process plan)
//             sap.ui.core.BusyIndicator.hide();
//             sap.m.MessageBox.error("Error fetching data. Please try again.");
//             console.error("OData read error (pagination):", oError);

//             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//             if (callback && typeof callback === 'function') {
//                 callback([]);
//             }
//         });
// },

            applyAllFilters: function () {
                const oView = this.getView();
                const oReleaseCombo = oView.byId("comboReleaseStatusFilter");
                const oGICombo = oView.byId("comboGIStatusFilter");
                const oGRCombo = oView.byId("comboGRStatusFilter");
                const oConfirmedQtyCombo = oView.byId("comboConfirmedQtyFilter");

                const sRelease = oReleaseCombo.getSelectedKey();
                const sGI = oGICombo.getSelectedKey();
                const sGR = oGRCombo.getSelectedKey();
                const sConfirmedQty = oConfirmedQtyCombo.getSelectedKey();

                // If all filters are "All", just reload full data without extra filtering
                if ((!sRelease || sRelease === "") &&
                    (!sGI || sGI === "") &&
                    (!sGR || sGR === "") &&
                    (!sConfirmedQty || sConfirmedQty === "")) {
                    this.GoFGProcessActualfilter();
                    return;
                }

                // Show loading indicator
                sap.ui.core.BusyIndicator.show(0);

                // Fetch fresh data (respects main search filters) and then apply status filters
                this.GoFGProcessActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Apply all three filters in one pass (AND condition)
                    const aFilteredData = fetchedData.filter(item => {
                        // ----- Release Status filter -----
                        let releaseOk = true;
                        if (sRelease && sRelease !== "") {
                            if (sRelease === "RELEASED") {
                                releaseOk = item.releasestatus === "RELEASED";
                            } else { // UNRELEASED
                                releaseOk = !item.releasestatus ||
                                    item.releasestatus.trim() === "" ||
                                    item.releasestatus === " ";
                            }
                        }

                        // ----- GI Status filter -----
                        let giOk = true;
                        if (sGI && sGI !== "") {
                            const giVal = item.gicnfmaterialdocnumber;
                            if (sGI === "COMPLETED") {
                                giOk = giVal && giVal.trim() !== "" && giVal !== "0";
                            } else { // NOT_COMPLETED
                                giOk = !giVal || giVal.trim() === "" || giVal === "0";
                            }
                        }

                        // ----- GR Status filter -----
                        let grOk = true;
                        if (sGR && sGR !== "") {
                            const grVal = item.grmaterialdocnumber;
                            if (sGR === "COMPLETED") {
                                grOk = grVal && grVal.trim() !== "" && grVal !== "0";
                            } else { // NOT_COMPLETED
                                grOk = !grVal || grVal.trim() === "" || grVal === "0";
                            }
                        }

                        // ----- Confirmed Quantity filter -----
                        let confirmedQtyOk = true;
                        if (sConfirmedQty && sConfirmedQty !== "") {
                            const qty = item.confirmedqty; // comes as string
                            const isFilled = qty && qty.trim() !== "" &&
                                !isNaN(parseFloat(qty)) &&
                                parseFloat(qty) !== 0;

                            if (sConfirmedQty === "FILLED") {
                                confirmedQtyOk = isFilled;
                            } else { // NOT_FILLED
                                confirmedQtyOk = !isFilled;
                            }
                        }

                        // All must be true
                        return releaseOk && giOk && grOk && confirmedQtyOk;
                    });

                    // Update the table model
                    const oTabModel = oView.getModel("TabModel");
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Optional: show summary
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} records`);
                });
            },

            onFilterConfirmedQty: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboConfirmedQtyFilter");
                const sSelectedFilter = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected, reload the full data
                if (!sSelectedFilter || sSelectedFilter === "") {
                    this.GoFGProcessActualfilter();
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                // Fetch data (via your existing GoFGProcessActualfilter) and apply client‑side filter
                this.GoFGProcessActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter logic for "FILLED" vs "NOT_FILLED"
                    const aFilteredData = fetchedData.filter(item => {
                        const qty = item.confirmedqty; // value comes as string
                        const isFilled = (qty && qty.trim() !== "" &&
                            !isNaN(parseFloat(qty)) &&
                            parseFloat(qty) !== 0);

                        return sSelectedFilter === "FILLED" ? isFilled : !isFilled;
                    });

                    // Update the model with filtered data
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show result summary
                    const sFilterText = sSelectedFilter === "FILLED" ? "Filled" : "Not Filled";
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} ${sFilterText} records`);
                });
            },





            onFilterReleaseStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboReleaseStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoFGProcessActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoFGProcessActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected status
                    const aFilteredData = fetchedData.filter(item => {
                        if (sSelectedStatus === "RELEASED") {
                            // For released: status must be exactly "RELEASED"
                            return item.releasestatus === "RELEASED";
                        } else {
                            // For unreleased: status is empty, null, undefined, or just whitespace
                            return !item.releasestatus ||
                                item.releasestatus.trim() === "" ||
                                item.releasestatus === " ";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "RELEASED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} released records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} unreleased records`);
                    }
                });
            },

            onFilterGIStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGIStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoFGProcessActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoFGProcessActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GI status
                    const aFilteredData = fetchedData.filter(item => {
                        const giCnfValue = item.gicnfmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return giCnfValue &&
                                giCnfValue.trim() !== "" &&
                                giCnfValue !== "0" &&
                                giCnfValue !== null &&
                                giCnfValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !giCnfValue ||
                                giCnfValue.trim() === "" ||
                                giCnfValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GI records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GI records`);
                    }
                });
            },

            onFilterGRStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGRStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoFGProcessActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoFGProcessActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GR status
                    const aFilteredData = fetchedData.filter(item => {
                        const grValue = item.grmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return grValue &&
                                grValue.trim() !== "" &&
                                grValue !== "0" &&
                                grValue !== null &&
                                grValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !grValue ||
                                grValue.trim() === "" ||
                                grValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GR records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GR records`);
                    }
                });
            },







            ontypeconfirmedqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get the binding context and row data
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                // Handle empty or invalid input - replace with 0
                let iConfirmedQty = parseFloat(sNewValue);
                if (isNaN(iConfirmedQty)) {
                    iConfirmedQty = 0;
                }

                const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;

                // Validate inputs
                // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
                //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
                //     oInput.setValue(""); // Clear the input
                //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
                //     oContext.getModel().refresh(); // Reflect change in UI
                //     return;
                // }

                if (iConfirmedQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
                    oInput.setValue("");
                    // oRowData.balanceqty = oRowData.productionorderqty || 0;
                    oContext.getModel().refresh();
                    return;
                }

                // Set Confirmed QTY explicitly if needed
                oRowData.confirmedqty = iConfirmedQty;

                // Calculate and update Balance QTY
                const iBalanceQty = iProductionOrderQty - iConfirmedQty;
                // oRowData.balanceqty = iBalanceQty;
                oRowData.scrapqty = isNaN(iBalanceQty) ? 0.000 : Number(iBalanceQty.toFixed(3));

                // Refresh the model to update UI
                oContext.getModel().refresh();
            },

            ontypebalanceqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get row context
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                const iScrapQty = parseFloat(sNewValue);              // this is balanceqty entered
                const iConfirmedQty = parseFloat(oRowData.confirmedqty);

                // Validate confirmed qty exists
                if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
                    sap.m.MessageBox.error("Please enter a valid Confirmed QTY before entering Scrap QTY.");
                    oInput.setValue("");
                    return;
                }

                // Validate scrap qty value
                if (isNaN(iScrapQty) || iScrapQty < 0) {
                    sap.m.MessageBox.error("Scrap QTY must be a valid positive number.");
                    oInput.setValue("");
                    return;
                }

                // Core Rule: Scrap QTY ≤ Confirmed QTY
                if (iScrapQty > iConfirmedQty) {
                    sap.m.MessageBox.error("Scrap QTY must be less than or equal to Confirmed QTY.");
                    oInput.setValue("");
                    return;
                }

                // Update the model properly using setProperty
                oContext.getModel().setProperty(oContext.getPath() + "/scrapqty", iScrapQty);
            },





            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },


            // onRejectCodesLiveChange: function (oEvent) {
            //     const inputValue = oEvent.getSource().getValue();
            //     const oModel = this.getView().getModel("TabModel");
            //     const oBindingContext = oEvent.getSource().getBindingContext("TabModel");
            //     const sPath = oBindingContext.getPath();
            //     const oData = oModel.getProperty(sPath);

            //     // Track previously set codes to clear them if not in new input
            //     const previouslySetCodes = new Set();
            //     const currentInputCodes = new Set();

            //     // Get previously set codes from the data
            //     for (let i = 1; i <= 62; i++) {
            //         const fieldName = `Code${i}`;
            //         if (oData[fieldName] && oData[fieldName] !== "") {
            //             previouslySetCodes.add(i.toString());
            //         }
            //     }

            //     // If input is empty, clear all previously set codes
            //     if (!inputValue || inputValue.trim() === '') {
            //         previouslySetCodes.forEach(code => {
            //             oModel.setProperty(`${sPath}/Code${code}`, "");
            //         });
            //         return;
            //     }

            //     // Split the input by commas to get individual code/value pairs
            //     const pairs = inputValue.split(',');
            //     const codeValues = {};

            //     // Process each pair
            //     pairs.forEach(pair => {
            //         const trimmedPair = pair.trim();

            //         // Skip empty pairs
            //         if (trimmedPair === '') return;

            //         // Split by slash to get code and value
            //         const [code, value] = trimmedPair.split('/').map(item => item.trim());

            //         // Validate: both code and value should be numbers between 1-62 for code
            //         if (code && value && !isNaN(code) && !isNaN(value)) {
            //             const codeNum = parseInt(code);
            //             const valueNum = parseInt(value);

            //             // Validate code is between 1-62
            //             if (codeNum >= 1 && codeNum <= 62) {
            //                 codeValues[code] = value;
            //                 currentInputCodes.add(code);
            //             } else {
            //                 console.warn(`Code ${code} is out of range (1-62)`);
            //             }
            //         } else {
            //             console.warn(`Invalid format: ${trimmedPair}`);
            //         }
            //     });

            //     // Clear codes that were previously set but not in current input
            //     previouslySetCodes.forEach(code => {
            //         if (!currentInputCodes.has(code)) {
            //             oModel.setProperty(`${sPath}/Code${code}`, "");
            //         }
            //     });

            //     // Update the model for each valid code found
            //     Object.keys(codeValues).forEach(code => {
            //         const fieldName = `Code${code}`;
            //         oModel.setProperty(`${sPath}/${fieldName}`, codeValues[code]);
            //     });
            // },





            // onExportExl: function () {
            //     const oModel = this.getView().getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // Filter selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     // Use selected rows if available, else use all rows
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     // Format both date fields to match table display (dd-MM-yyyy)
            //     const aFormattedData = aExportData.map(item => {
            //         const formattedItem = Object.assign({}, item);

            //         // Helper function to format date to dd-MM-yyyy
            //         const formatDate = (dateValue) => {
            //             if (!dateValue) return "";

            //             const date = new Date(dateValue);

            //             // Handle timezone correction - get local date
            //             const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

            //             // Format as dd-MM-yyyy
            //             const day = String(localDate.getDate()).padStart(2, '0');
            //             const month = String(localDate.getMonth() + 1).padStart(2, '0');
            //             const year = localDate.getFullYear();

            //             return `${day}-${month}-${year}`;
            //         };

            //         // Format production order start date
            //         if (formattedItem.productionordstartdate) {
            //             formattedItem.productionordstartdate = formatDate(formattedItem.productionordstartdate);
            //         }

            //         // Format manufacturing date
            //         if (formattedItem.manufacturingdate) {
            //             formattedItem.manufacturingdate = formatDate(formattedItem.manufacturingdate);
            //         }

            //         return formattedItem;
            //     });

            //     const aColumns = [
            //         { label: "Plant", property: "plant" },
            //         { label: "Production Order No", property: "productionorderno" },
            //         { label: "bipllotno", property: "bipllotno" },
            //         { label: "shift", property: "shift" },
            //         { label: "Material Code", property: "materialcode" },
            //         { label: "Description", property: "description" },
            //         { label: "Machine Number", property: "machinenumber" },
            //         { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         { label: "Production Order Qty", property: "productionorderqty" },
            //         { label: "Lot/Batch-No", property: "lotbatchno" },
            //         { label: "Storage Location", property: "storagelocation" },
            //         // { label: "compoundcode", property: "compoundcode" },
            //         { label: "Confirmed Qty", property: "confirmedqty" },
            //         { label: "Scrap Qty", property: "scrapqty" },

            //         // { label: "Defect Qty", property: "defectQty" },
            //         // { label: "Balance Qty", property: "balanceQty" },
            //         // { label: "UOM", property: "uom" },
            //         { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         // { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         // { label: "Batch Weight", property: "batchweight" },
            //         // { label: "Operator", property: "operator" },
            //         // { label: "Inspector", property: "inspector" },
            //         { label: "Released Status", property: "releasestatus" },
            //         { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
            //         { label: "Confirmation Count", property: "gicnfconfirmationcount" },
            //         { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
            //         { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
            //         { label: "GR Material Doc Year", property: "grmaterialdocyear" },
            //         { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
            //         // { label: "Status of Production Order", property: "statusOfProdOrd" }
            //     ];

            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: {
            //                 sheetName: "Mixing Plan"
            //             }
            //         },
            //         dataSource: aFormattedData,
            //         fileName: "Mixing_Plan_Export.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed.");
            //         })
            //         .catch(function (oError) {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },

            onExportExl: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, else use all rows
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // 🔹 Sort the data in the same sequence as the table
                // First by productionordstartdate (ascending), then by slabno (ascending)
                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by slabno (ascending)
                    const slabA = a.slabno || "";
                    const slabB = b.slabno || "";
                    if (slabA < slabB) return -1;
                    if (slabA > slabB) return 1;

                    return 0;
                });

                // Format both date fields to match table display (dd-MM-yyyy) and ensure time is properly formatted
                // const aFormattedData = aExportData.map(item => {
                //     const formattedItem = Object.assign({}, item);

                //     // Helper function to format date to dd-MM-yyyy
                //     const formatDate = (dateValue) => {
                //         if (!dateValue) return "";

                //         const date = new Date(dateValue);

                //         // Handle timezone correction - get local date
                //         const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                //         // Format as dd-MM-yyyy
                //         const day = String(localDate.getDate()).padStart(2, '0');
                //         const month = String(localDate.getMonth() + 1).padStart(2, '0');
                //         const year = localDate.getFullYear();

                //         return `${day}-${month}-${year}`;
                //     };

                //     // Format production order start date
                //     if (formattedItem.productionordstartdate) {
                //         formattedItem.productionordstartdate = formatDate(formattedItem.productionordstartdate);
                //     }

                //     // Format manufacturing date
                //     if (formattedItem.manufacturingdate) {
                //         formattedItem.manufacturingdate = formatDate(formattedItem.manufacturingdate);
                //     }

                //     // Ensure manufacturing time is properly formatted (HH:mm:ss)
                //     // If it's already in HH:mm:ss format, keep it as is
                //     // If it's a Date object or ISO string, extract the time part
                //     // if (formattedItem.manufacturingtime) {
                //     //     if (typeof formattedItem.manufacturingtime === 'string') {
                //     //         // If it's already a time string like "13:30:21", keep it
                //     //         // Just ensure it's in proper format
                //     //         const timeMatch = formattedItem.manufacturingtime.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
                //     //         if (timeMatch) {
                //     //             // Format to ensure HH:mm:ss with leading zeros
                //     //             const hours = String(timeMatch[1]).padStart(2, '0');
                //     //             const minutes = String(timeMatch[2]).padStart(2, '0');
                //     //             const seconds = timeMatch[3] ? String(timeMatch[3]).padStart(2, '0') : '00';
                //     //             formattedItem.manufacturingtime = `${hours}:${minutes}:${seconds}`;
                //     //         }
                //     //     } else if (formattedItem.manufacturingtime instanceof Date) {
                //     //         // If it's a Date object, extract time
                //     //         const hours = String(formattedItem.manufacturingtime.getHours()).padStart(2, '0');
                //     //         const minutes = String(formattedItem.manufacturingtime.getMinutes()).padStart(2, '0');
                //     //         const seconds = String(formattedItem.manufacturingtime.getSeconds()).padStart(2, '0');
                //     //         formattedItem.manufacturingtime = `${hours}:${minutes}:${seconds}`;
                //     //     }
                //     // } else {
                //     //     // If no time is set, set to empty string
                //     //     formattedItem.manufacturingtime = "";
                //     // }

                //     return formattedItem;
                // });

                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    // Manufacturing Date
                    if (formattedItem.manufacturingdate) {
                        const date = new Date(formattedItem.manufacturingdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    // Production Order Start Date
                    if (formattedItem.productionordstartdate) {
                        const date = new Date(formattedItem.productionordstartdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.productionordstartdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    if (formattedItem.PostingDate) {
                        const date = new Date(formattedItem.PostingDate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    return formattedItem;
                });

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "bipllotno", property: "bipllotno" },
                    { label: "shift", property: "shift" },
                    { label: "Material Code", property: "materialcode" },
                    { label: "Description", property: "description" },
                    { label: "Machine Number", property: "machinenumber" },
                    { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Production Order Qty", property: "productionorderqty" },
                    { label: "Lot/Batch-No", property: "lotbatchno" },
                    { label: "Storage Location", property: "storagelocation" },
                    // { label: "compoundcode", property: "compoundcode" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },
                    { label: "Reject Codes", property: "RejectCodes" },
                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Defect Qty", property: "defectQty" },
                    // { label: "Balance Qty", property: "balanceQty" },
                    // { label: "UOM", property: "uom" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Manufacturing Time", property: "manufacturingtime" }, // ADDED THIS LINE
                    // { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Batch Weight", property: "batchweight" },
                    // { label: "Operator", property: "operator" },
                    // { label: "Inspector", property: "inspector" },
                    { label: "Released Status", property: "releasestatus" },
                    { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
                    { label: "Confirmation Count", property: "gicnfconfirmationcount" },
                    { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
                    { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
                    { label: "GR Material Doc Year", property: "grmaterialdocyear" },
                    { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
                    // { label: "Status of Production Order", property: "statusOfProdOrd" }
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "FGProcess Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "FGProcess_Actual_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },




            // onExporttoImport: function () {
            //     const oModel = this.getView().getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // 🔍 Check for selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     const aColumns = [
            //         { label: "Plant", property: "plant" },
            //         { label: "Production Order No", property: "productionorderno" },
            //         { label: "Confirmed Qty", property: "confirmedqty" },
            //         // { label: "compoundcode", property: "compoundcode" },
            //         // { label: "Defect Qty", property: "defectQty" },
            //         // { label: "Scrap Qty", property: "balanceqty" },
            //         { label: "Scrap Qty", property: "scrapqty" },
            //         { label: "Reject Codes", property: "RejectCodes" },
            //         { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         // { label: "Batch Weight", property: "batchweight" },
            //         // { label: "Operator", property: "operator" },
            //         // { label: "Inspector", property: "inspector" },
            //     ];

            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: {
            //                 sheetName: "FG Process Actual"
            //             }
            //         },
            //         dataSource: aExportData,
            //         fileName: "FGProcessActualExporttoImport.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed.");
            //         })
            //         .catch(function (oError) {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },


            // onExporttoImport: function () {
            //     const oModel = this.getView().getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // 🔍 Check for selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     // Format manufacturing date to match table display (dd-MM-yyyy)
            //     const aFormattedData = aExportData.map(item => {
            //         const formattedItem = Object.assign({}, item);

            //         if (formattedItem.manufacturingdate) {
            //             // Convert to local date string in dd-MM-yyyy format (like in table)
            //             const date = new Date(formattedItem.manufacturingdate);

            //             // Handle timezone correction - get local date
            //             const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

            //             // Format as dd-MM-yyyy
            //             const day = String(localDate.getDate()).padStart(2, '0');
            //             const month = String(localDate.getMonth() + 1).padStart(2, '0');
            //             const year = localDate.getFullYear();

            //             formattedItem.manufacturingdate = `${day}-${month}-${year}`;
            //         }

            //         return formattedItem;
            //     });

            //     const aColumns = [
            //         { label: "Plant", property: "plant" },
            //         { label: "Production Order No", property: "productionorderno" },
            //         { label: "Prduction order qty", property: "productionorderqty" },
            //         { label: "Confirmed Qty", property: "confirmedqty" },
            //         { label: "Scrap Qty", property: "scrapqty" },
            //         { label: "Reject Codes", property: "RejectCodes" },
            //         { label: "Manufacturing Date", property: "manufacturingdate", type: "string" },
            //     ];

            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: {
            //                 sheetName: "FGProcess Actual"
            //             }
            //         },
            //         dataSource: aFormattedData,
            //         fileName: "FGProcessExporttoImport.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed.");
            //         })
            //         .catch(function (oError) {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },


            onExporttoImport: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // 🔍 Check for selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // 🔹 Sort the data in the same sequence as the table
                // First by productionordstartdate (ascending), then by slabno (ascending)
                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by slabno (ascending)
                    const slabA = a.slabno || "";
                    const slabB = b.slabno || "";
                    if (slabA < slabB) return -1;
                    if (slabA > slabB) return 1;

                    return 0;
                });

                // Format manufacturing date to match table display (dd-MM-yyyy) and include manufacturing time
                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    // Format manufacturing date to dd-MM-yyyy
                    if (formattedItem.manufacturingdate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.manufacturingdate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${day}-${month}-${year}`;
                    }

                    if (formattedItem.PostingDate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.PostingDate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${day}-${month}-${year}`;
                    }

                    // Format manufacturing time to HH:mm:ss
                    // if (formattedItem.manufacturingtime) {
                    //     if (typeof formattedItem.manufacturingtime === 'string') {
                    //         // If it's already a time string, ensure proper HH:mm:ss format
                    //         const timeMatch = formattedItem.manufacturingtime.match(/^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$/);
                    //         if (timeMatch) {
                    //             // Format to ensure HH:mm:ss with leading zeros
                    //             const hours = String(timeMatch[1]).padStart(2, '0');
                    //             const minutes = String(timeMatch[2]).padStart(2, '0');
                    //             const seconds = timeMatch[3] ? String(timeMatch[3]).padStart(2, '0') : '00';
                    //             formattedItem.manufacturingtime = `${hours}:${minutes}:${seconds}`;
                    //         }
                    //     } else if (formattedItem.manufacturingtime instanceof Date) {
                    //         // If it's a Date object, extract time part
                    //         const hours = String(formattedItem.manufacturingtime.getHours()).padStart(2, '0');
                    //         const minutes = String(formattedItem.manufacturingtime.getMinutes()).padStart(2, '0');
                    //         const seconds = String(formattedItem.manufacturingtime.getSeconds()).padStart(2, '0');
                    //         formattedItem.manufacturingtime = `${hours}:${minutes}:${seconds}`;
                    //     }
                    // } else {
                    //     // If no time is set, set to empty string
                    //     formattedItem.manufacturingtime = "";
                    // }

                    return formattedItem;
                });

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "Prduction order qty", property: "productionorderqty" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },
                    { label: "Reject Codes", property: "RejectCodes" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "string" },
                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Manufacturing Time", property: "manufacturingtime", type: "string" }, // ADDED THIS LINE
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "FGProcess Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "FGProcessExporttoImport.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },

            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: ""
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Parse manufacturing date (common for all cases)
            //                 let formattedDate = null;
            //                 const rawDateValue = importRow["Manufacturing Date"];

            //                 if (rawDateValue) {
            //                     if (typeof rawDateValue === "number") {
            //                         // Excel serial date
            //                         const excelEpoch = new Date(1899, 11, 30);
            //                         const manufacturingDate = new Date(excelEpoch.getTime() + rawDateValue * 86400000);
            //                         if (!isNaN(manufacturingDate.getTime())) {
            //                             formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                         }
            //                     } else if (typeof rawDateValue === "string") {
            //                         // Try to parse as yyyy-MM-dd (from export format)
            //                         if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(rawDateValue)) {
            //                             const [year, month, day] = rawDateValue.split("-").map(Number);
            //                             const manufacturingDate = new Date(year, month - 1, day);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                         // Try to parse as dd-MM-yyyy (UI format)
            //                         else if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(rawDateValue)) {
            //                             const [day, month, year] = rawDateValue.split("-").map(Number);
            //                             const manufacturingDate = new Date(year, month - 1, day);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                         // Try general date parsing
            //                         else {
            //                             const manufacturingDate = new Date(rawDateValue);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                     }
            //                 }

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";
            //                 const hasManufacturingDate = formattedDate !== null;

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = formattedDate;
            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available
            //                     if (formattedDate) {
            //                         updatedRow.manufacturingdate = formattedDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },

            // used till 28 jan 
            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             // ADDED: dateNF option for better date handling
            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy" // Added this option
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // ADDED: Timezone-safe date parsing function (same as working code)
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes (preserving original logic)
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     updatedRow.RejectCodes = rejectCodes;
            //                 }

            //                 // FIXED: Parse manufacturing date using the proper function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         // FIXED: Store Date object instead of formatted string
            //                         updatedRow.manufacturingdate = manufacturingDate;

            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available - FIXED: Store Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },

            // manufacturong time field:
            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             // ADDED: dateNF option for better date handling
            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy" // Added this option
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // ADDED: Timezone-safe date parsing function
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // ADDED: Function to parse Excel time (simple string format) - SINGLE DEFINITION
            //             // ADDED: Function to parse Excel time for OData Time type (ISO format)
            //             function parseExcelTime(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 let hours = 0, minutes = 0, seconds = 0;

            //                 // CASE 1: String value (HH:mm:ss format)
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try HH:mm:ss format
            //                     if (/^(\d{1,2}):(\d{1,2}):(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split(":");
            //                         hours = parseInt(parts[0], 10);
            //                         minutes = parseInt(parts[1], 10);
            //                         seconds = parseInt(parts[2], 10);
            //                     }
            //                     // Try HH:mm format (without seconds)
            //                     else if (/^(\d{1,2}):(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split(":");
            //                         hours = parseInt(parts[0], 10);
            //                         minutes = parseInt(parts[1], 10);
            //                         seconds = 0;
            //                     }
            //                     // If it's a Date object stored as string
            //                     else {
            //                         const date = new Date(trimmed);
            //                         if (!isNaN(date.getTime())) {
            //                             hours = date.getHours();
            //                             minutes = date.getMinutes();
            //                             seconds = date.getSeconds();
            //                         } else {
            //                             return null;
            //                         }
            //                     }
            //                 }
            //                 // CASE 2: Number (Excel time fraction)
            //                 else if (typeof rawValue === 'number') {
            //                     // Excel time is stored as fraction of a day (1 = 24 hours)
            //                     const totalSeconds = Math.round(rawValue * 24 * 60 * 60);
            //                     hours = Math.floor(totalSeconds / 3600);
            //                     minutes = Math.floor((totalSeconds % 3600) / 60);
            //                     seconds = totalSeconds % 60;
            //                 }
            //                 // CASE 3: Already a Date object
            //                 else if (rawValue instanceof Date) {
            //                     hours = rawValue.getHours();
            //                     minutes = rawValue.getMinutes();
            //                     seconds = rawValue.getSeconds();
            //                 } else {
            //                     return null;
            //                 }

            //                 // Validate time components
            //                 if (hours >= 0 && hours <= 23 &&
            //                     minutes >= 0 && minutes <= 59 &&
            //                     seconds >= 0 && seconds <= 59) {

            //                     // Return in ISO 8601 duration format for Edm.Time
            //                     // return `PT${hours}H${minutes}M${seconds}S`;

            //                     const ms = ((hours * 60 * 60) + (minutes * 60) + seconds) * 1000;

            //                     // IMPORTANT: return object for sap.ui.model.odata.type.Time
            //                     // return { ms: ms };
            //                     return `PT${hours}H${minutes}M${seconds}S`;


            //                 }



            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes (preserving original logic)
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     updatedRow.RejectCodes = rejectCodes;
            //                 }

            //                 // FIXED: Parse manufacturing date using the proper function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // ADDED: Parse manufacturing time
            //                 const rawTimeValue = importRow["Manufacturing Time"];
            //                 const manufacturingTime = parseExcelTime(rawTimeValue);
            //                 const hasManufacturingTime = manufacturingTime !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     // ADDED: Also check for manufacturing time
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate || hasManufacturingTime) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, Manufacturing Date, or Manufacturing Time"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date and Manufacturing Time can be imported if GI/CNF Material Doc number exists
            //                     // ADDED: Also allow Manufacturing Time
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date and Time if user provided them
            //                     }

            //                     // Import Manufacturing Date and/or Time for these rows
            //                     let hasImportedSomething = false;

            //                     if (hasManufacturingDate) {
            //                         // FIXED: Store Date object instead of formatted string
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                         hasImportedSomething = true;
            //                     }

            //                     if (hasManufacturingTime) {
            //                         // ADDED: Store manufacturing time
            //                         updatedRow.manufacturingtime = manufacturingTime;
            //                         hasImportedSomething = true;
            //                     }

            //                     if (hasImportedSomething) {
            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         const importedFields = [];
            //                         if (hasManufacturingDate) importedFields.push("Manufacturing Date");
            //                         if (hasManufacturingTime) importedFields.push("Manufacturing Time");
            //                         aUpdatedRows.push(`${prodOrder} (${importedFields.join(" and ")})`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available - FIXED: Store Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     // ADDED: Add manufacturing time if available
            //                     if (hasManufacturingTime) {
            //                         updatedRow.manufacturingtime = manufacturingTime;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },


            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             // ADDED: dateNF option for better date handling
            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy" // Added this option
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // ADDED: Timezone-safe date parsing function
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // ADDED: Function to parse Excel time (simple string format) - SINGLE DEFINITION
            //             // ADDED: Function to parse Excel time for OData Time type (ISO format)
            //             // Update the parseExcelTime function to return milliseconds
            //             // function parseExcelTime(rawValue) {
            //             //     if (!rawValue && rawValue !== 0) {
            //             //         return null;
            //             //     }

            //             //     let hours = 0, minutes = 0, seconds = 0;

            //             //     // CASE 1: String value (HH:mm:ss format)
            //             //     if (typeof rawValue === 'string') {
            //             //         const trimmed = rawValue.trim();
            //             //         if (!trimmed) return null;

            //             //         // Try HH:mm:ss format
            //             //         if (/^(\d{1,2}):(\d{1,2}):(\d{1,2})$/.test(trimmed)) {
            //             //             const parts = trimmed.split(":");
            //             //             hours = parseInt(parts[0], 10);
            //             //             minutes = parseInt(parts[1], 10);
            //             //             seconds = parseInt(parts[2], 10);
            //             //         }
            //             //         // Try HH:mm format (without seconds)
            //             //         else if (/^(\d{1,2}):(\d{1,2})$/.test(trimmed)) {
            //             //             const parts = trimmed.split(":");
            //             //             hours = parseInt(parts[0], 10);
            //             //             minutes = parseInt(parts[1], 10);
            //             //             seconds = 0;
            //             //         }
            //             //         // If it's a Date object stored as string
            //             //         else {
            //             //             const date = new Date(trimmed);
            //             //             if (!isNaN(date.getTime())) {
            //             //                 hours = date.getHours();
            //             //                 minutes = date.getMinutes();
            //             //                 seconds = date.getSeconds();
            //             //             } else {
            //             //                 return null;
            //             //             }
            //             //         }
            //             //     }
            //             //     // CASE 2: Number (Excel time fraction)
            //             //     else if (typeof rawValue === 'number') {
            //             //         // Excel time is stored as fraction of a day (1 = 24 hours)
            //             //         const totalSeconds = Math.round(rawValue * 24 * 60 * 60);
            //             //         hours = Math.floor(totalSeconds / 3600);
            //             //         minutes = Math.floor((totalSeconds % 3600) / 60);
            //             //         seconds = totalSeconds % 60;
            //             //     }
            //             //     // CASE 3: Already a Date object
            //             //     else if (rawValue instanceof Date) {
            //             //         hours = rawValue.getHours();
            //             //         minutes = rawValue.getMinutes();
            //             //         seconds = rawValue.getSeconds();
            //             //     } else {
            //             //         return null;
            //             //     }

            //             //     // Validate time components
            //             //     if (hours >= 0 && hours <= 23 &&
            //             //         minutes >= 0 && minutes <= 59 &&
            //             //         seconds >= 0 && seconds <= 59) {

            //             //         // For sap.ui.model.odata.type.Time, create a string in "HH:mm:ss" format
            //             //         // The type will automatically parse this correctly
            //             //         const formattedTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            //             //         return formattedTime; // Returns "05:00:25" for example
            //             //     }

            //             //     return null;
            //             // }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes (preserving original logic)
            //                 // const rejectCodes = importRow["Reject Codes"];
            //                 // if (rejectCodes !== undefined && rejectCodes !== null) {
            //                 //     updatedRow.RejectCodes = rejectCodes;
            //                 // }

            //                 // *** ADDED: VALIDATION FOR REJECT CODES LENGTH (MAX 60 CHARACTERS) ***
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     const rejectCodesStr = rejectCodes.toString().trim();

            //                     // Check if reject codes exceed 60 characters
            //                     if (rejectCodesStr.length > 60) {
            //                         aInvalidRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
            //                         });
            //                         return; // Skip this row entirely
            //                     }

            //                     // Only update if not empty string after trim
            //                     if (rejectCodesStr !== "") {
            //                         updatedRow.RejectCodes = rejectCodesStr;
            //                     }
            //                 }

            //                 // FIXED: Parse manufacturing date using the proper function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // ADDED: Parse manufacturing time
            //                 const rawTimeValue = importRow["Manufacturing Time"];
            //                 // const manufacturingTime = parseExcelTime(rawTimeValue);
            //                 // const hasManufacturingTime = manufacturingTime !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     // ADDED: Also check for manufacturing time   || hasManufacturingTime
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, Manufacturing Date, or Manufacturing Time"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 // else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                 //     // Rule 1 & 2: Only Manufacturing Date and Manufacturing Time can be imported if GI/CNF Material Doc number exists
            //                 //     // ADDED: Also allow Manufacturing Time
            //                 //     if (hasConfirmedQty || hasScrapQty) {
            //                 //         aBlockedRows.push({
            //                 //             prodOrder: prodOrder,
            //                 //             plant: plant,
            //                 //             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                 //         });
            //                 //         // But we can still import Manufacturing Date and Time if user provided them
            //                 //     }

            //                 //     // Import Manufacturing Date and/or Time for these rows
            //                 //     let hasImportedSomething = false;

            //                 //     if (hasManufacturingDate) {
            //                 //         // FIXED: Store Date object instead of formatted string
            //                 //         updatedRow.manufacturingdate = manufacturingDate;
            //                 //         hasImportedSomething = true;
            //                 //     }

            //                 //     // if (hasManufacturingTime) {
            //                 //     //     // ADDED: Store manufacturing time
            //                 //     //     updatedRow.manufacturingtime = manufacturingTime;
            //                 //     //     hasImportedSomething = true;
            //                 //     // }

            //                 //     if (hasImportedSomething) {
            //                 //         // Keep existing confirmedqty and scrapqty values
            //                 //         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                 //         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                 //         updatedRow.__selected = true;
            //                 //         aSamples[matchedRowIndex] = updatedRow;
            //                 //         const importedFields = [];
            //                 //         if (hasManufacturingDate) importedFields.push("Manufacturing Date");
            //                 //         // if (hasManufacturingTime) importedFields.push("Manufacturing Time");
            //                 //         aUpdatedRows.push(`${prodOrder} (${importedFields.join(" and ")})`);
            //                 //         hasAnyUpdate = true;
            //                 //     }
            //                 // }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date, Manufacturing Time, and Reject Codes can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date, Time, and Reject Codes if user provided them
            //                     }

            //                     // Track what we're importing
            //                     let hasImportedSomething = false;
            //                     const importedFields = [];

            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                         hasImportedSomething = true;
            //                         importedFields.push("Manufacturing Date");
            //                     }

            //                     // if (hasManufacturingTime) {
            //                     //     updatedRow.manufacturingtime = manufacturingTime;
            //                     //     hasImportedSomething = true;
            //                     //     importedFields.push("Manufacturing Time");
            //                     // }

            //                     // Check if Reject Codes were provided (and they passed validation)
            //                     const hasRejectCodes = rejectCodes !== undefined && rejectCodes !== null && rejectCodes.toString().trim() !== "";
            //                     if (hasRejectCodes) {
            //                         // RejectCodes were already set in updatedRow during validation
            //                         hasImportedSomething = true;
            //                         importedFields.push("Reject Codes");
            //                     }

            //                     if (hasImportedSomething) {
            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (${importedFields.join(", ")})`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available - FIXED: Store Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     // ADDED: Add manufacturing time if available
            //                     // if (hasManufacturingTime) {
            //                     //     updatedRow.manufacturingtime = manufacturingTime;
            //                     // }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            // ========================================================================
            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy"
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy"
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = [];
            //             let hasAnyUpdate = false;

            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 if (rawValue instanceof Date) {
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 if (typeof rawValue === 'number') {
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 try {
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];
            //                 const lotCardNo = importRow["Lot card No"]; // New field for matching

            //                 let matchedRowIndex = -1;
            //                 let identifier = ""; // For logging purposes

            //                 // FIRST: Try to match by Production Order No (old format)
            //                 if (plant && prodOrder) {
            //                     matchedRowIndex = aSamples.findIndex(item =>
            //                         item.plant === plant && item.productionorderno === prodOrder
            //                     );
            //                     identifier = `${plant}/${prodOrder}`;
            //                 }

            //                 // SECOND: If no match, try to match by Lot Card No (new format)
            //                 if (matchedRowIndex === -1 && lotCardNo) {
            //                     matchedRowIndex = aSamples.findIndex(item =>
            //                         item.bipllotno === lotCardNo.toString()
            //                     );
            //                     identifier = `Lot Card: ${lotCardNo}`;

            //                     // If we found by lot card, also get the production order from the matched row for logging
            //                     if (matchedRowIndex !== -1) {
            //                         const matchedRow = aSamples[matchedRowIndex];
            //                         identifier = `${matchedRow.plant || 'N/A'}/${matchedRow.productionorderno || 'N/A'} (Lot: ${lotCardNo})`;
            //                     }
            //                 }

            //                 if (matchedRowIndex === -1) {
            //                     if (prodOrder && plant) {
            //                         aNotFound.push(`${plant}/${prodOrder}`);
            //                     } else if (lotCardNo) {
            //                         aNotFound.push(`Lot Card: ${lotCardNo}`);
            //                     } else {
            //                         aNotFound.push("No matching identifier found in Excel row");
            //                     }
            //                     return;
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // *** HANDLE REJECT CODES - Support both old and new column names ***
            //                 let rejectCodes = importRow["Reject Codes"]; // Old format
            //                 if (rejectCodes === undefined || rejectCodes === null || rejectCodes.toString().trim() === "") {
            //                     rejectCodes = importRow["Rejection_Codes"]; // New format
            //                 }

            //                 // Validate reject codes length (if present)
            //                 if (rejectCodes !== undefined && rejectCodes !== null && rejectCodes.toString().trim() !== "") {
            //                     const rejectCodesStr = rejectCodes.toString().trim();

            //                     if (rejectCodesStr.length > 60) {
            //                         aInvalidRows.push({
            //                             identifier: identifier,
            //                             reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
            //                         });
            //                         return;
            //                     }

            //                     updatedRow.RejectCodes = rejectCodesStr;
            //                 }

            //                 // Parse manufacturing date
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // Check what user is trying to import from the new template
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Handle business rules based on existing documents
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             identifier: identifier,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return;
            //                     }
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             identifier: identifier,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                     }

            //                     let hasImportedSomething = false;
            //                     const importedFields = [];

            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                         hasImportedSomething = true;
            //                         importedFields.push("Manufacturing Date");
            //                     }

            //                     const hasRejectCodes = rejectCodes !== undefined && rejectCodes !== null && rejectCodes.toString().trim() !== "";
            //                     if (hasRejectCodes) {
            //                         hasImportedSomething = true;
            //                         importedFields.push("Reject Codes");
            //                     }

            //                     if (hasImportedSomething) {
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";
            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${identifier} (${importedFields.join(", ")})`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) {
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 identifier: identifier,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             identifier: identifier,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             identifier: identifier,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 identifier: identifier,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 identifier: identifier,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 identifier: identifier,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     // Add reject codes if available (already handled above)

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(identifier);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 oTabModel.setProperty("/Samples", aSamples);
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);
            //                 oTabModel.refresh(true);
            //             }

            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Items:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.identifier}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.identifier}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.identifier}: ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.identifier}: ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },


            onImportExl: function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oSelectedModel = oView.getModel("Tab_SelectAll");

                function ensureXLSX(cb) {
                    if (window.XLSX) {
                        return cb();
                    }

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = new Uint8Array(e.target.result);

                        const workbook = XLSX.read(data, {
                            type: "array",
                            raw: true,
                            cellDates: false,
                            dateNF: "dd-mm-yyyy"
                        });

                        const sheetName = workbook.SheetNames[0];
                        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
                            raw: true,
                            defval: "",
                            dateNF: "dd-mm-yyyy"
                        });

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        const aSamples = oTabModel.getProperty("/Samples") || [];
                        const aUpdatedRows = [];
                        const aNotFound = [];
                        const aAdjustedRows = [];
                        const aInvalidRows = [];
                        const aBlockedRows = [];
                        let hasAnyUpdate = false;

                        function parseExcelDate(rawValue) {
                            if (!rawValue && rawValue !== 0) {
                                return null;
                            }

                            if (rawValue instanceof Date) {
                                const d = new Date(rawValue);
                                return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
                            }

                            if (typeof rawValue === 'number') {
                                const excelEpoch = new Date(1899, 11, 30);
                                const days = Math.floor(rawValue);
                                const ms = Math.round((rawValue - days) * 86400000);
                                const date = new Date(excelEpoch);
                                date.setDate(date.getDate() + days);
                                date.setTime(date.getTime() + ms);
                                const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                return !isNaN(localDate.getTime()) ? localDate : null;
                            }

                            if (typeof rawValue === 'string') {
                                const trimmed = rawValue.trim();
                                if (!trimmed) return null;

                                if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const year = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const day = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const month = parseInt(parts[0], 10) - 1;
                                    const day = parseInt(parts[1], 10);
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                const parsed = new Date(trimmed);
                                if (!isNaN(parsed.getTime())) {
                                    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
                                }
                            }

                            try {
                                const date = new Date(rawValue);
                                if (!isNaN(date.getTime())) {
                                    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                }
                            } catch (e) {
                                console.warn("Could not parse date:", rawValue, e);
                            }

                            return null;
                        }

                        // Process each row individually
                        jsonData.forEach((importRow) => {
                            const plant = importRow["Plant"];
                            const prodOrder = importRow["Production Order No"];
                            const lotCardNo = importRow["Lot card No"]; // New field for matching

                            let matchedRowIndex = -1;
                            let identifier = ""; // For logging purposes

                            // FIRST: Try to match by Production Order No (old format)
                            if (plant && prodOrder) {
                                matchedRowIndex = aSamples.findIndex(item =>
                                    item.plant === plant && item.productionorderno === prodOrder
                                );
                                identifier = `${plant}/${prodOrder}`;
                            }

                            // SECOND: If no match, try to match by Lot Card No (new format)
                            if (matchedRowIndex === -1 && lotCardNo) {
                                matchedRowIndex = aSamples.findIndex(item =>
                                    item.bipllotno === lotCardNo.toString()
                                );
                                identifier = `Lot Card: ${lotCardNo}`;

                                // If we found by lot card, also get the production order from the matched row for logging
                                if (matchedRowIndex !== -1) {
                                    const matchedRow = aSamples[matchedRowIndex];
                                    identifier = `${matchedRow.plant || 'N/A'}/${matchedRow.productionorderno || 'N/A'} (Lot: ${lotCardNo})`;
                                }
                            }

                            if (matchedRowIndex === -1) {
                                if (prodOrder && plant) {
                                    aNotFound.push(`${plant}/${prodOrder}`);
                                } else if (lotCardNo) {
                                    aNotFound.push(`Lot Card: ${lotCardNo}`);
                                } else {
                                    aNotFound.push("No matching identifier found in Excel row");
                                }
                                return;
                            }

                            const matchedRow = aSamples[matchedRowIndex];

                            // Create updated row starting with original values
                            const updatedRow = { ...matchedRow };

                            // Parse manufacturing date
                            const rawDateValue = importRow["Manufacturing Date"];
                            const manufacturingDate = parseExcelDate(rawDateValue);
                            const hasManufacturingDate = manufacturingDate !== null;

                            const rawPostingDate = importRow["Posting Date"];
                            const postingDate = parseExcelDate(rawPostingDate);
                            const hasPostingDate = postingDate !== null;

                            // Check what user is trying to import from the new template
                            const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
                                importRow["Confirmed Qty"] !== null &&
                                importRow["Confirmed Qty"].toString().trim() !== "";
                            const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
                                importRow["Scrap Qty"] !== null &&
                                importRow["Scrap Qty"].toString().trim() !== "";

                            // Handle business rules based on existing documents
                            if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
                                if (hasConfirmedQty || hasScrapQty || hasManufacturingDate || hasPostingDate) {
                                    aBlockedRows.push({
                                        identifier: identifier,
                                        reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
                                    });
                                    return;
                                }
                            }
                            else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
                                if (hasConfirmedQty || hasScrapQty || hasPostingDate) {
                                    aBlockedRows.push({
                                        identifier: identifier,
                                        reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty, Scrap Qty, or Posting Date"
                                    });
                                }

                                let hasImportedSomething = false;
                                const importedFields = [];

                                if (hasManufacturingDate) {
                                    updatedRow.manufacturingdate = manufacturingDate;
                                    hasImportedSomething = true;
                                    importedFields.push("Manufacturing Date");
                                }

                                // *** ADDED: SCRAP/REJECT CODE VALIDATION FOR GI/CNF ROWS ***
                                const rejectCodes = importRow["Reject Codes"]; // Old format
                                if (rejectCodes === undefined || rejectCodes === null || rejectCodes.toString().trim() === "") {
                                    rejectCodes = importRow["Rejection_Codes"]; // New format
                                }

                                const hasRejectCodes = rejectCodes !== undefined && rejectCodes !== null && rejectCodes.toString().trim() !== "";

                                // For GI/CNF rows, we need to validate scrap/reject code rules if user is trying to import reject codes
                                if (hasRejectCodes) {
                                    // Parse scrap quantity to check if it's entered
                                    const parseDecimal = (val) => {
                                        if (val === undefined || val === null || val === "") return null;
                                        const cleaned = String(val).replace(/[^\d.-]/g, '');
                                        const parsed = parseFloat(cleaned);
                                        return isNaN(parsed) ? null : parsed.toFixed(3);
                                    };

                                    const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);
                                    const userHasScrapQty = scrapQtyStr !== null;

                                    // Check if scrap quantity is "entered" (not null/undefined/empty/0/0.00/0.000)
                                    let scrapQtyEntered = false;
                                    if (userHasScrapQty) {
                                        const scrapQtyNum = parseFloat(scrapQtyStr);
                                        scrapQtyEntered = !isNaN(scrapQtyNum) && scrapQtyNum !== 0;
                                    }

                                    const rejectCodesStr = rejectCodes.toString().trim();
                                    const rejectCodeEntered = rejectCodesStr !== "";

                                    // Apply the validation rules
                                    if (!scrapQtyEntered && rejectCodeEntered) {
                                        aInvalidRows.push({
                                            identifier: identifier,
                                            reason: `Reject Code provided but Scrap Qty is not entered (must be zero or empty). Cannot import.`
                                        });
                                        return; // Skip this row entirely
                                    }

                                    if (scrapQtyEntered && !rejectCodeEntered) {
                                        aInvalidRows.push({
                                            identifier: identifier,
                                            reason: `Scrap Qty entered but Reject Code is not filled. Please enter Reject Code.`
                                        });
                                        return; // Skip this row entirely
                                    }

                                    // Check reject code length
                                    if (rejectCodesStr.length > 60) {
                                        aInvalidRows.push({
                                            identifier: identifier,
                                            reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
                                        });
                                        return;
                                    }

                                    // Only update reject codes if both are valid
                                    updatedRow.RejectCodes = rejectCodesStr;
                                    hasImportedSomething = true;
                                    importedFields.push("Reject Codes");
                                }

                                if (hasImportedSomething) {
                                    updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
                                    updatedRow.scrapqty = matchedRow.scrapqty || "0.000";
                                    updatedRow.__selected = true;
                                    aSamples[matchedRowIndex] = updatedRow;
                                    aUpdatedRows.push(`${identifier} (${importedFields.join(", ")})`);
                                    hasAnyUpdate = true;
                                }
                            }
                            // else {
                            //     // No restrictions - import all fields with calculations
                            //     const parseDecimal = (val) => {
                            //         if (val === undefined || val === null || val === "") return null;
                            //         const cleaned = String(val).replace(/[^\d.-]/g, '');
                            //         const parsed = parseFloat(cleaned);
                            //         return isNaN(parsed) ? null : parsed.toFixed(3);
                            //     };

                            //     // Get original production order quantity
                            //     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                            //     // Parse values from import
                            //     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                            //     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                            //     // *** ADDED: SCRAP/REJECT CODE VALIDATION ***
                            //     let rejectCodes = importRow["Reject Codes"]; // Old format
                            //     if (rejectCodes === undefined || rejectCodes === null || rejectCodes.toString().trim() === "") {
                            //         rejectCodes = importRow["Rejection_Codes"]; // New format
                            //     }

                            //     // Check if scrap quantity is "entered" (not null/undefined/empty/0/0.00/0.000)
                            //     let scrapQtyEntered = false;
                            //     if (scrapQtyStr !== null) {
                            //         const scrapQtyNum = parseFloat(scrapQtyStr);
                            //         scrapQtyEntered = !isNaN(scrapQtyNum) && scrapQtyNum !== 0;
                            //     }

                            //     const rejectCodesStr = rejectCodes !== undefined && rejectCodes !== null ?
                            //         rejectCodes.toString().trim() : "";
                            //     const rejectCodeEntered = rejectCodesStr !== "";

                            //     // Apply the validation rules
                            //     if (!scrapQtyEntered && rejectCodeEntered) {
                            //         aInvalidRows.push({
                            //             identifier: identifier,
                            //             reason: `Reject Code provided but Scrap Qty is not entered (must be zero or empty). Cannot import.`
                            //         });
                            //         return; // Skip this row entirely
                            //     }

                            //     if (scrapQtyEntered && !rejectCodeEntered) {
                            //         aInvalidRows.push({
                            //             identifier: identifier,
                            //             reason: `Scrap Qty entered but Reject Code is not filled. Please enter Reject Code.`
                            //         });
                            //         return; // Skip this row entirely
                            //     }

                            //     // Check reject code length if both are entered
                            //     if (scrapQtyEntered && rejectCodeEntered && rejectCodesStr.length > 60) {
                            //         aInvalidRows.push({
                            //             identifier: identifier,
                            //             reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
                            //         });
                            //         return;
                            //     }

                            //     // Convert to numbers for calculation
                            //     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
                            //     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

                            //     // Logic for Confirmed Qty and Scrap Qty calculation
                            //     let finalConfirmedQty = confirmedQtyStr;
                            //     let finalScrapQty = scrapQtyStr;

                            //     // Determine if user provided values
                            //     const userHasConfirmedQty = confirmedQtyNum !== null;
                            //     const userHasScrapQty = scrapQtyNum !== null;

                            //     if (userHasConfirmedQty && userHasScrapQty) {
                            //         const calculatedScrap = productionOrderQty - confirmedQtyNum;
                            //         const difference = Math.abs(scrapQtyNum - calculatedScrap);

                            //         if (difference > 0.001) {
                            //             finalScrapQty = calculatedScrap.toFixed(3);
                            //             aAdjustedRows.push({
                            //                 identifier: identifier,
                            //                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                            //             });
                            //         }
                            //     } else if (userHasConfirmedQty && !userHasScrapQty) {
                            //         const calculatedScrap = productionOrderQty - confirmedQtyNum;
                            //         finalScrapQty = calculatedScrap.toFixed(3);
                            //         aAdjustedRows.push({
                            //             identifier: identifier,
                            //             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                            //         });
                            //     } else if (!userHasConfirmedQty && userHasScrapQty) {
                            //         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
                            //         finalConfirmedQty = calculatedConfirmed.toFixed(3);
                            //         aAdjustedRows.push({
                            //             identifier: identifier,
                            //             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
                            //         });
                            //     } else {
                            //         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
                            //         finalScrapQty = matchedRow.scrapqty || "0.000";
                            //     }

                            //     // Validate that calculated values make sense
                            //     if (finalConfirmedQty) {
                            //         const confirmedNum = parseFloat(finalConfirmedQty);
                            //         if (confirmedNum < 0) {
                            //             aInvalidRows.push({
                            //                 identifier: identifier,
                            //                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
                            //             });
                            //             finalConfirmedQty = "0.000";
                            //         }

                            //         if (confirmedNum > productionOrderQty) {
                            //             aInvalidRows.push({
                            //                 identifier: identifier,
                            //                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
                            //             });
                            //             finalConfirmedQty = productionOrderQty.toFixed(3);
                            //             finalScrapQty = "0.000";
                            //         }
                            //     }

                            //     if (finalScrapQty) {
                            //         const scrapNum = parseFloat(finalScrapQty);
                            //         if (scrapNum < 0) {
                            //             aInvalidRows.push({
                            //                 identifier: identifier,
                            //                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
                            //             });
                            //             finalScrapQty = "0.000";
                            //         }
                            //     }

                            //     // Update the row with all fields
                            //     updatedRow.confirmedqty = finalConfirmedQty;
                            //     updatedRow.scrapqty = finalScrapQty;

                            //     // Add manufacturing date if available
                            //     if (hasManufacturingDate) {
                            //         updatedRow.manufacturingdate = manufacturingDate;
                            //     }

                            //     // Add posting date if available (NEW)
                            //     if (hasPostingDate) {
                            //         updatedRow.PostingDate = postingDate;
                            //     }

                            //     // Add reject codes if available and validation passed
                            //     if (scrapQtyEntered && rejectCodeEntered) {
                            //         updatedRow.RejectCodes = rejectCodesStr;
                            //     }

                            //     updatedRow.__selected = true;
                            //     aSamples[matchedRowIndex] = updatedRow;
                            //     aUpdatedRows.push(identifier);
                            //     hasAnyUpdate = true;
                            // }
                            else {
                                // No restrictions - import all fields with calculations
                                const parseDecimal = (val) => {
                                    if (val === undefined || val === null || val === "") return null;
                                    const cleaned = String(val).replace(/[^\d.-]/g, '');
                                    const parsed = parseFloat(cleaned);
                                    return isNaN(parsed) ? null : parsed.toFixed(3);
                                };

                                // Get original production order quantity
                                const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                                // Parse values from import
                                const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                                const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                                // -----------------------------------------------------------------
                                // NEW: If Confirmed Qty exceeds Production Order Qty, block the row
                                // -----------------------------------------------------------------
                                if (confirmedQtyStr !== null) {
                                    const confirmedNum = parseFloat(confirmedQtyStr);
                                    if (confirmedNum > productionOrderQty) {
                                        aBlockedRows.push({
                                            prodOrder: prodOrder,
                                            plant: plant,
                                            reason: `Confirmed Qty (${confirmedQtyStr}) exceeds Production Order Qty (${productionOrderQty}) – import skipped`
                                        });
                                        return; // skip this row entirely, no updates
                                    }
                                }

                                // *** SCRAP/REJECT CODE VALIDATION (unchanged) ***
                                let rejectCodes = importRow["Reject Codes"];
                                if (rejectCodes === undefined || rejectCodes === null || rejectCodes.toString().trim() === "") {
                                    rejectCodes = importRow["Rejection_Codes"];
                                }

                                let scrapQtyEntered = false;
                                if (scrapQtyStr !== null) {
                                    const scrapQtyNum = parseFloat(scrapQtyStr);
                                    scrapQtyEntered = !isNaN(scrapQtyNum) && scrapQtyNum !== 0;
                                }

                                const rejectCodesStr = rejectCodes !== undefined && rejectCodes !== null ?
                                    rejectCodes.toString().trim() : "";
                                const rejectCodeEntered = rejectCodesStr !== "";

                                if (!scrapQtyEntered && rejectCodeEntered) {
                                    aInvalidRows.push({
                                        identifier: prodOrder, // using prodOrder as identifier
                                        reason: `Reject Code provided but Scrap Qty is not entered (must be zero or empty). Cannot import.`
                                    });
                                    return;
                                }

                                if (scrapQtyEntered && !rejectCodeEntered) {
                                    aInvalidRows.push({
                                        identifier: prodOrder,
                                        reason: `Scrap Qty entered but Reject Code is not filled. Please enter Reject Code.`
                                    });
                                    return;
                                }

                                if (scrapQtyEntered && rejectCodeEntered && rejectCodesStr.length > 60) {
                                    aInvalidRows.push({
                                        identifier: prodOrder,
                                        reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
                                    });
                                    return;
                                }

                                // Convert to numbers for calculation
                                const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
                                const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

                                let finalConfirmedQty = confirmedQtyStr;
                                let finalScrapQty = scrapQtyStr;

                                const userHasConfirmedQty = confirmedQtyNum !== null;
                                const userHasScrapQty = scrapQtyNum !== null;

                                if (userHasConfirmedQty && userHasScrapQty) {
                                    const calculatedScrap = productionOrderQty - confirmedQtyNum;
                                    const difference = Math.abs(scrapQtyNum - calculatedScrap);

                                    if (difference > 0.001) {
                                        finalScrapQty = calculatedScrap.toFixed(3);
                                        aAdjustedRows.push({
                                            identifier: prodOrder,
                                            reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                                        });
                                    }
                                } else if (userHasConfirmedQty && !userHasScrapQty) {
                                    const calculatedScrap = productionOrderQty - confirmedQtyNum;
                                    finalScrapQty = calculatedScrap.toFixed(3);
                                    aAdjustedRows.push({
                                        identifier: prodOrder,
                                        reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                                    });
                                } else if (!userHasConfirmedQty && userHasScrapQty) {
                                    const calculatedConfirmed = productionOrderQty - scrapQtyNum;
                                    finalConfirmedQty = calculatedConfirmed.toFixed(3);
                                    aAdjustedRows.push({
                                        identifier: prodOrder,
                                        reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
                                    });
                                } else {
                                    finalConfirmedQty = matchedRow.confirmedqty || "0.000";
                                    finalScrapQty = matchedRow.scrapqty || "0.000";
                                }

                                // Validate that calculated values make sense (negative checks only)
                                if (finalConfirmedQty) {
                                    const confirmedNum = parseFloat(finalConfirmedQty);
                                    if (confirmedNum < 0) {
                                        aInvalidRows.push({
                                            identifier: prodOrder,
                                            reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
                                        });
                                        finalConfirmedQty = "0.000";
                                    }
                                    // NOTE: The check for confirmedNum > productionOrderQty has been REMOVED
                                    // because the earlier block now prevents such rows from reaching this point.
                                }

                                if (finalScrapQty) {
                                    const scrapNum = parseFloat(finalScrapQty);
                                    if (scrapNum < 0) {
                                        aInvalidRows.push({
                                            identifier: prodOrder,
                                            reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
                                        });
                                        finalScrapQty = "0.000";
                                    }
                                }

                                // Update the row with all fields
                                updatedRow.confirmedqty = finalConfirmedQty;
                                updatedRow.scrapqty = finalScrapQty;

                                if (hasManufacturingDate) {
                                    updatedRow.manufacturingdate = manufacturingDate;
                                }

                                if (hasPostingDate) {
                                    updatedRow.PostingDate = postingDate;
                                }

                                if (scrapQtyEntered && rejectCodeEntered) {
                                    updatedRow.RejectCodes = rejectCodesStr;
                                }

                                updatedRow.__selected = true;
                                aSamples[matchedRowIndex] = updatedRow;
                                aUpdatedRows.push(prodOrder);
                                hasAnyUpdate = true;
                            }
                        });

                        if (hasAnyUpdate) {
                            oTabModel.setProperty("/Samples", aSamples);
                            const allSelected = aSamples.every(row => row.__selected);
                            oSelectedModel.setProperty("/Samples/selectall", allSelected);
                            oTabModel.refresh(true);
                        }

                        let message = "";

                        if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
                            if (aUpdatedRows.length > 0) {
                                message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
                                message += `Updated Items:\n`;
                                aUpdatedRows.forEach(row => {
                                    message += `  • ${row}\n`;
                                });
                                message += "\nCheckboxes have been selected for updated rows.\n\n";

                                if (aAdjustedRows.length > 0) {
                                    message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
                                    aAdjustedRows.forEach(adj => {
                                        message += `- ${adj.identifier}: ${adj.reason}\n`;
                                    });
                                    message += "\n";
                                }

                                if (aInvalidRows.length > 0) {
                                    message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
                                    aInvalidRows.forEach(inv => {
                                        message += `- ${inv.identifier}: ${inv.reason}\n`;
                                    });
                                    message += "\n";
                                }
                            }

                            if (aBlockedRows.length > 0) {
                                message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
                                aBlockedRows.forEach(blocked => {
                                    message += `- ${blocked.identifier}: ${blocked.reason}\n`;
                                });
                                message += "\n";
                            }

                            if (aNotFound.length > 0) {
                                message += `Not found in table: ${aNotFound.length} row(s)\n`;
                                message += aNotFound.join(", ");
                            }

                            const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
                            const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

                            sap.m.MessageBox.show(message, {
                                title: title,
                                icon: icon,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                        } else {
                            if (aNotFound.length > 0) {
                                message = `No matching rows found for:\n${aNotFound.join("\n")}`;
                            } else if (aBlockedRows.length > 0) {
                                message = "No data was imported due to business rule violations:\n\n";
                                aBlockedRows.forEach(blocked => {
                                    message += `• ${blocked.identifier}: ${blocked.reason}\n`;
                                });
                            } else {
                                message = "No data was imported.";
                            }

                            sap.m.MessageBox.show(message, {
                                title: "Import Results",
                                icon: sap.m.MessageBox.Icon.WARNING,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                        }
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsArrayBuffer(file);
                }

                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";

                fileInput.onchange = function (e) {
                    const file = e.target.files[0];
                    if (!file) return;

                    const fileName = file.name.toLowerCase();
                    if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
                        sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
                        document.body.removeChild(fileInput);
                        return;
                    }

                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                };

                document.body.appendChild(fileInput);
                fileInput.click();
            },

            // ------------------------------------------------------------------------------------------------------------------------------------------
            // For Goods issue Confirmation - Start
            // ------------------------------------------------------------------------------------------------------------------------------------------




            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     let aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     // Arrays to track results
            //     const aSuccessRows = [];
            //     const aFailedRows = [];
            //     const aSkippedRows = [];

            //     // Run validations first
            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     if (aWithGI.length > 0) {
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
            //         const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";

            //         // Track skipped rows
            //         aWithGI.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Goods Issue already exists"
            //             });
            //         });

            //         // Remove already GI rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));

            //         if (aSelectedRows.length === 0) {
            //             this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             return;
            //         }
            //     }

            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         // Track unreleased rows
            //         aUnreleased.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Not released"
            //             });
            //         });

            //         // Remove unreleased rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
            //     }

            //     const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
            //     if (aNotUpdated.length > 0) {
            //         // Track not updated rows
            //         aNotUpdated.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Please enter the QTY & update the status"
            //             });
            //         });

            //         // Remove not updated rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
            //     }

            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const confirmedVal = row.confirmedqty;
            //         const balanceVal = row.scrapqty;
            //         const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
            //         const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
            //         const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
            //         return confirmedInvalid || bothZeroOrNull;
            //     });

            //     if (aMissingQty.length > 0) {
            //         // Track missing quantity rows
            //         aMissingQty.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Invalid quantity values"
            //             });
            //         });

            //         // Remove missing quantity rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
            //     }

            //     const aQtyMismatch = aSelectedRows.filter(row => {
            //         const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
            //         const iBalanceQty = parseFloat(row.scrapqty) || 0;
            //         const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
            //         const iTotalQty = iConfirmedQty + iBalanceQty;
            //         const dTolerance = 0.0001;
            //         return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
            //     });

            //     if (aQtyMismatch.length > 0) {
            //         // Track quantity mismatch rows
            //         aQtyMismatch.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
            //             });
            //         });

            //         // Remove quantity mismatch rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
            //     }

            //     // Check if any rows remain to process
            //     if (aSelectedRows.length === 0) {
            //         // Show summary if all rows were skipped during validation
            //         this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //         return;
            //     }

            //     // 🔹 Sort the remaining rows in the same sequence as the table
            //     // First by productionordstartdate (ascending), then by slabno (ascending)
            //     aSelectedRows.sort((a, b) => {
            //         // Sort by productionordstartdate (ascending)
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);

            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;

            //         // If dates are equal, sort by slabno (ascending)
            //         const slabA = a.slabno || "";
            //         const slabB = b.slabno || "";
            //         if (slabA < slabB) return -1;
            //         if (slabA > slabB) return 1;

            //         return 0;
            //     });

            //     // ✅ Confirm before processing
            //     sap.m.MessageBox.confirm("Do you want to post the selected data?", {
            //         actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //         emphasizedAction: sap.m.MessageBox.Action.YES,
            //         onClose: async function (sAction) {
            //             if (sAction === sap.m.MessageBox.Action.YES) {
            //                 // Show loading indicator ONCE at the beginning
            //                 sap.ui.core.BusyIndicator.show(0);

            //                 // Process each row individually
            //                 for (let i = 0; i < aSelectedRows.length; i++) {
            //                     const oRow = aSelectedRows[i];

            //                     try {
            //                         const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //                         const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //                         const oData = await new Promise((resolve, reject) => {
            //                             oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                                 filters: [oFilter1, oFilter2],
            //                                 success: function (OData) {
            //                                     resolve(OData);
            //                                 },
            //                                 error: function (error) {
            //                                     reject(error);
            //                                 }
            //                             });
            //                         });

            //                         console.log("Response:", oData);

            //                         if (oData.results.length === 0) {
            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: `YBP4 data not found for order ${oRow.productionorderno}`
            //                             });
            //                             continue; // Skip to next row
            //                         }

            //                         // Activity - Confirmation qty + Scrap qty * Operation qty/base qty
            //                         const oResultData = oData.results[0];
            //                         // const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;
            //                         // const calcQty = (qty, total, scrap, ref) =>
            //                         //     (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);



            //                         const calcQty = (qty, total, scrap, ref) => {
            //                             const result =
            //                                 (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

            //                             // round to 3 decimals and return as NUMBER
            //                             return Number(result.toFixed(3));
            //                         };

            //                         const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

            //                         const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

            //                         const postResult = await that.ToConfirmIssueAPIPost(
            //                             ManufacturingOrderOperation,
            //                             opconfirmedworkquantity1,
            //                             opconfirmedworkquantity2,
            //                             opconfirmedworkquantity3,
            //                             opconfirmedworkquantity4,
            //                             opconfirmedworkquantity5,
            //                             opconfirmedworkquantity6,
            //                             oRow
            //                         );

            //                         const matDoc = postResult.materialdocument;

            //                         if (!matDoc) {
            //                             let ErrorMessage = "Some error occurred while posting.";
            //                             try {
            //                                 const kk = JSON.parse(postResult.errorresponse);
            //                                 ErrorMessage = kk.error.message.value;
            //                             } catch (e) { }

            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: ErrorMessage
            //                             });
            //                         } else {
            //                             // Update row with material document
            //                             oRow.gicnfmaterialdocnumber = postResult.materialdocument;
            //                             oRow.gicnfmaterialdocyear = postResult.matdocyear;
            //                             oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
            //                             oRow.gicnfconfirmationcount = postResult.confirmationcount;

            //                             // Update internal table
            //                             await that.ToUpdateIntTab(oRow, matDoc, postResult);

            //                             aSuccessRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 materialDocument: matDoc
            //                             });
            //                         }

            //                     } catch (error) {
            //                         console.error("Error in confirmation for order:", oRow.productionorderno, error);
            //                         aFailedRows.push({
            //                             productionOrder: oRow.productionorderno,
            //                             error: error.message || "Unknown error"
            //                         });
            //                     }
            //                 }

            //                 // Refresh table once at the end
            //                 oTabModel.refresh();

            //                 // Hide loading indicator only after all processing is complete
            //                 sap.ui.core.BusyIndicator.hide();

            //                 // Show summary
            //                 that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             }
            //         }
            //     });
            // },


            checkUserHasGoodsIssueRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },


            OnAPIPost_Confirmation: async function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- 1. Local GI check (already has material document in UI) ---
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                if (aWithGI.length > 0) {
                    aWithGI.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Goods Issue already exists (local)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));
                }

                // --- 2. Release status check ---
                const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
                if (aUnreleased.length > 0) {
                    aUnreleased.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not released"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
                }

                // --- 3. Update status check (must be "GT") ---
                const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
                if (aNotUpdated.length > 0) {
                    aNotUpdated.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not updated (status not GT)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
                }

                // --- 4. Quantity validation ---
                const aMissingQty = aSelectedRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });

                if (aMissingQty.length > 0) {
                    aMissingQty.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Invalid quantity values"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
                }

                // --- 5. Posting Date validation (mandatory) ---
                const aMissingPostingDate = aSelectedRows.filter(row => {
                    const postingDate = row.PostingDate;
                    // Check if null, undefined, empty string, or invalid Date object
                    if (!postingDate) return true;
                    // If it's a date object, check if valid
                    const dateObj = new Date(postingDate);
                    return isNaN(dateObj.getTime());
                });

                if (aMissingPostingDate.length > 0) {
                    aMissingPostingDate.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Missing or invalid posting date"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingPostingDate.includes(row));
                }

                const aQtyMismatch = aSelectedRows.filter(row => {
                    const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
                    const iBalanceQty = parseFloat(row.scrapqty) || 0;
                    const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
                    const iTotalQty = iConfirmedQty + iBalanceQty;
                    const dTolerance = 0.0001;
                    return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
                });

                if (aQtyMismatch.length > 0) {
                    // Track quantity mismatch rows
                    aQtyMismatch.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
                        });
                    });

                    // Remove quantity mismatch rows from processing
                    aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
                }


                // --- If no rows left after validations, show summary and return ---
                if (aSelectedRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- ADDED / MODIFIED: Fetch existing GI data from ZSB_MATDOC_FETCH ---
                const oFetchModel = oView.getModel("ZSB_MATDOC_FETCH");
                if (!oFetchModel) {
                    sap.m.MessageToast.show("Missing model for fetching existing goods issue data.");
                    return;
                }

                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];           // rows that need to be posted

                // ⏳ BUSY: Show busy indicator before async fetch
                sap.ui.core.BusyIndicator.show(0);

                // Fetch existing data for all remaining rows in parallel
                const fetchExistingPromises = aSelectedRows.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            row.productionorderno
                        );

                        const oSorter = new sap.ui.model.Sorter(
                            "MfgOrderConfirmation",
                            true   // descending = highest first
                        );

                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_MATDOC_FETCH", {
                                filters: [oFilter],
                                sorters: [oSorter],
                                top: 1,
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log("result fetched:", oData);

                        if (oData.results && oData.results.length > 0) {
                            // Already sorted by backend and limited to top 1,
                            // but keep explicit sort for safety
                            const sortedResults = [...oData.results].sort((a, b) =>
                                b.MfgOrderConfirmation - a.MfgOrderConfirmation
                            );
                            const highest = sortedResults[0];
                            console.log(`✅ Fetched for order ${row.productionorderno}: MfgOrderConfirmation = ${highest.MfgOrderConfirmation}, MaterialDocument = ${highest.MaterialDocument}`);
                            return { row, existing: highest };
                        } else {
                            // No existing data → treat as not existing
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GI for order ${row.productionorderno}:`, err);
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Populate arrays
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a material document in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;
                    const confirmationGroup = existing.MfgOrderConfirmationGroup;
                    const confirmationCount = existing.MfgOrderConfirmation;

                    // Update local row
                    row.gicnfmaterialdocnumber = matDoc;
                    row.gicnfmaterialdocyear = matDocYear;
                    row.gicnfconfirmationgroup = confirmationGroup;
                    row.gicnfconfirmationcount = confirmationCount;

                    // Update internal table (use the existing ToUpdateIntTab method)
                    try {
                        await that.ToUpdateIntTab(
                            row,
                            matDoc,
                            {
                                materialdocument: matDoc,
                                matdocyear: matDocYear,
                                confirmationgroup: confirmationGroup,
                                confirmationcount: confirmationCount
                            }
                        );
                        console.log(`✅ Updated internal table for existing order ${row.productionorderno}`);
                        aSuccessRows.push({
                            productionOrder: row.productionorderno,
                            materialDocument: matDoc,
                            materialDocumentYear: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update internal table for existing order ${row.productionorderno}:`, updateErr);
                        aFailedRows.push({
                            productionOrder: row.productionorderno,
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // ⏳ BUSY: Hide busy indicator before showing confirmation dialog
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- Sort rows to post ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods issue for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        // ⏳ BUSY: Show busy indicator again before posting
                        sap.ui.core.BusyIndicator.show(0);

                        // --- Process each row that needs to be posted ---
                        for (let i = 0; i < aRowsToPost.length; i++) {
                            const oRow = aRowsToPost[i];

                            try {
                                // Fetch YBP4 data (as in original)
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (oData.results.length === 0) {
                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: `YBP4 data not found for order ${oRow.productionorderno}`
                                    });
                                    continue;
                                }

                                const oResultData = oData.results[0];
                                const calcQty = (qty, total, scrap, ref) => {
                                    const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                                    return Number(result.toFixed(3));
                                };

                                const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

                                const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

                                const postResult = await that.ToConfirmIssueAPIPost(
                                    ManufacturingOrderOperation,
                                    opconfirmedworkquantity1,
                                    opconfirmedworkquantity2,
                                    opconfirmedworkquantity3,
                                    opconfirmedworkquantity4,
                                    opconfirmedworkquantity5,
                                    opconfirmedworkquantity6,
                                    oRow
                                );

                                const matDoc = postResult.materialdocument;
                                if (!matDoc) {
                                    let ErrorMessage = "Some error occurred while posting.";
                                    try {
                                        const kk = JSON.parse(postResult.errorresponse);
                                        ErrorMessage = kk.error.message.value;
                                    } catch (e) { }

                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: ErrorMessage
                                    });
                                } else {
                                    // Update row with material document
                                    oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                                    oRow.gicnfmaterialdocyear = postResult.matdocyear;
                                    oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                                    oRow.gicnfconfirmationcount = postResult.confirmationcount;

                                    // Update internal table
                                    await that.ToUpdateIntTab(oRow, matDoc, postResult);

                                    aSuccessRows.push({
                                        productionOrder: oRow.productionorderno,
                                        materialDocument: matDoc
                                    });
                                }

                            } catch (error) {
                                console.error("Error in confirmation for order:", oRow.productionorderno, error);
                                aFailedRows.push({
                                    productionOrder: oRow.productionorderno,
                                    error: error.message || "Unknown error"
                                });
                            }
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    }
                });
            },

            // Show confirmation summary
            showConfirmationSummary: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

            ToConfirmIssueAPIPost: function (
                ManufacturingOrderOperation,
                opconfirmedworkquantity1,
                opconfirmedworkquantity2,
                opconfirmedworkquantity3,
                opconfirmedworkquantity4,
                opconfirmedworkquantity5,
                opconfirmedworkquantity6,
                oSelectedRow
            ) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oEntry = {
                        orderid: oSelectedRow.productionorderno,
                        orderoperation: ManufacturingOrderOperation,
                        ordersuboperation: "0000",
                        confirmationyieldquantity: String(oSelectedRow.confirmedqty),
                        opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                        opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                        opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                        opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                        opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                        opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                        materialdocument: "",
                        matdocyear: "",
                        sequence: "0000",
                        confirmationgroup: "",
                        confirmationcount: "",
                        finalconfirmationtype: "X",
                        PostingDate: oSelectedRow.PostingDate ? new Date(oSelectedRow.PostingDate.toLocaleDateString('en-CA')) : null,
                        scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3),

                    };

                    console.log("payload being posted: ", oEntry);

                    const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1_FG");

                    oModelGet.create("/ZC_FT_PRODCONF1_JOINT", oEntry, {
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (error) {
                            reject(error);
                        }
                    });
                });
            },

            ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

                    var oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        RejectCodes: String(HeaderModel.RejectCodes),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                        PostingDate: HeaderModel.PostingDate ? new Date(HeaderModel.PostingDate.toLocaleDateString('en-CA')) : null,
                    };

                    oModelGet.update("/ZC_FG_PROCESS_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData, oResponse) {
                            console.log("Goods Issue No Updated Successfully...");
                            resolve(oData);
                        },
                        error: function (error) {
                            console.log("Error updating internal table:", error);
                            reject(error);
                        }
                    });
                });
            },


















            // =====================================================================================

            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqnoGI: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessageGoodsIssue: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Main Goods Issue function using header-item service (batch)
            // ============================================================
            onGoodsIssuePressBatch: async function () {
                const that = this;
                const oView = this.getView();
                const oGIModel = oView.getModel("ZSB_GICONF_HEAD_ITEM");   // new service
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Arrays for final summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- VALIDATIONS (same as original) ---
                // 1. Already has Goods Issue
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                aWithGI.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Issue already exists"
                    });
                });
                let aProcessRows = aSelectedRows.filter(row => !aWithGI.includes(row));

                // 2. Not released
                const aUnreleased = aProcessRows.filter(row => row.releasestatus !== "RELEASED");
                aUnreleased.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not released"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aUnreleased.includes(row));

                // 3. Update status not "GT"
                const aNotUpdated = aProcessRows.filter(row => row.updatestatusgistatus !== "GT");
                aNotUpdated.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not updated (status not GT)"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aNotUpdated.includes(row));

                // 4. Missing quantity
                const aMissingQty = aProcessRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });
                aMissingQty.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Invalid quantity values"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aMissingQty.includes(row));

                // 5. Quantity mismatch (confirmed + scrap ≠ production order qty)
                const aQtyMismatch = aProcessRows.filter(row => {
                    const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
                    const iBalanceQty = parseFloat(row.scrapqty) || 0;
                    const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
                    const iTotalQty = iConfirmedQty + iBalanceQty;
                    const dTolerance = 0.0001;
                    return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
                });
                aQtyMismatch.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aQtyMismatch.includes(row));

                // If no rows left to process, show summary and return
                if (aProcessRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // Sort rows by start date and lot number
                aProcessRows.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // Confirm with user
                sap.m.MessageBox.confirm("Do you want to post the selected data?", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) return;

                        sap.ui.core.BusyIndicator.show(0);

                        // --- FETCH YBP4 DATA FOR ALL PROCESS ROWS (parallel) ---
                        const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // model for reading YBP4 data
                        const fetchPromises = aProcessRows.map(async (row) => {
                            try {
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (!oData.results || oData.results.length === 0) {
                                    return { row, success: false, error: `YBP4 data not found for order ${row.productionorderno}` };
                                }

                                return { row, success: true, data: oData.results[0] };
                            } catch (err) {
                                return { row, success: false, error: err.message || "Error fetching YBP4 data" };
                            }
                        });

                        const fetchResults = await Promise.all(fetchPromises);

                        // Separate successful fetches from failed ones
                        const validFetchResults = fetchResults.filter(r => r.success);
                        const failedFetchResults = fetchResults.filter(r => !r.success);

                        // Add fetch failures to aFailedRows
                        failedFetchResults.forEach(f => {
                            aFailedRows.push({
                                productionOrder: f.row.productionorderno,
                                error: f.error
                            });
                        });

                        // If no valid rows after fetches, show summary
                        if (validFetchResults.length === 0) {
                            sap.ui.core.BusyIndicator.hide();
                            this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                            return;
                        }

                        // Build payload items array
                        const aItems = [];
                        const calcQty = (qty, total, scrap, ref) => {
                            const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                            return Number(result.toFixed(3));
                        };

                        validFetchResults.forEach(({ row, data }) => {
                            const opconfirmedworkquantity1 = calcQty(data.WorkCenterStandardWorkQty1, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity2 = calcQty(data.WorkCenterStandardWorkQty2, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity3 = calcQty(data.WorkCenterStandardWorkQty3, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity4 = calcQty(data.WorkCenterStandardWorkQty4, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity5 = calcQty(data.WorkCenterStandardWorkQty5, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity6 = calcQty(data.WorkCenterStandardWorkQty6, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);

                            aItems.push({
                                Id: row.sap_uuid,                                 // unique item identifier
                                Orderid: row.productionorderno,
                                Orderoperation: data.ManufacturingOrderOperation,
                                Ordersuboperation: "0000",
                                Confirmationyieldquantity: String(row.confirmedqty),
                                Opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                                Opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                                Opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                                Opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                                Opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                                Opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                                Scrapqty: parseFloat(row.scrapqty).toFixed(3),
                                Sequence: "0000",
                                Finalconfirmationtype: "X",
                                // Uom: optional, can be omitted or set from somewhere
                            });
                        });

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGI();

                        // Build final payload
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: { results: aItems }
                        };

                        console.log(`🚀 Posting Goods Issue with ${aItems.length} items in one payload`, oPayload);
                        // debugger

                        try {
                            // Create header with all items
                            const oResponse = await new Promise((resolve, reject) => {
                                oGIModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ Goods Issue batch created`, oResponse);

                            // Validate response structure
                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aProcessRows.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                // Check if backend returned an error for this item
                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aFailedRows.push({
                                        productionOrder: originalRow.productionorderno,
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                // Get material document details from item response
                                const matDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;
                                const confirmationGroup = itemResp.Confirmationgroup;
                                const confirmationCount = itemResp.Confirmationcount;

                                // Update local row
                                originalRow.gicnfmaterialdocnumber = matDoc;
                                originalRow.gicnfmaterialdocyear = matDocYear;
                                originalRow.gicnfconfirmationgroup = confirmationGroup;
                                originalRow.gicnfconfirmationcount = confirmationCount;

                                // Update FGProcess plan table
                                try {
                                    await this.ToUpdateIntTabGoodsIssue(
                                        originalRow,
                                        matDoc,
                                        {
                                            materialdocument: matDoc,
                                            matdocyear: matDocYear,
                                            confirmationgroup: confirmationGroup,
                                            confirmationcount: confirmationCount
                                        }
                                    );
                                    console.log(`✅ Updated FGProcess plan for row ${originalRow.sap_uuid}`);
                                } catch (updateErr) {
                                    console.error(`⚠️ FGProcess plan update failed for row ${originalRow.sap_uuid}`, updateErr);
                                    // Still consider the GI successful; log warning but don't mark as failed
                                }

                                aSuccessRows.push({
                                    productionOrder: originalRow.productionorderno,
                                    materialDocument: matDoc
                                });
                            }

                            // Update FinalStatus with last successful material document (if any)
                            if (aSuccessRows.length > 0) {
                                const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                                this.FinalStatus = new sap.ui.model.json.JSONModel({
                                    MSGSTRIP: {
                                        visible: true,
                                        text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                        type: 'Success'
                                    }
                                });
                                this.getView().setModel(this.FinalStatus, "FinalStatus");
                            }

                        } catch (oError) {
                            // Entire request failed
                            console.error(`❌ Goods Issue batch failed:`, oError);
                            const sErrorMessage = this._extractErrorMessageGoodsIssue(oError);

                            // Mark all rows that were supposed to be processed as failed
                            aProcessRows.forEach(row => {
                                aFailedRows.push({
                                    productionOrder: row.productionorderno,
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.setProperty("/Samples", aRows); // ensure selection cleared? Not cleared yet; we can clear later
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                    }.bind(this) // bind to keep 'this' context
                });
            },

            // ============================================================
            // Update internal table (FGProcess plan) with Goods Issue details
            // ============================================================
            ToUpdateIntTabGoodsIssue: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

                    const oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        RejectCodes: String(HeaderModel.RejectCodes),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                    };

                    console.log(`📝 Updating FGProcess plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_FG_PROCESS_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            reject(error);
                        }
                    });
                });
            },

            // Show confirmation summary
            showConfirmationSummarybatch: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

            // ======================================goods issue===================================
            // ======================================goods issue===================================
            // ======================================goods issue===================================
            // onGoodsReceiptPress: async function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
            //     const oTabModel = oView.getModel("TabModel");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let errors = [];

            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }

            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }

            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness)
            //     let aValidationErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];
            //         // if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- ✅ PROCESSING (all validations passed)
            //     sap.ui.core.BusyIndicator.show(0);

            //     // Arrays to collect results
            //     const aSuccessResults = [];
            //     const aErrorResults = [];

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sProdOrder = row.productionorderno || `Row ${i + 1}`;

            //         const oPayload = {
            //             material: row.materialcode,
            //             plant: row.plant,
            //             storagelocation: row.storagelocation,
            //             goodsmovementtype: "101",
            //             manufacturingorder: row.productionorderno,
            //             // manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             goodsmovementrefdoctype: "F",
            //             quantityinentryunit: String(row.confirmedqty),
            //             postingdate: new Date(),
            //             goodsmovementcode: "02"
            //         };
            //         console.log("payload:", oPayload);

            //         try {
            //             const oData = await new Promise((resolve, reject) => {
            //                 oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
            //                     success: function (oData) {
            //                         console.log("result:", oData);
            //                         // Check if material document exists AND if errorresponse is present
            //                         if (!oData.materialdocument && oData.errorresponse) {
            //                             // This is an error returned in success response
            //                             let errorMessage = "Unknown error";
            //                             try {
            //                                 const errorObj = JSON.parse(oData.errorresponse);
            //                                 errorMessage = errorObj.error?.message?.value || errorObj.error?.message || oData.errorresponse;
            //                             } catch (e) {
            //                                 errorMessage = oData.errorresponse;
            //                             }
            //                             reject(new Error(errorMessage));
            //                         } else if (!oData.materialdocument) {
            //                             // No material document and no error response
            //                             reject(new Error("No material document returned"));
            //                         } else {
            //                             resolve(oData);
            //                         }
            //                     },
            //                     error: reject
            //                 });
            //             });

            //             console.log("result:", oData);

            //             // If we get here, we have a valid material document
            //             row.grmaterialdocnumber = oData.materialdocument;
            //             row.grmaterialdocyear = oData.matdocyear;

            //             const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
            //             row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

            //             await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

            //             // Add to success list
            //             aSuccessResults.push({
            //                 productionOrder: sProdOrder,
            //                 materialDocument: oData.materialdocument,
            //                 year: oData.matdocyear
            //             });

            //         } catch (oError) {
            //             console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

            //             // Extract error message
            //             let sErrorMessage = oError.message || "Unknown error";

            //             // For OData errors
            //             if (oError.responseText) {
            //                 try {
            //                     const oErrorResponse = JSON.parse(oError.responseText);
            //                     if (oErrorResponse.error && oErrorResponse.error.message) {
            //                         sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
            //                     }
            //                 } catch (e) {
            //                     sErrorMessage = oError.responseText;
            //                 }
            //             }

            //             // Add to error list
            //             aErrorResults.push({
            //                 productionOrder: sProdOrder,
            //                 error: sErrorMessage
            //             });
            //         }
            //     }

            //     // Update the model with processed rows
            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();

            //     // Show summary message
            //     this.showGRSummary(aSuccessResults, aErrorResults);
            // },

            // // Also update the showGRSummary to be consistent with our other summaries:
            // showGRSummary: function (aSuccessResults, aErrorResults) {
            //     const sTotal = aSuccessResults.length + aErrorResults.length;

            //     if (sTotal === 0) {
            //         return;
            //     }

            //     let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
            //     let bHasSuccess = aSuccessResults.length > 0;
            //     let bHasFailed = aErrorResults.length > 0;

            //     if (bHasSuccess) {
            //         sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
            //         aSuccessResults.forEach(result => {
            //             sMessage += `   - Production Order ${result.productionOrder}`;
            //             if (result.materialDocument) {
            //                 sMessage += ` (Material Doc: ${result.materialDocument}/${result.year})`;
            //             }
            //             sMessage += `\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     if (bHasFailed) {
            //         sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
            //         aErrorResults.forEach(result => {
            //             sMessage += `   - Production Order ${result.productionOrder}: ${result.error}\n`;
            //         });
            //     }

            //     // Always show MessageBox for all cases (consistent with other summaries)
            //     setTimeout(() => {
            //         if (bHasFailed) {
            //             // Show detailed error dialog with summary
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.ERROR,
            //                     title: "Goods Receipt Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     details: aErrorResults.map(f =>
            //                         `Production Order: ${f.productionOrder}\nError: ${f.error}`
            //                     ).join('\n\n')
            //                 }
            //             );
            //         } else {
            //             // Show success dialog
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.SUCCESS,
            //                     title: "Goods Receipt Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK]
            //                 }
            //             );
            //         }
            //     }, 100);
            // },


            // ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
            //     return new Promise((resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();
            //         var that = this;
            //         var oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

            //         var oEntry = {
            //             grmaterialdocnumber: resp.materialdocument,
            //             grmaterialdocyear: resp.matdocyear,
            //             // manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             // batchweight: HeaderModel.batchweight,
            //             operator: HeaderModel.operator,
            //             inspector: HeaderModel.inspector,
            //             // batchweight: String(parseInt(HeaderModel.confirmedqty)),
            //             expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

            //         };

            //         oModelGet.update("/ZC_FG_PROCESS_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            //             success: function (oData) {
            //                 console.log("✅ Internal Table Updated Successfully.");
            //                 sap.ui.core.BusyIndicator.hide();
            //                 resolve(oData);
            //             },
            //             error: function (error) {
            //                 console.error("❌ Internal Table Update Failed");
            //                 sap.ui.core.BusyIndicator.hide();
            //                 sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
            //                 reject(error);
            //             }
            //         });
            //     });
            // },

            // ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
            //     var that = this;
            //     return new Promise((resolve, reject) => {
            //         var oView = that.getView();

            //         // Safely get the backend model
            //         var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
            //         if (!oModel) {
            //             sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
            //             return;
            //         }
            //         var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
            //         // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
            //         var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
            //         // Call the read function
            //         oModel.read("/ZC_MAT_DOC_ITEM", {
            //             filters: [oFilterMatDoco, oFilterMatDocyear],
            //             success: function (oData) {

            //                 resolve(oData.results)

            //             },
            //             error: function (oError) {
            //                 oView.setBusy(false);
            //                 sap.m.MessageBox.error("Failed to retrieve Calendering Plan data.");
            //                 console.error("OData read error:", oError);
            //                 reject(oError)
            //             }
            //         });
            //     });
            // },






            // Open fragment for single row processing
            ToGoodsIssueComponentsFragOpen: async function (oEvent) {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");

                // Get the clicked row data
                const oSource = oEvent.getSource();
                const oRowContext = oSource.getBindingContext("TabModel");

                if (oRowContext) {
                    const oRowData = oRowContext.getObject();

                    // Validate single row before opening fragment
                    const validationResult = await that.validateSingleRowForGoodsIssue(oRowData);
                    if (!validationResult.valid) {
                        sap.m.MessageBox.error(validationResult.message);
                        return;
                    }

                    // Store current row data for processing
                    that.currentGoodsIssueRow = oRowData;
                    that.currentRowIndex = oTabModel.getProperty("/Samples").indexOf(oRowData);

                    // debugger

                    // Fetch YBP4 data for calculation
                    sap.ui.core.BusyIndicator.show();

                    try {
                        const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                        const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRowData.productionorderno);
                        const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                        const oData = await new Promise((resolve, reject) => {
                            oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                filters: [oFilter1, oFilter2],
                                success: function (OData) {
                                    resolve(OData);
                                },
                                error: function (error) {
                                    reject(error);
                                }
                            });
                        });

                        if (oData.results.length === 0) {
                            sap.m.MessageBox.error(`YBP4 data not found for order ${oRowData.productionorderno}`);
                            sap.ui.core.BusyIndicator.hide();
                            return;
                        }

                        // Store YBP4 data for calculations
                        that.ybp4Data = oData.results[0];
                        console.log("ybp4 data fetched:", that.ybp4Data)
                        // debugger

                        // Calculate work quantities
                        const calcQty = (qty, total, scrap, ref) => {
                            const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                            return Number(result.toFixed(3));
                        };

                        that.calculatedQuantities = {
                            opconfirmedworkquantity1: calcQty(that.ybp4Data.WorkCenterStandardWorkQty1, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            opconfirmedworkquantity2: calcQty(that.ybp4Data.WorkCenterStandardWorkQty2, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            opconfirmedworkquantity3: calcQty(that.ybp4Data.WorkCenterStandardWorkQty3, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            opconfirmedworkquantity4: calcQty(that.ybp4Data.WorkCenterStandardWorkQty4, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            opconfirmedworkquantity5: calcQty(that.ybp4Data.WorkCenterStandardWorkQty5, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            opconfirmedworkquantity6: calcQty(that.ybp4Data.WorkCenterStandardWorkQty6, oRowData.confirmedqty, oRowData.scrapqty, that.ybp4Data.OperationReferenceQuantity),
                            ManufacturingOrderOperation: that.ybp4Data.ManufacturingOrderOperation,
                            // opworkquantityunit1: that.ybp4Data.

                        };

                        // Fetch component data for fragment
                        const componentData = await that.fetchComponentData(oRowData.productionorderno);

                        if (componentData.length === 0) {
                            sap.m.MessageBox.warning(
                                `No component data found for Production Order: ${oRowData.productionorderno}.`,
                                {
                                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                                    emphasizedAction: sap.m.MessageBox.Action.YES,
                                    onClose: async function (sAction) {
                                        if (sAction === sap.m.MessageBox.Action.YES) {
                                            // Optional: Add code here if you want to process without fragment
                                            return;
                                        }
                                        sap.ui.core.BusyIndicator.hide();
                                    }
                                }
                            );
                            sap.ui.core.BusyIndicator.hide();
                            return;
                        }

                        // Create model for fragment - FIXED: property name is "components"
                        that.compFragmentModel = new sap.ui.model.json.JSONModel({
                            components: componentData
                        });

                        that.getView().setModel(that.compFragmentModel, "CompFragmentModel");

                        // Create and open fragment
                        if (!that.goodsIssueFragment) {
                            that.goodsIssueFragment = sap.ui.xmlfragment(
                                "goodsIssueFragment",
                                "bando.view.CommonFragments.ActualScreens.ConfirmationFragment",
                                that
                            );
                            that.getView().addDependent(that.goodsIssueFragment);
                        }

                        that.goodsIssueFragment.open();

                    } catch (error) {
                        console.error("Error in fragment preparation:", error);
                        sap.m.MessageBox.error("Error preparing Goods Issue: " + error.message);
                    } finally {
                        sap.ui.core.BusyIndicator.hide();
                    }
                }
            },

            // Validate single row for goods issue
            validateSingleRowForGoodsIssue: function (oRowData) {
                return new Promise((resolve) => {
                    let validation = { valid: true, message: "" };

                    // Check if Goods Issue already exists
                    if (oRowData.gicnfmaterialdocnumber && oRowData.gicnfmaterialdocnumber.trim() !== "") {
                        validation.valid = false;
                        validation.message = `Goods Issue already exists for Production Order: ${oRowData.productionorderno}`;
                        resolve(validation);
                        return;
                    }

                    // Check release status
                    if (oRowData.releasestatus !== "RELEASED") {
                        validation.valid = false;
                        validation.message = `Production Order ${oRowData.productionorderno} is not released`;
                        resolve(validation);
                        return;
                    }

                    // Check update status
                    if (oRowData.updatestatusgistatus !== "GT") {
                        validation.valid = false;
                        validation.message = `Please enter the QTY & update the status for  ${oRowData.productionorderno}`;
                        resolve(validation);
                        return;
                    }

                    // Check quantity values
                    const confirmedVal = oRowData.confirmedqty;
                    const balanceVal = oRowData.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined ||
                        isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);

                    if (confirmedInvalid || bothZeroOrNull) {
                        validation.valid = false;
                        validation.message = `Invalid quantity values for order ${oRowData.productionorderno}`;
                        resolve(validation);
                        return;
                    }

                    // Check quantity mismatch
                    const iConfirmedQty = parseFloat(oRowData.confirmedqty) || 0;
                    const iBalanceQty = parseFloat(oRowData.scrapqty) || 0;
                    const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;
                    const iTotalQty = iConfirmedQty + iBalanceQty;
                    const dTolerance = 0.0001;

                    if (Math.abs(iTotalQty - iProductionOrderQty) > dTolerance) {
                        validation.valid = false;
                        validation.message = `Quantity mismatch for order ${oRowData.productionorderno}\n` +
                            `Confirmed (${iConfirmedQty}) + Scrap (${iBalanceQty}) ≠ Production Order (${iProductionOrderQty})`;
                        resolve(validation);
                        return;
                    }

                    resolve(validation);
                });
            },
            // fetch the components
            fetchComponentData: function (productionOrderNo) {
                return new Promise((resolve, reject) => {
                    const oModel = this.getView().getModel("ZSB_GI_COMP_POST");

                    console.log("oModel:", oModel);

                    if (!oModel) {
                        console.error("Model not found!");
                        resolve([]);
                        return;
                    }

                    // Prepare the filter - use EXACT property name from metadata
                    // DO NOT add leading zeros - backend will do alpha conversion!
                    const sProductionOrder = productionOrderNo; // Remove "000" prefix
                    const oFilter = new sap.ui.model.Filter(
                        "ProductionOrderNo",  // Exact case from metadata
                        sap.ui.model.FilterOperator.EQ,
                        sProductionOrder
                    );

                    console.log("Filter for ProductionOrderNo:", sProductionOrder);

                    try {
                        oModel.read("/ZC_GI_CONF_FRAG", {
                            filters: [oFilter],
                            success: function (oData) {
                                console.log("component data:", oData)
                                // sap.ui.core.BusyIndicator.hide(); // Hide busy indicator on success
                                // resolve(oData);
                                resolve(oData.results || []);

                            },
                            error: function (error) {
                                console.log("Error:", error);
                                sap.ui.core.BusyIndicator.hide(); // Hide busy indicator on error
                                reject(error);
                            }
                        });

                    } catch (error) {
                        resolve([])
                    }
                });
            },
            // posting of the goods issue components , main api code
            // onFragmentConfirm: async function () {
            //     const that = this;

            //     try {
            //         sap.ui.core.BusyIndicator.show();

            //         // Check if models exist
            //         if (!that.compFragmentModel) {
            //             throw new Error("Component model not found");
            //         }

            //         if (!that.currentGoodsIssueRow) {
            //             throw new Error("Current row data not found");
            //         }

            //         const rowData = that.currentGoodsIssueRow;

            //         // FIXED: Access the correct property from the model
            //         const compData = that.compFragmentModel.getProperty("/components") || [];

            //         // Check if we have component data
            //         if (!compData || compData.length === 0) {
            //             throw new Error("No component data available");
            //         }

            //         const calculatedQuantities = that.calculatedQuantities;

            //         // Prepare component items for posting
            //         // const toitem = compData.map(comp => ({
            //         //     manufacturingorder: rowData.productionorderno,
            //         //     sap_uid: rowData.sap_uid,
            //         //     ordertype: rowData.ordertype || "",
            //         //     material: comp.material,
            //         //     plant: comp.plant,
            //         //     batch: comp.batch,
            //         //     quantityinentryunit: parseFloat(comp.quantity || 0).toFixed(3),
            //         //     entryunit: comp.base_unit,
            //         //     storagelocation: comp.storage_location,
            //         //     goodsmovementtype: comp.movement_type,
            //         //     // BOM_ITEM: comp.BOM_ITEM || "",
            //         //     // BOM_ITEM_Number: comp.BOM_ITEM_Number || ""
            //         // }));


            //         const toitem = compData.map(comp => ({
            //             manufacturingorder: rowData.productionorderno,
            //             // reservationitem: comp.reservationitem,
            //             reservationitem: String(comp.reservationitem).padStart(4, '0'),

            //             // Remove sap_uid for items or use a dummy - the backend might auto-generate
            //             // sap_uid: "", // Let backend generate this
            //             ordertype: rowData.ordertype || "",
            //             material: comp.material,
            //             plant: comp.plant,
            //             batch: comp.batch,
            //             quantityinentryunit: parseFloat(comp.quantity || 0).toFixed(3),
            //             entryunit: comp.base_unit,
            //             storagelocation: comp.storage_location,
            //             goodsmovementtype: comp.movement_type,
            //         }));
            //         // debugger

            //         console.log("Component items to post:", toitem);

            //         // Prepare header data for posting
            //         const oEntry = {
            //             manufacturingorder: rowData.productionorderno,
            //             // sap_uid: "",
            //             orderoperation: String(calculatedQuantities.ManufacturingOrderOperation),
            //             ordersuboperation: "0000",
            //             confirmationyieldquantity: parseFloat(rowData.confirmedqty || 0).toFixed(3),
            //             confirmationscrapquantity: parseFloat(rowData.scrapqty || 0).toFixed(3),
            //             opconfirmedworkquantity1: parseFloat(calculatedQuantities.opconfirmedworkquantity1 || 0).toFixed(3),
            //             opconfirmedworkquantity2: parseFloat(calculatedQuantities.opconfirmedworkquantity2 || 0).toFixed(3),
            //             opconfirmedworkquantity3: parseFloat(calculatedQuantities.opconfirmedworkquantity3 || 0).toFixed(3),
            //             opconfirmedworkquantity4: parseFloat(calculatedQuantities.opconfirmedworkquantity4 || 0).toFixed(3),
            //             opconfirmedworkquantity5: parseFloat(calculatedQuantities.opconfirmedworkquantity5 || 0).toFixed(3),
            //             opconfirmedworkquantity6: parseFloat(calculatedQuantities.opconfirmedworkquantity6 || 0).toFixed(3),
            //             // opworkquantityunit1: that.ybp4Data.WorkCenterStandardWorkQtyUnit1,
            //             // opworkquantityunit2: that.ybp4Data.WorkCenterStandardWorkQtyUnit2,
            //             // opworkquantityunit3: that.ybp4Data.WorkCenterStandardWorkQtyUnit3,
            //             // opworkquantityunit4: that.ybp4Data.WorkCenterStandardWorkQtyUnit4,
            //             // opworkquantityunit5: that.ybp4Data.WorkCenterStandardWorkQtyUnit5,
            //             // opworkquantityunit6: that.ybp4Data.WorkCenterStandardWorkQtyUnit6,
            //             isfinalconfirmation: "X",
            //             toitem: toitem
            //         };

            //         console.log("Posting Goods Issue with entry:", oEntry);

            //         // Post using new OData service
            //         const postResult = await that.postGoodsIssueWithComponents(oEntry);

            //         // Check for errors
            //         if (postResult.errorresponse && postResult.errorresponse.trim() !== "") {
            //             let errorMessage = "Error occurred during posting";
            //             try {
            //                 const errorObj = JSON.parse(postResult.errorresponse);
            //                 if (errorObj.error && errorObj.error.message) {
            //                     errorMessage = errorObj.error.message.value;
            //                 }
            //             } catch (e) {
            //                 errorMessage = postResult.errorresponse;
            //             }
            //             throw new Error(errorMessage);
            //         }

            //         const matDoc = postResult.materialdocument;

            //         if (!matDoc) {
            //             throw new Error("No material document returned from posting");
            //         }

            //         // Update row with material document
            //         rowData.gicnfmaterialdocnumber = postResult.materialdocument;
            //         rowData.gicnfmaterialdocyear = postResult.matdocyear;
            //         rowData.gicnfconfirmationgroup = postResult.confirmationgroup;
            //         rowData.gicnfconfirmationcount = postResult.confirmationcount;

            //         // Update internal table (ZSB_FG_PROCESS_PLAN)
            //         await that.updateInternalTable(rowData, postResult);

            //         // Refresh the table model
            //         const oTabModel = that.getView().getModel("TabModel");
            //         oTabModel.refresh();

            //         // Show success message
            //         sap.m.MessageBox.success(
            //             `Goods Issue posted successfully!\n\n` +
            //             `Material Document: ${postResult.materialdocument}\n` +
            //             `Confirmation Count: ${postResult.confirmationcount}\n` +
            //             `Confirmation Group: ${postResult.confirmationgroup}`,
            //             {
            //                 title: "Success",
            //                 actions: [sap.m.MessageBox.Action.OK]
            //             }
            //         );

            //         // Update FinalStatus model
            //         that.FinalStatus = new sap.ui.model.json.JSONModel({
            //             MSGSTRIP: {
            //                 visible: true,
            //                 text: `Material Document No - Goods Issue : ${postResult.materialdocument}`,
            //                 type: 'Success'
            //             }
            //         });
            //         that.getView().setModel(that.FinalStatus, "FinalStatus");

            //         // Close fragment
            //         if (that.goodsIssueFragment) {
            //             that.goodsIssueFragment.close();
            //             that.goodsIssueFragment.destroy();
            //             that.goodsIssueFragment = null;
            //         }

            //     } catch (error) {
            //         console.error("Error in fragment confirmation:", error);
            //         sap.m.MessageBox.error(
            //             `Failed to post Goods Issue:\n${error.message}`,
            //             {
            //                 title: "Error",
            //                 actions: [sap.m.MessageBox.Action.OK]
            //             }
            //         );
            //     } finally {
            //         sap.ui.core.BusyIndicator.hide();
            //     }
            // },
            onFragmentConfirm: async function () {
                const that = this;

                try {
                    sap.ui.core.BusyIndicator.show();

                    // Check if models exist
                    if (!that.compFragmentModel) {
                        throw new Error("Component model not found");
                    }

                    if (!that.currentGoodsIssueRow) {
                        throw new Error("Current row data not found");
                    }

                    const rowData = that.currentGoodsIssueRow;

                    // FIXED: Access the correct property from the model
                    const compData = that.compFragmentModel.getProperty("/components") || [];

                    // Check if we have component data
                    if (!compData || compData.length === 0) {
                        throw new Error("No component data available");
                    }

                    const calculatedQuantities = that.calculatedQuantities;

                    // Filter out components where quantityinentryunit is "0.000"
                    const validCompData = compData.filter(comp => {
                        const quantity = parseFloat(comp.quantity || 0);
                        return quantity !== 0; // Filter out zero quantities
                    });

                    // Check if any valid components remain after filtering
                    if (validCompData.length === 0) {
                        throw new Error("No valid components to post (all quantities are zero)");
                    }

                    const toitem = validCompData.map(comp => ({
                        manufacturingorder: rowData.productionorderno,
                        reservationitem: String(comp.reservationitem).padStart(4, '0'),
                        ordertype: rowData.ordertype || "",
                        material: comp.material,
                        plant: comp.plant,
                        batch: comp.batch,
                        quantityinentryunit: parseFloat(comp.quantity || 0).toFixed(3),
                        entryunit: comp.base_unit,
                        storagelocation: comp.storage_location,
                        goodsmovementtype: comp.movement_type,
                    }));

                    console.log("Component items to post:", toitem);
                    console.log(`Filtered out ${compData.length - validCompData.length} items with zero quantity`);

                    // Prepare header data for posting
                    const oEntry = {
                        manufacturingorder: rowData.productionorderno,
                        orderoperation: String(calculatedQuantities.ManufacturingOrderOperation),
                        ordersuboperation: "0000",
                        confirmationyieldquantity: parseFloat(rowData.confirmedqty || 0).toFixed(3),
                        confirmationscrapquantity: parseFloat(rowData.scrapqty || 0).toFixed(3),
                        opconfirmedworkquantity1: parseFloat(calculatedQuantities.opconfirmedworkquantity1 || 0).toFixed(3),
                        opconfirmedworkquantity2: parseFloat(calculatedQuantities.opconfirmedworkquantity2 || 0).toFixed(3),
                        opconfirmedworkquantity3: parseFloat(calculatedQuantities.opconfirmedworkquantity3 || 0).toFixed(3),
                        opconfirmedworkquantity4: parseFloat(calculatedQuantities.opconfirmedworkquantity4 || 0).toFixed(3),
                        opconfirmedworkquantity5: parseFloat(calculatedQuantities.opconfirmedworkquantity5 || 0).toFixed(3),
                        opconfirmedworkquantity6: parseFloat(calculatedQuantities.opconfirmedworkquantity6 || 0).toFixed(3),
                        isfinalconfirmation: "X",
                        toitem: toitem
                    };

                    console.log("Posting Goods Issue with entry:", oEntry);

                    // Post using new OData service
                    const postResult = await that.postGoodsIssueWithComponents(oEntry);

                    // Check for errors
                    if (postResult.errorresponse && postResult.errorresponse.trim() !== "") {
                        let errorMessage = "Error occurred during posting";
                        try {
                            const errorObj = JSON.parse(postResult.errorresponse);
                            if (errorObj.error && errorObj.error.message) {
                                errorMessage = errorObj.error.message.value;
                            }
                        } catch (e) {
                            errorMessage = postResult.errorresponse;
                        }
                        throw new Error(errorMessage);
                    }

                    const matDoc = postResult.materialdocument;

                    if (!matDoc) {
                        throw new Error("No material document returned from posting");
                    }

                    // Update row with material document
                    rowData.gicnfmaterialdocnumber = postResult.materialdocument;
                    rowData.gicnfmaterialdocyear = postResult.matdocyear;
                    rowData.gicnfconfirmationgroup = postResult.confirmationgroup;
                    rowData.gicnfconfirmationcount = postResult.confirmationcount;

                    // Update internal table (ZSB_CALEN_PLAN)
                    await that.updateInternalTable(rowData, postResult);

                    // Refresh the table model
                    const oTabModel = that.getView().getModel("TabModel");
                    oTabModel.refresh();

                    // Show success message
                    sap.m.MessageBox.success(
                        `Goods Issue posted successfully!\n\n` +
                        `Material Document: ${postResult.materialdocument}\n` +
                        `Confirmation Count: ${postResult.confirmationcount}\n` +
                        `Confirmation Group: ${postResult.confirmationgroup}`,
                        {
                            title: "Success",
                            actions: [sap.m.MessageBox.Action.OK]
                        }
                    );

                    // Update FinalStatus model
                    that.FinalStatus = new sap.ui.model.json.JSONModel({
                        MSGSTRIP: {
                            visible: true,
                            text: `Material Document No - Goods Issue : ${postResult.materialdocument}`,
                            type: 'Success'
                        }
                    });
                    that.getView().setModel(that.FinalStatus, "FinalStatus");

                    // Close fragment
                    if (that.goodsIssueFragment) {
                        that.goodsIssueFragment.close();
                        that.goodsIssueFragment.destroy();
                        that.goodsIssueFragment = null;
                    }

                } catch (error) {
                    console.error("Error in fragment confirmation:", error);
                    sap.m.MessageBox.error(
                        `Failed to post Goods Issue:\n${error.message}`,
                        {
                            title: "Error",
                            actions: [sap.m.MessageBox.Action.OK]
                        }
                    );
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },

            // Post Goods Issue with components using new OData service
            postGoodsIssueWithComponents: function (oEntry) {
                return new Promise((resolve, reject) => {
                    const oModelGet = this.getView().getModel("ZSB_GI_PRCONF_COMP_POSTING");

                    if (oModelGet) {
                        console.log("Model exists:", oModelGet);
                    } else {
                        console.error("Model ZSB_GI_PRCONF_COMP_POSTING NOT found");
                    }

                    oModelGet.create("/ZC_HEAD_GI_PRCONF_COMP_POSTING", oEntry, {
                        // oModelGet.create("/ZC_GI_PRCONF_COMP_POST_ITEM", oEntry, {
                        success: function (oData) {
                            console.log("OData SUCCESS:", oData);
                            resolve(oData);
                        },
                        error: function (error) {
                            console.log("OData ERROR:", error);
                            reject(error);
                        }
                    });
                });
            },

            // Update internal table (ZSB_FG_PROCESS_PLAN)
            updateInternalTable: function (rowData, resp) {
                return new Promise((resolve, reject) => {
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

                    var oEntry = {
                        confirmedqty: String(rowData.confirmedqty),
                        scrapqty: String(rowData.scrapqty),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                    };

                    oModelGet.update("/ZC_FG_PROCESS_PLAN('" + rowData.sap_uuid + "')", oEntry, {
                        success: function (oData, oResponse) {
                            console.log("Goods Issue No Updated Successfully in internal table");
                            resolve(oData);
                        },
                        error: function (error) {
                            console.log("Error updating internal table:", error);
                            reject(error);
                        }
                    });
                });
            },
            // fragment cancel button
            onFragmentCancel: function () {
                const that = this;

                if (that.goodsIssueFragment) {
                    that.goodsIssueFragment.close();
                    that.goodsIssueFragment.destroy();
                    that.goodsIssueFragment = null;
                }

                sap.m.MessageToast.show("Goods Issue cancelled");
            },
























            onGoodsReceiptPress: async function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_GR_NO_BATCH");
                if (oModel) {
                    console.log("Model found:", oModel);
                } else {
                    console.error("Model NOT found: ZSB_GR_NO_BATCH");
                }
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                let aBlockerErrors = [];

                aSelectedRows.forEach((row) => {
                    let errors = [];

                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }

                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists");
                    }

                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness)
                let aValidationErrors = [];

                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
                    // if (!row.manufacturingtime) missingFields.push("Manufacturing Time");

                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- ✅ PROCESSING (all validations passed)
                sap.ui.core.BusyIndicator.show(0);

                // Arrays to collect results
                const aSuccessResults = [];
                const aErrorResults = [];

                // 🔹 Sort the remaining rows in the same sequence as the table
                // First by productionordstartdate (ascending), then by slabno (ascending)
                aSelectedRows.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by slabno (ascending)
                    const slabA = a.slabno || "";
                    const slabB = b.slabno || "";
                    if (slabA < slabB) return -1;
                    if (slabA > slabB) return 1;

                    return 0;
                });

                for (let i = 0; i < aSelectedRows.length; i++) {
                    const row = aSelectedRows[i];
                    const sProdOrder = row.productionorderno || `Row ${i + 1}`;

                    const oPayload = {
                        material: row.materialcode,
                        plant: row.plant,
                        storagelocation: row.storagelocation,
                        goodsmovementtype: "101",
                        manufacturingorder: row.productionorderno,
                        // manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementrefdoctype: "F",
                        quantityinentryunit: String(row.confirmedqty),
                        // postingdate: new Date(),
                        postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementcode: "02"
                    };
                    console.log("payload:", oPayload);

                    try {
                        const oData = await new Promise((resolve, reject) => {
                            oModel.create("/ZC_GR_NO_BATCH", oPayload, {
                                success: function (oData) {
                                    console.log("result:", oData);
                                    // Check if material document exists AND if errorresponse is present
                                    if (!oData.materialdocument && oData.errorresponse) {
                                        // This is an error returned in success response
                                        let errorMessage = "Unknown error";
                                        try {
                                            const errorObj = JSON.parse(oData.errorresponse);
                                            errorMessage = errorObj.error?.message?.value || errorObj.error?.message || oData.errorresponse;
                                        } catch (e) {
                                            errorMessage = oData.errorresponse;
                                        }
                                        reject(new Error(errorMessage));
                                    } else if (!oData.materialdocument) {
                                        // No material document and no error response
                                        reject(new Error("No material document returned"));
                                    } else {
                                        resolve(oData);
                                    }
                                },
                                error: reject
                            });
                        });

                        console.log("result:", oData);

                        // If we get here, we have a valid material document
                        row.grmaterialdocnumber = oData.materialdocument;
                        row.grmaterialdocyear = oData.matdocyear;

                        const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
                        row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

                        await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

                        // Add to success list
                        aSuccessResults.push({
                            productionOrder: sProdOrder,
                            materialDocument: oData.materialdocument,
                            year: oData.matdocyear
                        });

                    } catch (oError) {
                        console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

                        // Extract error message
                        let sErrorMessage = oError.message || "Unknown error";

                        // For OData errors
                        if (oError.responseText) {
                            try {
                                const oErrorResponse = JSON.parse(oError.responseText);
                                if (oErrorResponse.error && oErrorResponse.error.message) {
                                    sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                                }
                            } catch (e) {
                                sErrorMessage = oError.responseText;
                            }
                        }

                        // Add to error list
                        aErrorResults.push({
                            productionOrder: sProdOrder,
                            error: sErrorMessage
                        });
                    }
                }

                // Update the model with processed rows
                oTabModel.setProperty("/Samples", aRows);
                oTabModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showGRSummary(aSuccessResults, aErrorResults);
            },

            // Also update the showGRSummary to be consistent with our other summaries:
            showGRSummary: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                let bHasSuccess = aSuccessResults.length > 0;
                let bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}`;
                        if (result.materialDocument) {
                            sMessage += ` (Material Doc: ${result.materialDocument}/${result.year})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}: ${result.error}\n`;
                    });
                }

                // Always show MessageBox for all cases (consistent with other summaries)
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aErrorResults.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },


            ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");
                    function timeToEdmTime(vTime) {
                        if (!vTime) {
                            return null;
                        }

                        // Case 1: already Edm.Time object
                        if (typeof vTime === "object" && vTime.ms !== undefined) {
                            const totalSeconds = Math.floor(vTime.ms / 1000);
                            const h = Math.floor(totalSeconds / 3600);
                            const m = Math.floor((totalSeconds % 3600) / 60);
                            const s = totalSeconds % 60;

                            return `PT${h}H${m}M${s}S`;
                        }

                        // Case 2: string "HH:mm:ss"
                        if (typeof vTime === "string") {
                            const [h, m, s] = vTime.split(":").map(Number);
                            return `PT${h}H${m}M${s}S`;
                        }

                        return null;
                    }

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        RejectCodes: String(HeaderModel.RejectCodes),
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // manufacturingtime: item.manufacturingtime
                        //     ? timeToEdmTime(item.manufacturingtime)
                        //     : null,

                        // batchweight: HeaderModel.batchweight,
                        // operator: HeaderModel.operator,
                        // inspector: HeaderModel.inspector,
                        // batchweight: String(parseInt(HeaderModel.confirmedqty)),
                        // expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

                    };
                    // debugger

                    oModelGet.update("/ZC_FG_PROCESS_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully.");
                            sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed");
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    // Safely get the backend model
                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    // Call the read function
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {

                            resolve(oData.results)

                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve WeightRoller Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },

















            generateUUIDreqnoGR: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },


            // ============================================================
            // UPDATED: Main Goods Receipt function using header-item service
            // ============================================================
            // onGoodsReceiptPressBatch: async function () {
            //     const oView = this.getView();
            //     const oGRModel = oView.getModel("ZSD_GR_NO_BATCH_HEAD_ITEM");         // new service
            //     const oTabModel = oView.getModel("TabModel");
            //     const oFGProcessBeltModel = oView.getModel("ZSB_FG_PROCESS_PLAN");     // for updates
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let errors = [];
            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }
            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }
            //         if (!row.productionorderno || row.productionorderno.trim() === "") {
            //             errors.push("Missing Production Order");
            //         }
            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness) ---
            //     // let aValidationErrors = [];
            //     // aSelectedRows.forEach((row, index) => {
            //     //     let missingFields = [];
            //     //     if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //     //     if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //     //     if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //     //     if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //     //     if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //     //     if (missingFields.length > 0) {
            //     //         aValidationErrors.push(`Row ${index + 1}: ${missingFields.join(", ")}`);
            //     //     }
            //     // });

            //     // if (aValidationErrors.length > 0) {
            //     //     sap.m.MessageBox.error(
            //     //         "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //     //     );
            //     //     return;
            //     // }
            //     // --- 🧪 VALIDATION (field completeness) ---
            //     let aValidationErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];
            //         if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //         if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //         if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //         if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //         if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- Sort selected rows (same logic as before) ---
            //     const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);
            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;
            //         const lotA = parseInt(a.bipllotno, 10) || 0;
            //         const lotB = parseInt(b.bipllotno, 10) || 0;
            //         return lotA - lotB;
            //     });

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aSuccessResults = [];
            //     const aErrorResults = [];

            //     // Generate a unique request number (UUID style)
            //     const requestNo = this.generateUUIDreqnoGR();

            //     // Create ONE payload with ALL selected rows in toitem
            //     const oPayload = {
            //         Requestno: requestNo,
            //         toitem: {
            //             results: aSortedSelectedRows.map(row => ({
            //                 Id: row.sap_uuid,                                 // use sap_uuid as item identifier
            //                 Material: row.materialcode,
            //                 Plant: row.plant,
            //                 Storagelocation: row.storagelocation,
            //                 Goodsmovementtype: "101",
            //                 Goodsmovementcode: "02",
            //                 Quantityinentryunit: String(row.confirmedqty),
            //                 Manufacturingorder: row.productionorderno,
            //                 // Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                 Postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                 Goodsmovementrefdoctype: "F"
            //             }))
            //         }
            //     };

            //     console.log(`🚀 Creating GR with ${aSortedSelectedRows.length} items in one payload`, oPayload);
            //     try {
            //         // Create header with ALL items in one call
            //         const oResponse = await new Promise((resolve, reject) => {
            //             oGRModel.create("/header", oPayload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });

            //         console.log(`✅ GR created for all items`, oResponse);

            //         // Validate response structure
            //         if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            //             throw new Error("Invalid response: missing toitem results");
            //         }

            //         // Process each item in the response
            //         for (let i = 0; i < oResponse.toitem.results.length; i++) {
            //             const itemResp = oResponse.toitem.results[i];
            //             const originalRow = aSortedSelectedRows.find(r => r.sap_uuid === itemResp.Id);

            //             if (!originalRow) {
            //                 console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
            //                 continue;
            //             }

            //             // Check if backend returned an error for this item
            //             if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
            //                 aErrorResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     error: itemResp.Errorresponse
            //                 });
            //                 continue;
            //             }

            //             // Get the material document details from the item response
            //             const materialDoc = itemResp.Materialdocument;
            //             const matDocYear = itemResp.Matdocyear;

            //             try {
            //                 // --- STEP 1: Fetch expiry date from material document item entity ---
            //                 const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear }
            //                 );

            //                 // Extract expiry date (use first item's ShelfLifeExpirationDate)
            //                 const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

            //                 // Update local row
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

            //                 // --- STEP 2: Update FGProcessBelt plan table with fetched expiry date ---
            //                 await this.ToUpdateGRTabBatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear },
            //                     { ShelfLifeExpirationDate: expiryDate } // pass the fetched expiry
            //                 );

            //                 console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: expiryDate
            //                 });

            //             } catch (itemError) {
            //                 // If fetching expiry or updating fails, still consider GR successful? 
            //                 // According to original pattern, if GR succeeded but subsequent steps fail, 
            //                 // we log warning but still count as success (since GR was created).
            //                 console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);

            //                 // Still update local row with basic GR info
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = itemResp.Shelflifeexpirationdate
            //                     ? new Date(itemResp.Shelflifeexpirationdate)
            //                     : null;

            //                 // Add to success with warning note
            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: originalRow.expirydate,
            //                     warning: "Expiry fetch failed, using GR response expiry"
            //                 });
            //             }
            //         }
            //     } catch (oError) {
            //         // Entire request failed
            //         console.error(`❌ GR failed for all items:`, oError);
            //         const sErrorMessage = this._extractErrorMessage(oError);

            //         aSortedSelectedRows.forEach((row, idx) => {
            //             aErrorResults.push({
            //                 productionOrder: row.productionorderno,
            //                 rowId: `Row ${idx + 1}`,
            //                 bipllotno: row.bipllotno || "",
            //                 error: sErrorMessage
            //             });
            //         });
            //     }

            //     // --- Update local table model and clear selection ---
            //     aSelectedRows.forEach(row => { row.__selected = false; });
            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();

            //     sap.ui.core.BusyIndicator.hide();

            //     // --- Show summary ---
            //     this.showGRSummaryBatch(aSuccessResults, aErrorResults);
            // },


            checkUserHasGoodsRecieptRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },


            onGoodsReceiptPressBatch: async function () {
                const oView = this.getView();
                const oGRModel = oView.getModel("ZSD_GR_NO_BATCH_HEAD_ITEM");         // service for posting
                const oFetchModel = oView.getModel("ZSB_GR_MATDOC_FETCH");   // service for fetching existing GR
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                // --- Arrays to track results ---
                const aSuccessResults = [];
                const aErrorResults = [];
                const aSkippedRows = [];

                // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                let aBlockerErrors = [];
                aSelectedRows.forEach((row) => {
                    let errors = [];
                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }
                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists (local)");
                    }
                    if (!row.productionorderno || row.productionorderno.trim() === "") {
                        errors.push("Missing Production Order");
                    }
                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness) ---
                let aValidationErrors = [];
                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
                    if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
                    if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
                    if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
                    if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- Remove rows that already have a GR in the UI (local) ---
                const aWithLocalGR = aSelectedRows.filter(row => row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "");
                aWithLocalGR.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Receipt already exists (local)"
                    });
                });
                let aRowsToCheck = aSelectedRows.filter(row => !aWithLocalGR.includes(row));

                // --- If no rows left after local check, show summary and return ---
                if (aRowsToCheck.length === 0) {
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- 🕒 Show busy indicator before backend fetch ---
                sap.ui.core.BusyIndicator.show(0);

                // --- Fetch existing GR data from ZSB_GR_MATDOC_FETCH for remaining rows ---
                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];

                const fetchExistingPromises = aRowsToCheck.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_GR_MATDOC_FETCH", {
                                filters: [oFilter],
                                success: resolve,
                                error: reject
                            });
                        });

                        if (oData.results && oData.results.length > 0) {
                            // Use the first result (assuming at most one per order)
                            return { row, existing: oData.results[0] };
                        } else {
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GR for order ${row.productionorderno}:`, err);
                        // Treat as not existing; proceed with posting
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Separate rows
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a goods receipt in the backend ---
                // --- Update rows that already have a goods receipt in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;

                    // Update local row
                    row.grmaterialdocnumber = matDoc;
                    row.grmaterialdocyear = matDocYear;

                    // Update mixing plan table
                    try {
                        await this.ToUpdateGRTabBatch(
                            row,
                            matDoc,
                            { materialdocument: matDoc, matdocyear: matDocYear },
                            { ShelfLifeExpirationDate: null }   // expiry not available from this fetch
                        );
                        console.log(`✅ Updated mixing plan for existing order ${row.productionorderno}`);
                        aSuccessResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            materialDocument: matDoc,
                            year: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update mixing plan for existing order ${row.productionorderno}:`, updateErr);
                        aErrorResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // Hide busy indicator before showing confirmation
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- Sort rows to post (same logic as before) ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods receipt for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        sap.ui.core.BusyIndicator.show(0);

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGR();

                        // Build payload with all rows to post
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: {
                                results: aRowsToPost.map(row => ({
                                    Id: row.sap_uuid,                                 // use sap_uuid as item identifier
                                    Material: row.materialcode,
                                    Plant: row.plant,
                                    Storagelocation: row.storagelocation,
                                    Goodsmovementtype: "101",
                                    Goodsmovementcode: "02",
                                    Quantityinentryunit: String(row.confirmedqty),
                                    Manufacturingorder: row.productionorderno,
                                    // Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    // Postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    Postingdate: row.PostingDate ? new Date(row.PostingDate.toLocaleDateString('en-CA')) : null,
                                    Goodsmovementrefdoctype: "F"
                                }))
                            }
                        };



                        console.log(`🚀 Creating GR with ${aRowsToPost.length} items in one payload`, oPayload);

                        try {
                            const oResponse = await new Promise((resolve, reject) => {
                                oGRModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ GR created for all items`, oResponse);

                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aRowsToPost.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aErrorResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                const materialDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;

                                try {
                                    // Fetch expiry date from material document item
                                    const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear }
                                    );
                                    const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

                                    // Update local row
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

                                    // Update mixing plan table
                                    await this.ToUpdateGRTabBatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear },
                                        { ShelfLifeExpirationDate: expiryDate }
                                    );

                                    console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: expiryDate
                                    });

                                } catch (itemError) {
                                    console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);
                                    // Still count as success because GR was created, but log warning
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = itemResp.Shelflifeexpirationdate
                                        ? new Date(itemResp.Shelflifeexpirationdate)
                                        : null;

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: originalRow.expirydate,
                                        warning: "Expiry fetch failed, using GR response expiry"
                                    });
                                }
                            }
                        } catch (oError) {
                            console.error(`❌ GR failed for all items:`, oError);
                            const sErrorMessage = this._extractErrorMessage(oError);
                            aRowsToPost.forEach((row, idx) => {
                                aErrorResults.push({
                                    productionOrder: row.productionorderno,
                                    rowId: `Row ${idx + 1}`,
                                    bipllotno: row.bipllotno || "",
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Update table and clear selection
                        aSelectedRows.forEach(row => { row.__selected = false; });
                        oTabModel.setProperty("/Samples", aRows);
                        oTabModel.refresh();

                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    }.bind(this) // ensure 'this' context
                });
            },

            // ============================================================
            // UPDATED: Update FGProcessBelt plan table
            // ============================================================
            ToUpdateGRTabBatch: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    // sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_FG_PROCESS_PLAN");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // operator: HeaderModel.operator,
                        // inspector: HeaderModel.inspector,
                        // expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,
                    };

                    console.log(`📝 Updating FGProcessBelt plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_FG_PROCESS_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            // sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            // sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            // ============================================================
            // NEW HELPER: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // UPDATED: Summary dialog (now matches the style of showPostSummaryBatch)
            // ============================================================
            showGRSummaryBatch: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;
                if (sTotal === 0) return;

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                const bHasSuccess = aSuccessResults.length > 0;
                const bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}) → `;
                        if (result.materialDocument) {
                            sMessage += `Material Doc: ${result.materialDocument}/${result.year}`;
                            if (result.expiryDate) {
                                const d = new Date(result.expiryDate);
                                sMessage += `, Expiry: ${d.toLocaleDateString()}`;
                            }
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}): ${result.error}\n`;
                    });
                }

                setTimeout(() => {
                    if (bHasFailed && !bHasSuccess) {
                        sap.m.MessageBox.error(sMessage, { title: "Goods Receipt Failed" });
                    } else if (bHasFailed && bHasSuccess) {
                        sap.m.MessageBox.warning(sMessage, {
                            title: "Goods Receipt Partial Success",
                            details: aErrorResults.map(f =>
                                `${f.rowId} (Bipl: ${f.bipllotno})\nError: ${f.error}`
                            ).join('\n\n')
                        });
                    } else {
                        sap.m.MessageBox.success(sMessage, { title: "Goods Receipt Successful" });
                    }
                }, 100);
            },



            // ============================================================
            // EXISTING: Fetch expiry date (kept for compatibility, but no longer used in new flow)
            // ============================================================
            ToFetchExpiredateGRTabbatch: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {
                            console.log(oData)
                            resolve(oData.results)
                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve FGProcessBelt Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },




            // sap.ui.core.BusyIndicator.hide();
            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Update 
            // ------------------------------------------------------------------------------------------------------------------------------------------

            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);
                const aSelectedUUIDs = aSelectedRows.map(item => item.sap_uuid); // store for later

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }
                // debugger

                function timeToEdmTime(vTime) {
                    if (!vTime) {
                        return null;
                    }

                    // Case 1: already Edm.Time object
                    if (typeof vTime === "object" && vTime.ms !== undefined) {
                        const totalSeconds = Math.floor(vTime.ms / 1000);
                        const h = Math.floor(totalSeconds / 3600);
                        const m = Math.floor((totalSeconds % 3600) / 60);
                        const s = totalSeconds % 60;

                        return `PT${h}H${m}M${s}S`;
                    }

                    // Case 2: string "HH:mm:ss"
                    if (typeof vTime === "string") {
                        const [h, m, s] = vTime.split(":").map(Number);
                        return `PT${h}H${m}M${s}S`;
                    }

                    return null;
                }




                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {

                    const sKey = oODataModel.createKey("/ZC_FG_PROCESS_PLAN", {
                        sap_uuid: item.sap_uuid,
                    });

                    // Prepare payload with only editable fields
                    const oPayload = {
                        // confirmedqty: String(parseInt(item.confirmedqty)),
                        scrapqty: String(parseInt(item.scrapqty)),
                        confirmedqty: String(item.confirmedqty),
                        RejectCodes: String(item.RejectCodes),


                        manufacturingdate: item.manufacturingdate ? new Date(item.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        PostingDate: item.PostingDate ? new Date(item.PostingDate.toLocaleDateString('en-CA')) : null,
                        // manufacturingtime: item.manufacturingtime,
                        // manufacturingtime: item.manufacturingtime
                        //     ? timeToEdmTime(item.manufacturingtime)
                        //     : null,


                        updatestatusgistatus: "GT"
                    };
                    // debugger

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                // Promise.allSettled(aUpdatePromises).then(results => {
                //     sap.ui.core.BusyIndicator.hide();

                //     const aFailed = results.filter(r => r.status === "rejected");
                //     const aSuccess = results.filter(r => r.status === "fulfilled");

                //     let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                //     if (aFailed.length > 0) {
                //         sMsg += `\n${aFailed.length} row(s) failed to update.`;
                //     }

                //     sap.m.MessageBox.information(sMsg);
                //     oTabModel.refresh(true);
                //     this.GoFGProcessActualfilter()
                // });
                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);

                    // Now refresh data via GoFGProcessActualfilter and restore selection
                    this.GoFGProcessActualfilter(function (aNewData) {
                        // Restore selection: mark __selected = true for rows whose sap_uuid is in aSelectedUUIDs
                        aNewData.forEach(item => {
                            if (aSelectedUUIDs.indexOf(item.sap_uuid) !== -1) {
                                item.__selected = true;
                            }
                        });
                        // Update the model (GoFGProcessActualfilter already set it, but we need to reflect selection)
                        const oTabModel = this.getView().getModel("TabModel");
                        oTabModel.setProperty("/Samples", aNewData);
                        oTabModel.refresh(true);
                    }.bind(this));
                });
            },




            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Release and save oCalenderingPlanModel
            // ------------------------------------------------------------------------------------------------------------------------------------------
            // onReleasePress: async function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
            //     const oCalenderingPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Process rows one by one
            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sManufacturingOrder = row.productionorderno;

            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${i + 1} skipped: No production order.`);
            //             row.releasestatus = "";
            //             oTableModel.refresh();
            //             continue;
            //         }

            //         try {
            //             // Step 1: Check status from ZC_ORDER_CREATION - wait for response
            //             const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

            //             if (bStatusActive) {
            //                 console.log(`Row ${i + 1}: Status I0002 is active - already released.`);

            //                 // Update Calendering plan
            //                 await this.updateFGProcessPlan(oCalenderingPlanModel, row, true);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 oTableModel.refresh();

            //                 sap.m.MessageToast.show(`Row ${i + 1}: Already released.`);
            //                 continue; // Skip to next row
            //             }

            //             // Step 2: Create release - wait for response
            //             const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

            //             if (bReleaseSuccess) {
            //                 // Step 3: Update Calendering plan - wait for response
            //                 await this.updateFGProcessPlan(oCalenderingPlanModel, row, false);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 oTableModel.refresh();

            //                 console.log(`✅ Row ${i + 1} released successfully`);
            //                 sap.m.MessageToast.show(`Row ${i + 1}: Released successfully`);
            //             } else {
            //                 row.releasestatus = "";
            //                 oTableModel.refresh();
            //                 console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
            //             }

            //         } catch (error) {
            //             console.error(`❌ Error processing row ${i + 1}:`, error);
            //             row.releasestatus = "";
            //             oTableModel.refresh();
            //         }
            //     }

            //     // Final refresh and cleanup
            //     oTableModel.setProperty("/Samples", aRows);
            //     oTableModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();
            //     sap.m.MessageToast.show("Release process completed.");
            // },

            // // Helper function to check order status
            // checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];

            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 const bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });
            //                 resolve(bExists);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to create release
            // createRelease: function (oModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const oPayload = {
            //             ManufacturingOrder: sManufacturingOrder
            //         };

            //         oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //             success: function (oData) {
            //                 if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                     sap.m.MessageToast.show("Check material availability");
            //                     resolve(false);
            //                     return;
            //                 }
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to update Calendering plan
            // updateFGProcessPlan: function (oCalenderingPlanModel, row, bAlreadyReleased) {
            //     return new Promise((resolve, reject) => {
            //         const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
            //         const oUpdateEntry = {
            //             releasestatus: "RELEASED",
            //             batchweight: row.batchweight || "",
            //             operator: row.operator || "",
            //             inspector: row.inspector || "",
            //             manufacturingdate: row.manufacturingdate ?
            //                 new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
            //         };

            //         oCalenderingPlanModel.update(sUpdatePath, oUpdateEntry, {
            //             success: function () {
            //                 console.log(`🔄 Calendering Plan updated`);
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 if (!bAlreadyReleased) {
            //                     reject(oError);
            //                 } else {
            //                     // If already released, still resolve (don't fail the process)
            //                     resolve(true);
            //                 }
            //             }
            //         });
            //     });
            // },






            // onReleasePress: async function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
            //     const oFGProcessPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Arrays to track results
            //     const aSuccessRows = [];
            //     const aFailedRows = [];
            //     const aAlreadyReleasedRows = [];

            //     // Process rows one by one
            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sManufacturingOrder = row.productionorderno;

            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${i + 1} skipped: No production order.`);
            //             row.releasestatus = "";
            //             aFailedRows.push({
            //                 rowNumber: i + 1,
            //                 productionOrder: "No Production Order",
            //                 error: "No production order number"
            //             });
            //             continue;
            //         }

            //         try {
            //             // Step 1: Check status from ZC_ORDER_CREATION
            //             const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

            //             if (bStatusActive) {
            //                 console.log(`Row ${i + 1}: Status I0002 is active - already released.`);
            //                 aAlreadyReleasedRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder
            //                 });

            //                 // Update FGProess plan updateFGProessPlan
            //                 await this.updateFGProessPlan(oFGProcessPlanModel, row, true);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 continue;
            //             }

            //             // Step 2: Create release
            //             const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

            //             if (bReleaseSuccess) {
            //                 // Step 3: Update FGProess plan
            //                 await this.updateFGProessPlan(oFGProcessPlanModel, row, false);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 aSuccessRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder
            //                 });
            //                 console.log(`✅ Row ${i + 1} released successfully`);
            //             } else {
            //                 row.releasestatus = "";
            //                 aFailedRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder,
            //                     error: "Release creation failed - check material availability"
            //                 });
            //                 console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
            //             }

            //         } catch (error) {
            //             console.error(`❌ Error processing row ${i + 1}:`, error);
            //             row.releasestatus = "";
            //             aFailedRows.push({
            //                 rowNumber: i + 1,
            //                 productionOrder: sManufacturingOrder,
            //                 error: error.message || "Unknown error"
            //             });
            //         }
            //     }

            //     // Final refresh and cleanup
            //     oTableModel.setProperty("/Samples", aRows);
            //     oTableModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();

            //     // Show summary message
            //     this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            // },

            // showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
            //     const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

            //     if (sTotal === 0) {
            //         return;
            //     }

            //     let sMessage = `Release process completed for ${sTotal} rows.\n\n`;
            //     let bHasSuccess = aSuccessRows.length > 0;
            //     let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
            //     let bHasFailed = aFailedRows.length > 0;

            //     if (bHasSuccess) {
            //         sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
            //         aSuccessRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     if (bHasAlreadyReleased) {
            //         sMessage += `ℹ️ Already released: ${aAlreadyReleasedRows.length}\n`;
            //         aAlreadyReleasedRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     if (bHasFailed) {
            //         sMessage += `❌ Failed to release: ${aFailedRows.length}\n`;
            //         aFailedRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //             if (row.error) {
            //                 sMessage += `     Error: ${row.error}\n`;
            //             }
            //         });
            //     }

            //     // Always show MessageBox for all cases
            //     setTimeout(() => {
            //         if (bHasFailed) {
            //             // Show error dialog with details
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.ERROR,
            //                     title: "Release Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     details: aFailedRows.map(f =>
            //                         `Row ${f.rowNumber} - Production Order: ${f.productionOrder}\nError: ${f.error || "Unknown error"}`
            //                     ).join('\n\n')
            //                 }
            //             );
            //         } else {
            //             // Show success dialog (even if only already released rows)
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.SUCCESS,
            //                     title: "Release Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK]
            //                 }
            //             );
            //         }
            //     }, 100);
            // },

            // // Helper function to check order status (unchanged)
            // checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];

            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 const bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });
            //                 resolve(bExists);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to create release (unchanged)
            // createRelease: function (oModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const oPayload = {
            //             ManufacturingOrder: sManufacturingOrder
            //         };

            //         oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //             success: function (oData) {
            //                 if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                     resolve(false);
            //                     return;
            //                 }
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to update FGProess plan (unchanged)
            // updateFGProessPlan: function (oFGProcessPlanModel, row, bAlreadyReleased) {
            //     return new Promise((resolve, reject) => {
            //         const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
            //         const oUpdateEntry = {
            //             releasestatus: "RELEASED",
            //             RejectCodes: String(row.RejectCodes),
            //             // batchweight: row.batchweight || "",
            //             // operator: row.operator || "",
            //             // inspector: row.inspector || "",
            //             // manufacturingdate: row.manufacturingdate ?
            //             //     new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
            //         };

            //         oFGProcessPlanModel.update(sUpdatePath, oUpdateEntry, {
            //             success: function () {
            //                 console.log(`🔄 FG Process Plan updated`);
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 if (!bAlreadyReleased) {
            //                     reject(oError);
            //                 } else {
            //                     // If already released, still resolve (don't fail the process)
            //                     resolve(true);
            //                 }
            //             }
            //         });
            //     });
            // },



            onReleasePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
                const oFGProcessPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get ALL selected rows, regardless of UI status
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Sort selected rows according to table sorting logic
                aAllSelectedRows.sort((a, b) => {
                    // First sort by productionordstartdate (ascending)
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;

                    // Handle date comparison
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }

                    // If dates are equal or both null, sort by bipllotno (ascending)
                    const lotA = a.bipllotno || "";
                    const lotB = b.bipllotno || "";

                    if (lotA < lotB) return -1;
                    if (lotA > lotB) return 1;

                    return 0;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];
                const aRowsToRelease = [];

                // Phase 1: Check backend status for ALL selected rows
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);

                            // Track what we found
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update FGPrpcess plan for consistency
                                await this.updateFGProcessPlan(oFGProcessPlanModel, row, true);
                            }
                        } else {
                            // Order is not released in backend, add to list for release  
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Release rows that are not already released in backend
                for (let i = 0; i < aRowsToRelease.length; i++) {
                    const { originalIndex, row, manufacturingOrder } = aRowsToRelease[i];

                    try {
                        // Create release
                        const bReleaseSuccess = await this.createRelease(oModel, manufacturingOrder);

                        if (bReleaseSuccess) {
                            console.log(`Row ${originalIndex + 1}: Successfully released ${manufacturingOrder}`);

                            // Update FGProcess plan
                            await this.updateFGProcessPlan(oFGProcessPlanModel, row, false);

                            // Update UI
                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder
                            });
                            console.log(`✅ Row ${originalIndex + 1} released successfully`);
                        } else {
                            row.releasestatus = "";
                            aFailedRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder,
                                error: "Release creation failed - check material availability"
                            });
                            console.warn(`⚠️ Row ${originalIndex + 1}: Release creation failed`);
                        }

                    } catch (releaseError) {
                        console.error(`Row ${originalIndex + 1}: Error during release:`, releaseError);
                        row.releasestatus = "";

                        let sErrorMessage;

                        // Check EXACTLY for "Release of order not possible" or CO/118 error
                        const errorMessage = releaseError.message || "";
                        const errorCode = releaseError.code || "";

                        if (errorMessage.includes("Release of order not possible") ||
                            errorCode.includes("CO/118") ||
                            (releaseError.isMaterialAvailabilityError === true)) {
                            // ONLY for this specific error, show the material availability message
                            sErrorMessage = `Release failed: Check material availability for order ${manufacturingOrder}`;
                        } else {
                            // For ALL other errors, show the full error message
                            sErrorMessage = releaseError.message || "Unknown error";

                            // Include the error code if available
                            if (releaseError.code) {
                                sErrorMessage = `Error ${releaseError.code}: ${sErrorMessage}`;
                            }
                        }

                        aFailedRows.push({
                            rowNumber: originalIndex + 1,
                            productionOrder: manufacturingOrder,
                            error: sErrorMessage,
                            rawError: releaseError.message // Store the raw error for debugging
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

            // Updated createRelease function to properly handle errors
            createRelease: function (oModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const oPayload = {
                        ManufacturingOrder: sManufacturingOrder
                    };

                    oModel.create("/ZC_PROD_STATUS1", oPayload, {
                        success: function (oData) {
                            console.log("response success:", oData);

                            // Check if there's an error in the response
                            if (oData.errorresponse) {
                                try {
                                    // Parse the error response JSON
                                    const errorObj = JSON.parse(oData.errorresponse);
                                    console.error("Error in response:", errorObj);

                                    // Check for specific error codes
                                    const errorCode = errorObj.error?.code;
                                    const errorMessage = errorObj.error?.message?.value || "Unknown error";

                                    // Reject with structured error
                                    reject({
                                        message: errorMessage,
                                        code: errorCode,
                                        details: errorObj.error?.innererror,
                                        isMaterialAvailabilityError: errorCode === "CO/118" ||
                                            errorMessage.includes("Release of order not possible")
                                    });
                                } catch (parseError) {
                                    // If JSON parsing fails, reject with the raw error
                                    reject({
                                        message: "Error processing response",
                                        rawError: oData.errorresponse
                                    });
                                }
                                return;
                            }

                            // If no error, resolve with success
                            resolve(true);
                        },
                        error: function (oError) {
                            console.error("OData call failed:", oError);
                            reject({
                                message: oError.message || "OData call failed",
                                rawError: oError
                            });
                        }
                    });
                });
            },

            // Helper function to check order status (unchanged)
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData)
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            updateFGProcessPlan: function (oFGProcessPlanModel, row, bAlreadyReleased) {
                function timeToEdmTime(vTime) {
                    if (!vTime) {
                        return null;
                    }

                    // Case 1: already Edm.Time object
                    if (typeof vTime === "object" && vTime.ms !== undefined) {
                        const totalSeconds = Math.floor(vTime.ms / 1000);
                        const h = Math.floor(totalSeconds / 3600);
                        const m = Math.floor((totalSeconds % 3600) / 60);
                        const s = totalSeconds % 60;

                        return `PT${h}H${m}M${s}S`;
                    }

                    // Case 2: string "HH:mm:ss"
                    if (typeof vTime === "string") {
                        const [h, m, s] = vTime.split(":").map(Number);
                        return `PT${h}H${m}M${s}S`;
                    }

                    return null;
                }
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        // batchweight: row.batchweight || "",
                        // operator: row.operator || "",
                        // inspector: row.inspector || "",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,

                        // manufacturingtime: item.manufacturingtime
                        //     ? timeToEdmTime(item.manufacturingtime)
                        //     : null,

                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oFGProcessPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 FGProcess Plan updated`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },




            // -----------------------------------------------------------------------------------------------------

            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqno: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Batch Release using header-item service
            // ============================================================

            checkUserHasReleaseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_RELEASE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReleasePressBatch: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // for status check
                const oFgProcessBeltPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
                const oReleaseModel = oView.getModel("ZSB_RELEASE_HD_ITEM_FG");  // new service

                // Get ALL selected rows
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasReleaseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_RELEASE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Sort selected rows (same logic as original)
                aAllSelectedRows.sort((a, b) => {
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays for summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];

                // Phase 1: Check backend status for ALL selected rows
                const aRowsToRelease = [];
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update FGProcess plan for consistency (don't fail if this update fails)
                                try {
                                    // await this.updateMixingPlanBatch(oFgProcessBeltPlanModel, row, true);
                                    await this.updatePlanTableBatch(oFgProcessBeltPlanModel, row, true);
                                } catch (updateErr) {
                                    console.warn(`FGProcess plan update for already released row ${row.sap_uuid} failed:`, updateErr);
                                }
                            }
                        } else {
                            // Order is not released in backend, add to list for batch release
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Batch release rows that are not already released
                if (aRowsToRelease.length > 0) {
                    // Generate a unique request number
                    const requestNo = this.generateUUIDreqno();

                    // Build items array for the batch payload
                    const aItems = aRowsToRelease.map(item => ({
                        Id: item.row.sap_uuid,                    // unique item identifier
                        Manufacturingorder: item.manufacturingOrder
                        // No other fields needed for creation (output fields will be filled by backend)
                    }));

                    const oPayload = {
                        Requestno: requestNo,
                        toitem: { results: aItems }
                    };

                    console.log(`🚀 Posting Release batch with ${aItems.length} items`, oPayload);

                    try {
                        // Create header with all items in one call
                        const oResponse = await new Promise((resolve, reject) => {
                            oReleaseModel.create("/header", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Release batch created`, oResponse);

                        // Validate response structure
                        if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                            throw new Error("Invalid response: missing toitem results");
                        }

                        // Process each item in the response
                        for (let i = 0; i < oResponse.toitem.results.length; i++) {
                            const itemResp = oResponse.toitem.results[i];
                            const originalItem = aRowsToRelease.find(item => item.row.sap_uuid === itemResp.Id);

                            if (!originalItem) {
                                console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                continue;
                            }

                            const row = originalItem.row;
                            const rowNumber = originalItem.originalIndex + 1;

                            // Check if backend returned an error for this item
                            if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                // Parse error response if possible
                                let errorMsg = itemResp.Errorresponse;
                                try {
                                    const errObj = JSON.parse(itemResp.Errorresponse);
                                    errorMsg = errObj.error?.message?.value || errObj.message || itemResp.Errorresponse;
                                } catch (e) { /* use raw string */ }

                                aFailedRows.push({
                                    rowNumber: rowNumber,
                                    productionOrder: row.productionorderno,
                                    error: errorMsg
                                });
                                continue;
                            }

                            // Success: update FGProcess plan and UI
                            try {
                                await this.updatePlanTableBatch(oFgProcessBeltPlanModel, row, false);
                            } catch (updateErr) {
                                console.error(`⚠️ FGProcess plan update failed for row ${row.sap_uuid}`, updateErr);
                                // Still consider release successful; log warning but don't mark as failed
                            }

                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: rowNumber,
                                productionOrder: row.productionorderno
                            });
                        }
                    } catch (oError) {
                        // Entire request failed
                        console.error(`❌ Release batch failed:`, oError);
                        const sErrorMessage = this._extractErrorMessage(oError);

                        // Mark all rows that were supposed to be released as failed
                        aRowsToRelease.forEach(item => {
                            aFailedRows.push({
                                rowNumber: item.originalIndex + 1,
                                productionOrder: item.row.productionorderno,
                                error: sErrorMessage
                            });
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message (reusing the existing function)
                this.showReleaseSummarybatch(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            // ============================================================
            // Helper to check order status (unchanged)
            // ============================================================
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData);
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            // ============================================================
            // Update FGProcess plan (renamed with Batch suffix for consistency)
            // ============================================================
            updatePlanTableBatch: function (oFgProcessBeltPlanModel, row, bAlreadyReleased) {
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oFgProcessBeltPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 FGProcess Plan updated for ${row.sap_uuid}`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },

            // ============================================================
            // Existing showReleaseSummarybatch function (unchanged)
            // ============================================================
            showReleaseSummarybatch: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

















            onBatchValueHelp: function (oEvent) {
                const oView = this.getView();
                const oSource = oEvent.getSource();
                this._oBatchInputSource = oSource; // Save for setting value later

                // Load fragment if not already created
                if (!this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog = sap.ui.xmlfragment(
                        oView.getId(),
                        "bando.view.CommonFragments.ActualScreens.bombatchselect",
                        this
                    );
                    oView.addDependent(this._oBatchValueHelpDialog);
                }

                // Get current row data (for filtering)
                const oContext = oSource.getBindingContext("TabModel");
                if (!oContext) {
                    sap.m.MessageToast.show("No row context found.");
                    return;
                }

                const oRowData = oContext.getObject();
                const sMaterial = oRowData.Product;
                const sPlant = oRowData.Plant;
                const sStorageLoc = oRowData.StorageLocation;

                // Load data before opening
                this._loadBatchData(sMaterial, sPlant, sStorageLoc);
            },

            // ===========================================================
            // Load Batch Data and Bind to Fragment Table
            // ===========================================================
            _loadBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB"); // backend OData model

                // Build filters
                const aFilters = [
                    new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                const that = this;
                oModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        console.log("✅ Batch data received:", oData);

                        // Create JSON model from results array
                        const oJSONModel = new sap.ui.model.json.JSONModel(oData.results);

                        // Get table from fragment
                        const oTable = sap.ui.core.Fragment.byId(oView.getId(), "batchTable");
                        if (oTable) {
                            oTable.setModel(oJSONModel, "BatchModel");
                            console.log("✅ Bound rows:", oJSONModel.getData());
                            that._oBatchValueHelpDialog.open();
                        } else {
                            console.error("❌ batchTable not found in fragment");
                        }
                    },

                    error: function (oError) {
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // ===========================================================
            // Handle "Select" Button - Set Batch value in Input Field
            // ===========================================================


            onBatchRowSelect: function (oEvent) {
                const oTable = oEvent.getSource();
                const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

                if (!oSelectedContext) {
                    sap.m.MessageToast.show("No row selected.");
                    return;
                }

                const oSelectedData = oSelectedContext.getObject();

                if (this._oBatchInputSource) {
                    // Get the current row context in the TabModel
                    const oRowContext = this._oBatchInputSource.getBindingContext("TabModel");

                    if (oRowContext) {
                        const oTabModel = oRowContext.getModel();
                        const sRowPath = oRowContext.getPath();

                        // Set both Batch and Storage Location
                        oTabModel.setProperty(sRowPath + "/Batch", oSelectedData.Batch);
                        oTabModel.setProperty(sRowPath + "/StorageLocation", oSelectedData.StorageLocation);

                        // Optional: If you want to update the input field value as well
                        this._oBatchInputSource.setValue(oSelectedData.Batch);
                    }
                }

                // Close and destroy the dialog to avoid reuse issues
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy();
                    this._oBatchValueHelpDialog = null;
                }
            },

            // ===========================================================
            // Handle "Cancel" Button
            // ===========================================================
            onValueHelpCancel: function () {
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy(); // cleanup
                    this._oBatchValueHelpDialog = null; // reset reference
                }
            },

            generateUUID: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },




            onReleaseUpdatePress: function () {
                const oView = this.getView();
                const oModel = oView.getModel("TabModel");
                const oODataREL_BOM = this.getView().getModel("ZSB_REL_BOM_UPD");

                let aRows = oModel.getProperty("/BomRelease") || [];

                if (!aRows.length) {
                    sap.m.MessageToast.show("No data available to update.");
                    return;
                }

                // Build payload array
                let aPayloads = aRows.map(row => ({
                    sap_uuid: this.generateUUID(),   // FIXED
                    reservation: row.Reservation,
                    reservationitem: row.ReservationItem,
                    requiredquantity: row.ResvnItmRequiredQtyInBaseUnit,
                    storagelocation: row.StorageLocation,
                    baseunitisocode: row.UnitOfMeasureISOCode,
                    matlcompismarkedforbackflush: "true",
                }));

                // Log all payloads before starting
                console.log("📌 All Payloads Generated:", aPayloads);

                sap.m.MessageToast.show("Posting BOM items...");

                let iCount = 0;
                let iTotal = aPayloads.length;

                // LOOP (not forEach) → sends one by one independently
                for (let i = 0; i < iTotal; i++) {
                    let payload = aPayloads[i];

                    console.log(`📤 Posting Payload ${i + 1}/${iTotal}:`, payload);

                    oODataREL_BOM.create("/ZC_REL_BOM_UPD", payload, {
                        success: (oData, response) => {
                            console.log(`✔ Success for item ${i + 1}`);
                            console.log("🔹 Payload Sent:", payload);
                            console.log("🔹 SAP Response:", oData);
                            console.log("🔹 Full HTTP Response:", response);

                            iCount++;
                            if (iCount === iTotal) {
                                sap.m.MessageToast.show("Production order qty has been Changed successfully.");
                                console.log("🎉 All items processed.");
                            }
                        },
                        error: (err) => {
                            console.error(`❌ Error at item ${i + 1}`, err);
                            console.error("🔹 Failed Payload:", payload);
                            sap.m.MessageBox.error("Error while updating BOM. Check console.");
                        }
                    });
                }
            },




            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Release END
            // ------------------------------------------------------------------------------------------------------------------------------------------





            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse reciept start
            // ------------------------------------------------------------------------------------------------------------------------------------------













            // onReverseReceiptPress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1"); //ZSB_REVERSE_PORD    // Reverse OData model

            //     const oCalenderingPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");   // For updating internal table
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
            //         return;
            //     }

            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
            //     if (aInvalidRows.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     const aFilters = [
            //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, aSelectedRows[0].productionorderno)
            //     ];
            //     oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             const aResults = oData.results;
            //             // const oEntry = aResults && aResults[0];
            //             // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

            //             // const mapped = aResults.map(entry => {
            //             //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
            //             //   });

            //             //   const oEntry = mapped.find(entry => entry !== null);
            //             var bExists = aResults.some(function (oItem) {
            //                 return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
            //             });

            //             // const iSelectedIndex = aRows.findIndex(row => row.__selected);



            //             if (bExists) {
            //                 console.log("Combination exists: I0002 and active.");
            //                 // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
            //                 sap.m.MessageToast.show("Teco already active, cant reverse");
            //                 sap.ui.core.BusyIndicator.hide();

            //                 return;
            //             }
            //             else {
            //                 aSelectedRows.forEach((row, index) => {
            //                     const oPayload = {
            //                         Materialdocument: row.grmaterialdocnumber,
            //                         Matdocyear: row.grmaterialdocyear, // You can make this dynamic if needed
            //                         Postingdate: new Date()
            //                     };

            //                     console.log(`📤 Sending Reverse Receipt Payload for row ${index + 1}:`, oPayload);

            //                     oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
            //                         success: function (oData) {
            //                             console.log(`✅ Reverse receipt success for row ${index + 1}:`, oData);

            //                             const sResponseValue = oData.Response || "";

            //                             // Update internal table field `grmaterialdocnumber`
            //                             const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
            //                             const oUpdateEntry = {
            //                                 grmaterialdocnumber: sResponseValue,
            //                                 grmaterialdocyear: "",
            //                             };

            //                             oCalenderingPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                                 success: function () {
            //                                     console.log(`🔄 grmaterialdocnumber updated for row ${index + 1}`);
            //                                     row.grmaterialdocnumber = sResponseValue;
            //                                     row.grmaterialdocyear = "";
            //                                     checkCompletion();
            //                                 },
            //                                 error: function () {
            //                                     console.warn(`⚠️ Failed to update grmaterialdocnumber for row ${index + 1}`);
            //                                     checkCompletion();
            //                                 }
            //                             });
            //                         },
            //                         error: function (oError) {
            //                             console.error(`❌ Reverse receipt failed for row ${index + 1}`, oError);
            //                             checkCompletion();
            //                         }
            //                     });
            //                 });

            //                 function checkCompletion() {
            //                     iCompleted++;
            //                     if (iCompleted === aSelectedRows.length) {
            //                         oTableModel.setProperty("/Samples", aRows);
            //                         oTableModel.refresh();
            //                         sap.ui.core.BusyIndicator.hide();
            //                         sap.m.MessageToast.show("Reverse receipt process completed.");
            //                     }
            //                 }

            //             }

            //         }
            //     });

            // },


            checkUserHasGoodsRecieptReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReverseReceiptPress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1_FG");
                const oTablePlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Check missing GR fields
                const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    // Check TECO first
                    const aFilters = [
                        new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            aSelectedRows[0].productionorderno
                        )
                    ];

                    const oData = await new Promise((resolve, reject) => {
                        oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                            filters: aFilters,
                            success: resolve,
                            error: reject
                        });
                    });

                    const aResults = oData.results;

                    var bExists = aResults.some(function (oItem) {
                        return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
                    });

                    if (bExists) {
                        sap.m.MessageToast.show("Teco already active, cant reverse");
                        return;
                    }

                    // Process rows sequentially
                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Materialdocument: row.grmaterialdocnumber,
                            Matdocyear: row.grmaterialdocyear,
                            Postingdate: new Date()
                        };

                        console.log(`📤 Sending Reverse Receipt Payload for row ${i + 1}:`, oPayload);

                        // Reverse API
                        const oReverseData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZCDS_REVERSE_PROD1_FG", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse receipt success for row ${i + 1}:`, oReverseData);

                        const sResponseValue = oReverseData.Response || "";

                        const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            grmaterialdocnumber: sResponseValue,
                            grmaterialdocyear: ""
                        };

                        // Update API
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI
                        row.grmaterialdocnumber = sResponseValue;
                        row.grmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse receipt process completed.");

                } catch (error) {
                    console.error("❌ Reverse receipt error:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Receipt process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },










            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse issue start
            // ------------------------------------------------------------------------------------------------------------------------------------------








            // onReverseIssuePress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");//ZSB_CNFISSUEREVERSE // Reverse API model 
            //     const oCalenderingPlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN"); // For PATCH

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse issue.");
            //         return;
            //     }


            //     // ✅ New Validation: Prevent if any row has grmaterialdocnumber
            //     const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
            //     if (aHasGRRows.length > 0) {
            //         sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
            //         return;
            //     }


            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
            //     if (aInvalidRows1.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
            //         return;
            //     }
            //     // const aInvalidRows2 = aSelectedRows.filter(row => !row.grmaterialdocnumber);
            //     // if (aInvalidRows2.length > 0) {
            //     //     sap.ui.core.BusyIndicator.hide();
            //     //     sap.m.MessageBox.error("Cannot reverse Issue: Do Reciept reverse first.");
            //     //     return;
            //     // }





            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     aSelectedRows.forEach((row, index) => {
            //         const oPayload = {
            //             Porderno: row.productionorderno,
            //             ConfirmationGroup: row.gicnfconfirmationgroup,
            //             ConfirmationCount: row.gicnfconfirmationcount
            //         };

            //         console.log(`📤 Sending Reverse Issue Payload for row ${index + 1}:`, oPayload);

            //         oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
            //             success: function (oData) {
            //                 console.log(`✅ Reverse issue success for row ${index + 1}:`, oData);

            //                 // Get the returned material document number (assuming field is "Response")
            //                 const sResponseValue = oData.Response || "";

            //                 // Update Calendering Plan table with returned Response
            //                 const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";
            //                 const oUpdateEntry = {
            //                     gicnfmaterialdocnumber: "",
            //                     gicnfconfirmationgroup: "",
            //                     gicnfconfirmationcount: "",
            //                     gicnfmaterialdocyear: ""
            //                 };

            //                 oCalenderingPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                     success: function () {
            //                         console.log(`🔄 gicnfmaterialdocnumber updated for row ${index + 1}`);
            //                         row.gicnfmaterialdocnumber = "";
            //                         row.gicnfconfirmationgroup = "";
            //                         row.gicnfconfirmationcount = "";
            //                         row.gicnfmaterialdocyear = "";
            //                         checkCompletion();
            //                     },
            //                     error: function () {
            //                         console.warn(`⚠️ Failed to update gicnfmaterialdocnumber for row ${index + 1}`);
            //                         checkCompletion();
            //                     }
            //                 });
            //             },
            //             error: function (oError) {
            //                 console.error(`❌ Reverse issue failed for row ${index + 1}`, oError);
            //                 checkCompletion();
            //             }
            //         });
            //     });

            //     function checkCompletion() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Reverse issue process completed.");
            //         }
            //     }
            // },

            checkUserHasGoodsIssueReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReverseIssuePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1_FG");
                const oTablePlanModel = oView.getModel("ZSB_FG_PROCESS_PLAN");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse issue.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Prevent if any row has GR material doc
                const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
                if (aHasGRRows.length > 0) {
                    sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
                    return;
                }

                // Check missing GI material doc
                const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
                if (aInvalidRows1.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Porderno: row.productionorderno,
                            ConfirmationGroup: row.gicnfconfirmationgroup,
                            ConfirmationCount: row.gicnfconfirmationcount
                        };

                        console.log(`📤 Sending Reverse Issue Payload for row ${i + 1}:`, oPayload);

                        // Wait for reverse API
                        const oData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZDD_CNFISSUERSV1_FG", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse issue success for row ${i + 1}:`, oData);

                        const sUpdatePath = "/ZC_FG_PROCESS_PLAN('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            gicnfmaterialdocnumber: "",
                            gicnfconfirmationgroup: "",
                            gicnfconfirmationcount: "",
                            gicnfmaterialdocyear: ""
                        };

                        // Wait for update
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI row
                        row.gicnfmaterialdocnumber = "";
                        row.gicnfconfirmationgroup = "";
                        row.gicnfconfirmationcount = "";
                        row.gicnfmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse issue process completed.");

                } catch (error) {
                    console.error("❌ Error during reverse issue:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Issue process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },







            onMaterialValueHelp: function (oEvent) {
                this._oMaterialInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);

                // Create fragment if not already created
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                        this
                    );
                    oView.addDependent(this._oMaterialDialog);
                }

                var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
                var that = this;

                // Only fetch materials with ProductGroup = "MIXING"
                oModel.read("/ZC_MATERIALMASTER1", {
                    filters: [
                        new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "CALENDER")
                    ],
                    success: function (oData) {
                        // Create the model for the dialog
                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
                        that._oMaterialDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected materials
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                            "idMaterialTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedMaterials.forEach(material => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === material.Product) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedMaterials = [];

                        // Open the dialog after all processing is done
                        that._oMaterialDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Materials");
                    }
                });
            },

            onMaterialSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

                var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },

            onMaterialSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedMaterials = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onMaterialConfirm: function () {
                if (!this._oTempSelectedMaterials) return;

                // Store selected materials
                this._selectedMaterials = this._oTempSelectedMaterials.slice();

                // Clear old tokens first
                this._oMaterialInputField.removeAllTokens();

                // Add tokens for selected materials
                this._selectedMaterials.forEach(material => {
                    var oToken = new sap.m.Token({
                        key: material.Product,
                        text: material.Product,
                        tooltip: material.ProductName // Optional: show description on hover
                    });
                    this._oMaterialInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null;
                }
            },

            onMaterialTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedMaterials = this._selectedMaterials.filter(
                        material => material.Product !== token.getKey()
                    );
                });
            },

            onMaterialChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);

                        // Also add to selected materials array
                        if (!this._selectedMaterials.find(m => m.Product === sValue)) {
                            this._selectedMaterials.push({
                                Product: sValue,
                                ProductName: sValue // You might want to fetch the actual description if available
                            });
                        }
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },

            onMaterialVHClose: function () {
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null; // reset reference
                }
            },



            onProductionOrderValueHelp: function (oEvent) {
                this._oPOInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

                // Create fragment if not already created
                if (!this._oProductionOrderDialog) {
                    this._oProductionOrderDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                        this
                    );
                    oView.addDependent(this._oProductionOrderDialog);
                }

                var oModel = oView.getModel("ZSB_FG_PROCESS_PLAN");
                var that = this;

                oModel.read("/ZC_FG_PROCESS_PLAN", {
                    urlParameters: { "$top": 1000 }, // fetch top 1000 records
                    success: function (oData) {
                        // Filter out production orders where productionorderno is "0"
                        var aFilteredOrders = oData.results.filter(function (item) {
                            return item.productionorderno && item.productionorderno !== "0";
                        });

                        // Create the model for the dialog with the filtered results
                        var oJSON = new sap.ui.model.json.JSONModel({ Orders: aFilteredOrders });
                        that._oProductionOrderDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected orders
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                            "idProductionOrderTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedProductionOrders.forEach(po => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === po.productionorderno) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedOrders = [];

                        // Open the dialog after all processing is done
                        that._oProductionOrderDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Production Orders");
                    }
                });
            },


            onProductionOrderSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

                var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },
            onProductionOrderSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedOrders = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onProductionOrderConfirm: function () {
                if (!this._oTempSelectedOrders) return;

                // Store selected orders
                this._selectedProductionOrders = this._oTempSelectedOrders.slice();

                // Clear old tokens first
                this._oPOInputField.removeAllTokens();

                // Add tokens for selected production orders
                this._selectedProductionOrders.forEach(po => {
                    var oToken = new sap.m.Token({
                        key: po.productionorderno,
                        text: po.productionorderno
                    });
                    this._oPOInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null;
                }
            },

            onProductionOrderTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedProductionOrders = this._selectedProductionOrders.filter(
                        o => o.productionorderno !== token.getKey()
                    );
                });
            },
            onProductionOrderVHClose: function () {
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null; // reset reference
                }
            },

            onProductionOrderChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue // Display the same value as text for now
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },


        });
    }
);
