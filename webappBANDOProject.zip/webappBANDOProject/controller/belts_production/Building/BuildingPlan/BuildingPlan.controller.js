sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/IconPool",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Component",
    "sap/ui/core/UIComponent",
    "sap/m/routing/Router",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "sap/m/PDFViewer",
    "bando/util/jspdf/html2canvasmin",
    "bando/util/jspdf/jspdfmin",
    "bando/util/importfile/importexcelfile",
  ],
  function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
    "use strict";

    return BaseController.extend("bando.controller.belts_production.BuildingPlan", {
      onInit: function () {
        this._fetchPostedData(); // Initial load


        var TabModel = new sap.ui.model.json.JSONModel({
          Samples: [

          ]

        });
        this.getView().setModel(TabModel, "TabModel");


        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }

        });

        this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");


        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.getRoute("BuildingPlan").attachMatched(this._onRouteMatched, this); // Re-fetch on return
      },

      _onRouteMatched: function () {
        this._fetchPostedData(); // Always refresh from backend on route match
      },


      _fetchPostedData: function () {
        var oView = this.getView();

        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }
        });
        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

        // Safely get the backend model
        var oModel = this.getOwnerComponent().getModel("ZSB_BUILDING_PLAN");
        if (!oModel) {
          sap.m.MessageBox.error("Model 'ZSB_BUILDING_PLAN' not found.");
          return;
        }

        // Show busy indicator during loading
        oView.setBusy(true);

        var prodordFilter = new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '');

        // Call the read function
        oModel.read("/ZC_BUILDING_PLAN", {
          filters: [prodordFilter],

          success: function (oData) {
            // Create a new JSON model and set the data
            var oJSONModel = new sap.ui.model.json.JSONModel();
            oJSONModel.setData({
              Samples: oData.results
            });

            // Attach to view with name 'TabModel'
            oView.setModel(oJSONModel, "TabModel");

            // ✅ Call ComboBox loader after data is set
            this._loadMachineComboBox();

            oView.setBusy(false);
            oModel.refresh();
          }.bind(this), // ✅ BIND the controller context here

          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Failed to retrieve Mixing Plan data.");
            console.error("OData read error:", oError);
          }
        });
      },

      _loadMachineComboBox: function () {
        var oView = this.getView();
        var oTabModel = oView.getModel("TabModel");
        var aSamples = oTabModel.getProperty("/Samples") || [];

        // Get unique machine numbers
        var aUniqueMachineNumbers = [...new Set(aSamples.map(item => item.machinenumber))];

        // Convert to ComboBox item format
        var aComboBoxItems = aUniqueMachineNumbers.map(function (sMachineNumber) {
          return {
            key: sMachineNumber,
            text: sMachineNumber
          };
        });

        // Create JSON model for ComboBox
        var oMachineModel = new sap.ui.model.json.JSONModel({
          MachineNumbers: aComboBoxItems
        });

        // Set the model to the view
        oView.setModel(oMachineModel, "MachineModel");

        // Clear selection in ComboBox (optional)
        var oComboBox = oView.byId("inputMachineNumberFilter");
        if (oComboBox) {
          oComboBox.setSelectedKey("");
        }
      },


      onSelectAll: function (oEvent) {
        const bSelected = oEvent.getParameter("selected");
        const oTableModel = this.getView().getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples") || [];

        aRows.forEach(row => {
          row.__selected = bSelected;
        });

        oTableModel.setProperty("/Samples", aRows);
      },



      onAddRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        // Create a blank row (add fields as required)
        var oNewRow = {
          sap_uuid: "",
          plant: "1200",
          materialcode: "",
          description: "",
          compoundcode: "",
          storagelocation: "",
          machinenumber: "",
          productionorderqty: "",
          productionordstartdate: "",
          // uom: "",
          // balanceQty: "",
          lotbatchno: "",
          manufacturingdate: null,
          expirydate: null,
          batchweight: "",
          operator: "",
          inspector: "",
          savedstatus: "",
          productionorderno: "",
          statusOfProdOrd: "",
          __selected: false
        };

        aData.push(oNewRow);
        oModel.setProperty("/Samples", aData);
      },



      onRemoveRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        var aRowsToKeep = [];
        var bAnyDeleted = false;
        var bAnyBlocked = false;

        aData.forEach(function (row) {
          if (row.__selected) {
            if (!row.sap_uuid || row.sap_uuid.trim() === "") {
              // Deletable row — skip adding to keep list
              bAnyDeleted = true;
            } else {
              // Selected but not deletable — keep it
              aRowsToKeep.push(row);
              bAnyBlocked = true;
            }
          } else {
            // Not selected — keep it
            aRowsToKeep.push(row);
          }
        });

        oModel.setProperty("/Samples", aRowsToKeep);

        // Show appropriate message
        if (bAnyDeleted && bAnyBlocked) {
          sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
        } else if (bAnyBlocked && !bAnyDeleted) {
          sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
        } else if (bAnyDeleted) {
          sap.m.MessageBox.success("Selected rows removed successfully.");
        } else {
          sap.m.MessageBox.information("No rows were selected for deletion.");
        }
      },


      // onNumericLiveChange: function (oEvent) {
      //     var sValue = oEvent.getParameter("value");

      //     // Remove any non-numeric characters (except decimal if needed)
      //     var sCleanedValue = sValue.replace(/[^\d]/g, ""); // only digits allowed

      //     // Optional: allow decimals
      //     // var sCleanedValue = sValue.replace(/[^0-9.]/g, "");

      //     if (sValue !== sCleanedValue) {
      //         oEvent.getSource().setValue(sCleanedValue);
      //     }
      // },
      onNumericLiveChange: function (oEvent) {
        var sValue = oEvent.getParameter("value");

        // Allow digits, commas, and periods
        var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

        // Optional (if you want to normalize double dots or commas)
        // Limit to only one dot and one comma max
        var hasDot = false;
        var hasComma = false;
        sCleanedValue = sCleanedValue
          .split("")
          .filter(char => {
            if (char === "." && !hasDot) {
              hasDot = true;
              return true;
            } else if (char === "," && !hasComma) {
              hasComma = true;
              return true;
            } else if (/\d/.test(char)) {
              return true;
            }
            return false;
          })
          .join("");

        // Set the cleaned value back if changed
        if (sValue !== sCleanedValue) {
          oEvent.getSource().setValue(sCleanedValue);
        }
      },













      onBeforeRendering: function () {
        var oUserInfo = sap.ushell.Container.getService("UserInfo");
        this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
      },


      onFilterProdStart: function () {
        const oView = this.getView();
        const oDatePicker = oView.byId("dpFilterProdStart");
        const oModel = oView.getModel("ZSB_BUILDING_PLAN"); // ODataModel
        const oTabModel = oView.getModel("TabModel");      // Local JSONModel for table binding

        // Get selected date
        const oDate = oDatePicker.getDateValue();

        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '') // Only empty production order
        ];

        if (oDate) {
          // Format date to yyyy-MM-dd
          const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          const sSelectedDate = oDateFormat.format(oDate);

          // Add date filter
          aFilters.push(new sap.ui.model.Filter("productionordstartdate", sap.ui.model.FilterOperator.EQ, sSelectedDate));
        }

        sap.ui.core.BusyIndicator.show(0);

        // Perform OData read with combined filters
        oModel.read("/ZC_BUILDING_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []); // No results
              sap.m.MessageToast.show("No records found for selected criteria");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend");
          }
        });
      },
      onFilterMachineNumber: function () {
        const oView = this.getView();
        const oComboBox = oView.byId("inputMachineNumberFilter");
        const sSelectedMachine = oComboBox.getSelectedKey();

        const oModel = oView.getModel("ZSB_BUILDING_PLAN"); // Your ODataModel
        const oTabModel = oView.getModel("TabModel");      // Your table model

        // Validate selection
        if (!sSelectedMachine) {
          // Reload full dataset
          this._fetchPostedData();
          return;
        }


        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, ''), // Only empty prod orders
          new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, sSelectedMachine)
        ];

        // Show loading indicator
        sap.ui.core.BusyIndicator.show(0);

        // Perform filtered read
        oModel.read("/ZC_BUILDING_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []);
              sap.m.MessageToast.show("No records found for selected Machine Number");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend.");
          }
        });
      },





      // onImportExl: function () {
      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       // const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });


      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("buildingtabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));
      //       // const mapped = jsonData.map(row => {
      //       //     const obj = {};
      //       //     headers.forEach((hdr, idx) => {
      //       //         const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //       //         if (field) {
      //       //             const rawValue = row[Object.keys(row)[idx]];
      //       //             obj[field] = rawValue;
      //       //         }
      //       //     });
      //       //     return obj;
      //       // });
      //       const mapped = jsonData.map(row => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // 🔁 Convert Excel serial number to JS Date
      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               const utcValue = utcDays * 86400; // seconds
      //               rawValue = new Date(utcValue * 1000); // convert to ms
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });


      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1"); //ZSB_MATERIALMASTER
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // ✅ 1. Validate Material Codes & Fetch Product Names
      //       const aUniqueMaterials = [...new Set(aSelectedRows.map(r => r.materialcode))];
      //       const aMaterialFilters = new sap.ui.model.Filter({
      //         filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
      //         and: false
      //       });

      //       const oMaterialDataMap = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters: [aMaterialFilters],
      //           success: function (oData) {
      //             const map = {};
      //             oData.results.forEach(entry => {
      //               map[entry.Product] = entry.ProductName;
      //             });
      //             resolve(map);
      //           },
      //           error: reject
      //         });
      //       });

      //       const aValidMaterials = Object.keys(oMaterialDataMap);
      //       const aInvalidMaterials = aUniqueMaterials.filter(mat => !aValidMaterials.includes(mat));
      //       const aInvalidMaterialMessages = aSelectedRows
      //         .map((row, idx) => {
      //           if (aInvalidMaterials.includes(row.materialcode)) {
      //             return `Row ${idx + 1}: Material code "${row.materialcode}" is invalid.`;
      //           }
      //           return null;
      //         })
      //         .filter(Boolean);

      //       if (aInvalidMaterialMessages.length > 0) {
      //         aErrors.push("Invalid Material Code(s):\n\n" + aInvalidMaterialMessages.join("\n"));
      //       }

      //       // ✅ Overwrite Excel descriptions with ProductName
      //       // aSelectedRows.forEach(row => {
      //       //     if (oMaterialDataMap[row.materialcode]) {
      //       //         row.description = oMaterialDataMap[row.materialcode]; // Overwrite
      //       //     }
      //       // });

      //       //2nd best whothpitut date
      //       aSelectedRows.forEach(row => {
      //         const fullProductName = oMaterialDataMap[row.materialcode];
      //         if (fullProductName) {
      //           row.description = fullProductName;

      //           // ✅ Extract before '(' for compoundcode
      //           const parts = fullProductName.split("(");
      //           const productNameOnly = parts[0]?.trim() || fullProductName;
      //           row.compoundcode = productNameOnly;
      //         }
      //       });





      //       // ✅ 2. Validate Machine Combinations
      //       const comboFilters = new sap.ui.model.Filter({
      //         filters: aSelectedRows.map(row =>
      //           new sap.ui.model.Filter({
      //             filters: [
      //               new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //               new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //               new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //             ],
      //             and: true
      //           })
      //         ),
      //         and: false
      //       });

      //       const aValidCombos = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //           filters: [comboFilters],
      //           success: function (oData) {
      //             const keys = oData.results.map(
      //               r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //             );
      //             resolve(keys);
      //           },
      //           error: reject
      //         });
      //       });

      //       const aInvalidRowsCombo = aSelectedRows
      //         .map((row, idx) => {
      //           const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //           if (!aValidCombos.includes(key)) {
      //             return `Row ${idx + 1}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}"`;
      //           }
      //           return null;
      //         })
      //         .filter(Boolean);

      //       if (aInvalidRowsCombo.length > 0) {
      //         aErrors.push("Invalid Production Version Assignments:\n\n" + aInvalidRowsCombo.join("\n"));
      //       }

      //       // ❌ If any errors exist, show them
      //       if (aErrors.length > 0) {
      //         sap.m.MessageBox.error(aErrors.join("\n\n"));
      //         return;
      //       }

      //       // ✅ All validations passed — import data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(mapped);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");
      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }

      //   // Trigger file selection
      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },



onImportExl: function () {
                const that = this;

                function ensureXLSX(cb) {
                    if (window.XLSX) return cb();

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = e.target.result;
                        const workbook = XLSX.read(data, { type: "binary" });
                        const sheet = workbook.Sheets[workbook.SheetNames[0]];
                        // const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "" });
                        const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });


                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        const table = that.byId("buildingtabl");
                        const columns = table.getColumns();
                        const fieldNames = columns.map(col => {
                            const template = col.getTemplate();
                            const bindInfo =
                                template.getBindingInfo("value") ||
                                template.getBindingInfo("text") ||
                                template.getBindingInfo("selected") ||
                                template.getBindingInfo("selectedKey");
                            return bindInfo?.parts?.[0]?.path || null;
                        }).filter(Boolean);

                        const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));
                        // const mapped = jsonData.map(row => {
                        //     const obj = {};
                        //     headers.forEach((hdr, idx) => {
                        //         const field = fieldNames.find(f => f.toLowerCase() === hdr);
                        //         if (field) {
                        //             const rawValue = row[Object.keys(row)[idx]];
                        //             obj[field] = rawValue;
                        //         }
                        //     });
                        //     return obj;
                        // });
                        const mapped = jsonData.map(row => {
                            const obj = {};
                            headers.forEach((hdr, idx) => {
                                const field = fieldNames.find(f => f.toLowerCase() === hdr);
                                if (field) {
                                    let rawValue = row[Object.keys(row)[idx]];

                                    // 🔁 Convert Excel serial number to JS Date
                                    if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
                                        const utcDays = Math.floor(rawValue - 25569);
                                        const utcValue = utcDays * 86400; // seconds
                                        rawValue = new Date(utcValue * 1000); // convert to ms
                                    }

                                    obj[field] = rawValue;
                                }
                            });
                            return obj;
                        });


                        validateAndImport(mapped);
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsBinaryString(file);
                }

                
                async function validateAndImport(mapped) {
                    const oView = that.getView();
                    const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
                    const oQtyModel = oView.getModel("ZSB_PROD_QTY"); // 🆕 Production Qty model
                    const aSelectedRows = mapped;

                    try {
                        const aErrors = [];

                        // 🧠 STEP 1: Gather all unique material codes and descriptions
                        const aUniqueMaterials = [...new Set(
                            aSelectedRows
                                .map(r => String(r.materialcode || "").trim())
                                .filter(Boolean)
                        )];

                        const aUniqueDescriptions = [...new Set(
                            aSelectedRows
                                .map(r => String(r.description || "").trim())
                                .filter(Boolean)
                        )];

                        if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
                            sap.m.MessageBox.error("No material data found in the Excel file.");
                            return;
                        }

                        // 🧠 STEP 2: Build filters for both code and description
                        const filters = [];
                        if (aUniqueMaterials.length > 0) {
                            filters.push(new sap.ui.model.Filter({
                                filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
                                and: false
                            }));
                        }
                        if (aUniqueDescriptions.length > 0) {
                            filters.push(new sap.ui.model.Filter({
                                filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
                                and: false
                            }));
                        }

                        // 🧠 STEP 3: Fetch material master data
                        const oMaterialResults = await new Promise((resolve, reject) => {
                            oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
                                filters,
                                success: data => resolve(data.results || []),
                                error: reject
                            });
                        });

                        // Build lookup maps
                        const codeToName = {};
                        const nameToCode = {};
                        oMaterialResults.forEach(entry => {
                            const code = String(entry.Product).trim();
                            const name = String(entry.ProductName).trim();
                            codeToName[code] = name;
                            nameToCode[name] = code;
                        });

                        // 🧠 STEP 4: Validate & enrich each row
                        aSelectedRows.forEach((row, idx) => {
                            const code = String(row.materialcode || "").trim();
                            const desc = String(row.description || "").trim();

                            if (!code && !desc) {
                                aErrors.push(`Row ${idx + 1}: Material code and description both missing.`);
                                return;
                            }

                            if (code && !desc) {
                                if (codeToName[code]) {
                                    row.description = codeToName[code];
                                } else {
                                    aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
                                }
                            } else if (!code && desc) {
                                if (nameToCode[desc]) {
                                    row.materialcode = nameToCode[desc];
                                } else {
                                    aErrors.push(`Row ${idx + 1}: Description "${desc}" not found in material master.`);
                                }
                            } else if (code && desc) {
                                const validDesc = codeToName[code];
                                if (!validDesc) {
                                    aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
                                } else if (validDesc !== desc) {
                                    aErrors.push(
                                        `Row ${idx + 1}: Description "${desc}" does not match material "${code}" (expected "${validDesc}").`
                                    );
                                }
                            }

                            const finalDesc = String(row.description || "").trim();
                            if (finalDesc) {
                                const base = finalDesc.split("(")[0]?.trim() || finalDesc;
                                row.compoundcode = base;
                            }
                        });

                        // 🧠 STEP 5: Validate Machine Combinations
                        const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

                        if (rowsWithMachine.length > 0) {
                            const comboFilters = new sap.ui.model.Filter({
                                filters: rowsWithMachine.map(row =>
                                    new sap.ui.model.Filter({
                                        filters: [
                                            new sap.ui.model.Filter("Plant", "EQ", row.plant),
                                            new sap.ui.model.Filter("Material", "EQ", row.materialcode),
                                            new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
                                        ],
                                        and: true
                                    })
                                ),
                                and: false
                            });

                            const validCombos = await new Promise((resolve, reject) => {
                                oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
                                    filters: [comboFilters],
                                    success: data => resolve(
                                        (data.results || []).map(
                                            r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
                                        )
                                    ),
                                    error: reject
                                });
                            });

                            const invalidCombos = rowsWithMachine
                                .map((row, idx) => {
                                    const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
                                    if (!validCombos.includes(key)) {
                                        const trueIdx = aSelectedRows.indexOf(row);
                                        return `Row ${trueIdx + 1}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
                                    }
                                    return null;
                                })
                                .filter(Boolean);

                            if (invalidCombos.length > 0) {
                                aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
                            }
                        }

                        // 🧠 STEP 6: Fetch Production Quantity for each unique material individually and set 0.000 if not found

                        // Prepare unique valid materials for production qty fetching
                        const aUniqueValidMaterials = [...new Set(
                            aSelectedRows
                                .map(r => String(r.materialcode || "").trim())
                                .filter(Boolean)
                        )];
                        const aProdQtyPromises = aUniqueValidMaterials.map(mat =>
                            new Promise((resolve, reject) => {
                                oQtyModel.read("/ZC_PROD_QTY", {
                                    filters: [new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, mat)],
                                    success: function (oData) {
                                        resolve({
                                            material: mat,
                                            qty: oData.results?.[0]?.Qty || "0.000",
                                            baseunit: oData.results?.[0]?.BaseUnit || ""
                                        });
                                    },
                                    error: function (err) {
                                        console.error("Production order qty fetch failed for", mat, err);
                                        resolve({ material: mat, qty: "0.000", baseunit: "" });
                                    }
                                });
                            })
                        );

                        const aProdQtyResults = await Promise.all(aProdQtyPromises);

                        const qtyMap = {};
                        aProdQtyResults.forEach(entry => {
                            qtyMap[entry.material] = {
                                Qty: entry.qty,
                                BaseUnit: entry.baseunit
                            };
                        });

                        // Assign qty and base unit to each row
                        aSelectedRows.forEach(row => {
                            const mat = String(row.materialcode || "").trim();
                            if (mat && qtyMap[mat]) {
                                row.productionorderqty = qtyMap[mat].Qty;
                                row.baseunit = qtyMap[mat].BaseUnit;
                            } else {
                                // If material not found in qtyMap, set productionorderqty to 0.000 anyway
                                row.productionorderqty = "0.000";
                                row.baseunit = "";
                            }
                        });


                        // 🚫 STEP 7: Show all accumulated errors together
                        if (aErrors.length > 0) {
                            sap.m.MessageBox.error(aErrors.join("\n\n"));
                            return;
                        }

                        // ✅ STEP 8: Import Validated & Enriched Data
                        const oModel = oView.getModel("TabModel");
                        const existingData = oModel.getProperty("/Samples") || [];
                        const updatedData = existingData.concat(aSelectedRows);
                        oModel.setProperty("/Samples", updatedData);

                        sap.m.MessageToast.show("Data imported and validated successfully.");

                    } catch (error) {
                        console.error("Validation error:", error);
                        sap.m.MessageBox.error("Validation failed. Please try again.");
                    }
                }





                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";

                fileInput.addEventListener("change", function (e) {
                    const file = e.target.files[0];
                    if (!file) return;
                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                });

                document.body.appendChild(fileInput);
                fileInput.click();
            },






      //final export code 
      onExportExl: function () {
        const oModel = this.getView().getModel("TabModel");
        const aData = oModel.getProperty("/Samples");

        const aColumns = [
          { label: "Plant", property: "plant" },
          { label: "Material Code", property: "materialcode" },
          { label: "Description", property: "description" },
          { label: "Machine Number", property: "machinenumber" },
          { label: "Production Order Qty", property: "productionorderqty" },
          { label: "productionordstartdate", property: "productionordstartdate" },
          { label: "Lot/Batch-No", property: "lotbatchno" },
          { label: "Production Order No", property: "productionorderno" },
          { label: "Compound Code", property: "compoundcode" },
          { label: "Storage Location", property: "storagelocation" },
          { label: "Manufacturing Date", property: "manufacturingdate" },
          { label: "Expiry Date", property: "expirydate" },
          { label: "Batch Weight", property: "batchweight" },
          { label: "operator", property: "operator" },
          { label: "inspector", property: "inspector" },
        ];

        // If no data, still export empty row just to include headers
        const aSafeData = Array.isArray(aData) && aData.length > 0 ? aData : [{}];

        const oSpreadsheet = new sap.ui.export.Spreadsheet({
          workbook: {
            columns: aColumns,
            context: {
              sheetName: "Building Plan"
            }
          },
          dataSource: aSafeData,
          fileName: "Building_Plan_Export.xlsx"
        });

        oSpreadsheet.build().then(() => {
          sap.m.MessageToast.show("Export completed.");
        }).catch(function (oError) {
          sap.m.MessageBox.error("Export failed: " + oError.message);
        });
      },



      // { label: "UOM", property: "uom" },
      //         { label: "Balance Qty", property: "balanceQty" },



      //         { label: "Saved Status", property: "savedstatus" },

      //         { label: "Status of Production Order", property: "statusOfProdOrd" }














      onFetchMixingPlanData: function (plannedOrderNo) {
        var that = this;

        if (plannedOrderNo !== null) {
          var oModel = this.getView().getModel("TabModel");
          var aData = oModel.getProperty("/Samples");
          console.log("processOrderNo not found");
          return new Promise(function (resolve, reject) {
            try {
              // ✅ Show busy indicator
              // sap.ui.core.BusyIndicator.show(0);

              var oFilter = new sap.ui.model.Filter("plannedorderno", sap.ui.model.FilterOperator.EQ, plannedOrderNo);
              var oModel2 = that.getView().getModel("ZSB_BUILDING_PLAN");

              oModel2.read("/ZC_BUILDING_PLAN", {
                filters: [oFilter],
                success: function (oData) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  var aItems = oData.results;
                  console.log("aItems:", aItems);

                  var oTarget = aData.find(function (item) {
                    return item.processOrderNo === plannedOrderNo;
                  });

                  if (oTarget) {
                    if (aItems.length > 0) {
                      oTarget.machinenumber = aItems[0].machinenumber || null;
                      oTarget.productionOrderQty = aItems[0].productionorderqty || null;
                      oTarget.balanceQty = aItems[0].balanceqty || null;
                      oTarget.LotBatchNo = aItems[0].lotbatchno || null;
                      oTarget.ManufacturingDate = aItems[0].manufacturingdate || null;
                      oTarget.ExpiryDate = aItems[0].expirydate || null;
                      oTarget.batchweight = aItems[0].batchweight || null;
                      oTarget.Operator = aItems[0].operator || null;
                      oTarget.Inspector = aItems[0].inspector || null;
                      oTarget.savedstatus = aItems[0].status || null;
                    } else {
                      oTarget.machinenumber = null;
                      oTarget.productionOrderQty = null;
                      oTarget.balanceQty = null;
                      oTarget.LotBatchNo = null;
                      oTarget.ManufacturingDate = null;
                      oTarget.ExpiryDate = null;
                      oTarget.batchweight = null;
                      oTarget.Operator = null;
                      oTarget.Inspector = null;
                      oTarget.savedstatus = null;
                    }

                    oModel.refresh();
                  } else {
                    console.log("processOrderNo not found");
                  }

                  resolve(aItems.length > 0 ? (aItems[0].machinenumber || null) : null);
                },
                error: function (oError) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  console.error("Error reading data: ", oError);
                  reject(oError);
                }
              });
            } catch (e) {
              // ✅ Hide busy indicator in case of unexpected error
              sap.ui.core.BusyIndicator.hide();

              console.error("Unexpected error: ", e);
              reject(e);
            }
          });
        }
      },



      generateUUID: function () {
        return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          const r = Math.random() * 16 | 0,
            v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
      },


      onSavePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_BUILDING_PLAN");

        const aData = oView.getModel("TabModel").getProperty("/Samples");


        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
          return;
        }


        // ✅ Separate validation for Production Order Qty
  const invalidQtyRows = aSelectedRows.filter(row => 
    row.productionorderno !== null && 
    row.productionorderno !== undefined && 
    Number(row.productionorderno) !== 0
  );

  if (invalidQtyRows.length > 0) {
    const invalidIndexes = invalidQtyRows.map(row => aData.indexOf(row) + 1);
    sap.m.MessageBox.error(
      "Cannot save. The following selected row(s) already have a Production Order Quantity (not 0 or empty):\n\n" +
      invalidIndexes.join(", ")
    );
    return;
  }




        // ✅ Validate mandatory fields
        const aInvalidRows = [];

        aSelectedRows.forEach((row, index) => {
          const missingFields = [];

          // if (!row.plant) missingFields.push("Plant");
          if (!row.machinenumber) missingFields.push("Machine Number");
          // if (!row.lotbatchno) missingFields.push("lot batchno");
          if (!row.materialcode) missingFields.push("Material Code");
          // if (!row.productionorderqty) missingFields.push("Production Order Qty");
          if (!row.productionordstartdate) missingFields.push("Production order start Date");
          // if (!row.storagelocation) missingFields.push("storage location");

          if (missingFields.length > 0) {
            const rowIndex = aData.indexOf(row) + 1; // Get actual row number from full dataset
            aInvalidRows.push(`Row ${rowIndex} is missing: ${missingFields.join(", ")}`);
          }
        });

        if (aInvalidRows.length > 0) {
          sap.m.MessageBox.error(
            "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
          );
          return;
        }



        sap.ui.core.BusyIndicator.show(0);

        const aPromises = aSelectedRows.map(row => {

          const oPayload = {
            sap_uuid: this.generateUUID(),
            plant: "1200",
            materialcode: row.materialcode,
            // plannedorderno: row.plannedOrderNo,
            // plannedOrderQty: oItem.PlannedOrderQty,
            // plannedOrdDate: oItem.PlannedOrderDate

            description: row.description,
            compoundcode: row.compoundcode,
            machinenumber: row.machinenumber,
            productionorderqty: String(row.productionorderqty) || "0",
            // Mfgorderplannedenddate:row.productionordstartdate ? `/Date(${new Date(row.productionordstartdate).getTime()})/` : null,

            // productionordstartdate: row.productionordstartdate.toLocaleDateString('en-CA'), //.toLocaleDateString("en-GB")
            productionordstartdate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,

            // zdate: rowData.zdate ? new Date(rowData.zdate.toLocaleDateString('en-CA')) : null,

            storagelocation: row.storagelocation,
            // uom: row.uom,
            lotbatchno: row.lotbatchno,
            manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,

            // expirydate: row.expirydate.toLocaleDateString('en-CA'),
            batchweight: row.batchweight || "0",
            operator: row.operator,
            inspector: row.inspector,
            productionorderno: null,
            status: "GT",
            // productionorddate: row.plannedOrdDate ? `/Date(${new Date(row.plannedOrdDate).getTime()})/` : null,
            // confirmedqty: parseFloat(row.productionorderqty),
            // defectqty: "0",
            // balanceqty: row.balanceQty,
            // releasestatus: "",
            // goodsissueconfirmationstatus: "",
            // gicnfmaterialdocnumber: "",
            // goodsreceiptstatus: "",
            // grmaterialdocnumber: "",
            // overallstatus: "",
            // itemstatus: "",
            // status:"yes",
            screenname: "JOINTING",
            screencode: "MP01",
            createdat: new Date(),
            createdby: this.sUserId
          };

          return new Promise((resolve, reject) => {
            oModel.create("/ZC_BUILDING_PLAN", oPayload, {
              success: resolve,
              error: reject
            });
          });
        });
        var that = this;

        Promise.allSettled(aPromises).then(async results => {
          sap.ui.core.BusyIndicator.hide();

          const aFailed = results.filter(r => r.status === "rejected");
          if (aFailed.length > 0) {
            sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post.`);
          } else {
            // let oMixingPostDatas = await that.ToFetchMixingPlanData();
            that._fetchPostedData();
            // debugger
            sap.m.MessageBox.success("All selected rows posted successfully.", {
              onClose: () => {
                oModel.refresh(true); // Reloads all bindings
              }
            });

          }
        });
      },




      onDeletePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_BUILDING_PLAN");
        const oTabModel = oView.getModel("TabModel");
        const aData = oTabModel.getProperty("/Samples");

        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row to delete.");
          return;
        }
        if (aSelectedRows.some(row => !row.sap_uuid)) {
          sap.m.MessageBox.warning("Row not saved to delete.");
          return;
        }
        if (aSelectedRows.some(row => row.productionorderno && row.productionorderno !== "0")) {
          sap.m.MessageBox.error("Cannot delete rows that already have a Production order No.");
          return;
        }

        sap.m.MessageBox.confirm(
          `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
          {
            title: "Confirm Deletion",
            actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
            onClose: function (oAction) {
              if (oAction !== sap.m.MessageBox.Action.OK) return;

              sap.ui.core.BusyIndicator.show(0);

              const aDeletePromises = aSelectedRows.map(row => {
                return new Promise((resolve, reject) => {
                  if (!row.sap_uuid) {
                    reject("Missing sap_uuid for deletion.");
                    return;
                  }

                  const sKeyPath = `/ZC_BUILDING_PLAN(sap_uuid='${row.sap_uuid}')`;

                  oModel.remove(sKeyPath, {
                    success: resolve,
                    error: reject
                  });
                });
              });

              Promise.allSettled(aDeletePromises).then(results => {
                sap.ui.core.BusyIndicator.hide();

                const aFailed = results.filter(r => r.status === "rejected");
                const aSuccess = results.filter(r => r.status === "fulfilled");

                // Remove deleted rows from TabModel local data
                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                oTabModel.setProperty("/Samples", aRemainingData);

                if (aSuccess.length > 0) {
                  sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                }

                if (aFailed.length > 0) {
                  sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                  console.error("Deletion errors:", aFailed);
                }
              });
            }
          }
        );
      },











      // Fragment for material - product

      onMaterialFragmentOpen: function (oEvent) {
                // console.log("hi")
                sap.ui.core.BusyIndicator.show();  // Show busy indicator when starting
                this.EventRowCollNo = oEvent.getSource().getParent();

                var mod01 = this.getView().getModel("TabModel");
                var ItemTableModel = mod01.getProperty("/Samples");

                const input = oEvent.getSource(); // the Input field
                const context = input.getBindingContext("TabModel");

                if (context) {
                    const rowPath = context.getPath();
                    const rowData = context.getObject();

                    // var mod01 = this.getView().getModel("TabModel");
                    // var ItemTableModel = mod01.getProperty(rowPath)
                    // const rowData = ItemTableModel;

                    this.oEventModelRowDatas = rowData;
                    this.oEventModelRowPath = rowPath;

                    if (rowData.plant === "") {
                        sap.m.MessageBox.information("Please enter the plant...")
                        sap.ui.core.BusyIndicator.hide();
                        return;
                    }

                    var that = this;

                    var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);
                    var productGroupFilter = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "41");


                    this._oBasicSearchField = new sap.m.SearchField();

                    this.loadFragment({
                        name: "bando.view.CommonFragments.PlanScreens.materialmaster"
                    }).then(function (oDialog) {
                        // bando.view.CommonFragments.PlanScreens.
                        var oFilterBar = oDialog.getFilterBar(),
                            oColumnProductCode, oColumnProductName, oColumnPlant;

                        this._oVHD_Product = oDialog;
                        this.getView().addDependent(oDialog);

                        // Set key fields for filtering in the Define Conditions Tab
                        oDialog.setRangeKeyFields([{
                            label: "Product",
                            key: "Product",
                            type: "string",
                            typeInstance: new sap.ui.model.type.String({}, {
                                maxLength: 10
                            })
                        }]);

                        // Set Basic Search for FilterBar
                        oFilterBar.setFilterBarExpanded(false);
                        oFilterBar.setBasicSearch(this._oBasicSearchField);

                        // Trigger filter bar search when the basic search is fired
                        this._oBasicSearchField.attachSearch(function () {
                            oFilterBar.search();
                        });

                        oDialog.getTableAsync().then(function (oTable) {
                            // Get the model for the products and bind it to the table
                            oTable.setModel(this.oProductsModel);

                            // Apply plant filter to the data binding

                            // For Desktop and tablet, the default table is sap.ui.table.Table
                            if (oTable.bindRows) {
                                // Bind rows to the ODataModel with a filter for plant
                                // ZSB_MATERIALMASTER
                                oTable.bindAggregation("rows", {
                                    path: "ZSB_MATERIALMASTER1>/ZC_MATERIALMASTER1",
                                    filters: [plantFilter, productGroupFilter], // Apply the plant filter here
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });
                                //ZSB_MATERIALMASTER

                                // Define columns for the table
                                oColumnProductCode = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "Product" }),
                                    template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Product}" })
                                });
                                oColumnProductCode.data({
                                    fieldName: "Product"
                                });

                                oColumnProductName = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "ProductName" }),
                                    template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>ProductName}" })
                                });
                                oColumnProductName.data({
                                    fieldName: "ProductName"
                                });

                                oColumnPlant = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "Plant" }),
                                    template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Plant}" })
                                });
                                oColumnPlant.data({
                                    fieldName: "Plant"
                                });

                                oTable.addColumn(oColumnProductCode);
                                oTable.addColumn(oColumnProductName);
                                oTable.addColumn(oColumnPlant);
                            }
                            //ZSB_MATERIALMASTER

                            // For Mobile, the default table is sap.m.Table
                            if (oTable.bindItems) {
                                // Bind items to the ODataModel with a filter for plant
                                oTable.bindAggregation("items", {
                                    path: "ZSB_MATERIALMASTER1>/ZC_MATERIALMASTER1",
                                    filters: [plantFilter], // Apply the plant filter here
                                    template: new sap.m.ColumnListItem({
                                        cells: [
                                            new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Product}" }),
                                            new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductName}" }),
                                            new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Plant}" }),
                                        ]
                                    }),
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                // Add columns for mobile/table view
                                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product" }) }));
                                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "ProductName" }) }));
                                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
                            }

                            // Open the dialog
                            oDialog.open();
                            sap.ui.core.BusyIndicator.hide(); // Hide the busy indicator after dialog opens
                        }.bind(this));
                    }.bind(this));
                }
            },



            onValueHelpOkPress_Product: async function (oEvent) {
                sap.ui.core.BusyIndicator.show();

                var aTokens = oEvent.getParameter("tokens");
                let KeyVal = aTokens[0].getKey();   // Product Code
                let TextVal = aTokens[0].getText();

                let parts = TextVal.split("(");
                let ProductCode = KeyVal;
                let ProductName = parts[0].trim();

                var mod01 = this.getView().getModel("TabModel");
                var ItemTableModel = mod01.getProperty(this.oEventModelRowPath);

                // Fill basic material details
                ItemTableModel.materialcode = ProductCode;
                ItemTableModel.description = ProductName;

                var oODataModel = this.getView().getModel("ZSB_MATERIALMASTER1"); // check alias in manifest
                var oProdQty = this.getView().getModel("ZSB_PROD_QTY"); // check alias in manifest

                // 🔥 Fetch BatchWeight
                // oODataModel.read("/ZC_BATCHWEIGHT", {
                //     filters: [
                //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode)
                //     ],
                //     success: function (oData) {
                //         if (oData.results && oData.results.length > 0) {
                //             let batchWeight = oData.results[0].Batchweight;
                //             ItemTableModel.batchweight = batchWeight;
                //         } else {
                //             ItemTableModel.batchweight = "";
                //         }
                //         mod01.refresh();
                //     },
                //     error: function (oError) {
                //         console.error("Batch weight fetch failed", oError);
                //         ItemTableModel.batchweight = "";
                //         mod01.refresh();
                //     }
                // });
                // 🔥 Fetch BatchWeight with additional filters
                oODataModel.read("/ZC_BATCHWEIGHT", {
                    filters: [
                        new sap.ui.model.Filter({
                            filters: [
                                new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode),
                                new sap.ui.model.Filter("ClassType", sap.ui.model.FilterOperator.EQ, "001"),
                                new sap.ui.model.Filter("CharcInternalID", sap.ui.model.FilterOperator.EQ, "0000000833")
                            ],
                            and: true
                        })
                    ],
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            let batchWeight = oData.results[0].Batchweight;
                            ItemTableModel.batchweight = batchWeight;
                        } else {
                            ItemTableModel.batchweight = "";
                        }
                        mod01.refresh();
                    },
                    error: function (oError) {
                        console.error("Batch weight fetch failed", oError);
                        ItemTableModel.batchweight = "";
                        mod01.refresh();
                    }
                });


                // 🔥 Fetch CompoundCode
                oODataModel.read("/ZC_COMPOUNDCODE", {
                    filters: [
                        new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode)
                    ],
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            let compoundCode = oData.results[0].CompoundCode;
                            ItemTableModel.compoundcode = compoundCode;
                        } else {
                            ItemTableModel.compoundcode = "";
                        }
                        mod01.refresh();
                    },
                    error: function (oError) {
                        console.error("Compound code fetch failed", oError);
                        ItemTableModel.compoundcode = "";
                        mod01.refresh();
                    }
                });
                oProdQty.read("/ZC_PROD_QTY", {
                    filters: [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, ProductCode)
                    ],
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            let prodQty = oData.results[0].Qty;
                            let baseUnit = oData.results[0].BaseUnit;

                            // ✅ Set the production order quantity and base unit in the row
                            ItemTableModel.productionorderqty = prodQty;
                            ItemTableModel.baseunit = baseUnit || ""; // optional, if you want to show it elsewhere

                            mod01.refresh();
                        } else {
                            // If no record found, clear the value
                            ItemTableModel.productionorderqty = "";
                            mod01.refresh();
                        }
                    },
                    error: function (oError) {
                        console.error("Production order qty fetch failed", oError);
                        ItemTableModel.productionorderqty = "";
                        mod01.refresh();
                    }
                });


                // ✅ close/destroy dialog (decide on one strategy)
                this._oVHD_Product.destroy();
                sap.ui.core.BusyIndicator.hide();
            },



            onFilterBarSearch_Product: function (oEvent) {
                console.log(oEvent);
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                // Construct filters for search and selection set values
                var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new sap.ui.model.Filter({
                            path: oControl.getName(),
                            operator: sap.ui.model.FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }
                    return aResult;
                }, []);

                aFilters.push(new sap.ui.model.Filter({
                    filters: [
                        new sap.ui.model.Filter({ path: "Product", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
                        new sap.ui.model.Filter({ path: "ProductName", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
                        new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
                        // new sap.ui.model.Filter({ path: "StandardPrice", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
                    ],
                    and: false
                }));

                this._filterTable_Product(new sap.ui.model.Filter({
                    filters: aFilters,
                    and: true
                }));
            },

            _filterTable_Product: function (oFilter) {
                var oVHD = this._oVHD_Product;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // Update the dialog after filtering
                    oVHD.update();
                });
            },

            onValueHelpCancelPress_Product: function () {
                this._oVHD_Product.close(); // Close the value help dialog without making any changes
            },



      //suggest  section for material -product

      onSuggestMaterial: function (oEvent) {
        const sTerm = oEvent.getParameter("suggestValue");
        const oInput = oEvent.getSource();
        const oModel = this.getView().getModel("ZSB_MATERIALMASTER1"); //ZSB_MATERIALMASTER

        if (!sTerm) return;

        // Get context and row info
        const context = oInput.getBindingContext("TabModel");
        let aFilters = [];
        let rowPath, rowData, tabModel;

        if (context) {
          rowPath = context.getPath();
          rowData = context.getObject();
          tabModel = context.getModel();

          if (!rowData.plant) {
            sap.m.MessageBox.information("Please enter the plant...");
            return;
          }

          aFilters.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant));
          aFilters.push(new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "41"));

        }

        // Search term filter
        const oSearchFilter = new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sTerm),

          ],
          and: false
        });

        aFilters.push(oSearchFilter);

        // Fetch suggestions from OData
        oModel.read("/ZC_MATERIALMASTER1", {
          filters: aFilters,
          success: function (oData) {
            oInput.destroySuggestionItems();

            oData.results.forEach(item => {
              const oItem = new sap.ui.core.Item({
                text: `${item.Product} (${item.ProductName})`,
                key: item.Product
              });
              oItem.data("ProductName", item.ProductName); // attach extra data
              oInput.addSuggestionItem(oItem);
            });

            // Attach suggestionItemSelected only once
            if (!oInput._hasSuggestionSelectHandler) {
              oInput.attachSuggestionItemSelected(function (oEvt) {
                const selectedItem = oEvt.getParameter("selectedItem");
                if (!selectedItem || !context) return;

                const sSelectedKey = selectedItem.getKey();
                const sSelectedText = selectedItem.getText();
                const productName = selectedItem.data("ProductName") || sSelectedText;

                // Set values in model
                tabModel.setProperty(rowPath + "/materialcode", sSelectedKey);
                tabModel.setProperty(rowPath + "/description", productName);
                tabModel.setProperty(rowPath + "/compoundcode", productName);
                tabModel.refresh();
              });
              oInput._hasSuggestionSelectHandler = true; // prevent double attachment
            }
          },
          error: function () {
            console.error("Failed to fetch suggestions");
          }
        });
      },




      // End Fragment for material - product


      // Start Fragment for Productionversion

      onProductVersionFrag: function (oEvent) {
        sap.ui.core.BusyIndicator.show();  // Show busy indicator when starting
        this.EventRowCollNo = oEvent.getSource().getParent();

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty("/Samples");

        const input = oEvent.getSource(); // the Input field
        const context = input.getBindingContext("TabModel");

        if (context) {
          const rowPath = context.getPath();
          const rowData = context.getObject();

          // var mod01 = this.getView().getModel("TabModel");
          // var ItemTableModel = mod01.getProperty(rowPath)
          // const rowData = ItemTableModel;

          this.oEventModelRowDatas = rowData;
          this.oEventModelRowPath = rowPath;

          if (rowData.plant === "") {
            sap.m.MessageBox.information("Please enter the plant...")
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          if (rowData.materialcode === "") {
            sap.m.MessageBox.information("Please enter the Material...")
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          var that = this;

          var MaterialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, rowData.materialcode);
          var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);

          this._oBasicSearchField = new sap.m.SearchField();

          this.loadFragment({
            name: "bando.view.CommonFragments.PlanScreens.productionversion"
          }).then(function (oDialog) {
            var oFilterBar = oDialog.getFilterBar(),
              oColumnProduct, oColumnProductionVersion, oColumnPlant;

            this._ProdVer = oDialog;
            this.getView().addDependent(oDialog);

            // Set key fields for filtering in the Define Conditions Tab
            oDialog.setRangeKeyFields([{
              label: "Product",
              key: "Product",
              type: "string",
              typeInstance: new sap.ui.model.type.String({}, {
                maxLength: 10
              })
            }]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchField.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.getTableAsync().then(function (oTable) {
              // Get the model for the products and bind it to the table
              oTable.setModel(this.oProductsModel);

              // Apply plant filter to the data binding

              // For Desktop and tablet, the default table is sap.ui.table.Table
              //ZSB_MATERIALMASTER
              if (oTable.bindRows) {
                // Bind rows to the ODataModel with a filter for plant
                oTable.bindAggregation("rows", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter, MaterialFilter], // Apply the plant filter here
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Define columns for the table
                //ZSB_MATERIALMASTER
                oColumnProductionVersion = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "ProductionVersion" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>ProductionVersion}" })
                });
                oColumnProductionVersion.data({
                  fieldName: "ProductionVersion"
                });

                oColumnProduct = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Material" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Material}" })
                });
                oColumnProduct.data({
                  fieldName: "Material"
                });

                oColumnPlant = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Plant" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Plant}" })
                });
                oColumnPlant.data({
                  fieldName: "Plant"
                });

                oTable.addColumn(oColumnProductionVersion);
                oTable.addColumn(oColumnProduct);
                oTable.addColumn(oColumnPlant);
              }

              // For Mobile, the default table is sap.m.Table
              //ZSB_MATERIALMASTER
              if (oTable.bindItems) {
                // Bind items to the ODataModel with a filter for plant
                oTable.bindAggregation("items", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter], // Apply the plant filter here
                  template: new sap.m.ColumnListItem({
                    cells: [
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductionVersion}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Material}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Plant}" }),
                    ]
                  }),
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Add columns for mobile/table view
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "ProductionVersion" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Material" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
              }

              // Open the dialog
              oDialog.open();
              sap.ui.core.BusyIndicator.hide(); // Hide the busy indicator after dialog opens
            }.bind(this));
          }.bind(this));
        }
      },

      onValueHelpOkPress_ProdVer: async function (oEvent) {
        sap.ui.core.BusyIndicator.show();
        // this.oEventModelRowDatas = rowData;
        // this.oEventModelRowPath = rowPath;

        console.log("this.oEventModelDatas", this.oEventModelRowDatas)
        console.log("this.oEventModelRowPath", this.oEventModelRowPath)

        var aTokens = oEvent.getParameter("tokens");
        let KeyVal = aTokens[0].getKey(); // Get the key of the selected token
        let TextVal = aTokens[0].getText();

        let parts = TextVal.split("(")

        let ProductCode = KeyVal;
        let ProductName = parts[0];

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(this.oEventModelRowPath)
        ItemTableModel.machinenumber = ProductCode
        mod01.refresh()

        // context.getModel().setProperty(`${rowPath}/dipscurrent`, getdipcurr);

        this._ProdVer.destroy(); // Destroy the value help dialog
        sap.ui.core.BusyIndicator.hide();
      },

      onValueHelpCancelPress_ProdVer: function () {
        this._ProdVer.close(); // Close the value help dialog without making any changes
      },

      onFilterBarSearch_ProdVer: function (oEvent) {
        console.log(oEvent);
        var sSearchQuery = this._oBasicSearchField.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet");

        // Construct filters for search and selection set values
        var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(new sap.ui.model.Filter({
              path: oControl.getName(),
              operator: sap.ui.model.FilterOperator.Contains,
              value1: oControl.getValue()
            }));
          }
          return aResult;
        }, []);

        aFilters.push(new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter({ path: "ProductionVersion", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Material", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            // new sap.ui.model.Filter({ path: "StandardPrice", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
          ],
          and: false
        }));

        this._filterTable_ProdVer(new sap.ui.model.Filter({
          filters: aFilters,
          and: true
        }));
      },

      _filterTable_ProdVer: function (oFilter) {
        var oVHD = this._ProdVer;

        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }

          // Update the dialog after filtering
          oVHD.update();
        });
      },



      //suggest  section for  product[MACHINENUMBER]


      onSuggestMachineNumber: function (oEvent) {
        const sTerm = oEvent.getParameter("suggestValue");
        const oInput = oEvent.getSource();
        const oModel = this.getView().getModel("ZSB_MATERIALMASTER1");//ZSB_MATERIALMASTER

        if (!sTerm) return;

        const context = oInput.getBindingContext("TabModel");
        let aFilters = [];

        let rowPath, rowData, tabModel;

        if (context) {
          rowPath = context.getPath();
          rowData = context.getObject();
          tabModel = context.getModel();

          if (!rowData.plant) {
            sap.m.MessageBox.information("Please enter the plant...");
            return;
          }

          if (!rowData.materialcode) {
            sap.m.MessageBox.information("Please enter the material...");
            return;
          }

          aFilters.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant));
          aFilters.push(new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, rowData.materialcode));

        }

        // Search based on ProductionVersion (machine number), Material, or Plant
        const oSearchFilter = new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sTerm)
          ],
          and: false
        });

        aFilters.push(oSearchFilter);

        oModel.read("/ZC_PRODUCTIONVERSION1", {
          filters: aFilters,
          success: function (oData) {
            oInput.destroySuggestionItems();

            oData.results.forEach(item => {
              const oItem = new sap.ui.core.Item({
                key: item.ProductionVersion,
                text: `${item.ProductionVersion} (${item.Material}) - ${item.Plant}`
              });
              oItem.data("Material", item.Material);
              oItem.data("Plant", item.Plant);
              oInput.addSuggestionItem(oItem);
            });

            // Attach handler once
            if (!oInput._hasSuggestionSelectHandler_Machine) {
              oInput.attachSuggestionItemSelected(function (oEvt) {
                const selectedItem = oEvt.getParameter("selectedItem");
                if (!selectedItem || !context) return;

                const machineNum = selectedItem.getKey();

                tabModel.setProperty(rowPath + "/machinenumber", machineNum);
                tabModel.refresh();
              });
              oInput._hasSuggestionSelectHandler_Machine = true;
            }
          },
          error: function () {
            console.error("Failed to fetch machine number suggestions.");
          }
        });
      },


      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oMixingModel = oView.getModel("ZSB_BUILDING_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);
      //   debugger

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (aRowsWithUUID.length !== 1) {
      //     sap.m.MessageBox.warning("Select exactly one row that has a UUID.");
      //     return;
      //   }

      //   // ✅ Continue with the selected row that has a UUID
      //   const oSelectedRow = aRowsWithUUID[0];

      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZJO1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: row.productionorderqty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;

      //       if (!sProdOrder) {
      //         sap.m.MessageToast.show(`No production order returned for row ${i + 1}. Skipping.`);
      //         continue;
      //       }

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) {
      //         sap.m.MessageToast.show(`No batch number for Production Order ${sProdOrder}. Skipping.`);
      //         continue;
      //       }

      //       // Update backend
      //       const sKeyPath = `/ZC_BUILDING_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       };

      //       await new Promise((resolve, reject) => {
      //         oMixingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       // Save to apply to TabModel later
      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //       sap.m.MessageToast.show(`Error processing row ${i + 1}.`);
      //     }
      //   }

      //   // Update TabModel in one go
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       aData[idx].productionorderno = updated.productionorderno;
      //       aData[idx].lotbatchno = updated.lotbatchno;
      //       aData[idx].storagelocation = updated.storagelocation;
      //     }
      //   });

      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");
      // },




      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oMixingModel = oView.getModel("ZSB_BUILDING_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Save the selected row first");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }


      //   // ✅ Continue with the selected row that has a UUID
      //   // const oSelectedRow = aRowsWithUUID[0];

      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZCL1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: row.productionorderqty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;

      //       if (!sProdOrder) {
      //         sap.m.MessageToast.show(`No production order returned for row ${i + 1}. Skipping.`);
      //         continue;
      //       }

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) {
      //         sap.m.MessageToast.show(`No batch number for Production Order ${sProdOrder}. Skipping.`);
      //         continue;
      //       }

      //       // Update backend
      //       const sKeyPath = `/ZC_BUILDING_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       };

      //       await new Promise((resolve, reject) => {
      //         oMixingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       // Save to apply to TabModel later
      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //       sap.m.MessageToast.show(`Error processing row ${i + 1}.`);
      //     }
      //   }

      //   // Update TabModel in one go
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       aData[idx].productionorderno = updated.productionorderno;
      //       aData[idx].lotbatchno = updated.lotbatchno;
      //       aData[idx].storagelocation = updated.storagelocation;
      //     }
      //   });

      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");
      // },



      onApiPostButton: async function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oSewingModel = oView.getModel("ZSB_BUILDING_PLAN");
        const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");
        const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

        const aData = oTabModel.getProperty("/Samples");
        const aSelectedRows = aData.filter(row => row.__selected);

        if (!aSelectedRows.length) {
          sap.m.MessageBox.warning("Please select at least one row.");
          return;
        }

        const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

        if (!aRowsWithUUID.length) {
          sap.m.MessageBox.warning("Save the selected row first");
          return;
        }

        const aRowsWithProdOrder = aSelectedRows.filter(row => {
          const val = row.productionorderno;
          return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
        });

        if (aRowsWithProdOrder.length > 0) {
          sap.m.MessageBox.warning(
            "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
          );
          return;
        }


        // const oSelectedRow = aRowsWithUUID[0];
        sap.ui.core.BusyIndicator.show(0);

        const aUpdatedRows = [];

        for (let i = 0; i < aSelectedRows.length; i++) {
          const row = aSelectedRows[i];

          const oPayload = {
            Material: row.materialcode,
            ProductionPlant: row.plant,
            ManufacturingOrderType: "ZCL1",
            ProductionVersion: row.machinenumber,
            TotalQuantity: row.productionorderqty,
            MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
            BasicSchedulingType: "1"
          };

          try {
            const oPostData = await new Promise((resolve, reject) => {
              oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
                success: resolve,
                error: reject
              });
            });

            const sProdOrder = oPostData.Productionorder;
            const sStorageLoc = oPostData.StorageLocation;
            if (!sProdOrder) continue;

            const oBatchData = await new Promise((resolve, reject) => {
              oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
                success: resolve,
                error: reject
              });
            });

            const sBatchNo = oBatchData.Batch;
            if (!sBatchNo) continue;

            const sKeyPath = `/ZC_BUILDING_PLAN(sap_uuid='${row.sap_uuid}')`;
            const oUpdatePayload = {
              productionorderno: sProdOrder,
              lotbatchno: sBatchNo,
              storagelocation: sStorageLoc
            };

            await new Promise((resolve, reject) => {
              oSewingModel.update(sKeyPath, oUpdatePayload, {
                merge: true,
                success: resolve,
                error: reject
              });
            });

            aUpdatedRows.push({
              sap_uuid: row.sap_uuid,
              productionorderno: sProdOrder,
              lotbatchno: sBatchNo,
              storagelocation: sStorageLoc,
              productionordstartdate: row.productionordstartdate,
              plant: row.plant,
              materialcode: row.materialcode
            });

          } catch (err) {
            console.error("Error processing row", row, err);
          }
        }

        // 🔄 Update TabModel
        aUpdatedRows.forEach(updated => {
          const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
          if (idx !== -1) {
            Object.assign(aData[idx], updated);
          }
        });
        oTabModel.setProperty("/Samples", aData);
        oTabModel.refresh();

        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageToast.show("All selected rows processed.");

        // ✅ Now Generate QR PDF
        // this._generateQRPdf(aUpdatedRows);
      },

      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oMixingModel = oView.getModel("ZSB_BUILDING_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");
      //   const oQtyModel = oView.getModel("ZSB_PROD_QTY");  // new model for quantity fetching

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Save the selected row first");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }

      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     // Fetch production order qty from ZC_PROD_QTY entity using material code
      //     let productionOrderQty = row.productionorderqty;  // fallback if fetch fails

      //     try {
      //       // Assuming materialcode is the key or filter param here
      //       const qtyResult = await new Promise((resolve, reject) => {
      //         oQtyModel.read(`/ZC_PROD_QTY('${row.materialcode}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });
      //       if (qtyResult && qtyResult.Qty !== undefined) {
      //         productionOrderQty = qtyResult.Qty; // map Qty field to productionorderqty
      //       }
      //     } catch (qtyErr) {
      //       console.warn(`Could not fetch production order qty for material ${row.materialcode}`, qtyErr);
      //       // continue with original qty or zero if you want
      //     }

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZCL1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: productionOrderQty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;
      //       if (!sProdOrder) continue;

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) continue;

      //       const sKeyPath = `/ZC_BUILDING_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc,
      //         productionorderqty: productionOrderQty  // update qty also in your model
      //       };

      //       await new Promise((resolve, reject) => {
      //         oMixingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc,
      //         productionordstartdate: row.productionordstartdate,
      //         plant: row.plant,
      //         materialcode: row.materialcode,
      //         productionorderqty: productionOrderQty
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //     }
      //   }

      //   // 🔄 Update TabModel with productionorderqty too
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       Object.assign(aData[idx], updated);
      //     }
      //   });
      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");
      // },







      onPrintPress: async function () {
        const oModel = this.getView().getModel("TabModel").getProperty("/Samples");
        const aSelectedRows = oModel.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row to print.");
          return;
        }

        const { jsPDF } = window.jspdf;

        const loadImageAsBase64 = async (url) => {
          const response = await fetch(url);
          const blob = await response.blob();
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        };

        const svgLogoBase64 = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode.png"));
        // const svgLogoBase64_ = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode2.png"));
        // const svgLogoBase64_Bando = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/Bando.png"));

        const generateCardHTML = (data) => {
          const productionorderno = data?.productionorderno || "";
          const lotbatchno = data?.lotbatchno || "";
          const manufacturingdate = data?.manufacturingdate ? new Date(data.manufacturingdate).toLocaleDateString("en-GB") : "";
          const expirydate = data?.expirydate ? new Date(data.expirydate).toLocaleDateString("en-GB") : "";
          const name = data?.compoundcode || "872T"; // adjust mapping if needed
          const moldol = data?.moldol || "1098 mm";
          const beltSpec = data?.beltspec || "TS2833R";
          const typeSize = data?.typesize || "1098";

          return `
      <div class="card">
        <div class="card-title">Sewing Joint Process Canvas Lot Guarantee Card</div>
        <table>
          <tr><th>Prod Order</th><td>${productionorderno}</td><th>Canvas Lot</th><td>${lotbatchno}</td></tr>
          <tr><th>Prod DATE</th><td>${manufacturingdate}</td><th>Pot Life</th>
              <td style='font-family:"Courier New", Courier, monospace; font-size:70%;padding-top:10px'>
                From a paste pull day is 30 days
              </td></tr>
          <tr><th>Name</th><td>${name}</td><td colspan="2"></td></tr>
          <tr><th style="text-align: left; padding-top:30px" rowspan="3">Dimension</th>
              <td>(Width) 1080 mm</td><th>Mold OL</th><td>${moldol}</td></tr>
          <tr><td colspan="3">(Cutting) 1052 (1047~105) mm</td></tr>
          <tr><td colspan="3">(Sewing) 516 (513~519) mm</td></tr>
          <tr><th>Building Line</th><td colspan="3">Building (RA1 Line)</td></tr>
          <tr><td style="text-align: left; padding-top:30px" rowspan="3" colspan="4">
            <img src="${svgLogoBase64}" alt="Image" align="middle" width="650" height="70">
          </td></tr>
          <tr></tr><tr></tr>
          <tr><th>SPEC No</th><th>Belt Spec</th><th>Type/Size</th><th rowspan="4">Supervisor</th></tr>
          <tr><td>.</td><td>${beltSpec}</td><td>${typeSize}</td></tr>
          <tr><th rowspan="2" colspan="3">Expiry date</th></tr>
          <tr></tr>
        </table>
        <div class="footer">
          <div>BIPL/LC/PD-06</div>
          <div>Rev : 00</div>
          <div>Rev Date : April 12, 2015</div>
        </div>
      </div>`;
        };

        const generateFullHTML = (sections) => `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Sewing Joint Process Canvas Lot Guarantee Card</title>
      <style>
        @page { size: A4 portrait; margin: 0; }
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 10mm;
          width: 210mm;
          height: 297mm;
          box-sizing: border-box;
        }

        .card {
          border: 2px solid #000;
          padding: 5mm;
          margin-bottom: 5mm;
          height: 120mm;       /* match your reference */
          box-sizing: border-box;
          page-break-inside: avoid;
        }


        .card-title {
          text-align: center;
          font-weight: bold;
          font-size: 14pt;
          margin-bottom: 5px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          font-size: 10pt;
        }
        th, td {
          border: 1px solid black;
          padding: 4px;
          vertical-align: top;
          text-align: left;
        }
        .footer {
          font-size: 8pt;
          margin-top: 4mm;
          display: flex;
          justify-content: space-between;
          border-top: 1px solid #000;
          padding-top: 2mm;
        }
      </style>
    </head>
    <body>
      ${sections.map(section => generateCardHTML(section)).join('')}
    </body>
    </html>`;

        const doc = new jsPDF('p', 'mm', [210, 297]); // A4 portrait
        const preparedData = aSelectedRows;
        const promises = [];

        // Process cards in groups of 3
        for (let i = 0; i < preparedData.length; i += 3) {
          const sectionsForThisPage = [];
          sectionsForThisPage.push(preparedData[i]);
          if (i + 1 < preparedData.length) sectionsForThisPage.push(preparedData[i + 1]);
          if (i + 2 < preparedData.length) sectionsForThisPage.push(preparedData[i + 2]);

          const htmlContent = generateFullHTML(sectionsForThisPage);

          promises.push(new Promise((resolve, reject) => {
            const iframe = document.createElement('iframe');
            iframe.style.position = 'fixed';
            iframe.style.top = '-100000px';
            iframe.style.width = '210mm';
            iframe.style.height = '297mm';
            document.body.appendChild(iframe);

            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            iframeDoc.open();
            iframeDoc.write(htmlContent);
            iframeDoc.close();

            iframe.onload = () => {
              html2canvas(iframeDoc.body, {
                scale: 2,
                width: 794,
                height: 1123
              }).then(canvas => {
                const imgData = canvas.toDataURL('image/jpeg', 0.95);
                doc.addImage(imgData, 'JPEG', 0, 0, 210, 297);
                if (i + 3 < preparedData.length) doc.addPage();
                document.body.removeChild(iframe);
                resolve();
              }).catch(error => {
                document.body.removeChild(iframe);
                reject(error);
              });
            };
          }));
        }

        await Promise.all(promises);

        const blob = doc.output('blob');
        const pdfUrl = URL.createObjectURL(blob);

        if (!this._PDFViewer) {
          this._PDFViewer = new sap.m.PDFViewer({
            source: pdfUrl,
            title: "Sewing Joint Process Canvas Lot Guarantee Card",
            width: "auto"
          });
          jQuery.sap.addUrlWhitelist("blob");
        }

        this._PDFViewer.setSource(pdfUrl);
        this._PDFViewer.open();
      },



    });
  }
);

