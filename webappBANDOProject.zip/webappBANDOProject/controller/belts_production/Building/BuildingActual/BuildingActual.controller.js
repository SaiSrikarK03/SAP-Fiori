sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",
        "bando/util/jspdf/html2canvasmin",
        "bando/util/jspdf/jspdfmin",
        "bando/util/importfile/importexcelfile",
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
        "use strict";

        return BaseController.extend("bando.controller.belts_production.BuildingActual", {
            onInit: function () {


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("BuildingActual").attachMatched(this._onRouteMatched, this);

            },

            _onRouteMatched: function () {
                // Clear filters
                // this.byId("idDateRange").setDateValue(null);
                // this.byId("idDateRange").setSecondDateValue(null);
                // this.byId("idPlant").setValue("");
                // this.byId("idMaterial").setValue("");
                // this.byId("idProductGroup").setValue("");

                // Optionally: clear or re-fetch table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);
                this.HeaderModel = new sap.ui.model.json.JSONModel({

                    HeaderData: {
                        idDateRange: "",
                        idPlant: "",
                        idMaterial: "",
                        // idProductGroup: "",
                        idProductionorderno: "",

                    }
                })

                this.getView().setModel(this.HeaderModel, "HeaderModel");
            },


            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },


            GoBuildingActual: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_BUILDING_PLAN"); // OData model
                const oTabModel = oView.getModel("TabModel");     // Local model

                // Get filter inputs
                const oDateRange = oView.byId("idDateRange");
                const oPlant = oView.byId("idPlant").getValue().trim();
                const oMaterial = oView.byId("idMaterial").getValue().trim();
                // const oProductGroup = oView.byId("idProductGroup").getValue().trim();
                const oProductionOrder = oView.byId("idProductionorderno").getValue().trim();

                const oStartDate = oDateRange.getDateValue();
                const oEndDate = oDateRange.getSecondDateValue();

                // At least one filter is required

                // && !oProductGroup
                if (
                    !oStartDate && !oEndDate &&
                    !oPlant && !oMaterial && !oProductionOrder
                ) {
                    sap.m.MessageBox.warning("Please enter at least one filter criteria.");
                    return;
                }

                const aFilters = [];

                // Date Range filter (optional)
                // if (oStartDate && oEndDate) {
                //     const oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
                //         pattern: "yyyy-MM-ddTHH:mm:ss"
                //     });

                //     const sStartDate = oDateFormat.format(new Date(oStartDate.setHours(0, 0, 0, 0)));
                //     const sEndDate = oDateFormat.format(new Date(oEndDate.setHours(23, 59, 59, 999)));

                //     aFilters.push(new sap.ui.model.Filter({
                //         path: "productionordstartdate",
                //         operator: sap.ui.model.FilterOperator.BT,
                //         value1: sStartDate,
                //         value2: sEndDate
                //     }));
                // }

                if (oStartDate && oEndDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

                    const sStartDate = oDateFormat.format(oStartDate); // 'yyyy-MM-dd'
                    const sEndDate = oDateFormat.format(oEndDate);     // 'yyyy-MM-dd'

                    aFilters.push(new sap.ui.model.Filter({
                        path: "productionordstartdate",
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: sStartDate,
                        value2: sEndDate
                    }));
                }


                // Add filters only if values are entered
                if (oPlant) {
                    aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
                }
                if (oMaterial) {
                    aFilters.push(new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, oMaterial));
                }
                // if (oProductGroup) {
                //     aFilters.push(new sap.ui.model.Filter("productgroup", sap.ui.model.FilterOperator.EQ, oProductGroup));
                // }
                if (oProductionOrder) {
                    aFilters.push(new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, oProductionOrder));
                }

                const oDynamicPage = this.byId("idBuildActualDynamic");
                if (oDynamicPage) {
                    oDynamicPage.setShowFooter(true);
                }

                sap.ui.core.BusyIndicator.show(0);

                oModel.read("/ZC_BUILDING_PLAN", {
                    filters: aFilters,
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();

                        const aFiltered = oData.results.filter(row => {
                            const prodOrder = row.productionorderno;
                            return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
                        });

                        oTabModel.setProperty("/Samples", aFiltered);
                        oView.byId("idBuildingActualtablescreen").setVisible(true);

                        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                            Samples: {
                                selectall: false
                            }
                        });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");

                        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                            Samples: {
                                selectall: false
                            }
                        });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    }
                });
            },



            ontypeconfirmedqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get the binding context and row data
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                const iConfirmedQty = parseFloat(sNewValue);
                const iProductionOrderQty = parseFloat(oRowData.productionorderqty);

                // Validate inputs
                // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
                //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
                //     oInput.setValue(""); // Clear the input
                //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
                //     oContext.getModel().refresh(); // Reflect change in UI
                //     return;
                // }

                if (iConfirmedQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
                    oInput.setValue("");
                    // oRowData.balanceqty = oRowData.productionorderqty || 0;
                    oContext.getModel().refresh();
                    return;
                }

                // Set Confirmed QTY explicitly if needed
                oRowData.confirmedqty = iConfirmedQty;

                // Calculate and update Balance QTY
                // const iBalanceQty = iProductionOrderQty - iConfirmedQty;
                // oRowData.balanceqty = iBalanceQty;

                // Refresh the model to update UI
                oContext.getModel().refresh();
            },



            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },



            onImportExl: function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_BUILDING_PLAN");

                function ensureXLSX(cb) {
                    if (window.XLSX) {
                        return cb();
                    }

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = new Uint8Array(e.target.result);
                        const workbook = XLSX.read(data, { type: "array" });
                        const sheetName = workbook.SheetNames[0];
                        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        const aSamples = oTabModel.getProperty("/Samples") || [];
                        const aNotFound = [];

                        sap.ui.core.BusyIndicator.show(0);

                        const aUpdatePromises = jsonData.map((importRow) => {
                            const plant = importRow["Plant"];
                            const prodOrder = importRow["Production Order No"];

                            const matchedRow = aSamples.find(item =>
                                item.plant === plant && item.productionorderno === prodOrder
                            );

                            if (!matchedRow || !matchedRow.sap_uuid) {
                                aNotFound.push(prodOrder);
                                return null;
                            }

                            const parseDecimal = (val) => {
                                const parsed = parseFloat(val);
                                return isNaN(parsed) ? "0.000" : parsed.toFixed(3);
                            };

                            const oPayload = {
                                confirmedqty: parseDecimal(importRow["Confirmed Qty"]),
                                compoundcode: parseDecimal(importRow["compoundcode"]),
                                // defectqty: parseDecimal(importRow["Defect Qty"]),
                                balanceqty: parseDecimal(importRow["Balance Qty"]),
                                manufacturingdate: importRow["Manufacturing Date"] ? new Date(importRow["Manufacturing Date"]) : null,
                                batchweight: String(importRow["Batch Weight"] || ""),
                                operator: String(importRow["Operator"] || ""),
                                inspector: String(importRow["Inspector"] || "")
                            };



                            // ✅ Update model row for UI (safe now)
                            matchedRow.confirmedqty = oPayload.confirmedqty;
                            matchedRow.compoundcode = oPayload.compoundcode;
                            // matchedRow.defectqty = oPayload.defectqty;
                            matchedRow.balanceqty = oPayload.balanceqty;
                            matchedRow.manufacturingdate = oPayload.manufacturingdate;
                            matchedRow.batchweight = oPayload.batchweight;
                            matchedRow.operator = oPayload.operator;
                            matchedRow.inspector = oPayload.inspector;

                            // 🔑 Construct OData entity key
                            const sKey = oODataModel.createKey("/ZC_BUILDING_PLAN", {
                                sap_uuid: matchedRow.sap_uuid
                            });

                            // 🔁 Return update promise
                            return new Promise((resolve, reject) => {
                                oODataModel.update(sKey, oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });
                        }).filter(Boolean); // remove any nulls (not found rows)

                        Promise.allSettled(aUpdatePromises).then(results => {
                            sap.ui.core.BusyIndicator.hide();

                            const aFailed = results.filter(r => r.status === "rejected");
                            let msg = `${results.length - aFailed.length} rows updated successfully.`;
                            if (aFailed.length > 0) msg += `\n${aFailed.length} rows failed to update.`;
                            if (aNotFound.length > 0) {
                                msg += `\n\nThe following Production Orders were not found or missing sap_uuid:\n${aNotFound.join(", ")}`;
                            }

                            sap.m.MessageBox.information(msg);
                            oTabModel.refresh(true);
                        });
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsArrayBuffer(file);
                }

                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";
                fileInput.onchange = function (e) {
                    const file = e.target.files[0];
                    if (!file) return;
                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                };
                document.body.appendChild(fileInput);
                fileInput.click();
            },



            onExportExl: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, else use all rows
                const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "Material Code", property: "materialcode" },
                    { label: "Description", property: "description" },
                    { label: "Machine Number", property: "machinenumber" },
                    { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Production Order Qty", property: "productionorderqty" },
                    { label: "Lot/Batch-No", property: "lotbatchno" },
                    { label: "Storage Location", property: "storagelocation" },
                    { label: "compoundcode", property: "compoundcode" },
                    { label: "Confirmed Qty", property: "confirmedQty" },

                    // { label: "Defect Qty", property: "defectQty" },
                    { label: "Balance Qty", property: "balanceQty" },
                    // { label: "UOM", property: "uom" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Batch Weight", property: "batchweight" },
                    { label: "Operator", property: "operator" },
                    { label: "Inspector", property: "inspector" },
                    { label: "Released Status", property: "releasestatus" },
                    { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
                    { label: "Confirmation Count", property: "gicnfconfirmationcount" },
                    { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
                    { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
                    { label: "GR Material Doc Year", property: "grmaterialdocyear" },
                    { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
                    // { label: "Status of Production Order", property: "statusOfProdOrd" }
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "Building Plan"
                        }
                    },
                    dataSource: aExportData,
                    fileName: "Building_Plan_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },



            onExporttoImport: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // 🔍 Check for selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "Confirmed Qty", property: "confirmedQty" },
                    { label: "compoundcode", property: "compoundcode" },
                    // { label: "Defect Qty", property: "defectQty" },
                    { label: "Balance Qty", property: "balanceQty" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Batch Weight", property: "batchweight" },
                    { label: "Operator", property: "operator" },
                    { label: "Inspector", property: "inspector" },
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "Building Plan"
                        }
                    },
                    dataSource: aExportData,
                    fileName: "Export_to_Import.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },




            // ------------------------------------------------------------------------------------------------------------------------------------------
            // For Goods issue Confirmation - Start
            // ------------------------------------------------------------------------------------------------------------------------------------------


            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // Confirmation OData //ZSB_TB_FT_PRODCONF

            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");

            //     if (aWithGI.length > 0) {
            //         // Extract production order numbers from those rows
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);

            //         // Create message string
            //         const sMessage =
            //             "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") +
            //             "\n\nPlease unselect them before proceeding.";

            //         sap.m.MessageBox.warning(sMessage);
            //         return;
            //     }

            //     // Check if all selected rows are released
            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
            //         return;
            //     }


            //     // const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     // if (aWithGI.length > 0) {
            //     //     sap.m.MessageBox.warning("Goods Issue already exists for one or more selected rows. Cannot proceed.");
            //     //     return;
            //     // }



            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const val = row.confirmedqty;
            //         return val === "" || val === null || val === undefined || isNaN(val) || parseFloat(val) <= 0;
            //     });

            //     if (aMissingQty.length > 0) {
            //         sap.m.MessageBox.error("Please enter a valid Confirmed QTY (greater than 0) for all selected rows.");
            //         return;
            //     }

            //     // const aMissingQty = aSelectedRows.filter(row => !row.confirmedqty);

            //     // if (aMissingQty.length > 0) {
            //     //     sap.m.MessageBox.error("Please enter Confirmed QTY for all selected rows.");
            //     //     return;
            //     // }




            //     sap.ui.core.BusyIndicator.show(0);

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const oRow = aSelectedRows[i];

            //         try {
            //             // Apply filters
            //             const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //             const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //             await new Promise((resolve, reject) => {
            //                 oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                     filters: [oFilter1, oFilter2],
            //                     success: async function (OData) {
            //                         if (OData.results.length === 0) {
            //                             sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
            //                             return resolve();
            //                         }

            //                         const oData = OData.results[0];

            //                         // Calculate work quantities
            //                         const calcQty = (qty, total, ref) => (qty * total) / ref;
            //                         const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oData.OperationReferenceQuantity);

            //                         // Call Confirm Issue API
            //                         let ManufacturingOrderOperation = oData.ManufacturingOrderOperation;
            //                         let GR_NO = await that.ToConfirmIssueAPIPost(
            //                             ManufacturingOrderOperation,
            //                             opconfirmedworkquantity1,
            //                             opconfirmedworkquantity2,
            //                             opconfirmedworkquantity3,
            //                             opconfirmedworkquantity4,
            //                             opconfirmedworkquantity5,
            //                             opconfirmedworkquantity6,
            //                             oRow // <-- pass the row
            //                         );

            //                         const matDoc = GR_NO[0].materialdocument;
            //                         oRow.gicnfmaterialdocnumber = GR_NO[0].materialdocument;
            //                         oRow.gicnfmaterialdocyear = GR_NO[0].matdocyear;
            //                         oRow.gicnfconfirmationgroup = GR_NO[0].confirmationgroup;
            //                         oRow.gicnfconfirmationcount = GR_NO[0].confirmationcount;

            //                         oTabModel.refresh();

            //                         if (!matDoc) {
            //                             let ErrorMessage = "Some error occurred while posting.";
            //                             try {
            //                                 const kk = JSON.parse(GR_NO[0].errorresponse);
            //                                 ErrorMessage = kk.error.message.value;
            //                             } catch (e) {
            //                                 // ignore
            //                             }
            //                             sap.m.MessageBox.error(ErrorMessage);
            //                         } else {
            //                             await that.ToUpdateIntTab(oRow, matDoc, GR_NO[0]);
            //                             sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
            //                             that.FinalStatus = new sap.ui.model.json.JSONModel({
            //                                 MSGSTRIP: {
            //                                     visible: true,
            //                                     text: "Material Document No - Goods Issue : " + matDoc,
            //                                     type: 'Success'
            //                                 }
            //                             });
            //                             oView.setModel(that.FinalStatus, "FinalStatus");
            //                         }

            //                         resolve();
            //                     },
            //                     error: function (error) {
            //                         console.log(error);
            //                         sap.ui.core.BusyIndicator.hide();
            //                         reject(error);
            //                     }
            //                 });
            //             });

            //         } catch (e) {
            //             console.error("Error in confirmation:", e);
            //         }
            //     }

            //     sap.ui.core.BusyIndicator.hide();
            // },


            // ToConfirmIssueAPIPost: function (ManufacturingOrderOperation, opconfirmedworkquantity1, opconfirmedworkquantity2, opconfirmedworkquantity3, opconfirmedworkquantity4, opconfirmedworkquantity5, opconfirmedworkquantity6) {

            //     return new Promise(async (resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();



            //         const oView = this.getView();
            //         const oTabModel = oView.getModel("TabModel");

            //         const aRows = oTabModel.getProperty("/Samples");
            //         const iSelectedIndex = aRows.findIndex(row => row.__selected);

            //         if (iSelectedIndex === -1) {
            //             sap.m.MessageToast.show("Please select a row.");
            //             return;
            //         }

            //         const oSelectedRow = aRows[iSelectedIndex];



            //         var that = this;
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.information("Do you want to post this data.", {
            //             actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //             emphasizedAction: sap.m.MessageBox.Action.YES,
            //             onClose: async function (sAction) {
            //                 if (sAction === "YES") {

            //                     sap.ui.core.BusyIndicator.show();

            //                     // ************** Start For Header *********************
            //                     const postIDTableLevel = new Promise((resolve, reject) => {

            //                         var oEntry = {
            //                             orderid: oSelectedRow.productionorderno,
            //                             orderoperation: ManufacturingOrderOperation,
            //                             ordersuboperation: "0000",
            //                             // "ConfirmationUnit"  : "KG",
            //                             //  "ConfirmationUnitISOCode" : "PCE",
            //                             confirmationyieldquantity: String(oSelectedRow.confirmedqty),
            //                             //  "ConfirmationScrapQuantity" : "0",
            //                             //  "OpWorkQuantityUnit1" : "HR",
            //                             //  "WorkQuantityUnit1ISOCode"  : "HR",
            //                             opconfirmedworkquantity1: String(opconfirmedworkquantity1),
            //                             opconfirmedworkquantity2: String(opconfirmedworkquantity2),
            //                             opconfirmedworkquantity3: String(opconfirmedworkquantity3),
            //                             opconfirmedworkquantity4: String(opconfirmedworkquantity4),
            //                             opconfirmedworkquantity5: String(opconfirmedworkquantity5),
            //                             opconfirmedworkquantity6: String(opconfirmedworkquantity6),
            //                             // uom:"",
            //                             materialdocument: "",
            //                             matdocyear: "",
            //                             sequence: "0000",
            //                             // "response" : ""
            //                             confirmationgroup: "",
            //                             confirmationcount: "",
            //                             finalconfirmationtype: "X",
            //                             scrapqty: parseFloat(oSelectedRow.balanceqty).toFixed(3)

            //                         };
            //                         console.log("oEntryoEntry:", oEntry);

            //                         that.getView().setModel();

            //                         var oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");//ZSB_TB_FT_PRODCONF

            //                         oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
            //                             success: function (oData, oResponse) {

            //                                 console.log(oData);
            //                                 console.log(oData.response);

            //                                 console.log(oData)
            //                                 // oModelGet.refresh(true);
            //                                 sap.ui.core.BusyIndicator.hide();
            //                                 resolve(oData);
            //                             },

            //                             error: function (error) {
            //                                 console.log("error");
            //                                 sap.ui.core.BusyIndicator.hide();
            //                                 sap.m.MessageBox.error("Process Failed...")
            //                                 reject(error)
            //                             }
            //                         });

            //                     });
            //                     // / ************** End For Header *********************

            //                     let OutPutData = await Promise.all([postIDTableLevel]);

            //                     // ************************************************************

            //                     resolve(OutPutData);

            //                 } else {
            //                     sap.m.MessageToast.show("Cancelled");
            //                     sap.ui.core.BusyIndicator.hide();
            //                 }
            //             }
            //         });
            //     });
            // },

            // ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

            //     return new Promise((resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();
            //         var that = this;
            //         var oModelGet = that.getView().getModel("ZSB_BUILDING_PLAN");
            //         // oModelGet.setHeaders({
            //         //     "X-Requested-With": "X",
            //         //     "Content-Type": "application/json"
            //         // });

            //         var oEntry = {
            //             confirmedqty: String(HeaderModel.confirmedqty),
            //             // confirmedqty: String(HeaderModel.confirmedqty),
            //             balanceqty: String(HeaderModel.balanceqty), // ✅ Added balanceqty
            //             gicnfmaterialdocnumber: resp.materialdocument,
            //             gicnfmaterialdocyear: resp.matdocyear,
            //             gicnfconfirmationgroup: resp.confirmationgroup,
            //             gicnfconfirmationcount: resp.confirmationcount,


            //         };

            //         oModelGet.update("/ZC_BUILDING_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            //             success: function (oData, oResponse) {
            //                 console.log("Goods Issue No Updated Successfully...")
            //                 resolve(oData);
            //             },

            //             error: function (error) {
            //                 console.log("error");
            //                 sap.ui.core.BusyIndicator.hide();
            //                 sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
            //                 reject(error)
            //             }
            //         });

            //     });
            // },

            OnAPIPost_Confirmation: async function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                if (aWithGI.length > 0) {
                    const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
                    const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
                        aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";
                    sap.m.MessageBox.warning(sMessage);
                    return;
                }

                const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
                if (aUnreleased.length > 0) {
                    sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
                    return;
                }

                const aMissingQty = aSelectedRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.balanceqty;

                    // Function to check zero or empty values for qty fields
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;

                    // Check if confirmedqty invalid (null, empty, NaN, or negative)
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;

                    // Check if BOTH confirmedqty and balanceqty are zero/null (or equivalent)
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);

                    // Return true if either:
                    // 1) confirmedqty is invalid (negative, missing, NaN)
                    // OR
                    // 2) both confirmedqty and balanceqty are zero/null
                    return confirmedInvalid || bothZeroOrNull;
                });

                if (aMissingQty.length > 0) {
                    sap.m.MessageBox.error("Please enter a valid Confirmed QTY (0 or greater) for all selected rows. If the value is empty, please add 0.");
                    return;
                }

                // ✅ Confirm before processing
                sap.m.MessageBox.confirm("Do you want to post the selected data?", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction === sap.m.MessageBox.Action.YES) {
                            sap.ui.core.BusyIndicator.show(0);

                            let allSuccessful = true;

                            for (let i = 0; i < aSelectedRows.length; i++) {
                                const oRow = aSelectedRows[i];

                                try {
                                    const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                                    const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                    await new Promise((resolve, reject) => {
                                        oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                            filters: [oFilter1, oFilter2],
                                            success: async function (OData) {
                                                if (OData.results.length === 0) {
                                                    sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
                                                    allSuccessful = false;
                                                    return resolve();
                                                }

                                                const oData = OData.results[0];
                                                const calcQty = (qty, total, ref) => (qty * total) / ref;

                                                const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oData.OperationReferenceQuantity);
                                                const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oData.OperationReferenceQuantity);
                                                const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oData.OperationReferenceQuantity);
                                                const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oData.OperationReferenceQuantity);
                                                const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oData.OperationReferenceQuantity);
                                                const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oData.OperationReferenceQuantity);

                                                const ManufacturingOrderOperation = oData.ManufacturingOrderOperation;

                                                const postResult = await that.ToConfirmIssueAPIPost(
                                                    ManufacturingOrderOperation,
                                                    opconfirmedworkquantity1,
                                                    opconfirmedworkquantity2,
                                                    opconfirmedworkquantity3,
                                                    opconfirmedworkquantity4,
                                                    opconfirmedworkquantity5,
                                                    opconfirmedworkquantity6,
                                                    oRow
                                                );

                                                const matDoc = postResult.materialdocument;
                                                oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                                                oRow.gicnfmaterialdocyear = postResult.matdocyear;
                                                oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                                                oRow.gicnfconfirmationcount = postResult.confirmationcount;

                                                oTabModel.refresh();

                                                if (!matDoc) {
                                                    let ErrorMessage = "Some error occurred while posting.";
                                                    try {
                                                        const kk = JSON.parse(postResult.errorresponse);
                                                        ErrorMessage = kk.error.message.value;
                                                    } catch (e) { }
                                                    sap.m.MessageBox.error(ErrorMessage);
                                                    allSuccessful = false;
                                                } else {
                                                    await that.ToUpdateIntTab(oRow, matDoc, postResult);
                                                    that.FinalStatus = new sap.ui.model.json.JSONModel({
                                                        MSGSTRIP: {
                                                            visible: true,
                                                            text: "Material Document No - Goods Issue : " + matDoc,
                                                            type: 'Success'
                                                        }
                                                    });
                                                    oView.setModel(that.FinalStatus, "FinalStatus");
                                                }

                                                resolve();
                                            },
                                            error: function (error) {
                                                console.log(error);
                                                sap.ui.core.BusyIndicator.hide();
                                                allSuccessful = false;
                                                reject(error);
                                            }
                                        });
                                    });

                                } catch (e) {
                                    console.error("Error in confirmation:", e);
                                    allSuccessful = false;
                                }
                            }

                            sap.ui.core.BusyIndicator.hide();

                            // ✅ Final message at the end
                            if (allSuccessful) {
                                sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
                            } else {
                                sap.m.MessageBox.warning("Process completed with some errors. Check details.");
                            }
                        }
                    }
                });
            },


            ToConfirmIssueAPIPost: function (
                ManufacturingOrderOperation,
                opconfirmedworkquantity1,
                opconfirmedworkquantity2,
                opconfirmedworkquantity3,
                opconfirmedworkquantity4,
                opconfirmedworkquantity5,
                opconfirmedworkquantity6,
                oSelectedRow
            ) {
                return new Promise(async (resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();

                    const that = this;
                    const oEntry = {
                        orderid: oSelectedRow.productionorderno,
                        orderoperation: ManufacturingOrderOperation,
                        ordersuboperation: "0000",
                        confirmationyieldquantity: String(oSelectedRow.confirmedqty),
                        opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                        opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                        opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                        opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                        opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                        opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                        materialdocument: "",
                        matdocyear: "",
                        sequence: "0000",
                        confirmationgroup: "",
                        confirmationcount: "",
                        finalconfirmationtype: "X",
                        scrapqty: parseFloat(oSelectedRow.balanceqty).toFixed(3)
                    };
                    console.log("payload bring posrted: ", oEntry)

                    const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");

                    oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
                        success: function (oData) {
                            sap.ui.core.BusyIndicator.hide();
                            resolve(oData); // ✅ Return the object directly
                        },
                        error: function (error) {
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageBox.error("Process Failed...");
                            reject(error);
                        }
                    });
                });
            },



            ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

                return new Promise((resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_MIXING_PLAN1");
                    // oModelGet.setHeaders({
                    //     "X-Requested-With": "X",
                    //     "Content-Type": "application/json"
                    // });

                    var oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        // confirmedqty: String(HeaderModel.confirmedqty),
                        balanceqty: String(HeaderModel.balanceqty), // ✅ Added balanceqty
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,


                    };

                    oModelGet.update("/ZC_MIXING_PLAN1('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData, oResponse) {
                            console.log("Goods Issue No Updated Successfully...")
                            resolve(oData);
                        },

                        error: function (error) {
                            console.log("error");
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
                            reject(error)
                        }
                    });

                });
            },






            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Goods reciept start
            // ------------------------------------------------------------------------------------------------------------------------------------------




            onGoodsReceiptPress: async function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                let aBlockerErrors = [];

                aSelectedRows.forEach((row) => {
                    let errors = [];

                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }

                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists");
                    }

                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness)
                let aValidationErrors = [];

                aSelectedRows.forEach((row) => {
                    let missingFields = [];

                    if (!row.batchweight) missingFields.push("Batch Weight");
                    // if (!row.operator) missingFields.push("Operator");
                    // if (!row.inspector) missingFields.push("Inspector");
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }


                // --- ✅ PROCESSING (all validations passed)
                sap.ui.core.BusyIndicator.show(0);

                for (let i = 0; i < aSelectedRows.length; i++) {
                    const row = aSelectedRows[i];

                    const oPayload = {
                        material: row.materialcode,
                        plant: row.plant,
                        storagelocation: row.storagelocation,
                        goodsmovementtype: "101",
                        manufacturingorder: row.productionorderno,
                        manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementrefdoctype: "F",
                        quantityinentryunit: String(row.confirmedqty),
                        postingdate: new Date(),
                        goodsmovementcode: "02"
                    };

                    try {
                        const oData = await new Promise((resolve, reject) => {
                            oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        row.grmaterialdocnumber = oData.materialdocument;
                        row.grmaterialdocyear = oData.matdocyear;
                        row.batchweight = String(row.confirmedqty);

                        const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
                        row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

                        await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

                    } catch (oError) {
                        console.error(`❌ GR Failed for row ${i + 1}:`, oError);
                        sap.m.MessageBox.error(`Goods Receipt failed for row ${i + 1}. See console for details.`);
                        continue; // Optionally stop or continue
                    }
                }

                oTabModel.setProperty("/Samples", aRows);
                oTabModel.refresh();
                sap.ui.core.BusyIndicator.hide();
                sap.m.MessageToast.show("Goods Receipt process completed.");
            },


            ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_BUILDING_PLAN");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // batchweight: HeaderModel.batchweight,
                        operator: HeaderModel.operator,
                        inspector: HeaderModel.inspector,
                        // batchweight: String(parseInt(HeaderModel.confirmedqty)),
                        expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

                    };

                    oModelGet.update("/ZC_BUILDING_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully.");
                            sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed");
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    // Safely get the backend model
                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    // Call the read function
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {

                            resolve(oData.results)

                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve Building Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },






            // sap.ui.core.BusyIndicator.hide();
            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Update 
            // ------------------------------------------------------------------------------------------------------------------------------------------

            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_BUILDING_PLAN");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {
                    // Construct OData key based on your service (likely composite key)
                    const sKey = oODataModel.createKey("/ZC_BUILDING_PLAN", {
                        sap_uuid: item.sap_uuid,
                        // plant: item.plant,
                        // productionorderno: item.productionorderno
                    });

                    // Prepare payload with only editable fields
                    const oPayload = {
                        confirmedqty: String(parseInt(item.confirmedqty)),// item.confirmedqty,

                        compoundcode: item.compoundcode,
                        // defectqty: item.defectqty,

                        balanceqty: item.balanceqty,
                        manufacturingdate: item.manufacturingdate,
                        expirydate: item.expirydate,
                        batchweight: item.batchweight,
                        operator: item.operator,
                        inspector: item.inspector
                    };

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);
                    oTabModel.refresh(true);
                });
            },

            // ===========================================================================================================
            // ===========================================================================================================
            // ===========================================================================================================
            onReleaseFragmentPress: function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                // Get selected rows from main table
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select a row first.");
                    return;
                }
                if (aSelectedRows.length > 1) {
                    sap.m.MessageToast.show("Please select only one row.");
                    return;
                }

                // ✅ Save selected rows for later use
                oTableModel.setProperty("/SelectedRowData", aSelectedRows);

                sap.ui.core.BusyIndicator.show(0); 

                // Step 1: Get Manufacturing Order (production order number)
                const sProdOrderNo = aSelectedRows[0].productionorderno;
                const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

                // Step 2: First fetch Reservation from ZC_RESERVATION_COMPONENT
                const aReservationFilter = [
                    new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
                ];

                oODataModel.read("/ZC_RESERVATION_COMPONENT", {
                    filters: aReservationFilter,
                    success: function (oReservationData) {
                        const aResults = oReservationData.results;

                        if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
                            sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
                            return;
                        }

                        const sReservation = aResults[0].Reservation;

                        // Step 3: Now fetch BOM data from ZC_RELEASE_BOM using Reservation
                        const aBomFilters = [
                            new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
                        ];

                        oODataModel.read("/ZC_RELEASE_BOM", {
                            filters: aBomFilters,
                            success: function (oBomData) {
                                oTableModel.setProperty("/BomRelease", oBomData.results || []);

                                // Open fragment if not already open
                                if (!this._oBomReleaseDialog) {
                                    this._oBomReleaseDialog = sap.ui.xmlfragment(
                                        "bando.view.CommonFragments.ActualScreens.BomRelease",
                                        this
                                        // bando.view.CommonFragments.ActualScreens.BomRelease
                                    
                                    );
                                    oView.addDependent(this._oBomReleaseDialog);
                                }
                                this._oBomReleaseDialog.open();
                                sap.ui.core.BusyIndicator.hide();
                            }.bind(this),
                            error: function (oError) {
                                sap.m.MessageToast.show("Error fetching BOM Release data.");
                                console.error(oError);
                            }
                        });

                    }.bind(this),
                    error: function (oError) {
                        sap.m.MessageToast.show("Error fetching Reservation.");
                        console.error(oError);
                    }
                });
            },


            onReleaseCancel: function () {
                if (this._oBomReleaseDialog) {
                    this._oBomReleaseDialog.close();
                    this._oBomReleaseDialog.destroy();
                    this._oBomReleaseDialog = null; // reset reference
                }
            },


            onReleasePress: function () {
                const that = this;
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oModel = oView.getModel("ZSB_PRODUCT_ORD1"); // OData backend for release
                const oBuildingPlanModel = oView.getModel("ZSB_BUILDING_PLAN"); // For PATCH
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Same model for status check

                // ✅ Use filtered selected rows
                const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);
                let iCompleted = 0;

                aSelectedRows.forEach((row, index) => {
                    const sManufacturingOrder = row.productionorderno;
                    // debugger;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${index + 1} skipped: No production order.`);
                        iCompleted++;
                        checkCompletion();
                        return;
                    }

                    // Step 1: Check status from ZC_ORDER_CREATION
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            const aResults = oData.results;
                            // debugger;

                            var bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });

                            if (bExists) {
                                console.log("Combination exists: I0002 and active.");
                                sap.m.MessageToast.show("Rows may already be released.");

                                // Update Building plan as RELEASED anyway
                                const sUpdatePath = "/ZC_BUILDING_PLAN('" + row.sap_uuid + "')";
                                const oUpdateEntry = {
                                    releasestatus: "RELEASED",
                                    batchweight: row.batchweight || "",
                                    operator: row.operator || "",
                                    inspector: row.inspector || "",
                                    manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                                };
                                // debugger;

                                oBuildingPlanModel.update(sUpdatePath, oUpdateEntry, {
                                    success: function () {
                                        console.log(`🔄 Building Plan updated for row ${index + 1}`);
                                        row.releasestatus = "RELEASED";
                                        oTableModel.setProperty("/Samples", aRows);
                                        oTableModel.refresh();
                                        checkCompletion01();
                                    },
                                    error: function () {
                                        row.releasestatus = ""; // revert
                                        checkCompletion01();
                                    }
                                });

                                sap.ui.core.BusyIndicator.hide(0);
                                return;
                            }

                            // Step 2: Continue with create logic
                            const oPayload = { ManufacturingOrder: sManufacturingOrder };
                            // debugger;

                            oModel.create("/ZC_PROD_STATUS1", oPayload, {
                                success: function (oData) {
                                    console.log(`✅ Release POST success for row ${index + 1}`, oData);

                                    if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
                                        sap.m.MessageToast.show("Check material availability");
                                        row.releasestatus = ""; // not released
                                        sap.ui.core.BusyIndicator.hide();
                                        return;
                                    }

                                    row.releasestatus = "RELEASED";

                                    const sUpdatePath = "/ZC_BUILDING_PLAN('" + row.sap_uuid + "')";
                                    const oUpdateEntry = {
                                        releasestatus: "RELEASED",
                                        batchweight: row.batchweight || "",
                                        operator: row.operator || "",
                                        inspector: row.inspector || "",
                                        manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                                    };
                                    // debugger;

                                    oBuildingPlanModel.update(sUpdatePath, oUpdateEntry, {
                                        success: function () {
                                            console.log(`🔄 Building Plan updated for row ${index + 1}`);
                                            checkCompletion();
                                        },
                                        error: function () {
                                            row.releasestatus = "";
                                            console.log(`⚠️ Building Plan update failed for row ${index + 1}`);
                                            checkCompletion();
                                        }
                                    });
                                },
                                error: function (oError) {
                                    row.releasestatus = "";
                                    console.error(`❌ Release POST failed for row ${index + 1}`, oError);
                                    checkCompletion();
                                }
                            });
                        },
                        error: function (oError) {
                            console.error(`🔍 Status check failed for row ${index + 1}`, oError);
                            iCompleted++;
                            checkCompletion();
                        }
                    });
                });

                // function checkCompletion() {
                //     iCompleted++;
                //     if (iCompleted === aSelectedRows.length) {
                //         oTableModel.setProperty("/Samples", aRows);
                //         oTableModel.refresh();
                //         sap.ui.core.BusyIndicator.hide();
                //         sap.m.MessageToast.show("Release process completed.");
                //     }
                // }
                function checkCompletion() {
                    iCompleted++;
                    if (iCompleted === aSelectedRows.length) {
                        oTableModel.setProperty("/Samples", aRows);
                        oTableModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        sap.m.MessageToast.show("Release process completed.");

                        // 🔁 Refresh the BOM data in the fragment
                        that._refreshBomData();
                    }
                }


                function checkCompletion01() {
                    iCompleted++;
                    if (iCompleted === aSelectedRows.length) {
                        oTableModel.setProperty("/Samples", aRows);
                        oTableModel.refresh();
                        sap.ui.core.BusyIndicator.hide();
                        // Optional: sap.m.MessageToast.show("Release process completed.");
                    }
                }
            },

            //refetching data after release such that batch is fetched in the bom
            _refreshBomData: function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

                const aSelectedRows = oTableModel.getProperty("/SelectedRowData");
                if (!aSelectedRows || aSelectedRows.length === 0) return;

                const sProdOrderNo = aSelectedRows[0].productionorderno;

                const aReservationFilter = [
                    new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
                ];

                // Step 1: Get Reservation
                oODataModel.read("/ZC_RESERVATION_COMPONENT", {
                    filters: aReservationFilter,
                    success: function (oReservationData) {
                        const aResults = oReservationData.results;
                        if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
                            sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
                            return;
                        }

                        const sReservation = aResults[0].Reservation;

                        // Step 2: Fetch BOM
                        const aBomFilters = [
                            new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
                        ];

                        oODataModel.read("/ZC_RELEASE_BOM", {
                            filters: aBomFilters,
                            success: function (oBomData) {
                                oTableModel.setProperty("/BomRelease", oBomData.results || []);
                                oTableModel.refresh();
                                sap.m.MessageToast.show("BOM data refreshed successfully.");
                            },
                            error: function (oError) {
                                console.error("Error fetching refreshed BOM data:", oError);
                            }
                        });
                    },
                    error: function (oError) {
                        console.error("Error fetching reservation:", oError);
                    }
                });
            },


            onRowSelectionChange: async function (oEvent) {
                const oCheckBox = oEvent.getSource();
                const oView = this.getView();

                // Get the table model and all rows
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/BomRelease");

                // Get the binding context path of the checkbox
                const sPath = oCheckBox.getBindingContext("TabModel").getPath(); // e.g., "/BomRelease/3"
                const iIndex = parseInt(sPath.split("/").pop());

                // Get the selected row data
                const oSelectedRowData = aRows[iIndex];
                console.log("Selected Row Data:", oSelectedRowData);

                // --- Prepare Data for Barcode ---
                const barcodeData = `
                    ManufacturingOrder: ${oSelectedRowData.ManufacturingOrder || ""}
                    Product: ${oSelectedRowData.Product || ""}
                    Plant: ${oSelectedRowData.Plant || ""}
                    StorageLocation: ${oSelectedRowData.StorageLocation || ""}
                    Batch: ${oSelectedRowData.Batch || ""}
                    Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}
                    UOM: ${oSelectedRowData.BaseUnit || ""}
                `;

                // --- Generate Barcode ---
                const canvas = document.createElement("canvas");
                JsBarcode(canvas, oSelectedRowData.ManufacturingOrder || "N/A", {
                    format: "CODE128",
                    width: 2,
                    height: 60,
                    displayValue: true
                });

                const barcodeBase64 = canvas.toDataURL("image/png");

                // --- Generate PDF with Barcode ---
                const { jsPDF } = window.jspdf;
                const doc = new jsPDF();

                doc.setFontSize(12);
                doc.text(`Manufacturing Order: ${oSelectedRowData.ManufacturingOrder || ""}`, 20, 30);
                doc.text(`Product: ${oSelectedRowData.Product || ""}`, 20, 40);
                doc.text(`Plant: ${oSelectedRowData.Plant || ""}`, 20, 50);
                doc.text(`Storage Location: ${oSelectedRowData.StorageLocation || ""}`, 20, 60);
                doc.text(`Batch: ${oSelectedRowData.Batch || ""}`, 20, 70);
                doc.text(`Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}`, 20, 80);
                doc.text(`UOM: ${oSelectedRowData.BaseUnit || ""}`, 20, 90);

                // Add Barcode image to PDF
                doc.addImage(barcodeBase64, "PNG", 140, 20, 50, 20);

                // Open PDF in new tab
                const blob = doc.output("blob");
                const pdfUrl = URL.createObjectURL(blob);
                window.open(pdfUrl, "_blank");
            },

            // ======================================================================================
            // ======================================================================================
            // ======================================================================================


            onBatchValueHelp: function (oEvent) {
                const oView = this.getView();
                const oSource = oEvent.getSource();
                this._oBatchInputSource = oSource; // Save for setting value later

                // Load fragment if not already created
                if (!this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog = sap.ui.xmlfragment(
                        oView.getId(),
                        "bando.view.CommonFragments.ActualScreens.bombatchselect",
                        this
                    );
                    oView.addDependent(this._oBatchValueHelpDialog);
                }

                // Get current row data (for filtering)
                const oContext = oSource.getBindingContext("TabModel");
                if (!oContext) {
                    sap.m.MessageToast.show("No row context found.");
                    return;
                }

                const oRowData = oContext.getObject();
                const sMaterial = oRowData.Product;
                const sPlant = oRowData.Plant;
                const sStorageLoc = oRowData.StorageLocation;

                // Load data before opening
                this._loadBatchData(sMaterial, sPlant, sStorageLoc);
            },

            // ===========================================================
            // Load Batch Data and Bind to Fragment Table
            // ===========================================================
            _loadBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB"); // backend OData model

                // Build filters
                const aFilters = [
                    new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                const that = this;
                oModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        console.log("✅ Batch data received:", oData);

                        // Create JSON model from results array
                        const oJSONModel = new sap.ui.model.json.JSONModel(oData.results);

                        // Get table from fragment
                        const oTable = sap.ui.core.Fragment.byId(oView.getId(), "batchTable");
                        if (oTable) {
                            oTable.setModel(oJSONModel, "BatchModel");
                            console.log("✅ Bound rows:", oJSONModel.getData());
                            that._oBatchValueHelpDialog.open();
                        } else {
                            console.error("❌ batchTable not found in fragment");
                        }
                    },

                    error: function (oError) {
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // ===========================================================
            // Handle "Select" Button - Set Batch value in Input Field
            // ===========================================================

            onBatchRowSelect: function (oEvent) {
                const oTable = oEvent.getSource();
                const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

                if (!oSelectedContext) {
                    sap.m.MessageToast.show("No row selected.");
                    return;
                }

                const oSelectedData = oSelectedContext.getObject();

                if (this._oBatchInputSource) {
                    this._oBatchInputSource.setValue(oSelectedData.Batch); // Set selected batch
                }

                // Close and destroy the dialog to avoid reuse issues
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy();
                    this._oBatchValueHelpDialog = null;
                }
            },


            // ===========================================================
            // Handle "Cancel" Button
            // ===========================================================
            onValueHelpCancel: function () {
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy(); // cleanup
                    this._oBatchValueHelpDialog = null; // reset reference
                }
            },






            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Release END
            // ------------------------------------------------------------------------------------------------------------------------------------------





            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse reciept start
            // ------------------------------------------------------------------------------------------------------------------------------------------













            onReverseReceiptPress: function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1"); //ZSB_REVERSE_PORD    // Reverse OData model

                const oBuildingPlanModel = oView.getModel("ZSB_BUILDING_PLAN");   // For updating internal table
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
                    return;
                }

                // Check for missing GR Material Document Number or Year
                const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
                if (aInvalidRows.length > 0) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);
                let iCompleted = 0;

                const aFilters = [
                    new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, aSelectedRows[0].productionorderno)
                ];
                oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                    filters: aFilters,
                    success: function (oData) {
                        const aResults = oData.results;
                        // const oEntry = aResults && aResults[0];
                        // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

                        // const mapped = aResults.map(entry => {
                        //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
                        //   });

                        //   const oEntry = mapped.find(entry => entry !== null);
                        var bExists = aResults.some(function (oItem) {
                            return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
                        });

                        // const iSelectedIndex = aRows.findIndex(row => row.__selected);



                        if (bExists) {
                            console.log("Combination exists: I0002 and active.");
                            // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
                            sap.m.MessageToast.show("Teco already active, cant reverse");
                            sap.ui.core.BusyIndicator.hide();

                            return;
                        }
                        else {
                            aSelectedRows.forEach((row, index) => {
                                const oPayload = {
                                    Materialdocument: row.grmaterialdocnumber,
                                    Matdocyear: row.grmaterialdocyear, // You can make this dynamic if needed
                                    Postingdate: new Date()
                                };

                                console.log(`📤 Sending Reverse Receipt Payload for row ${index + 1}:`, oPayload);

                                oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
                                    success: function (oData) {
                                        console.log(`✅ Reverse receipt success for row ${index + 1}:`, oData);

                                        const sResponseValue = oData.Response || "";

                                        // Update internal table field `grmaterialdocnumber`
                                        const sUpdatePath = "/ZC_BUILDING_PLAN('" + row.sap_uuid + "')";
                                        const oUpdateEntry = {
                                            grmaterialdocnumber: sResponseValue,
                                            grmaterialdocyear: "",
                                        };

                                        oBuildingPlanModel.update(sUpdatePath, oUpdateEntry, {
                                            success: function () {
                                                console.log(`🔄 grmaterialdocnumber updated for row ${index + 1}`);
                                                row.grmaterialdocnumber = sResponseValue;
                                                row.grmaterialdocyear = "";
                                                checkCompletion();
                                            },
                                            error: function () {
                                                console.warn(`⚠️ Failed to update grmaterialdocnumber for row ${index + 1}`);
                                                checkCompletion();
                                            }
                                        });
                                    },
                                    error: function (oError) {
                                        console.error(`❌ Reverse receipt failed for row ${index + 1}`, oError);
                                        checkCompletion();
                                    }
                                });
                            });

                            function checkCompletion() {
                                iCompleted++;
                                if (iCompleted === aSelectedRows.length) {
                                    oTableModel.setProperty("/Samples", aRows);
                                    oTableModel.refresh();
                                    sap.ui.core.BusyIndicator.hide();
                                    sap.m.MessageToast.show("Reverse receipt process completed.");
                                }
                            }

                        }

                    }
                });

            },










            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse issue start
            // ------------------------------------------------------------------------------------------------------------------------------------------





            // onReverseIssuePress: function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_CNFISSUEREVERSE"); // Backend OData model for reverse

            //     // 🔁 Static test payload
            //     const oPayload = {
            //         Porderno: "110000150",            // Replace with actual Production Order number
            //         ConfirmationGroup: "0000000176",     // Replace with actual Confirmation Group
            //         ConfirmationCount: "00000005"      // Replace with actual Confirmation Count
            //     };


            //     console.log("📤 Sending Reverse issue Payload:", oPayload);
            //     sap.ui.core.BusyIndicator.show(0);

            //     oModel.create("/ZDD_CNFISSUERSV", oPayload, {
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();
            //             console.log("✅ Reverse issue POST Success:", oData);
            //             sap.m.MessageToast.show("Reverse issue request posted successfully.");
            //         },
            //         error: function (oError) {
            //             sap.ui.core.BusyIndicator.hide();
            //             console.error("❌ Reverse issue POST Failed:", oError);
            //             sap.m.MessageBox.error("Reverse issue failed. Check console for details.");
            //         }
            //     });
            // },



            onReverseIssuePress: function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");//ZSB_CNFISSUEREVERSE // Reverse API model 
                const oBuildingPlanModel = oView.getModel("ZSB_BUILDING_PLAN"); // For PATCH

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse issue.");
                    return;
                }


                // ✅ New Validation: Prevent if any row has grmaterialdocnumber
                const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
                if (aHasGRRows.length > 0) {
                    sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
                    return;
                }


                // Check for missing GR Material Document Number or Year
                const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
                if (aInvalidRows1.length > 0) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
                    return;
                }
                // const aInvalidRows2 = aSelectedRows.filter(row => !row.grmaterialdocnumber);
                // if (aInvalidRows2.length > 0) {
                //     sap.ui.core.BusyIndicator.hide();
                //     sap.m.MessageBox.error("Cannot reverse Issue: Do Reciept reverse first.");
                //     return;
                // }





                sap.ui.core.BusyIndicator.show(0);
                let iCompleted = 0;

                aSelectedRows.forEach((row, index) => {
                    const oPayload = {
                        Porderno: row.productionorderno,
                        ConfirmationGroup: row.gicnfconfirmationgroup,
                        ConfirmationCount: row.gicnfconfirmationcount
                    };

                    console.log(`📤 Sending Reverse Issue Payload for row ${index + 1}:`, oPayload);

                    oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
                        success: function (oData) {
                            console.log(`✅ Reverse issue success for row ${index + 1}:`, oData);

                            // Get the returned material document number (assuming field is "Response")
                            const sResponseValue = oData.Response || "";

                            // Update Building Plan table with returned Response
                            const sUpdatePath = "/ZC_BUILDING_PLAN('" + row.sap_uuid + "')";
                            const oUpdateEntry = {
                                gicnfmaterialdocnumber: "",
                                gicnfconfirmationgroup: "",
                                gicnfconfirmationcount: "",
                                gicnfmaterialdocyear: ""
                            };

                            oBuildingPlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: function () {
                                    console.log(`🔄 gicnfmaterialdocnumber updated for row ${index + 1}`);
                                    row.gicnfmaterialdocnumber = "";
                                    row.gicnfconfirmationgroup = "";
                                    row.gicnfconfirmationcount = "";
                                    row.gicnfmaterialdocyear = "";
                                    checkCompletion();
                                },
                                error: function () {
                                    console.warn(`⚠️ Failed to update gicnfmaterialdocnumber for row ${index + 1}`);
                                    checkCompletion();
                                }
                            });
                        },
                        error: function (oError) {
                            console.error(`❌ Reverse issue failed for row ${index + 1}`, oError);
                            checkCompletion();
                        }
                    });
                });

                function checkCompletion() {
                    iCompleted++;
                    if (iCompleted === aSelectedRows.length) {
                        oTableModel.setProperty("/Samples", aRows);
                        oTableModel.refresh();
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Reverse issue process completed.");
                    }
                }
            },

            //srikar

            onPrintPress: async function () {
                const oModel = this.getView().getModel("TabModel").getProperty("/Samples");
                const aSelectedRows = oModel.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                const { jsPDF } = window.jspdf;

                const loadImageAsBase64 = async (url) => {
                    const response = await fetch(url);
                    const blob = await response.blob();
                    return new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.onerror = reject;
                        reader.readAsDataURL(blob);
                    });
                };

                const svgLogoBase64 = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode.png"));
                const svgLogoBase64_ = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode2.png"));
                const svgLogoBase64_Bando = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/Bando.png"));

                const generateSectionHTML = (data) => {
                    const isEmpty = !data;
                    const lotbatchno = data?.lotbatchno || "";
                    const batchweight = data?.batchweight || "";
                    const manufacturingdate = data?.manufacturingdate ? new Date(data.manufacturingdate).toLocaleDateString("en-GB") : "";
                    const productionordstartdate = data?.productionordstartdate ? new Date(data.productionordstartdate).toLocaleDateString("en-GB") : "";
                    const confirmedqty = data?.confirmedqty || "";
                    const compoundcode = data?.compoundcode || "";
                    const operator = data?.operator || "";
                    const expirydate = data?.expirydate ? new Date(data.expirydate).toLocaleDateString("en-GB") : "";
                    const inspector = data?.inspector || "";
                    const productionorderqty = data?.productionorderqty || "";
                    const productionorderno = data?.productionorderno || "";

                    return `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            * { box-sizing: border-box; }
            .row { display: flex; margin: 0; }
            .column1 { flex: 120%; padding: 6px; }
            .column2 { flex: 110%; padding-left: 30px; padding-top: 5px; padding-right: 5px; }
            table, th, td {
              border: 1px solid black;
              border-collapse: collapse;
              text-align: left;
              padding: 5px;
            }
            .center-align { text-align: center; }
          </style>
        </head>
        <body>
        <div class="row">
          <div class="column1">
            <table style="width:106%">
              <tr>
                <td colspan="7" style="text-align:left;">
                  <img src="${svgLogoBase64_Bando}" alt="Bando Logo" width="100" style="vertical-align: middle; margin-right: 10px;">
                  Building Process lot Guarantee Card
                </td>
              </tr>
              <tr>
                <td colspan="2">B I P L COMPOUND FORMULA</td>
                <td colspan="2">COMPOUND CODE</td>
                <td colspan="4" class="center-align">${compoundcode}</td>
              </tr>
              <tr>
                <td>Production ord No : ${productionorderno}</td>
                <td>Production Date :<br>${manufacturingdate}</td>
                <td>Lot No.</td>
                <td>${lotbatchno}</td>
                <td>EXPIRY DATE</td>
                <td>${expirydate}</td>
              </tr>
              <tr>
                <td>
                  <table>
                    <tr><td>Batch Wt. - kgs</td></tr>
                    <tr>
                      <td>
                        <table>
                          <tr><td>Spec.</td><td>${productionorderqty}</td></tr>
                          <tr><td>Actual</td><td>${confirmedqty}</td></tr>
                          <tr><td>Difference</td><td>${productionorderqty - confirmedqty}</td></tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
                <td colspan="4">
                  ${!isEmpty ? `<img src="${svgLogoBase64_}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td>Operator</td>
              </tr>
              <tr>
                <td colspan="2">
                  ${!isEmpty ? `<img src="${svgLogoBase64}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td colspan="4">
                  <table style="width:100%">
                    <tr>
                      <th class="center-align">Operator</th>
                      <th class="center-align">Inspector</th>
                    </tr>
                    <tr>
                      <td class="center-align"><br><br>${operator}<br><br></td>
                      <td class="center-align">${inspector}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>
          <div class="column2">
            <table style="width:118%">
              <tr><td class="center-align">Compound Code<br><br><br>${compoundcode}</td></tr>
              <tr><td class="center-align">Lot No<br><br><br>${lotbatchno}</td></tr>
              <tr><td class="center-align">Production Date<br><br><br>${manufacturingdate}</td></tr>
              <tr><td class="center-align">Operator Sign<br><br><br><br><br><br>${operator}</td></tr>
            </table>
          </div>
        </div>
        </body>
        </html>
        `;
                };

                const doc = new jsPDF('l', 'mm', [297, 148.5]); // Half A4 landscape

                const promises = aSelectedRows.map((row, idx) => {
                    return new Promise((resolve, reject) => {
                        const htmlContent = generateSectionHTML(row);

                        const iframe = document.createElement('iframe');
                        iframe.style.position = 'fixed';
                        iframe.style.top = '-100000px';
                        document.body.appendChild(iframe);

                        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        iframeDoc.open();
                        iframeDoc.write(htmlContent);
                        iframeDoc.close();

                        iframe.onload = () => {
                            html2canvas(iframeDoc.body, { scale: 3 }).then(canvas => {
                                const imgData = canvas.toDataURL('image/jpeg', 0.95);
                                doc.addImage(imgData, 'JPEG', 0, 0, 297, 148.5);
                                if (idx !== aSelectedRows.length - 1) {
                                    doc.addPage();
                                }
                                document.body.removeChild(iframe);
                                resolve();
                            }).catch(error => {
                                document.body.removeChild(iframe);
                                reject(error);
                            });
                        };
                    });
                });

                await Promise.all(promises);

                const blob = doc.output('blob');
                const pdfUrl = URL.createObjectURL(blob);

                if (!this._PDFViewer) {
                    this._PDFViewer = new sap.m.PDFViewer({
                        source: pdfUrl,
                        title: "Building Guarantee Card",
                        width: "auto"
                    });
                    jQuery.sap.addUrlWhitelist("blob");
                }

                this._PDFViewer.setSource(pdfUrl);
                this._PDFViewer.open();
            },


            

            // ==========================================================================================
            // ====================================MATERIAL FRAGMENT=================================
            // ==========================================================================================
            onMaterialFragmentOpenSimple: function (oEvent) {
                this._oInputField = oEvent.getSource();
                var oView = this.getView();

                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                        this
                    );
                    oView.addDependent(this._oMaterialDialog);
                }

                var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
                var that = this;

                // Only fetch materials with ProductGroup = "38"
                oModel.read("/ZC_MATERIALMASTER1", {
                    filters: [
                        new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "41")
                    ],
                    success: function (oData) {
                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
                        that._oMaterialDialog.setModel(oJSON, "VHModel");
                        that._oMaterialDialog.open();
                    },
                    error: function () {
                        sap.m.MessageToast.show("Error fetching materials");
                    }
                });
            },

            onMaterialSelected: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

                if (this._oInputField) {
                    // If input is inside a table row (has a binding context)
                    var oRowCtx = this._oInputField.getBindingContext("TabModel");
                    if (oRowCtx) {
                        oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialcode", oCtx.Product);
                        oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialname", oCtx.ProductName);
                    } else {
                        // If it’s a standalone input field (like yours)
                        this.getView().getModel("TabModel").setProperty("/materialcode", oCtx.Product);
                        this.getView().getModel("TabModel").setProperty("/materialname", oCtx.ProductName);

                        // Update input field value directly
                        this._oInputField.setValue(oCtx.Product);
                    }
                }

                // this._oMaterialDialog.close();
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null; // reset reference
                }
            },


            onMaterialSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

                var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },

            onVHClose: function () {
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null; // reset reference
                }
            },

            // ==========================================================================================
            // ========================PRODUCTION ORDER NUMBER FRAGMENT=================================
            // ==========================================================================================

            onProductionOrderValueHelp: function (oEvent) {
                this._oPOInputField = oEvent.getSource();
                var oView = this.getView();

                if (!this._oProductionOrderDialog) {
                    this._oProductionOrderDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                        this
                    );
                    oView.addDependent(this._oProductionOrderDialog);
                }

                var oModel = this.getView().getModel("ZSB_BUILDING_PLAN");
                var that = this;

                oModel.read("/ZC_BUILDING_PLAN", {
                    urlParameters: {
                        "$top": 1000 // fetch top 1000 for scrollable table; can adjust
                    },
                    success: function (oData) {
                        var oJSON = new sap.ui.model.json.JSONModel({ Orders: oData.results });
                        that._oProductionOrderDialog.setModel(oJSON, "VHModel");
                        that._oProductionOrderDialog.open();
                    },
                    error: function () {
                        sap.m.MessageToast.show("Error fetching Production Orders");
                    }
                });
            },

            onProductionOrderSelected: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

                if (this._oPOInputField) {
                    // Set the selected Production Order No directly to the input field
                    this._oPOInputField.setValue(oCtx.productionorderno);
                }

                // this._oProductionOrderDialog.close();
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null; // reset reference
                }
            },


            onProductionOrderSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

                var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },

            onProductionOrderVHClose: function () {
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null; // reset reference
                }
            },




        });
    }
);
