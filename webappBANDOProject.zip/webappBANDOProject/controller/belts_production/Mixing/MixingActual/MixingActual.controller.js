sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",
        "bando/util/jspdf/html2canvasmin",
        "bando/util/jspdf/jspdfmin",
        "bando/util/importfile/importexcelfile",
        "sap/ndc/BarcodeScanner",
        // "bando/util/barcode/JsBarcode.all.min"
        "bando/util/barcode/JsBarcode.all.min",
        "sap/ui/core/Fragment",
        // "sap/ui/model/Filter",
        // "sap/ui/model/FilterOperator"

    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile, BarcodeScanner, Fragment) {
        "use strict";

        return BaseController.extend("bando.controller.belts_production.Mixing.MixingActual.MixingActual", {

            onInit: function () {
                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [],
                    // this is the fragments table of bom in release....which is usin tabmodel
                    BomRelease: [
                        {

                        }
                    ]
                });
                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: { selectall: false }
                });
                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");


                // this._selectedProductionOrders = [];
                this._selectedProductionOrders = []; // track selected tokens globally
                this._selectedMaterials = [];

                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("MixingActual").attachMatched(this._onRouteMatched, this);
            },

            _onRouteMatched: function () {
                // Clear table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);

                // Reset header model (if needed)
                this.HeaderModel = new sap.ui.model.json.JSONModel({
                    HeaderData: {
                        idDateRange: "",
                        idPlant: "",
                        idMaterial: "",
                        idProductionorderno: "",
                    }
                });
                this.getView().setModel(this.HeaderModel, "HeaderModel");

                // 🔥 CLEAR INPUT FIELDS BY ID (this is what fixes your issue)
                this.byId("idDateRange").setDateValue(null);
                this.byId("idDateRange").setSecondDateValue(null);

                this.byId("idPlant").setValue("");


                // this.byId("idMaterial").setValue("");
                var oMaterialInput = this.byId("idMaterial");
                oMaterialInput.setValue("");  // Clear the value
                oMaterialInput.removeAllTokens();  // Clear all tokens

                // this.byId("idProductionorderno").setValue("");
                var oPOInput = this.byId("idProductionorderno");
                oPOInput.setValue("");  // Clear the value
                oPOInput.removeAllTokens();  // Clear all tokens

            },
            onBeforeRendering: function () {
                var oUserInfo = sap.ushell.Container.getService("UserInfo");
                this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
                console.log("user id:", this.sUserId)
            },



            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },


// GoMixingActual: function (callback) {
//     const oView = this.getView();
//     const oModel = oView.getModel("ZSB_MIXING_PLAN1");
//     const oTabModel = oView.getModel("TabModel");
//     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

//     // --- Collect filters -------------------------------------------------
//     const oDateRange = oView.byId("idDateRange");
//     const oPlant = oView.byId("idPlant").getValue().trim();
//     const oShiftComboBox = oView.byId("idshift");
//     const sSelectedShift = oShiftComboBox.getSelectedKey();
//     const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();
//     const oMaterialInput = oView.byId("idMaterial");
//     const aMaterialTokens = oMaterialInput.getTokens();
//     const aMaterials = aMaterialTokens.map(t => t.getKey());
//     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

//     const oMI = oView.byId("idProductionorderno");
//     const aTokens = oMI.getTokens();
//     const aProductionOrders = aTokens.map(t => t.getKey());

//     const oStartDate = oDateRange.getDateValue();
//     const oEndDate = oDateRange.getSecondDateValue();

//     // Mandatory start date
//     if (!oStartDate) {
//         sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
//         oDateRange.setValueState("Error");
//         oDateRange.setValueStateText("Please select Production Order Start Date.");
//         return;
//     } else {
//         oDateRange.setValueState("None");
//     }

//     // Build filter array for the first read
//     const aFilters = [];
//     if (oStartDate && oEndDate) {
//         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
//         const sStartDate = oDateFormat.format(oStartDate);
//         const sEndDate = oDateFormat.format(oEndDate);
//         aFilters.push(new sap.ui.model.Filter({
//             path: "productionordstartdate",
//             operator: sap.ui.model.FilterOperator.BT,
//             value1: sStartDate,
//             value2: sEndDate
//         }));
//     }
//     if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
//     if (oMachineNumber) aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
//     if (sSelectedShift) aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
//     if (sBiplLotNo) aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
//     if (aMaterials.length > 0) {
//         const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
//         aFilters.push(new sap.ui.model.Filter({ filters: aMaterialFilters, and: false }));
//     }
//     if (aProductionOrders.length > 0) {
//         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
//         aFilters.push(new sap.ui.model.Filter({ filters: aPOFilters, and: false }));
//     }

//     const oDynamicPage = this.byId("dynamicgeneralpurchase");
//     if (oDynamicPage) oDynamicPage.setShowFooter(true);

//     sap.ui.core.BusyIndicator.show(0);

//     // ---------- Helper: fetch all pages from an OData entity ----------
//     function fetchAllPages(oModel, sEntitySet, aFilters, iPageSize = 1000) {
//         const deferred = $.Deferred();
//         let allResults = [];
//         let iSkip = 0;

//         function fetchPage() {
//             oModel.read(sEntitySet, {
//                 filters: aFilters,
//                 urlParameters: {
//                     "$top": iPageSize,
//                     "$skip": iSkip
//                 },
//                 success: function (oData) {
//                     const aPage = oData.results || [];
//                     allResults = allResults.concat(aPage);
//                     if (aPage.length < iPageSize) {
//                         deferred.resolve(allResults);
//                     } else {
//                         iSkip += iPageSize;
//                         fetchPage();
//                     }
//                 },
//                 error: function (oError) {
//                     deferred.reject(oError);
//                 }
//             });
//         }

//         fetchPage();
//         return deferred.promise();
//     }

//     // ---------- Helper: fetch TECO status for a list of orders using chunked OR ----------
//     function fetchTecoForOrders(oModel, aOrderNumbers, iChunkSize = 500) {
//         const deferred = $.Deferred();
//         const allTecoOrders = [];
//         const aChunks = [];

//         for (let i = 0; i < aOrderNumbers.length; i += iChunkSize) {
//             aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
//         }

//         if (aChunks.length === 0) {
//             deferred.resolve(new Set());
//             return deferred.promise();
//         }

//         function processChunk(chunk) {
//             const aOrderFilters = chunk.map(order =>
//                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
//             );
//             const oOrFilter = new sap.ui.model.Filter({ filters: aOrderFilters, and: false });

//             const aCombinedFilters = [
//                 oOrFilter,
//                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
//                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
//             ];

//             const oDeferred = $.Deferred();
//             oModel.read("/ZC_ORDER_CREATION1", {
//                 filters: aCombinedFilters,
//                 urlParameters: { "$top": chunk.length * 2 },
//                 success: function (oData) {
//                     const aResults = oData.results || [];
//                     const aTecoOrders = aResults.map(item => item.ManufacturingOrder);
//                     oDeferred.resolve(aTecoOrders);
//                 },
//                 error: function (oError) {
//                     oDeferred.reject(oError);
//                 }
//             });
//             return oDeferred.promise();
//         }

//         function processSequentially(index) {
//             if (index >= aChunks.length) {
//                 deferred.resolve(new Set(allTecoOrders));
//                 return;
//             }
//             processChunk(aChunks[index])
//                 .then(function (aTecoOrders) {
//                     allTecoOrders.push(...aTecoOrders);
//                     processSequentially(index + 1);
//                 })
//                 .catch(function (oError) {
//                     deferred.reject(oError);
//                 });
//         }

//         processSequentially(0);
//         return deferred.promise();
//     }

//     // ---------- Step 1: Fetch all rows from the main entity ----------
//     fetchAllPages(oModel, "/ZC_MIXING_PLAN1", aFilters, 1000)
//         .then(function (aAllRows) {
//             console.log("Total rows fetched from main entity:", aAllRows.length);

//             // Filter out invalid production order numbers
//             const aFiltered = aAllRows.filter(row => {
//                 const prodOrder = row.productionorderno;
//                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
//             });
//             console.log("After removing invalid production order numbers:", aFiltered.length);

//             if (aFiltered.length === 0) {
//                 sap.ui.core.BusyIndicator.hide();
//                 oTabModel.setProperty("/Samples", []);
//                 oView.byId("idmixactualtablescreen").setVisible(true);
//                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");
//                 if (callback && typeof callback === 'function') {
//                     callback([]);
//                 }
//                 return;
//             }

//             // Unique production orders
//             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];
//             console.log("Unique production orders to check for TECO:", aUniqueOrders.length);

//             // ---------- Step 2: Fetch TECO status only for these orders (chunked) ----------
//             return fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
//                 .then(function (tecoSet) {
//                     console.log("TECO orders found among the queried list:", tecoSet.size);

//                     const aFinal = aFiltered.filter(row => !tecoSet.has(row.productionorderno));
//                     console.log("Rows after removing TECO orders:", aFinal.length);

//                     sap.ui.core.BusyIndicator.hide();
//                     oTabModel.setProperty("/Samples", aFinal);
//                     oView.byId("idmixactualtablescreen").setVisible(true);
//                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

//                     if (callback && typeof callback === 'function') {
//                         callback(aFinal);
//                     }
//                 }.bind(this));
//         }.bind(this))
//         .catch(function (oError) {
//             sap.ui.core.BusyIndicator.hide();
//             console.error("Error in data fetching:", oError);
//             sap.m.MessageBox.error("Error fetching data. Please try again.");
//             oTabModel.setProperty("/Samples", []);
//             oView.byId("idmixactualtablescreen").setVisible(true);
//             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
//             oView.setModel(Tab_SelectAll, "Tab_SelectAll");
//             if (callback && typeof callback === 'function') {
//                 callback([]);
//             }
//         }.bind(this));
// },



GoMixingActual: function (callback) {
    const oView = this.getView();
    const oModel = oView.getModel("ZSB_MIXING_PLAN1");
    const oTabModel = oView.getModel("TabModel");
    const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

    // --- Collect filters -------------------------------------------------
    const oDateRange = oView.byId("idDateRange");
    const oPlant = oView.byId("idPlant").getValue().trim();
    const oShiftComboBox = oView.byId("idshift");
    const sSelectedShift = oShiftComboBox.getSelectedKey();
    const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();
    const oMaterialInput = oView.byId("idMaterial");
    const aMaterialTokens = oMaterialInput.getTokens();
    const aMaterials = aMaterialTokens.map(t => t.getKey());
    const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

    const oMI = oView.byId("idProductionorderno");
    const aTokens = oMI.getTokens();
    const aProductionOrders = aTokens.map(t => t.getKey());

    const oStartDate = oDateRange.getDateValue();
    const oEndDate = oDateRange.getSecondDateValue();

    // --- Read TECO dropdown selection ------------------------------------
    const oTecoFilter = oView.byId("idTecoFilter");
    const sTecoFilter = oTecoFilter ? oTecoFilter.getSelectedKey() : "UN-TECO";

    // Mandatory start date
    if (!oStartDate) {
        sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
        oDateRange.setValueState("Error");
        oDateRange.setValueStateText("Please select Production Order Start Date.");
        return;
    } else {
        oDateRange.setValueState("None");
    }

    // Build filter array for the first read
    const aFilters = [];
    if (oStartDate && oEndDate) {
        const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
        const sStartDate = oDateFormat.format(oStartDate);
        const sEndDate = oDateFormat.format(oEndDate);
        aFilters.push(new sap.ui.model.Filter({
            path: "productionordstartdate",
            operator: sap.ui.model.FilterOperator.BT,
            value1: sStartDate,
            value2: sEndDate
        }));
    }
    if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
    if (oMachineNumber) aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
    if (sSelectedShift) aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
    if (sBiplLotNo) aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
    if (aMaterials.length > 0) {
        const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
        aFilters.push(new sap.ui.model.Filter({ filters: aMaterialFilters, and: false }));
    }
    if (aProductionOrders.length > 0) {
        const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
        aFilters.push(new sap.ui.model.Filter({ filters: aPOFilters, and: false }));
    }

    const oDynamicPage = this.byId("dynamicgeneralpurchase");
    if (oDynamicPage) oDynamicPage.setShowFooter(true);

    sap.ui.core.BusyIndicator.show(0);

    // ---------- Helper: fetch all pages from an OData entity ----------
    function fetchAllPages(oModel, sEntitySet, aFilters, iPageSize = 1000) {
        const deferred = $.Deferred();
        let allResults = [];
        let iSkip = 0;

        function fetchPage() {
            oModel.read(sEntitySet, {
                filters: aFilters,
                urlParameters: {
                    "$top": iPageSize,
                    "$skip": iSkip
                },
                success: function (oData) {
                    const aPage = oData.results || [];
                    allResults = allResults.concat(aPage);
                    if (aPage.length < iPageSize) {
                        deferred.resolve(allResults);
                    } else {
                        iSkip += iPageSize;
                        fetchPage();
                    }
                },
                error: function (oError) {
                    deferred.reject(oError);
                }
            });
        }

        fetchPage();
        return deferred.promise();
    }

    // ---------- Helper: fetch TECO status for a list of orders using chunked OR ----------
    function fetchTecoForOrders(oModel, aOrderNumbers, iChunkSize = 500) {
        const deferred = $.Deferred();
        const allTecoOrders = [];
        const aChunks = [];

        for (let i = 0; i < aOrderNumbers.length; i += iChunkSize) {
            aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
        }

        if (aChunks.length === 0) {
            deferred.resolve(new Set());
            return deferred.promise();
        }

        function processChunk(chunk) {
            const aOrderFilters = chunk.map(order =>
                new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            );
            const oOrFilter = new sap.ui.model.Filter({ filters: aOrderFilters, and: false });

            const aCombinedFilters = [
                oOrFilter,
                new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            ];

            const oDeferred = $.Deferred();
            oModel.read("/ZC_ORDER_CREATION1", {
                filters: aCombinedFilters,
                urlParameters: { "$top": chunk.length * 2 },
                success: function (oData) {
                    const aResults = oData.results || [];
                    const aTecoOrders = aResults.map(item => item.ManufacturingOrder);
                    oDeferred.resolve(aTecoOrders);
                },
                error: function (oError) {
                    oDeferred.reject(oError);
                }
            });
            return oDeferred.promise();
        }

        function processSequentially(index) {
            if (index >= aChunks.length) {
                deferred.resolve(new Set(allTecoOrders));
                return;
            }
            processChunk(aChunks[index])
                .then(function (aTecoOrders) {
                    allTecoOrders.push(...aTecoOrders);
                    processSequentially(index + 1);
                })
                .catch(function (oError) {
                    deferred.reject(oError);
                });
        }

        processSequentially(0);
        return deferred.promise();
    }

    // ---------- Step 1: Fetch all rows from the main entity ----------
    fetchAllPages(oModel, "/ZC_MIXING_PLAN1", aFilters, 1000)
        .then(function (aAllRows) {
            console.log("Total rows fetched from main entity:", aAllRows.length);

            // Filter out invalid production order numbers
            const aFiltered = aAllRows.filter(row => {
                const prodOrder = row.productionorderno;
                return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            });
            console.log("After removing invalid production order numbers:", aFiltered.length);

            if (aFiltered.length === 0) {
                sap.ui.core.BusyIndicator.hide();
                oTabModel.setProperty("/Samples", []);
                oView.byId("idmixactualtablescreen").setVisible(true);
                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                if (callback && typeof callback === 'function') {
                    callback([]);
                }
                return;
            }

            // Unique production orders
            const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];
            console.log("Unique production orders to check for TECO:", aUniqueOrders.length);

            // ---------- Step 2: Fetch TECO status only for these orders (chunked) ----------
            return fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
                .then(function (tecoSet) {
                    console.log("TECO orders found among the queried list:", tecoSet.size);

                    // ---------- Step 3: Apply TECO filter based on dropdown ----------
                    let aFinal;
                    if (sTecoFilter === "TECO") {
                        // Keep only TECO orders
                        aFinal = aFiltered.filter(row => tecoSet.has(row.productionorderno));
                        console.log("Filtered to TECO orders:", aFinal.length);
                    } else if (sTecoFilter === "UN-TECO") {
                        // Keep only non‑TECO orders (original behaviour)
                        aFinal = aFiltered.filter(row => !tecoSet.has(row.productionorderno));
                        console.log("Filtered to UN‑TECO orders:", aFinal.length);
                    } else { // "ALL" or any other
                        // Keep all orders
                        aFinal = aFiltered;
                        console.log("Showing ALL orders:", aFinal.length);
                    }

                    sap.ui.core.BusyIndicator.hide();
                    oTabModel.setProperty("/Samples", aFinal);
                    oView.byId("idmixactualtablescreen").setVisible(true);
                    const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                    oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    if (callback && typeof callback === 'function') {
                        callback(aFinal);
                    }
                }.bind(this));
        }.bind(this))
        .catch(function (oError) {
            sap.ui.core.BusyIndicator.hide();
            console.error("Error in data fetching:", oError);
            sap.m.MessageBox.error("Error fetching data. Please try again.");
            oTabModel.setProperty("/Samples", []);
            oView.byId("idmixactualtablescreen").setVisible(true);
            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            if (callback && typeof callback === 'function') {
                callback([]);
            }
        }.bind(this));
},


GoMixingActualfilter: function (callback) {
    const oView = this.getView();
    const oModel = oView.getModel("ZSB_MIXING_PLAN1");
    const oTabModel = oView.getModel("TabModel");
    const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

    // --- Collect filters -------------------------------------------------
    const oDateRange = oView.byId("idDateRange");
    const oPlant = oView.byId("idPlant").getValue().trim();
    const oShiftComboBox = oView.byId("idshift");
    const sSelectedShift = oShiftComboBox.getSelectedKey();
    const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();
    const oMaterialInput = oView.byId("idMaterial");
    const aMaterialTokens = oMaterialInput.getTokens();
    const aMaterials = aMaterialTokens.map(t => t.getKey());
    const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

    const oMI = oView.byId("idProductionorderno");
    const aTokens = oMI.getTokens();
    const aProductionOrders = aTokens.map(t => t.getKey());

    const oStartDate = oDateRange.getDateValue();
    const oEndDate = oDateRange.getSecondDateValue();

    // Original validation: at least one filter criterion must be provided
    if (!oStartDate && !oEndDate && !oPlant && !oMachineNumber && aMaterials.length === 0 && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
        sap.m.MessageBox.warning("Please enter at least one filter criteria.");
        return;
    }

    // Build filter array for the first read
    const aFilters = [];
    if (oStartDate && oEndDate) {
        const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
        const sStartDate = oDateFormat.format(oStartDate);
        const sEndDate = oDateFormat.format(oEndDate);
        aFilters.push(new sap.ui.model.Filter({
            path: "productionordstartdate",
            operator: sap.ui.model.FilterOperator.BT,
            value1: sStartDate,
            value2: sEndDate
        }));
    }
    if (oPlant) aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
    if (oMachineNumber) aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
    if (sSelectedShift) aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
    if (sBiplLotNo) aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
    if (aMaterials.length > 0) {
        const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
        aFilters.push(new sap.ui.model.Filter({ filters: aMaterialFilters, and: false }));
    }
    if (aProductionOrders.length > 0) {
        const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
        aFilters.push(new sap.ui.model.Filter({ filters: aPOFilters, and: false }));
    }

    const oDynamicPage = this.byId("dynamicgeneralpurchase");
    if (oDynamicPage) oDynamicPage.setShowFooter(true);

    sap.ui.core.BusyIndicator.show(0);

    // ---------- Helper: fetch all pages from an OData entity ----------
    function fetchAllPages(oModel, sEntitySet, aFilters, iPageSize = 1000) {
        const deferred = $.Deferred();
        let allResults = [];
        let iSkip = 0;

        function fetchPage() {
            oModel.read(sEntitySet, {
                filters: aFilters,
                urlParameters: {
                    "$top": iPageSize,
                    "$skip": iSkip
                },
                success: function (oData) {
                    const aPage = oData.results || [];
                    allResults = allResults.concat(aPage);
                    if (aPage.length < iPageSize) {
                        deferred.resolve(allResults);
                    } else {
                        iSkip += iPageSize;
                        fetchPage();
                    }
                },
                error: function (oError) {
                    deferred.reject(oError);
                }
            });
        }

        fetchPage();
        return deferred.promise();
    }

    // ---------- Helper: fetch TECO status for a list of orders using chunked OR ----------
    function fetchTecoForOrders(oModel, aOrderNumbers, iChunkSize = 500) {
        const deferred = $.Deferred();
        const allTecoOrders = [];
        const aChunks = [];

        for (let i = 0; i < aOrderNumbers.length; i += iChunkSize) {
            aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
        }

        if (aChunks.length === 0) {
            deferred.resolve(new Set());
            return deferred.promise();
        }

        function processChunk(chunk) {
            const aOrderFilters = chunk.map(order =>
                new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            );
            const oOrFilter = new sap.ui.model.Filter({ filters: aOrderFilters, and: false });

            const aCombinedFilters = [
                oOrFilter,
                new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            ];

            const oDeferred = $.Deferred();
            oModel.read("/ZC_ORDER_CREATION1", {
                filters: aCombinedFilters,
                urlParameters: { "$top": chunk.length * 2 },
                success: function (oData) {
                    const aResults = oData.results || [];
                    const aTecoOrders = aResults.map(item => item.ManufacturingOrder);
                    oDeferred.resolve(aTecoOrders);
                },
                error: function (oError) {
                    oDeferred.reject(oError);
                }
            });
            return oDeferred.promise();
        }

        function processSequentially(index) {
            if (index >= aChunks.length) {
                deferred.resolve(new Set(allTecoOrders));
                return;
            }
            processChunk(aChunks[index])
                .then(function (aTecoOrders) {
                    allTecoOrders.push(...aTecoOrders);
                    processSequentially(index + 1);
                })
                .catch(function (oError) {
                    deferred.reject(oError);
                });
        }

        processSequentially(0);
        return deferred.promise();
    }

    // ---------- Step 1: Fetch all rows from the main entity ----------
    fetchAllPages(oModel, "/ZC_MIXING_PLAN1", aFilters, 1000)
        .then(function (aAllRows) {
            console.log("Total rows fetched from main entity:", aAllRows.length);

            // Filter out invalid production order numbers
            const aFiltered = aAllRows.filter(row => {
                const prodOrder = row.productionorderno;
                return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            });
            console.log("After removing invalid production order numbers:", aFiltered.length);

            if (aFiltered.length === 0) {
                sap.ui.core.BusyIndicator.hide();
                oTabModel.setProperty("/Samples", []);
                oView.byId("idmixactualtablescreen").setVisible(true);
                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                if (callback && typeof callback === 'function') {
                    callback([]);
                }
                return;
            }

            // Unique production orders
            const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];
            console.log("Unique production orders to check for TECO:", aUniqueOrders.length);

            // ---------- Step 2: Fetch TECO status only for these orders (chunked) ----------
            return fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
                .then(function (tecoSet) {
                    console.log("TECO orders found among the queried list:", tecoSet.size);

                    const aFinal = aFiltered.filter(row => !tecoSet.has(row.productionorderno));
                    console.log("Rows after removing TECO orders:", aFinal.length);

                    sap.ui.core.BusyIndicator.hide();
                    oTabModel.setProperty("/Samples", aFinal);
                    oView.byId("idmixactualtablescreen").setVisible(true);
                    const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                    oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    if (callback && typeof callback === 'function') {
                        callback(aFinal);
                    }
                }.bind(this));
        }.bind(this))
        .catch(function (oError) {
            sap.ui.core.BusyIndicator.hide();
            console.error("Error in data fetching:", oError);
            sap.m.MessageBox.error("Error fetching data. Please try again.");
            oTabModel.setProperty("/Samples", []);
            oView.byId("idmixactualtablescreen").setVisible(true);
            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            if (callback && typeof callback === 'function') {
                callback([]);
            }
        }.bind(this));
},


            applyAllFilters: function () {
                const oView = this.getView();
                const oReleaseCombo = oView.byId("comboReleaseStatusFilter");
                const oGICombo = oView.byId("comboGIStatusFilter");
                const oGRCombo = oView.byId("comboGRStatusFilter");
                const oConfirmedQtyCombo = oView.byId("comboConfirmedQtyFilter");

                const sRelease = oReleaseCombo.getSelectedKey();
                const sGI = oGICombo.getSelectedKey();
                const sGR = oGRCombo.getSelectedKey();
                const sConfirmedQty = oConfirmedQtyCombo.getSelectedKey();


                // If all filters are "All" (empty), just reload the full data without extra filtering
                if ((!sRelease || sRelease === "") &&
                    (!sGI || sGI === "") &&
                    (!sGR || sGR === "") &&
                    (!sConfirmedQty || sConfirmedQty === "")) {
                    this.GoMixingActualfilter();
                    return;
                }

                // Show loading indicator
                sap.ui.core.BusyIndicator.show(0);

                // Fetch fresh data (respects main search filters) and then apply status filters
                this.GoMixingActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Apply all three filters in one pass (AND condition)
                    const aFilteredData = fetchedData.filter(item => {
                        // ----- Release Status filter -----
                        let releaseOk = true;
                        if (sRelease && sRelease !== "") {
                            if (sRelease === "RELEASED") {
                                releaseOk = item.releasestatus === "RELEASED";
                            } else { // UNRELEASED
                                releaseOk = !item.releasestatus ||
                                    item.releasestatus.trim() === "" ||
                                    item.releasestatus === " ";
                            }
                        }

                        // ----- GI Status filter -----
                        let giOk = true;
                        if (sGI && sGI !== "") {
                            const giVal = item.gicnfmaterialdocnumber;
                            if (sGI === "COMPLETED") {
                                giOk = giVal && giVal.trim() !== "" && giVal !== "0";
                            } else { // NOT_COMPLETED
                                giOk = !giVal || giVal.trim() === "" || giVal === "0";
                            }
                        }

                        // ----- GR Status filter -----
                        let grOk = true;
                        if (sGR && sGR !== "") {
                            const grVal = item.grmaterialdocnumber;
                            if (sGR === "COMPLETED") {
                                grOk = grVal && grVal.trim() !== "" && grVal !== "0";
                            } else { // NOT_COMPLETED
                                grOk = !grVal || grVal.trim() === "" || grVal === "0";
                            }
                        }

                        // ----- Confirmed Quantity filter -----
                        let confirmedQtyOk = true;
                        if (sConfirmedQty && sConfirmedQty !== "") {
                            const qty = item.confirmedqty; // comes as string
                            const isFilled = qty && qty.trim() !== "" &&
                                !isNaN(parseFloat(qty)) &&
                                parseFloat(qty) !== 0;

                            if (sConfirmedQty === "FILLED") {
                                confirmedQtyOk = isFilled;
                            } else { // NOT_FILLED
                                confirmedQtyOk = !isFilled;
                            }
                        }

                        // All must be true
                        return releaseOk && giOk && grOk && confirmedQtyOk;
                    });

                    // Update the table model
                    const oTabModel = oView.getModel("TabModel");
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Optional: show summary
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} records`);
                });
            },


            onFilterConfirmedQty: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboConfirmedQtyFilter");
                const sSelectedFilter = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected, reload the full data
                if (!sSelectedFilter || sSelectedFilter === "") {
                    this.GoMixingActualfilter();
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                // Fetch data (via your existing GoMixingActualfilter) and apply client‑side filter
                this.GoMixingActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter logic for "FILLED" vs "NOT_FILLED"
                    const aFilteredData = fetchedData.filter(item => {
                        const qty = item.confirmedqty; // value comes as string
                        const isFilled = (qty && qty.trim() !== "" &&
                            !isNaN(parseFloat(qty)) &&
                            parseFloat(qty) !== 0);

                        return sSelectedFilter === "FILLED" ? isFilled : !isFilled;
                    });

                    // Update the model with filtered data
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show result summary
                    const sFilterText = sSelectedFilter === "FILLED" ? "Filled" : "Not Filled";
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} ${sFilterText} records`);
                });
            },


            onFilterReleaseStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboReleaseStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoMixingActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoMixingActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected status
                    const aFilteredData = fetchedData.filter(item => {
                        if (sSelectedStatus === "RELEASED") {
                            // For released: status must be exactly "RELEASED"
                            return item.releasestatus === "RELEASED";
                        } else {
                            // For unreleased: status is empty, null, undefined, or just whitespace
                            return !item.releasestatus ||
                                item.releasestatus.trim() === "" ||
                                item.releasestatus === " ";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "RELEASED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} released records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} unreleased records`);
                    }
                });
            },

            onFilterGIStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGIStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoMixingActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoMixingActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GI status
                    const aFilteredData = fetchedData.filter(item => {
                        const giCnfValue = item.gicnfmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return giCnfValue &&
                                giCnfValue.trim() !== "" &&
                                giCnfValue !== "0" &&
                                giCnfValue !== null &&
                                giCnfValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !giCnfValue ||
                                giCnfValue.trim() === "" ||
                                giCnfValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GI records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GI records`);
                    }
                });
            },

            onFilterGRStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGRStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoMixingActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoMixingActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GR status
                    const aFilteredData = fetchedData.filter(item => {
                        const grValue = item.grmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return grValue &&
                                grValue.trim() !== "" &&
                                grValue !== "0" &&
                                grValue !== null &&
                                grValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !grValue ||
                                grValue.trim() === "" ||
                                grValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GR records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GR records`);
                    }
                });
            },










            onRowSelect: function (oEvent) {
                const oTable = oEvent.getSource();
                const iSelectedIndex = oTable.getSelectedIndex();
                if (iSelectedIndex < 0) {
                    return; // no row selected
                }

                // 1. Validate any required Inputs/ComboBoxes in the clicked row
                const oRow = oTable.getRows()[iSelectedIndex];
                const aCells = oRow.getCells();
                const aEmptyRequired = aCells.filter(cell => {
                    if (typeof cell.getRequired !== "function" || !cell.getRequired()) {
                        return false;
                    }
                    let sVal = "";
                    if (typeof cell.getValue === "function") {
                        sVal = cell.getValue();
                    } else if (typeof cell.getSelectedKey === "function") {
                        sVal = cell.getSelectedKey();
                    }
                    return !sVal;
                });
                if (aEmptyRequired.length) {
                    sap.m.MessageToast.show("Please fill in all required fields before proceeding.");
                    return;
                }

                // 2. Grab the row’s context data
                const oContext = oTable.getContextByIndex(iSelectedIndex);
                const oRowData = oContext.getObject();

                // 3. Set it in a global model accessible by both views
                const oComponent = this.getOwnerComponent();
                const oSelectedRowModel = new sap.ui.model.json.JSONModel(oRowData);
                oComponent.setModel(oSelectedRowModel, "SelectedRow");

                // 4. Navigate to screen 2
                const oRouter = oComponent.getRouter();
                oRouter.navTo("MixingActualScreen2");
            },


            ontypeconfirmedqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get the binding context and row data
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                // Handle empty or invalid input - replace with 0
                let iConfirmedQty = parseFloat(sNewValue);
                if (isNaN(iConfirmedQty)) {
                    iConfirmedQty = 0;
                }

                const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;

                // Validate inputs
                // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
                //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
                //     oInput.setValue(""); // Clear the input
                //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
                //     oContext.getModel().refresh(); // Reflect change in UI
                //     return;
                // }

                if (iConfirmedQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
                    oInput.setValue("");
                    // oRowData.balanceqty = oRowData.productionorderqty || 0;
                    oContext.getModel().refresh();
                    return;
                }

                // Set Confirmed QTY explicitly if needed
                oRowData.confirmedqty = iConfirmedQty;

                // Calculate and update Balance QTY
                const iBalanceQty = iProductionOrderQty - iConfirmedQty;
                // oRowData.balanceqty = iBalanceQty;
                // oRowData.scrapqty = isNaN(iBalanceQty) ? 0.000 : Number(iBalanceQty.toFixed(3));  //uncomment this if u want scrap value to change.

                // Refresh the model to update UI
                oContext.getModel().refresh();
            },

            ontypebalanceqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get row context
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                const iScrapQty = parseFloat(sNewValue);              // this is balanceqty entered
                const iConfirmedQty = parseFloat(oRowData.confirmedqty);

                // Validate confirmed qty exists
                if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
                    sap.m.MessageBox.error("Please enter a valid Confirmed QTY before entering Scrap QTY.");
                    oInput.setValue("");
                    return;
                }

                // Validate scrap qty value
                if (isNaN(iScrapQty) || iScrapQty < 0) {
                    sap.m.MessageBox.error("Scrap QTY must be a valid positive number.");
                    oInput.setValue("");
                    return;
                }

                // Core Rule: Scrap QTY ≤ Confirmed QTY
                if (iScrapQty > iConfirmedQty) {
                    sap.m.MessageBox.error("Scrap QTY must be less than or equal to Confirmed QTY.");
                    oInput.setValue("");
                    return;
                }

                // Update the model properly using setProperty
                oContext.getModel().setProperty(oContext.getPath() + "/scrapqty", iScrapQty);
            },





            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },

            // Format both date fields to match table display (dd-MM-yyyy)
            // const aFormattedData = aExportData.map(item => {
            //     const formattedItem = Object.assign({}, item);

            //     // Helper function to format date to dd-MM-yyyy
            //     const formatDate = (dateValue) => {
            //         if (!dateValue) return "";

            //         const date = new Date(dateValue);

            //         // Handle timezone correction - get local date
            //         const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

            //         // Format as dd-MM-yyyy
            //         const day = String(localDate.getDate()).padStart(2, '0');
            //         const month = String(localDate.getMonth() + 1).padStart(2, '0');
            //         const year = localDate.getFullYear();

            //         return `${day}-${month}-${year}`;
            //     };

            //     // Format production order start date
            //     if (formattedItem.productionordstartdate) {
            //         formattedItem.productionordstartdate = formatDate(formattedItem.productionordstartdate);
            //     }

            //     // Format manufacturing date
            //     if (formattedItem.manufacturingdate) {
            //         formattedItem.manufacturingdate = formatDate(formattedItem.manufacturingdate);
            //     }

            //     return formattedItem;
            // });



            onExportExl: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, else use all rows
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // 🔹 Sort the data in the same sequence as the table
                // First by productionordstartdate (ascending), then by bipllotno (ascending)
                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });


                // const aFormattedData = aExportData.map(item => {
                //     const formattedItem = Object.assign({}, item);

                //     if (formattedItem.manufacturingdate) {
                //         // Convert to local date string in dd-MM-yyyy format (like in table)
                //         const date = new Date(formattedItem.manufacturingdate);

                //         // Handle timezone correction - get local date
                //         const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                //         // Format as dd-MM-yyyy
                //         const day = String(localDate.getDate()).padStart(2, '0');
                //         const month = String(localDate.getMonth() + 1).padStart(2, '0');
                //         const year = localDate.getFullYear();

                //         formattedItem.manufacturingdate = `${day}-${month}-${year}`;
                //         formattedItem.productionordstartdate = `${day}-${month}-${year}`;
                //     }

                //     return formattedItem;
                // });
                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    // Manufacturing Date
                    if (formattedItem.manufacturingdate) {
                        const date = new Date(formattedItem.manufacturingdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    // Production Order Start Date
                    if (formattedItem.productionordstartdate) {
                        const date = new Date(formattedItem.productionordstartdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.productionordstartdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    if (formattedItem.PostingDate) {
                        const date = new Date(formattedItem.PostingDate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    return formattedItem;
                });

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "bipllotno", property: "bipllotno" },
                    { label: "shift", property: "shift" },
                    { label: "Material Code", property: "materialcode" },
                    { label: "Description", property: "description" },
                    { label: "Machine Number", property: "machinenumber" },
                    { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Production Order Qty", property: "productionorderqty" },
                    { label: "Lot/Batch-No", property: "lotbatchno" },
                    { label: "Storage Location", property: "storagelocation" },
                    // { label: "compoundcode", property: "compoundcode" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },

                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },

                    // { label: "Defect Qty", property: "defectQty" },
                    // { label: "Balance Qty", property: "balanceQty" },
                    // { label: "UOM", property: "uom" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Batch Weight", property: "batchweight" },
                    // { label: "Operator", property: "operator" },
                    // { label: "Inspector", property: "inspector" },
                    { label: "Released Status", property: "releasestatus" },
                    { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
                    { label: "Confirmation Count", property: "gicnfconfirmationcount" },
                    { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
                    { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
                    { label: "GR Material Doc Year", property: "grmaterialdocyear" },
                    { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
                    // { label: "Status of Production Order", property: "statusOfProdOrd" }

                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "Mixing Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "Mixing_Actual_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },

            onExporttoImport: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // 🔍 Check for selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // 🔹 Sort the data in the same sequence as the table
                // First by productionordstartdate (ascending), then by bipllotno (ascending)
                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                // Format manufacturing date to match table display (dd-MM-yyyy)
                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    if (formattedItem.manufacturingdate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.manufacturingdate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${day}-${month}-${year}`;
                    }

                    if (formattedItem.PostingDate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.PostingDate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${day}-${month}-${year}`;
                    }

                    return formattedItem;
                });

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "Prduction order qty", property: "productionorderqty" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },
                    // { label: "Reject Codes", property: "RejectCodes" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "string" },
                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },

                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "Mixing Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "MixingActualExporttoImport.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },




            // the below import code has the automtic scrap qty calculator
            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy"
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // FIXED: Timezone-safe date parsing function
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];
            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Parse manufacturing date using improved function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;

            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     // const parseDecimal = (val) => {
            //                     //     if (val === undefined || val === null || val === "") return null;
            //                     //     // Remove any non-numeric characters except decimal point and minus
            //                     //     const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                     //     const parsed = parseFloat(cleaned);
            //                     //     return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     // };

            //                     // // Get original production order quantity
            //                     // const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // // Parse values from import
            //                     // const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     // const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // // Convert to numbers for calculation
            //                     // const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     // const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // // Logic for Confirmed Qty and Scrap Qty calculation
            //                     // let finalConfirmedQty = confirmedQtyStr;
            //                     // let finalScrapQty = scrapQtyStr;

            //                     // // Determine if user provided values
            //                     // const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     // const userHasScrapQty = scrapQtyNum !== null;

            //                     // if (userHasConfirmedQty && userHasScrapQty) {
            //                     //     // User provided both values - check if they are correct
            //                     //     const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                     //     const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                     //     if (difference > 0.001) { // Tolerance for floating point comparison
            //                     //         // Values don't match - adjust scrapqty based on calculation
            //                     //         finalScrapQty = calculatedScrap.toFixed(3);
            //                     //         aAdjustedRows.push({
            //                     //             prodOrder: prodOrder,
            //                     //             reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                     //         });
            //                     //     }
            //                     // } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                     //     // User only provided confirmedqty - calculate scrapqty
            //                     //     const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                     //     finalScrapQty = calculatedScrap.toFixed(3);
            //                     //     aAdjustedRows.push({
            //                     //         prodOrder: prodOrder,
            //                     //         reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                     //     });
            //                     // } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                     //     // User only provided scrapqty - calculate confirmedqty
            //                     //     const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                     //     finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                     //     aAdjustedRows.push({
            //                     //         prodOrder: prodOrder,
            //                     //         reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                     //     });
            //                     // } else {
            //                     //     // User provided neither - keep existing values
            //                     //     finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                     //     finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     // }

            //                     // // // Validate that calculated values make sense
            //                     // // if (finalConfirmedQty) {
            //                     // //     const confirmedNum = parseFloat(finalConfirmedQty);
            //                     // //     if (confirmedNum < 0) {
            //                     // //         aInvalidRows.push({
            //                     // //             prodOrder: prodOrder,
            //                     // //             reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                     // //         });
            //                     // //         finalConfirmedQty = "0.000";
            //                     // //     }

            //                     // //     if (confirmedNum > productionOrderQty) {
            //                     // //         aInvalidRows.push({
            //                     // //             prodOrder: prodOrder,
            //                     // //             reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                     // //         });
            //                     // //         finalConfirmedQty = productionOrderQty.toFixed(3);
            //                     // //         finalScrapQty = "0.000";
            //                     // //     }
            //                     // // }

            //                     // // if (finalScrapQty) {
            //                     // //     const scrapNum = parseFloat(finalScrapQty);
            //                     // //     if (scrapNum < 0) {
            //                     // //         aInvalidRows.push({
            //                     // //             prodOrder: prodOrder,
            //                     // //             reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                     // //         });
            //                     // //         finalScrapQty = "0.000";
            //                     // //     }
            //                     // // }
            //                     // // Validate that calculated values make sense
            //                     // if (finalConfirmedQty) {
            //                     //     const confirmedNum = parseFloat(finalConfirmedQty);
            //                     //     if (confirmedNum < 0) {
            //                     //         aInvalidRows.push({
            //                     //             prodOrder: prodOrder,
            //                     //             reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                     //         });
            //                     //         finalConfirmedQty = "0.000";
            //                     //     }

            //                     //     if (confirmedNum > productionOrderQty) {
            //                     //         // Allow confirmed to exceed production order qty, but set scrap to 0
            //                     //         aAdjustedRows.push({
            //                     //             prodOrder: prodOrder,
            //                     //             reason: `Confirmed Qty (${finalConfirmedQty}) exceeds Production Order Qty (${productionOrderQty}), Scrap Qty set to 0`
            //                     //         });
            //                     //         finalScrapQty = "0.000";
            //                     //     }
            //                     // }

            //                     // if (finalScrapQty) {
            //                     //     const scrapNum = parseFloat(finalScrapQty);
            //                     //     if (scrapNum < 0) {
            //                     //         aInvalidRows.push({
            //                     //             prodOrder: prodOrder,
            //                     //             reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                     //         });
            //                     //         finalScrapQty = "0.000";
            //                     //     }
            //                     // }

            //                     // // Update the row with all fields
            //                     // updatedRow.confirmedqty = finalConfirmedQty;
            //                     // updatedRow.scrapqty = finalScrapQty;
            //                     // --- Start of modified calculation block ---
            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Determine if Confirmed Qty is exactly zero (or 0.00/0.000) – skip calculation in this case
            //                     const isConfirmedZero = confirmedQtyNum !== null && confirmedQtyNum === 0;

            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     if (isConfirmedZero) {
            //                         // Confirmed Qty is zero – no calculation should happen.
            //                         // Keep imported values (or existing if not provided).
            //                         finalConfirmedQty = confirmedQtyStr !== null ? confirmedQtyStr : (matchedRow.confirmedqty || "0.000");
            //                         finalScrapQty = scrapQtyStr !== null ? scrapQtyStr : (matchedRow.scrapqty || "0.000");
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Calculation skipped because Confirmed Qty is 0. Values kept as imported (or existing).`
            //                         });
            //                     } else {
            //                         // Calculation is allowed – only consider Confirmed Qty if it is non-zero
            //                         const userHasConfirmedQtyForCalc = confirmedQtyNum !== null && confirmedQtyNum !== 0;
            //                         const userHasScrapQty = scrapQtyNum !== null;

            //                         if (userHasConfirmedQtyForCalc && userHasScrapQty) {
            //                             // User provided both values – check if they are consistent
            //                             const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                             const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                             if (difference > 0.001) {
            //                                 finalScrapQty = calculatedScrap.toFixed(3);
            //                                 aAdjustedRows.push({
            //                                     prodOrder: prodOrder,
            //                                     reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                                 });
            //                             }
            //                         } else if (userHasConfirmedQtyForCalc && !userHasScrapQty) {
            //                             // User only provided Confirmed Qty – calculate Scrap Qty
            //                             const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         } else if (!userHasConfirmedQtyForCalc && userHasScrapQty) {
            //                             // User only provided Scrap Qty – calculate Confirmed Qty
            //                             const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                             finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                             });
            //                         } else {
            //                             // User provided neither – keep existing values
            //                             finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                             finalScrapQty = matchedRow.scrapqty || "0.000";
            //                         }
            //                     }

            //                     // --- Validation (unchanged) ---
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) exceeds Production Order Qty (${productionOrderQty}), Scrap Qty set to 0`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;
            //                     // --- End of modified calculation block ---

            //                     // Add manufacturing date if available - FIXED: Always store as Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },


            onImportExl: function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oSelectedModel = oView.getModel("Tab_SelectAll");

                function ensureXLSX(cb) {
                    if (window.XLSX) {
                        return cb();
                    }

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = new Uint8Array(e.target.result);

                        const workbook = XLSX.read(data, {
                            type: "array",
                            raw: true,
                            cellDates: false,
                            dateNF: "dd-mm-yyyy" // Specify expected date format
                        });

                        const sheetName = workbook.SheetNames[0];
                        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
                            raw: true,
                            defval: "",
                            dateNF: "dd-mm-yyyy"
                        });

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        const aSamples = oTabModel.getProperty("/Samples") || [];
                        const aUpdatedRows = [];
                        const aNotFound = [];
                        const aAdjustedRows = [];
                        const aInvalidRows = [];
                        const aBlockedRows = []; // For rows that cannot be imported due to business rules
                        let hasAnyUpdate = false;

                        // FIXED: Timezone-safe date parsing function
                        function parseExcelDate(rawValue) {
                            if (!rawValue && rawValue !== 0) {
                                return null;
                            }

                            // CASE 1: Already a Date object (shouldn't happen with raw:true)
                            if (rawValue instanceof Date) {
                                // Create local date from the date object
                                const d = new Date(rawValue);
                                return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
                            }

                            // CASE 2: Excel serial number (most common case from Excel)
                            if (typeof rawValue === 'number') {
                                // Excel incorrectly treats 1900 as a leap year, so we need to adjust
                                // Use local date calculation to avoid timezone issues
                                const excelEpoch = new Date(1899, 11, 30);
                                const days = Math.floor(rawValue);
                                const ms = Math.round((rawValue - days) * 86400000);

                                // Calculate in local time
                                const date = new Date(excelEpoch);
                                date.setDate(date.getDate() + days);
                                date.setTime(date.getTime() + ms);

                                // Create a new date with just year/month/day (no time)
                                const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                return !isNaN(localDate.getTime()) ? localDate : null;
                            }

                            // CASE 3: String value
                            if (typeof rawValue === 'string') {
                                const trimmed = rawValue.trim();
                                if (!trimmed) return null;

                                // Try dd-mm-yyyy format first (most common)
                                if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
                                    const year = parseInt(parts[2], 10);

                                    // Validate date components
                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        // Verify the date is valid (e.g., not Feb 31)
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try yyyy-mm-dd format
                                if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const year = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const day = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try dd/mm/yyyy format
                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try mm/dd/yyyy format
                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const month = parseInt(parts[0], 10) - 1;
                                    const day = parseInt(parts[1], 10);
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try parsing as local date (for other formats)
                                // Parse the string in local timezone
                                const parsed = new Date(trimmed);
                                if (!isNaN(parsed.getTime())) {
                                    // Extract just the date part to avoid timezone issues
                                    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
                                }
                            }

                            // If we get here, try one more approach
                            try {
                                // Force local date parsing
                                const date = new Date(rawValue);
                                if (!isNaN(date.getTime())) {
                                    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                }
                            } catch (e) {
                                console.warn("Could not parse date:", rawValue, e);
                            }

                            return null;
                        }

                        // Process each row individually
                        jsonData.forEach((importRow) => {
                            const plant = importRow["Plant"];
                            const prodOrder = importRow["Production Order No"];

                            // Find matching row by Plant and Production Order No
                            const matchedRowIndex = aSamples.findIndex(item =>
                                item.plant === plant && item.productionorderno === prodOrder
                            );

                            if (matchedRowIndex === -1) {
                                aNotFound.push(`${plant}/${prodOrder}`);
                                return; // Skip to next row
                            }

                            const matchedRow = aSamples[matchedRowIndex];
                            // Create updated row starting with original values
                            const updatedRow = { ...matchedRow };

                            // Parse manufacturing date using improved function
                            const rawDateValue = importRow["Manufacturing Date"];
                            const manufacturingDate = parseExcelDate(rawDateValue);
                            const hasManufacturingDate = manufacturingDate !== null;

                            // Parse posting date (NEW)
                            const rawPostingDate = importRow["Posting Date"];
                            const postingDate = parseExcelDate(rawPostingDate);
                            const hasPostingDate = postingDate !== null;

                            // Check what user is trying to import
                            const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
                                importRow["Confirmed Qty"] !== null &&
                                importRow["Confirmed Qty"].toString().trim() !== "";
                            const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
                                importRow["Scrap Qty"] !== null &&
                                importRow["Scrap Qty"].toString().trim() !== "";

                            // Now handle import based on business rules
                            if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
                                // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
                                if (hasConfirmedQty || hasScrapQty || hasManufacturingDate || hasPostingDate) {
                                    aBlockedRows.push({
                                        prodOrder: prodOrder,
                                        plant: plant,
                                        reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
                                    });
                                    return; // Skip this row, don't import anything
                                }
                                // If user is not trying to import any of these fields, nothing happens
                            }
                            else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
                                // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
                                if (hasConfirmedQty || hasScrapQty || hasPostingDate) {
                                    aBlockedRows.push({
                                        prodOrder: prodOrder,
                                        plant: plant,
                                        reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
                                    });
                                    // But we can still import Manufacturing Date if user provided it
                                }

                                // Only import Manufacturing Date for these rows
                                if (hasManufacturingDate) {
                                    updatedRow.manufacturingdate = manufacturingDate;

                                    // Keep existing confirmedqty and scrapqty values
                                    updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
                                    updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

                                    updatedRow.__selected = true;
                                    aSamples[matchedRowIndex] = updatedRow;
                                    aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
                                    hasAnyUpdate = true;
                                }
                            }
                            // else {
                            //     // No restrictions - import all fields with calculations

                            //     // Parse decimal values with better handling
                            //     // const parseDecimal = (val) => {
                            //     //     if (val === undefined || val === null || val === "") return null;
                            //     //     // Remove any non-numeric characters except decimal point and minus
                            //     //     const cleaned = String(val).replace(/[^\d.-]/g, '');
                            //     //     const parsed = parseFloat(cleaned);
                            //     //     return isNaN(parsed) ? null : parsed.toFixed(3);
                            //     // };

                            //     // // Get original production order quantity
                            //     // const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                            //     // // Parse values from import
                            //     // const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                            //     // const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                            //     // // Convert to numbers for calculation
                            //     // const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
                            //     // const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

                            //     // // Logic for Confirmed Qty and Scrap Qty calculation
                            //     // let finalConfirmedQty = confirmedQtyStr;
                            //     // let finalScrapQty = scrapQtyStr;

                            //     // // Determine if user provided values
                            //     // const userHasConfirmedQty = confirmedQtyNum !== null;
                            //     // const userHasScrapQty = scrapQtyNum !== null;

                            //     // if (userHasConfirmedQty && userHasScrapQty) {
                            //     //     // User provided both values - check if they are correct
                            //     //     const calculatedScrap = productionOrderQty - confirmedQtyNum;
                            //     //     const difference = Math.abs(scrapQtyNum - calculatedScrap);

                            //     //     if (difference > 0.001) { // Tolerance for floating point comparison
                            //     //         // Values don't match - adjust scrapqty based on calculation
                            //     //         finalScrapQty = calculatedScrap.toFixed(3);
                            //     //         aAdjustedRows.push({
                            //     //             prodOrder: prodOrder,
                            //     //             reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                            //     //         });
                            //     //     }
                            //     // } else if (userHasConfirmedQty && !userHasScrapQty) {
                            //     //     // User only provided confirmedqty - calculate scrapqty
                            //     //     const calculatedScrap = productionOrderQty - confirmedQtyNum;
                            //     //     finalScrapQty = calculatedScrap.toFixed(3);
                            //     //     aAdjustedRows.push({
                            //     //         prodOrder: prodOrder,
                            //     //         reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
                            //     //     });
                            //     // } else if (!userHasConfirmedQty && userHasScrapQty) {
                            //     //     // User only provided scrapqty - calculate confirmedqty
                            //     //     const calculatedConfirmed = productionOrderQty - scrapQtyNum;
                            //     //     finalConfirmedQty = calculatedConfirmed.toFixed(3);
                            //     //     aAdjustedRows.push({
                            //     //         prodOrder: prodOrder,
                            //     //         reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
                            //     //     });
                            //     // } else {
                            //     //     // User provided neither - keep existing values
                            //     //     finalConfirmedQty = matchedRow.confirmedqty || "0.000";
                            //     //     finalScrapQty = matchedRow.scrapqty || "0.000";
                            //     // }

                            //     // // // Validate that calculated values make sense
                            //     // // if (finalConfirmedQty) {
                            //     // //     const confirmedNum = parseFloat(finalConfirmedQty);
                            //     // //     if (confirmedNum < 0) {
                            //     // //         aInvalidRows.push({
                            //     // //             prodOrder: prodOrder,
                            //     // //             reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
                            //     // //         });
                            //     // //         finalConfirmedQty = "0.000";
                            //     // //     }

                            //     // //     if (confirmedNum > productionOrderQty) {
                            //     // //         aInvalidRows.push({
                            //     // //             prodOrder: prodOrder,
                            //     // //             reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
                            //     // //         });
                            //     // //         finalConfirmedQty = productionOrderQty.toFixed(3);
                            //     // //         finalScrapQty = "0.000";
                            //     // //     }
                            //     // // }

                            //     // // if (finalScrapQty) {
                            //     // //     const scrapNum = parseFloat(finalScrapQty);
                            //     // //     if (scrapNum < 0) {
                            //     // //         aInvalidRows.push({
                            //     // //             prodOrder: prodOrder,
                            //     // //             reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
                            //     // //         });
                            //     // //         finalScrapQty = "0.000";
                            //     // //     }
                            //     // // }
                            //     // // Validate that calculated values make sense
                            //     // if (finalConfirmedQty) {
                            //     //     const confirmedNum = parseFloat(finalConfirmedQty);
                            //     //     if (confirmedNum < 0) {
                            //     //         aInvalidRows.push({
                            //     //             prodOrder: prodOrder,
                            //     //             reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
                            //     //         });
                            //     //         finalConfirmedQty = "0.000";
                            //     //     }

                            //     //     if (confirmedNum > productionOrderQty) {
                            //     //         // Allow confirmed to exceed production order qty, but set scrap to 0
                            //     //         aAdjustedRows.push({
                            //     //             prodOrder: prodOrder,
                            //     //             reason: `Confirmed Qty (${finalConfirmedQty}) exceeds Production Order Qty (${productionOrderQty}), Scrap Qty set to 0`
                            //     //         });
                            //     //         finalScrapQty = "0.000";
                            //     //     }
                            //     // }

                            //     // if (finalScrapQty) {
                            //     //     const scrapNum = parseFloat(finalScrapQty);
                            //     //     if (scrapNum < 0) {
                            //     //         aInvalidRows.push({
                            //     //             prodOrder: prodOrder,
                            //     //             reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
                            //     //         });
                            //     //         finalScrapQty = "0.000";
                            //     //     }
                            //     // }

                            //     // // Update the row with all fields
                            //     // updatedRow.confirmedqty = finalConfirmedQty;
                            //     // updatedRow.scrapqty = finalScrapQty;
                            //     // --- Start of modified calculation block ---
                            //     // Parse decimal values with better handling
                            //     const parseDecimal = (val) => {
                            //         if (val === undefined || val === null || val === "") return null;
                            //         const cleaned = String(val).replace(/[^\d.-]/g, '');
                            //         const parsed = parseFloat(cleaned);
                            //         return isNaN(parsed) ? null : parsed.toFixed(3);
                            //     };

                            //     // Get original production order quantity (kept for compatibility but not used in calculation)
                            //     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                            //     // Parse values from import
                            //     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                            //     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                            //     // Simple import: use imported values if provided, otherwise keep existing values
                            //     let finalConfirmedQty = confirmedQtyStr !== null ? confirmedQtyStr : (matchedRow.confirmedqty || "0.000");
                            //     let finalScrapQty = scrapQtyStr !== null ? scrapQtyStr : (matchedRow.scrapqty || "0.000");

                            //     // Update the row with all fields
                            //     updatedRow.confirmedqty = finalConfirmedQty;
                            //     updatedRow.scrapqty = finalScrapQty;
                            //     // --- End of modified calculation block ---

                            //     // Add manufacturing date if available - FIXED: Always store as Date object
                            //     if (hasManufacturingDate) {
                            //         updatedRow.manufacturingdate = manufacturingDate;
                            //     }

                            //     // Add posting date if available (NEW)
                            //     if (hasPostingDate) {
                            //         updatedRow.PostingDate = postingDate;
                            //     }

                            //     updatedRow.__selected = true;
                            //     aSamples[matchedRowIndex] = updatedRow;
                            //     aUpdatedRows.push(prodOrder);
                            //     hasAnyUpdate = true;
                            // }
                            else {
                                // No restrictions – import all fields as provided by user

                                // Parse decimal values with better handling
                                const parseDecimal = (val) => {
                                    if (val === undefined || val === null || val === "") return null;
                                    const cleaned = String(val).replace(/[^\d.-]/g, '');
                                    const parsed = parseFloat(cleaned);
                                    return isNaN(parsed) ? null : parsed.toFixed(3);
                                };

                                // Get original production order quantity
                                const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                                // Parse values from import
                                const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                                const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                                // -----------------------------------------------------------------
                                // NEW: If user provided a Confirmed Qty that exceeds the production order qty,
                                // skip this row entirely (do not import anything).
                                // -----------------------------------------------------------------
                                if (confirmedQtyStr !== null) {
                                    const confirmedNum = parseFloat(confirmedQtyStr);
                                    if (confirmedNum > productionOrderQty) {
                                        aBlockedRows.push({
                                            prodOrder: prodOrder,
                                            plant: plant,
                                            reason: `Confirmed Qty (${confirmedQtyStr}) exceeds Production Order Qty (${productionOrderQty}) – import skipped`
                                        });
                                        return; // skip this row – no update
                                    }
                                }

                                // Determine final values based on user input
                                let finalConfirmedQty = confirmedQtyStr !== null ? confirmedQtyStr : (matchedRow.confirmedqty || "0.000");
                                let finalScrapQty = scrapQtyStr !== null ? scrapQtyStr : (matchedRow.scrapqty || "0.000");

                                // Validate that values make sense (no negative values)
                                if (finalConfirmedQty) {
                                    const confirmedNum = parseFloat(finalConfirmedQty);
                                    if (confirmedNum < 0) {
                                        aInvalidRows.push({
                                            prodOrder: prodOrder,
                                            reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
                                        });
                                        finalConfirmedQty = "0.000";
                                    }
                                    // Removed the old check that allowed exceeding and set scrap to 0
                                    // Now the exceeding case is handled above (skip)
                                }

                                if (finalScrapQty) {
                                    const scrapNum = parseFloat(finalScrapQty);
                                    if (scrapNum < 0) {
                                        aInvalidRows.push({
                                            prodOrder: prodOrder,
                                            reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
                                        });
                                        finalScrapQty = "0.000";
                                    }
                                }

                                // Update the row with all fields
                                updatedRow.confirmedqty = finalConfirmedQty;
                                updatedRow.scrapqty = finalScrapQty;

                                // Add manufacturing date if available
                                if (hasManufacturingDate) {
                                    updatedRow.manufacturingdate = manufacturingDate;
                                }

                                // Add posting date if available
                                if (hasPostingDate) {
                                    updatedRow.PostingDate = postingDate;
                                }

                                updatedRow.__selected = true;
                                aSamples[matchedRowIndex] = updatedRow;
                                aUpdatedRows.push(prodOrder);
                                hasAnyUpdate = true;
                            }
                        });

                        if (hasAnyUpdate) {
                            // Update the model
                            oTabModel.setProperty("/Samples", aSamples);

                            // Optionally update the select all checkbox
                            const allSelected = aSamples.every(row => row.__selected);
                            oSelectedModel.setProperty("/Samples/selectall", allSelected);

                            // Refresh the table
                            oTabModel.refresh(true);
                        }

                        // Build result message
                        let message = "";

                        if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
                            if (aUpdatedRows.length > 0) {
                                message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
                                message += `Updated Production Orders:\n`;
                                aUpdatedRows.forEach(row => {
                                    message += `  • ${row}\n`;
                                });
                                message += "\nCheckboxes have been selected for updated rows.\n\n";

                                // Add adjustment information
                                if (aAdjustedRows.length > 0) {
                                    message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
                                    aAdjustedRows.forEach(adj => {
                                        message += `- ${adj.prodOrder}: ${adj.reason}\n`;
                                    });
                                    message += "\n";
                                }

                                // Add invalid rows information
                                if (aInvalidRows.length > 0) {
                                    message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
                                    aInvalidRows.forEach(inv => {
                                        message += `- ${inv.prodOrder}: ${inv.reason}\n`;
                                    });
                                    message += "\n";
                                }
                            }

                            // Add blocked rows information
                            if (aBlockedRows.length > 0) {
                                message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
                                aBlockedRows.forEach(blocked => {
                                    message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
                                });
                                message += "\n";
                            }

                            // Add not found information
                            if (aNotFound.length > 0) {
                                message += `Not found in table: ${aNotFound.length} row(s)\n`;
                                message += aNotFound.join(", ");
                            }

                            const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
                            const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

                            sap.m.MessageBox.show(message, {
                                title: title,
                                icon: icon,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                        } else {
                            if (aNotFound.length > 0) {
                                message = `No matching rows found for:\n${aNotFound.join("\n")}`;
                            } else if (aBlockedRows.length > 0) {
                                message = "No data was imported due to business rule violations:\n\n";
                                aBlockedRows.forEach(blocked => {
                                    message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
                                });
                            } else {
                                message = "No data was imported.";
                            }

                            sap.m.MessageBox.show(message, {
                                title: "Import Results",
                                icon: sap.m.MessageBox.Icon.WARNING,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                        }
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsArrayBuffer(file);
                }

                // Create file input element
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";

                fileInput.onchange = function (e) {
                    const file = e.target.files[0];
                    if (!file) return;

                    // Check file extension
                    const fileName = file.name.toLowerCase();
                    if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
                        sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
                        document.body.removeChild(fileInput);
                        return;
                    }

                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                };

                document.body.appendChild(fileInput);
                fileInput.click();
            },



            // =====================================================================================

            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     let aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     // Arrays to track results
            //     const aSuccessRows = [];
            //     const aFailedRows = [];
            //     const aSkippedRows = [];

            //     // Run validations first
            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     if (aWithGI.length > 0) {
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
            //         const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";

            //         // Track skipped rows
            //         aWithGI.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Goods Issue already exists"
            //             });
            //         });

            //         // Remove already GI rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));

            //         if (aSelectedRows.length === 0) {
            //             this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             return;
            //         }
            //     }

            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         // Track unreleased rows
            //         aUnreleased.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Not released"
            //             });
            //         });

            //         // Remove unreleased rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
            //     }

            //     const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
            //     if (aNotUpdated.length > 0) {
            //         // Track not updated rows
            //         aNotUpdated.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Not updated (status not GT)"
            //             });
            //         });

            //         // Remove not updated rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
            //     }

            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const confirmedVal = row.confirmedqty;
            //         const balanceVal = row.scrapqty;
            //         const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
            //         const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
            //         const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
            //         return confirmedInvalid || bothZeroOrNull;
            //     });

            //     if (aMissingQty.length > 0) {
            //         // Track missing quantity rows
            //         aMissingQty.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Invalid quantity values"
            //             });
            //         });

            //         // Remove missing quantity rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
            //     }

            //     const aQtyMismatch = aSelectedRows.filter(row => {
            //         const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
            //         const iBalanceQty = parseFloat(row.scrapqty) || 0;
            //         const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
            //         const iTotalQty = iConfirmedQty + iBalanceQty;
            //         const dTolerance = 0.0001;
            //         return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
            //     });

            //     // if (aQtyMismatch.length > 0) {
            //     //     // Track quantity mismatch rows
            //     //     aQtyMismatch.forEach(row => {
            //     //         aSkippedRows.push({
            //     //             productionOrder: row.productionorderno,
            //     //             reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
            //     //         });
            //     //     });

            //     //     // Remove quantity mismatch rows from processing
            //     //     aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
            //     // }

            //     // Check if any rows remain to process
            //     if (aSelectedRows.length === 0) {
            //         // Show summary if all rows were skipped during validation
            //         this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //         return;
            //     }

            //     aSelectedRows.sort((a, b) => {
            //         // Sort by productionordstartdate (ascending)
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);

            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;

            //         // If dates are equal, sort by bipllotno (ascending)
            //         // If dates are equal, sort by bipllotno numerically (ascending)
            //         const lotA = parseInt(a.bipllotno, 10) || 0;
            //         const lotB = parseInt(b.bipllotno, 10) || 0;

            //         // Return difference for numeric order
            //         return lotA - lotB;
            //     });

            //     // ✅ Confirm before processing
            //     sap.m.MessageBox.confirm("Do you want to post the selected data?", {
            //         actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //         emphasizedAction: sap.m.MessageBox.Action.YES,
            //         onClose: async function (sAction) {
            //             if (sAction === sap.m.MessageBox.Action.YES) {
            //                 // Show loading indicator ONCE at the beginning
            //                 sap.ui.core.BusyIndicator.show(0);

            //                 // Process each row individually
            //                 for (let i = 0; i < aSelectedRows.length; i++) {
            //                     const oRow = aSelectedRows[i];

            //                     try {
            //                         const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //                         const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //                         const oData = await new Promise((resolve, reject) => {
            //                             oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                                 filters: [oFilter1, oFilter2],
            //                                 success: function (OData) {
            //                                     resolve(OData);
            //                                 },
            //                                 error: function (error) {
            //                                     reject(error);
            //                                 }
            //                             });
            //                         });

            //                         console.log("Response:", oData);

            //                         if (oData.results.length === 0) {
            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: `YBP4 data not found for order ${oRow.productionorderno}`
            //                             });
            //                             continue; // Skip to next row
            //                         }

            //                         // Activity - Confirmation qty + Scrap qty * Operation qty/base qty
            //                         const oResultData = oData.results[0];
            //                         // const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;

            //                         // const calcQty = (qty, total, scrap, ref) =>
            //                         //     (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

            //                         const calcQty = (qty, total, scrap, ref) => {
            //                             const result =
            //                                 (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

            //                             // round to 3 decimals and return as NUMBER
            //                             return Number(result.toFixed(3));
            //                         };


            //                         const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

            //                         const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

            //                         const postResult = await that.ToConfirmIssueAPIPost(
            //                             ManufacturingOrderOperation,
            //                             opconfirmedworkquantity1,
            //                             opconfirmedworkquantity2,
            //                             opconfirmedworkquantity3,
            //                             opconfirmedworkquantity4,
            //                             opconfirmedworkquantity5,
            //                             opconfirmedworkquantity6,
            //                             oRow
            //                         );

            //                         const matDoc = postResult.materialdocument;
            //                         // pls check from this
            //                         if (!matDoc) {
            //                             let ErrorMessage = "Some error occurred while posting.";
            //                             try {
            //                                 const kk = JSON.parse(postResult.errorresponse);
            //                                 ErrorMessage = kk.error.message.value;
            //                             } catch (e) { }

            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: ErrorMessage
            //                             });
            //                         } else {
            //                             // Update row with material document
            //                             oRow.gicnfmaterialdocnumber = postResult.materialdocument;
            //                             oRow.gicnfmaterialdocyear = postResult.matdocyear;
            //                             oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
            //                             oRow.gicnfconfirmationcount = postResult.confirmationcount;

            //                             // Update internal table
            //                             await that.ToUpdateIntTab(oRow, matDoc, postResult);

            //                             aSuccessRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 materialDocument: matDoc
            //                             });
            //                         }

            //                     } catch (error) {
            //                         console.error("Error in confirmation for order:", oRow.productionorderno, error);
            //                         aFailedRows.push({
            //                             productionOrder: oRow.productionorderno,
            //                             error: error.message || "Unknown error"
            //                         });
            //                     }
            //                 }

            //                 // Refresh table once at the end
            //                 oTabModel.refresh();

            //                 // Hide loading indicator only after all processing is complete
            //                 sap.ui.core.BusyIndicator.hide();

            //                 // Show summary
            //                 that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             }
            //         }
            //     });
            // },

            checkUserHasGoodsIssueRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            OnAPIPost_Confirmation: async function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- 1. Local GI check (already has material document in UI) ---
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                if (aWithGI.length > 0) {
                    aWithGI.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Goods Issue already exists (local)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));
                }

                // --- 2. Release status check ---
                const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
                if (aUnreleased.length > 0) {
                    aUnreleased.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not released"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
                }

                // --- 3. Update status check (must be "GT") ---
                const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
                if (aNotUpdated.length > 0) {
                    aNotUpdated.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not updated (status not GT)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
                }

                // --- 4. Quantity validation ---
                const aMissingQty = aSelectedRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });

                if (aMissingQty.length > 0) {
                    aMissingQty.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Invalid quantity values"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
                }


                // --- 5. Posting Date validation (mandatory) ---
                const aMissingPostingDate = aSelectedRows.filter(row => {
                    const postingDate = row.PostingDate;
                    // Check if null, undefined, empty string, or invalid Date object
                    if (!postingDate) return true;
                    // If it's a date object, check if valid
                    const dateObj = new Date(postingDate);
                    return isNaN(dateObj.getTime());
                });

                if (aMissingPostingDate.length > 0) {
                    aMissingPostingDate.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Missing or invalid posting date"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingPostingDate.includes(row));
                }
                // debugger

                // --- If no rows left after validations, show summary and return ---
                if (aSelectedRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- ADDED / MODIFIED: Fetch existing GI data from ZSB_MATDOC_FETCH ---
                const oFetchModel = oView.getModel("ZSB_MATDOC_FETCH");
                if (!oFetchModel) {
                    sap.m.MessageToast.show("Missing model for fetching existing goods issue data.");
                    return;
                }

                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];           // rows that need to be posted

                // ⏳ BUSY: Show busy indicator before async fetch
                sap.ui.core.BusyIndicator.show(0);


                const fetchExistingPromises = aSelectedRows.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            row.productionorderno
                        );

                        const oSorter = new sap.ui.model.Sorter(
                            "MfgOrderConfirmation",
                            true   // descending = highest first
                        );

                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_MATDOC_FETCH", {
                                filters: [oFilter],
                                sorters: [oSorter],
                                top: 1,
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log("result fetched:", oData);

                        if (oData.results && oData.results.length > 0) {
                            // Already sorted by backend and limited to top 1,
                            // but keep explicit sort for safety
                            const sortedResults = [...oData.results].sort((a, b) =>
                                b.MfgOrderConfirmation - a.MfgOrderConfirmation
                            );
                            const highest = sortedResults[0];
                            console.log(`✅ Fetched for order ${row.productionorderno}: MfgOrderConfirmation = ${highest.MfgOrderConfirmation}, MaterialDocument = ${highest.MaterialDocument}`);
                            return { row, existing: highest };
                        } else {
                            // No existing data → treat as not existing
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GI for order ${row.productionorderno}:`, err);
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Populate arrays
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a material document in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;
                    const confirmationGroup = existing.MfgOrderConfirmationGroup;
                    const confirmationCount = existing.MfgOrderConfirmation;

                    // Update local row
                    row.gicnfmaterialdocnumber = matDoc;
                    row.gicnfmaterialdocyear = matDocYear;
                    row.gicnfconfirmationgroup = confirmationGroup;
                    row.gicnfconfirmationcount = confirmationCount;

                    // Update internal table (use the existing ToUpdateIntTab method)
                    try {
                        await that.ToUpdateIntTab(
                            row,
                            matDoc,
                            {
                                materialdocument: matDoc,
                                matdocyear: matDocYear,
                                confirmationgroup: confirmationGroup,
                                confirmationcount: confirmationCount
                            }
                        );
                        console.log(`✅ Updated internal table for existing order ${row.productionorderno}`);
                        aSuccessRows.push({
                            productionOrder: row.productionorderno,
                            materialDocument: matDoc,
                            materialDocumentYear: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update internal table for existing order ${row.productionorderno}:`, updateErr);
                        aFailedRows.push({
                            productionOrder: row.productionorderno,
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // ⏳ BUSY: Hide busy indicator before showing confirmation dialog
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- Sort rows to post ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods issue for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        // ⏳ BUSY: Show busy indicator again before posting
                        sap.ui.core.BusyIndicator.show(0);

                        // --- Process each row that needs to be posted ---
                        for (let i = 0; i < aRowsToPost.length; i++) {
                            const oRow = aRowsToPost[i];

                            try {
                                // Fetch YBP4 data (as in original)
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (oData.results.length === 0) {
                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: `YBP4 data not found for order ${oRow.productionorderno}`
                                    });
                                    continue;
                                }

                                const oResultData = oData.results[0];
                                const calcQty = (qty, total, scrap, ref) => {
                                    const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                                    return Number(result.toFixed(3));
                                };

                                const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

                                const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

                                const postResult = await that.ToConfirmIssueAPIPost(
                                    ManufacturingOrderOperation,
                                    opconfirmedworkquantity1,
                                    opconfirmedworkquantity2,
                                    opconfirmedworkquantity3,
                                    opconfirmedworkquantity4,
                                    opconfirmedworkquantity5,
                                    opconfirmedworkquantity6,
                                    oRow
                                );

                                const matDoc = postResult.materialdocument;
                                if (!matDoc) {
                                    let ErrorMessage = "Some error occurred while posting.";
                                    try {
                                        const kk = JSON.parse(postResult.errorresponse);
                                        ErrorMessage = kk.error.message.value;
                                    } catch (e) { }

                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: ErrorMessage
                                    });
                                } else {
                                    // Update row with material document
                                    oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                                    oRow.gicnfmaterialdocyear = postResult.matdocyear;
                                    oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                                    oRow.gicnfconfirmationcount = postResult.confirmationcount;

                                    // Update internal table
                                    await that.ToUpdateIntTab(oRow, matDoc, postResult);

                                    aSuccessRows.push({
                                        productionOrder: oRow.productionorderno,
                                        materialDocument: matDoc
                                    });
                                }

                            } catch (error) {
                                console.error("Error in confirmation for order:", oRow.productionorderno, error);
                                aFailedRows.push({
                                    productionOrder: oRow.productionorderno,
                                    error: error.message || "Unknown error"
                                });
                            }
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    }
                });
            },

            // Show confirmation summary
            showConfirmationSummary: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },


            ToConfirmIssueAPIPost: function (
                ManufacturingOrderOperation,
                opconfirmedworkquantity1,
                opconfirmedworkquantity2,
                opconfirmedworkquantity3,
                opconfirmedworkquantity4,
                opconfirmedworkquantity5,
                opconfirmedworkquantity6,
                oSelectedRow
            ) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oEntry = {
                        orderid: oSelectedRow.productionorderno,
                        orderoperation: ManufacturingOrderOperation,
                        ordersuboperation: "0000",
                        confirmationyieldquantity: String(oSelectedRow.confirmedqty),
                        opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                        opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                        opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                        opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                        opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                        opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                        materialdocument: "",
                        matdocyear: "",
                        sequence: "0000",
                        confirmationgroup: "",
                        confirmationcount: "",
                        finalconfirmationtype: "X",
                        // PostingDate:new Date(),
                        // PostingDate: new Date(new Date().toLocaleDateString('en-CA')),
                        // PostingDate: new Date(new Date().toLocaleDateString('en-CA')),
                        PostingDate: oSelectedRow.PostingDate ? new Date(oSelectedRow.PostingDate.toLocaleDateString('en-CA')) : null,
                        scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3)
                    };

                    console.log("payload being posted: ", oEntry);
                    // debugger

                    const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");

                    oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
                        success: function (oData) {
                            console.log("✅ Response from /ZC_TB_FT_PRODCONF1:", oData);
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Error response from /ZC_TB_FT_PRODCONF1:", error);
                            reject(error);
                        }
                    });
                });
            },

            ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_MIXING_PLAN1");

                    var oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                        PostingDate: HeaderModel.PostingDate ? new Date(HeaderModel.PostingDate.toLocaleDateString('en-CA')) : null,
                    };

                    oModelGet.update("/ZC_MIXING_PLAN1('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData, oResponse) {
                            console.log("Goods Issue No Updated Successfully...");
                            resolve(oData);
                        },
                        error: function (error) {
                            console.log("Error updating internal table:", error);
                            reject(error);
                        }
                    });
                });
            },

            // =====================================================================================

            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqnoGI: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessageGoodsIssue: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Main Goods Issue function using header-item service (batch)
            // ============================================================
            onGoodsIssuePressBatch: async function () {
                const that = this;
                const oView = this.getView();
                const oGIModel = oView.getModel("ZSB_GICONF_HEAD_ITEM");   // new service
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Arrays for final summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- VALIDATIONS (same as original) ---
                // 1. Already has Goods Issue
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                aWithGI.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Issue already exists"
                    });
                });
                let aProcessRows = aSelectedRows.filter(row => !aWithGI.includes(row));

                // 2. Not released
                const aUnreleased = aProcessRows.filter(row => row.releasestatus !== "RELEASED");
                aUnreleased.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not released"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aUnreleased.includes(row));

                // 3. Update status not "GT"
                const aNotUpdated = aProcessRows.filter(row => row.updatestatusgistatus !== "GT");
                aNotUpdated.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not updated (status not GT)"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aNotUpdated.includes(row));

                // 4. Missing quantity
                const aMissingQty = aProcessRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });
                aMissingQty.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Invalid quantity values"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aMissingQty.includes(row));

                // 5. Quantity mismatch (confirmed + scrap ≠ production order qty)
                // const aQtyMismatch = aProcessRows.filter(row => {
                //     const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
                //     const iBalanceQty = parseFloat(row.scrapqty) || 0;
                //     const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
                //     const iTotalQty = iConfirmedQty + iBalanceQty;
                //     const dTolerance = 0.0001;
                //     return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
                // });
                // aQtyMismatch.forEach(row => {
                //     aSkippedRows.push({
                //         productionOrder: row.productionorderno,
                //         reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
                //     });
                // });
                // aProcessRows = aProcessRows.filter(row => !aQtyMismatch.includes(row));

                // If no rows left to process, show summary and return
                if (aProcessRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // Sort rows by start date and lot number
                aProcessRows.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // Confirm with user
                sap.m.MessageBox.confirm("Do you want to post the selected data?", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) return;

                        sap.ui.core.BusyIndicator.show(0);

                        // --- FETCH YBP4 DATA FOR ALL PROCESS ROWS (parallel) ---
                        const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // model for reading YBP4 data
                        const fetchPromises = aProcessRows.map(async (row) => {
                            try {
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (!oData.results || oData.results.length === 0) {
                                    return { row, success: false, error: `YBP4 data not found for order ${row.productionorderno}` };
                                }

                                return { row, success: true, data: oData.results[0] };
                            } catch (err) {
                                return { row, success: false, error: err.message || "Error fetching YBP4 data" };
                            }
                        });

                        const fetchResults = await Promise.all(fetchPromises);

                        // Separate successful fetches from failed ones
                        const validFetchResults = fetchResults.filter(r => r.success);
                        const failedFetchResults = fetchResults.filter(r => !r.success);

                        // Add fetch failures to aFailedRows
                        failedFetchResults.forEach(f => {
                            aFailedRows.push({
                                productionOrder: f.row.productionorderno,
                                error: f.error
                            });
                        });

                        // If no valid rows after fetches, show summary
                        if (validFetchResults.length === 0) {
                            sap.ui.core.BusyIndicator.hide();
                            this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                            return;
                        }

                        // Build payload items array
                        const aItems = [];
                        const calcQty = (qty, total, scrap, ref) => {
                            const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                            return Number(result.toFixed(3));
                        };

                        validFetchResults.forEach(({ row, data }) => {
                            const opconfirmedworkquantity1 = calcQty(data.WorkCenterStandardWorkQty1, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity2 = calcQty(data.WorkCenterStandardWorkQty2, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity3 = calcQty(data.WorkCenterStandardWorkQty3, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity4 = calcQty(data.WorkCenterStandardWorkQty4, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity5 = calcQty(data.WorkCenterStandardWorkQty5, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity6 = calcQty(data.WorkCenterStandardWorkQty6, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);

                            aItems.push({
                                Id: row.sap_uuid,                                 // unique item identifier
                                Orderid: row.productionorderno,
                                Orderoperation: data.ManufacturingOrderOperation,
                                Ordersuboperation: "0000",
                                Confirmationyieldquantity: String(row.confirmedqty),
                                Opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                                Opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                                Opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                                Opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                                Opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                                Opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                                Scrapqty: parseFloat(row.scrapqty).toFixed(3),
                                Sequence: "0000",
                                Finalconfirmationtype: "X",
                                // Uom: optional, can be omitted or set from somewhere
                            });
                        });

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGI();

                        // Build final payload
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: { results: aItems }
                        };

                        console.log(`🚀 Posting Goods Issue with ${aItems.length} items in one payload`, oPayload);
                        // debugger

                        try {
                            // Create header with all items
                            const oResponse = await new Promise((resolve, reject) => {
                                oGIModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ Goods Issue batch created`, oResponse);

                            // Validate response structure
                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aProcessRows.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                // Check if backend returned an error for this item
                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aFailedRows.push({
                                        productionOrder: originalRow.productionorderno,
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                // Get material document details from item response
                                const matDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;
                                const confirmationGroup = itemResp.Confirmationgroup;
                                const confirmationCount = itemResp.Confirmationcount;

                                // Update local row
                                originalRow.gicnfmaterialdocnumber = matDoc;
                                originalRow.gicnfmaterialdocyear = matDocYear;
                                originalRow.gicnfconfirmationgroup = confirmationGroup;
                                originalRow.gicnfconfirmationcount = confirmationCount;

                                // Update mixing plan table
                                try {
                                    await this.ToUpdateIntTabGoodsIssue(
                                        originalRow,
                                        matDoc,
                                        {
                                            materialdocument: matDoc,
                                            matdocyear: matDocYear,
                                            confirmationgroup: confirmationGroup,
                                            confirmationcount: confirmationCount
                                        }
                                    );
                                    console.log(`✅ Updated mixing plan for row ${originalRow.sap_uuid}`);
                                } catch (updateErr) {
                                    console.error(`⚠️ Mixing plan update failed for row ${originalRow.sap_uuid}`, updateErr);
                                    // Still consider the GI successful; log warning but don't mark as failed
                                }

                                aSuccessRows.push({
                                    productionOrder: originalRow.productionorderno,
                                    materialDocument: matDoc
                                });
                            }

                            // Update FinalStatus with last successful material document (if any)
                            if (aSuccessRows.length > 0) {
                                const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                                this.FinalStatus = new sap.ui.model.json.JSONModel({
                                    MSGSTRIP: {
                                        visible: true,
                                        text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                        type: 'Success'
                                    }
                                });
                                this.getView().setModel(this.FinalStatus, "FinalStatus");
                            }

                        } catch (oError) {
                            // Entire request failed
                            console.error(`❌ Goods Issue batch failed:`, oError);
                            const sErrorMessage = this._extractErrorMessageGoodsIssue(oError);

                            // Mark all rows that were supposed to be processed as failed
                            aProcessRows.forEach(row => {
                                aFailedRows.push({
                                    productionOrder: row.productionorderno,
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.setProperty("/Samples", aRows); // ensure selection cleared? Not cleared yet; we can clear later
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                    }.bind(this) // bind to keep 'this' context
                });
            },

            // ============================================================
            // Update internal table (mixing plan) with Goods Issue details
            // ============================================================
            ToUpdateIntTabGoodsIssue: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oModelGet = that.getView().getModel("ZSB_MIXING_PLAN1");

                    const oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                    };

                    console.log(`📝 Updating mixing plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_MIXING_PLAN1('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            reject(error);
                        }
                    });
                });
            },

            // Show confirmation summary
            showConfirmationSummarybatch: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },



            onGoodsReceiptPress: async function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                let aBlockerErrors = [];

                aSelectedRows.forEach((row) => {
                    let errors = [];

                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }

                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists");
                    }

                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness)
                let aValidationErrors = [];

                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- ✅ PROCESSING (all validations passed)
                sap.ui.core.BusyIndicator.show(0);

                // Arrays to collect results
                const aSuccessResults = [];
                const aErrorResults = [];

                aSelectedRows.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno (ascending)
                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                for (let i = 0; i < aSelectedRows.length; i++) {
                    const row = aSelectedRows[i];
                    const sProdOrder = row.productionorderno || `Row ${i + 1}`;

                    const oPayload = {
                        material: row.materialcode,
                        plant: row.plant,
                        storagelocation: row.storagelocation,
                        goodsmovementtype: "101",
                        manufacturingorder: row.productionorderno,
                        manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementrefdoctype: "F",
                        quantityinentryunit: String(row.confirmedqty),
                        postingdate: new Date(),
                        // postingdate: row.PostingDate ? new Date(row.PostingDate.toLocaleDateString('en-CA')) : null,
                        goodsmovementcode: "02"
                    };
                    console.log("payload:", oPayload);

                    try {
                        const oData = await new Promise((resolve, reject) => {
                            oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
                                success: function (oData) {
                                    console.log("result:", oData);
                                    // Check if material document exists AND if errorresponse is present
                                    if (!oData.materialdocument && oData.errorresponse) {
                                        // This is an error returned in success response
                                        let errorMessage = "Unknown error";
                                        try {
                                            const errorObj = JSON.parse(oData.errorresponse);
                                            errorMessage = errorObj.error?.message?.value || errorObj.error?.message || oData.errorresponse;
                                        } catch (e) {
                                            errorMessage = oData.errorresponse;
                                        }
                                        reject(new Error(errorMessage));
                                    } else if (!oData.materialdocument) {
                                        // No material document and no error response
                                        reject(new Error("No material document returned"));
                                    } else {
                                        resolve(oData);
                                    }
                                },
                                error: reject
                            });
                        });

                        console.log("result:", oData);

                        // If we get here, we have a valid material document
                        row.grmaterialdocnumber = oData.materialdocument;
                        row.grmaterialdocyear = oData.matdocyear;

                        const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
                        row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

                        await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

                        // Add to success list
                        aSuccessResults.push({
                            productionOrder: sProdOrder,
                            materialDocument: oData.materialdocument,
                            year: oData.matdocyear
                        });

                    } catch (oError) {
                        console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

                        // Extract error message
                        let sErrorMessage = oError.message || "Unknown error";

                        // For OData errors
                        if (oError.responseText) {
                            try {
                                const oErrorResponse = JSON.parse(oError.responseText);
                                if (oErrorResponse.error && oErrorResponse.error.message) {
                                    sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                                }
                            } catch (e) {
                                sErrorMessage = oError.responseText;
                            }
                        }

                        // Add to error list
                        aErrorResults.push({
                            productionOrder: sProdOrder,
                            error: sErrorMessage
                        });
                    }
                }

                // Update the model with processed rows
                oTabModel.setProperty("/Samples", aRows);
                oTabModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showGRSummary(aSuccessResults, aErrorResults);
            },

            // Also update the showGRSummary to be consistent with our other summaries:
            showGRSummary: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                let bHasSuccess = aSuccessResults.length > 0;
                let bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}`;
                        if (result.materialDocument) {
                            sMessage += ` (Material Doc: ${result.materialDocument}/${result.year})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}: ${result.error}\n`;
                    });
                }

                // Always show MessageBox for all cases (consistent with other summaries)
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aErrorResults.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },


            ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_MIXING_PLAN1");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // batchweight: HeaderModel.batchweight,
                        operator: HeaderModel.operator,
                        inspector: HeaderModel.inspector,
                        // batchweight: String(parseInt(HeaderModel.confirmedqty)),
                        expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

                    };

                    oModelGet.update("/ZC_MIXING_PLAN1('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully.");
                            sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed");
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    // Safely get the backend model
                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    // Call the read function
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {
                            console.log(oData)

                            resolve(oData.results)

                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve Mixing Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },





            generateUUIDreqnoGR: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },


            // ============================================================
            // UPDATED: Main Goods Receipt function using header-item service
            // ============================================================
            // onGoodsReceiptPressBatch: async function () {
            //     const oView = this.getView();
            //     const oGRModel = oView.getModel("ZSB_GR_HEAD_ITEM");         // new service
            //     const oTabModel = oView.getModel("TabModel");
            //     const oMixingModel = oView.getModel("ZSB_MIXING_PLAN1");     // for updates
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let errors = [];
            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }
            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }
            //         if (!row.productionorderno || row.productionorderno.trim() === "") {
            //             errors.push("Missing Production Order");
            //         }
            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness) ---
            //     // let aValidationErrors = [];
            //     // aSelectedRows.forEach((row, index) => {
            //     //     let missingFields = [];
            //     //     if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //     //     if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //     //     if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //     //     if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //     //     if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //     //     if (missingFields.length > 0) {
            //     //         aValidationErrors.push(`Row ${index + 1}: ${missingFields.join(", ")}`);
            //     //     }
            //     // });

            //     // if (aValidationErrors.length > 0) {
            //     //     sap.m.MessageBox.error(
            //     //         "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //     //     );
            //     //     return;
            //     // }
            //     // --- 🧪 VALIDATION (field completeness) ---
            //     let aValidationErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];
            //         if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //         if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //         if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //         if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //         if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- Sort selected rows (same logic as before) ---
            //     const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);
            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;
            //         const lotA = parseInt(a.bipllotno, 10) || 0;
            //         const lotB = parseInt(b.bipllotno, 10) || 0;
            //         return lotA - lotB;
            //     });

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aSuccessResults = [];
            //     const aErrorResults = [];

            //     // Generate a unique request number (UUID style)
            //     const requestNo = this.generateUUIDreqnoGR();

            //     // Create ONE payload with ALL selected rows in toitem
            //     const oPayload = {
            //         Requestno: requestNo,
            //         toitem: {
            //             results: aSortedSelectedRows.map(row => ({
            //                 Id: row.sap_uuid,                                 // use sap_uuid as item identifier
            //                 Material: row.materialcode,
            //                 Plant: row.plant,
            //                 Storagelocation: row.storagelocation,
            //                 Goodsmovementtype: "101",
            //                 Goodsmovementcode: "02",
            //                 Quantityinentryunit: String(row.confirmedqty),
            //                 Manufacturingorder: row.productionorderno,
            //                 Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                 Postingdate: new Date(),
            //                 Goodsmovementrefdoctype: "F"
            //             }))
            //         }
            //     };

            //     console.log(`🚀 Creating GR with ${aSortedSelectedRows.length} items in one payload`, oPayload);

            //     // try {
            //     //     // Create header with ALL items in one call
            //     //     const oResponse = await new Promise((resolve, reject) => {
            //     //         oGRModel.create("/header", oPayload, {
            //     //             success: resolve,
            //     //             error: reject
            //     //         });
            //     //     });

            //     //     console.log(`✅ GR created for all items`, oResponse);

            //     //     // Validate response structure
            //     //     if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            //     //         throw new Error("Invalid response: missing toitem results");
            //     //     }

            //     //     // Process each item in the response - EACH ITEM HAS ITS OWN MATERIAL DOCUMENT
            //     //     for (let i = 0; i < oResponse.toitem.results.length; i++) {
            //     //         const itemResp = oResponse.toitem.results[i];
            //     //         const originalRow = aSortedSelectedRows.find(r => r.sap_uuid === itemResp.Id);

            //     //         if (!originalRow) {
            //     //             console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
            //     //             continue;
            //     //         }

            //     //         // Check if backend returned an error for this item
            //     //         if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
            //     //             aErrorResults.push({
            //     //                 productionOrder: originalRow.productionorderno,
            //     //                 rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //     //                 bipllotno: originalRow.bipllotno || "",
            //     //                 error: itemResp.Errorresponse
            //     //             });
            //     //             continue;
            //     //         }

            //     //         // Get the material document details from the item response (not from header)
            //     //         const materialDoc = itemResp.Materialdocument;
            //     //         const matDocYear = itemResp.Matdocyear;

            //     //         // Success: update local row with item-specific material document
            //     //         originalRow.grmaterialdocnumber = materialDoc;
            //     //         originalRow.grmaterialdocyear = matDocYear;
            //     //         originalRow.expirydate = itemResp.Shelflifeexpirationdate
            //     //             ? new Date(itemResp.Shelflifeexpirationdate)
            //     //             : null;

            //     //         // Update mixing plan table with the item-specific material document
            //     //         try {
            //     //             await this.ToUpdateGRTabBatch(
            //     //                 originalRow,
            //     //                 materialDoc,
            //     //                 {
            //     //                     materialdocument: materialDoc,
            //     //                     matdocyear: matDocYear
            //     //                 },
            //     //                 {
            //     //                     ShelfLifeExpirationDate: itemResp.Shelflifeexpirationdate
            //     //                 }
            //     //             );

            //     //             console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}`);
            //     //         } catch (updateErr) {
            //     //             console.error("⚠️ Mixing plan update failed for row", originalRow.sap_uuid, updateErr);
            //     //         }

            //     //         aSuccessResults.push({
            //     //             productionOrder: originalRow.productionorderno,
            //     //             rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //     //             bipllotno: originalRow.bipllotno || "",
            //     //             materialDocument: materialDoc,
            //     //             year: matDocYear,
            //     //             expiryDate: itemResp.Shelflifeexpirationdate
            //     //         });
            //     //     }
            //     // } catch (oError) {
            //     //     // Entire request failed
            //     //     console.error(`❌ GR failed for all items:`, oError);
            //     //     const sErrorMessage = this._extractErrorMessage(oError);

            //     //     aSortedSelectedRows.forEach((row, idx) => {
            //     //         aErrorResults.push({
            //     //             productionOrder: row.productionorderno,
            //     //             rowId: `Row ${idx + 1}`,
            //     //             bipllotno: row.bipllotno || "",
            //     //             error: sErrorMessage
            //     //         });
            //     //     });
            //     // }
            //     try {
            //         // Create header with ALL items in one call
            //         const oResponse = await new Promise((resolve, reject) => {
            //             oGRModel.create("/header", oPayload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });

            //         console.log(`✅ GR created for all items`, oResponse);

            //         // Validate response structure
            //         if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            //             throw new Error("Invalid response: missing toitem results");
            //         }

            //         // Process each item in the response
            //         for (let i = 0; i < oResponse.toitem.results.length; i++) {
            //             const itemResp = oResponse.toitem.results[i];
            //             const originalRow = aSortedSelectedRows.find(r => r.sap_uuid === itemResp.Id);

            //             if (!originalRow) {
            //                 console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
            //                 continue;
            //             }

            //             // Check if backend returned an error for this item
            //             if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
            //                 aErrorResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     error: itemResp.Errorresponse
            //                 });
            //                 continue;
            //             }

            //             // Get the material document details from the item response
            //             const materialDoc = itemResp.Materialdocument;
            //             const matDocYear = itemResp.Matdocyear;

            //             try {
            //                 // --- STEP 1: Fetch expiry date from material document item entity ---
            //                 const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear }
            //                 );

            //                 // Extract expiry date (use first item's ShelfLifeExpirationDate)
            //                 const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

            //                 // Update local row
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

            //                 // --- STEP 2: Update mixing plan table with fetched expiry date ---
            //                 await this.ToUpdateGRTabBatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear },
            //                     { ShelfLifeExpirationDate: expiryDate } // pass the fetched expiry
            //                 );

            //                 console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: expiryDate
            //                 });

            //             } catch (itemError) {
            //                 // If fetching expiry or updating fails, still consider GR successful? 
            //                 // According to original pattern, if GR succeeded but subsequent steps fail, 
            //                 // we log warning but still count as success (since GR was created).
            //                 console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);

            //                 // Still update local row with basic GR info
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = itemResp.Shelflifeexpirationdate
            //                     ? new Date(itemResp.Shelflifeexpirationdate)
            //                     : null;

            //                 // Add to success with warning note
            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: originalRow.expirydate,
            //                     warning: "Expiry fetch failed, using GR response expiry"
            //                 });
            //             }
            //         }
            //     } catch (oError) {
            //         // Entire request failed
            //         console.error(`❌ GR failed for all items:`, oError);
            //         const sErrorMessage = this._extractErrorMessage(oError);

            //         aSortedSelectedRows.forEach((row, idx) => {
            //             aErrorResults.push({
            //                 productionOrder: row.productionorderno,
            //                 rowId: `Row ${idx + 1}`,
            //                 bipllotno: row.bipllotno || "",
            //                 error: sErrorMessage
            //             });
            //         });
            //     }

            //     // --- Update local table model and clear selection ---
            //     aSelectedRows.forEach(row => { row.__selected = false; });
            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();

            //     sap.ui.core.BusyIndicator.hide();

            //     // --- Show summary ---
            //     this.showGRSummaryBatch(aSuccessResults, aErrorResults);
            // },
            // ============================================================
            // UPDATED: Main Goods Receipt function with backend fetch & confirmation
            // ============================================================

            checkUserHasGoodsRecieptRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onGoodsReceiptPressBatch: async function () {
                const oView = this.getView();
                const oGRModel = oView.getModel("ZSB_GR_HEAD_ITEM");         // service for posting
                const oFetchModel = oView.getModel("ZSB_GR_MATDOC_FETCH");   // service for fetching existing GR
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                // --- Arrays to track results ---
                const aSuccessResults = [];
                const aErrorResults = [];
                const aSkippedRows = [];

                // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                let aBlockerErrors = [];
                aSelectedRows.forEach((row) => {
                    let errors = [];
                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }
                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists (local)");
                    }
                    if (!row.productionorderno || row.productionorderno.trim() === "") {
                        errors.push("Missing Production Order");
                    }
                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness) ---
                let aValidationErrors = [];
                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
                    if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
                    if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
                    if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
                    if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- Remove rows that already have a GR in the UI (local) ---
                const aWithLocalGR = aSelectedRows.filter(row => row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "");
                aWithLocalGR.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Receipt already exists (local)"
                    });
                });
                let aRowsToCheck = aSelectedRows.filter(row => !aWithLocalGR.includes(row));

                // --- If no rows left after local check, show summary and return ---
                if (aRowsToCheck.length === 0) {
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- 🕒 Show busy indicator before backend fetch ---
                sap.ui.core.BusyIndicator.show(0);

                // --- Fetch existing GR data from ZSB_GR_MATDOC_FETCH for remaining rows ---
                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];

                const fetchExistingPromises = aRowsToCheck.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_GR_MATDOC_FETCH", {
                                filters: [oFilter],
                                success: resolve,
                                error: reject
                            });
                        });

                        if (oData.results && oData.results.length > 0) {
                            // Use the first result (assuming at most one per order)
                            return { row, existing: oData.results[0] };
                        } else {
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GR for order ${row.productionorderno}:`, err);
                        // Treat as not existing; proceed with posting
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Separate rows
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a goods receipt in the backend ---
                // --- Update rows that already have a goods receipt in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;

                    // Update local row
                    row.grmaterialdocnumber = matDoc;
                    row.grmaterialdocyear = matDocYear;

                    // Update mixing plan table
                    try {
                        await this.ToUpdateGRTabBatch(
                            row,
                            matDoc,
                            { materialdocument: matDoc, matdocyear: matDocYear },
                            { ShelfLifeExpirationDate: null }   // expiry not available from this fetch
                        );
                        console.log(`✅ Updated mixing plan for existing order ${row.productionorderno}`);
                        aSuccessResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            materialDocument: matDoc,
                            year: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update mixing plan for existing order ${row.productionorderno}:`, updateErr);
                        aErrorResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // Hide busy indicator before showing confirmation
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- Sort rows to post (same logic as before) ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods receipt for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        sap.ui.core.BusyIndicator.show(0);

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGR();

                        // Build payload with all rows to post
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: {
                                results: aRowsToPost.map(row => ({
                                    Id: row.sap_uuid,
                                    Material: row.materialcode,
                                    Plant: row.plant,
                                    Storagelocation: row.storagelocation,
                                    Goodsmovementtype: "101",
                                    Goodsmovementcode: "02",
                                    Quantityinentryunit: String(row.confirmedqty),
                                    Manufacturingorder: row.productionorderno,
                                    Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    // Postingdate: new Date(),
                                    Postingdate: row.PostingDate ? new Date(row.PostingDate.toLocaleDateString('en-CA')) : null,
                                    Goodsmovementrefdoctype: "F"
                                }))
                            }
                        };

                        console.log(`🚀 Creating GR with ${aRowsToPost.length} items in one payload`, oPayload);

                        try {
                            const oResponse = await new Promise((resolve, reject) => {
                                oGRModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ GR created for all items`, oResponse);

                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aRowsToPost.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aErrorResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                const materialDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;

                                try {
                                    // Fetch expiry date from material document item
                                    const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear }
                                    );
                                    const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

                                    // Update local row
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

                                    // Update mixing plan table
                                    await this.ToUpdateGRTabBatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear },
                                        { ShelfLifeExpirationDate: expiryDate }
                                    );

                                    console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: expiryDate
                                    });

                                } catch (itemError) {
                                    console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);
                                    // Still count as success because GR was created, but log warning
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = itemResp.Shelflifeexpirationdate
                                        ? new Date(itemResp.Shelflifeexpirationdate)
                                        : null;

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: originalRow.expirydate,
                                        warning: "Expiry fetch failed, using GR response expiry"
                                    });
                                }
                            }
                        } catch (oError) {
                            console.error(`❌ GR failed for all items:`, oError);
                            const sErrorMessage = this._extractErrorMessage(oError);
                            aRowsToPost.forEach((row, idx) => {
                                aErrorResults.push({
                                    productionOrder: row.productionorderno,
                                    rowId: `Row ${idx + 1}`,
                                    bipllotno: row.bipllotno || "",
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Update table and clear selection
                        aSelectedRows.forEach(row => { row.__selected = false; });
                        oTabModel.setProperty("/Samples", aRows);
                        oTabModel.refresh();

                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    }.bind(this) // ensure 'this' context
                });
            },

            // ============================================================
            // UPDATED: Update mixing plan table
            // ============================================================
            ToUpdateGRTabBatch: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    // sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_MIXING_PLAN1");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        operator: HeaderModel.operator,
                        inspector: HeaderModel.inspector,
                        expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,
                    };

                    console.log(`📝 Updating mixing plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_MIXING_PLAN1('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            // sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            // sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            // ============================================================
            // NEW HELPER: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // UPDATED: Summary dialog (now matches the style of showPostSummaryBatch)
            // ============================================================
            showGRSummaryBatch: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;
                if (sTotal === 0) return;

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                const bHasSuccess = aSuccessResults.length > 0;
                const bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}) → `;
                        if (result.materialDocument) {
                            sMessage += `Material Doc: ${result.materialDocument}/${result.year}`;
                            if (result.expiryDate) {
                                const d = new Date(result.expiryDate);
                                sMessage += `, Expiry: ${d.toLocaleDateString()}`;
                            }
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}): ${result.error}\n`;
                    });
                }

                setTimeout(() => {
                    if (bHasFailed && !bHasSuccess) {
                        sap.m.MessageBox.error(sMessage, { title: "Goods Receipt Failed" });
                    } else if (bHasFailed && bHasSuccess) {
                        sap.m.MessageBox.warning(sMessage, {
                            title: "Goods Receipt Partial Success",
                            details: aErrorResults.map(f =>
                                `${f.rowId} (Bipl: ${f.bipllotno})\nError: ${f.error}`
                            ).join('\n\n')
                        });
                    } else {
                        sap.m.MessageBox.success(sMessage, { title: "Goods Receipt Successful" });
                    }
                }, 100);
            },



            // ============================================================
            // EXISTING: Fetch expiry date (kept for compatibility, but no longer used in new flow)
            // ============================================================
            ToFetchExpiredateGRTabbatch: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {
                            console.log(oData)
                            resolve(oData.results)
                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve Mixing Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },






            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_MIXING_PLAN1");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);
                const aSelectedUUIDs = aSelectedRows.map(item => item.sap_uuid); // store for later

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {
                    const sKey = oODataModel.createKey("/ZC_MIXING_PLAN1", {
                        sap_uuid: item.sap_uuid,
                    });

                    const oPayload = {
                        confirmedqty: String(item.confirmedqty),
                        scrapqty: String(item.scrapqty),
                        manufacturingdate: item.manufacturingdate ? new Date(item.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        PostingDate: item.PostingDate ? new Date(item.PostingDate.toLocaleDateString('en-CA')) : null,
                        updatestatusgistatus: "GT"
                    };

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);

                    // Now refresh data via GoMixingActualfilter and restore selection
                    this.GoMixingActualfilter(function (aNewData) {
                        // Restore selection: mark __selected = true for rows whose sap_uuid is in aSelectedUUIDs
                        aNewData.forEach(item => {
                            if (aSelectedUUIDs.indexOf(item.sap_uuid) !== -1) {
                                item.__selected = true;
                            }
                        });
                        // Update the model (GoMixingActualfilter already set it, but we need to reflect selection)
                        const oTabModel = this.getView().getModel("TabModel");
                        oTabModel.setProperty("/Samples", aNewData);
                        oTabModel.refresh(true);
                    }.bind(this));
                });
            },




            onReleasePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
                const oMixingPlanModel = oView.getModel("ZSB_MIXING_PLAN1");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get ALL selected rows, regardless of UI status
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Sort selected rows according to table sorting logic
                aAllSelectedRows.sort((a, b) => {
                    // First sort by productionordstartdate (ascending)
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;

                    // Handle date comparison
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }

                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];
                const aRowsToRelease = [];

                // Phase 1: Check backend status for ALL selected rows
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);

                            // Track what we found
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update mixing plan for consistency
                                await this.updateMixingPlan(oMixingPlanModel, row, true);
                            }
                        } else {
                            // Order is not released in backend, add to list for release
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Release rows that are not already released in backend
                for (let i = 0; i < aRowsToRelease.length; i++) {
                    const { originalIndex, row, manufacturingOrder } = aRowsToRelease[i];

                    try {
                        // Create release
                        const bReleaseSuccess = await this.createRelease(oModel, manufacturingOrder);

                        if (bReleaseSuccess) {
                            console.log(`Row ${originalIndex + 1}: Successfully released ${manufacturingOrder}`);

                            // Update mixing plan
                            await this.updateMixingPlan(oMixingPlanModel, row, false);

                            // Update UI
                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder
                            });
                            console.log(`✅ Row ${originalIndex + 1} released successfully`);
                        } else {
                            row.releasestatus = "";
                            aFailedRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder,
                                error: "Release creation failed - check material availability"
                            });
                            console.warn(`⚠️ Row ${originalIndex + 1}: Release creation failed`);
                        }

                    } catch (releaseError) {
                        console.error(`Row ${originalIndex + 1}: Error during release:`, releaseError);
                        row.releasestatus = "";

                        let sErrorMessage;

                        // Check EXACTLY for "Release of order not possible" or CO/118 error
                        const errorMessage = releaseError.message || "";
                        const errorCode = releaseError.code || "";

                        if (errorMessage.includes("Release of order not possible") ||
                            errorCode.includes("CO/118") ||
                            (releaseError.isMaterialAvailabilityError === true)) {
                            // ONLY for this specific error, show the material availability message
                            sErrorMessage = `Release failed: Check material availability for order ${manufacturingOrder}`;
                        } else {
                            // For ALL other errors, show the full error message
                            sErrorMessage = releaseError.message || "Unknown error";

                            // Include the error code if available
                            if (releaseError.code) {
                                sErrorMessage = `Error ${releaseError.code}: ${sErrorMessage}`;
                            }
                        }

                        aFailedRows.push({
                            rowNumber: originalIndex + 1,
                            productionOrder: manufacturingOrder,
                            error: sErrorMessage,
                            rawError: releaseError.message // Store the raw error for debugging
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

            // Updated createRelease function to properly handle errors
            createRelease: function (oModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const oPayload = {
                        ManufacturingOrder: sManufacturingOrder
                    };

                    oModel.create("/ZC_PROD_STATUS1", oPayload, {
                        success: function (oData) {
                            console.log("response success:", oData);

                            // Check if there's an error in the response
                            if (oData.errorresponse) {
                                try {
                                    // Parse the error response JSON
                                    const errorObj = JSON.parse(oData.errorresponse);
                                    console.error("Error in response:", errorObj);

                                    // Check for specific error codes
                                    const errorCode = errorObj.error?.code;
                                    const errorMessage = errorObj.error?.message?.value || "Unknown error";

                                    // Reject with structured error
                                    reject({
                                        message: errorMessage,
                                        code: errorCode,
                                        details: errorObj.error?.innererror,
                                        isMaterialAvailabilityError: errorCode === "CO/118" ||
                                            errorMessage.includes("Release of order not possible")
                                    });
                                } catch (parseError) {
                                    // If JSON parsing fails, reject with the raw error
                                    reject({
                                        message: "Error processing response",
                                        rawError: oData.errorresponse
                                    });
                                }
                                return;
                            }

                            // If no error, resolve with success
                            resolve(true);
                        },
                        error: function (oError) {
                            console.error("OData call failed:", oError);
                            reject({
                                message: oError.message || "OData call failed",
                                rawError: oError
                            });
                        }
                    });
                });
            },

            // Helper function to check order status (unchanged)
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData)
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            updateMixingPlan: function (oMixingPlanModel, row, bAlreadyReleased) {
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        // batchweight: row.batchweight || "",
                        // operator: row.operator || "",
                        // inspector: row.inspector || "",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oMixingPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 Mixing Plan updated`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },





            // -----------------------------------------------------------------------------------------------------

            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqno: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Batch Release using header-item service
            // ============================================================

            checkUserHasReleaseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_RELEASE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReleasePressBatch: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // for status check
                const oMixingPlanModel = oView.getModel("ZSB_MIXING_PLAN1");
                const oReleaseModel = oView.getModel("ZSB_RELEASE_HEAD_ITEM");  // new service



                // Get ALL selected rows
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasReleaseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_RELEASE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Sort selected rows (same logic as original)
                aAllSelectedRows.sort((a, b) => {
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays for summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];

                // Phase 1: Check backend status for ALL selected rows
                const aRowsToRelease = [];
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update mixing plan for consistency (don't fail if this update fails)
                                try {
                                    // await this.updateMixingPlanBatch(oMixingPlanModel, row, true);
                                    await this.updatePlanTableBatch(oMixingPlanModel, row, true);
                                } catch (updateErr) {
                                    console.warn(`Mixing plan update for already released row ${row.sap_uuid} failed:`, updateErr);
                                }
                            }
                        } else {
                            // Order is not released in backend, add to list for batch release
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Batch release rows that are not already released
                if (aRowsToRelease.length > 0) {
                    // Generate a unique request number
                    const requestNo = this.generateUUIDreqno();

                    // Build items array for the batch payload
                    const aItems = aRowsToRelease.map(item => ({
                        Id: item.row.sap_uuid,                    // unique item identifier
                        Manufacturingorder: item.manufacturingOrder
                        // No other fields needed for creation (output fields will be filled by backend)
                    }));

                    const oPayload = {
                        Requestno: requestNo,
                        toitem: { results: aItems }
                    };

                    console.log(`🚀 Posting Release batch with ${aItems.length} items`, oPayload);

                    try {
                        // Create header with all items in one call
                        const oResponse = await new Promise((resolve, reject) => {
                            oReleaseModel.create("/header", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Release batch created`, oResponse);

                        // Validate response structure
                        if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                            throw new Error("Invalid response: missing toitem results");
                        }

                        // Process each item in the response
                        for (let i = 0; i < oResponse.toitem.results.length; i++) {
                            const itemResp = oResponse.toitem.results[i];
                            const originalItem = aRowsToRelease.find(item => item.row.sap_uuid === itemResp.Id);

                            if (!originalItem) {
                                console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                continue;
                            }

                            const row = originalItem.row;
                            const rowNumber = originalItem.originalIndex + 1;

                            // Check if backend returned an error for this item
                            if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                // Parse error response if possible
                                let errorMsg = itemResp.Errorresponse;
                                try {
                                    const errObj = JSON.parse(itemResp.Errorresponse);
                                    errorMsg = errObj.error?.message?.value || errObj.message || itemResp.Errorresponse;
                                } catch (e) { /* use raw string */ }

                                aFailedRows.push({
                                    rowNumber: rowNumber,
                                    productionOrder: row.productionorderno,
                                    error: errorMsg
                                });
                                continue;
                            }

                            // Success: update mixing plan and UI
                            try {
                                await this.updatePlanTableBatch(oMixingPlanModel, row, false);
                            } catch (updateErr) {
                                console.error(`⚠️ Mixing plan update failed for row ${row.sap_uuid}`, updateErr);
                                // Still consider release successful; log warning but don't mark as failed
                            }

                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: rowNumber,
                                productionOrder: row.productionorderno
                            });
                        }
                    } catch (oError) {
                        // Entire request failed
                        console.error(`❌ Release batch failed:`, oError);
                        const sErrorMessage = this._extractErrorMessage(oError);

                        // Mark all rows that were supposed to be released as failed
                        aRowsToRelease.forEach(item => {
                            aFailedRows.push({
                                rowNumber: item.originalIndex + 1,
                                productionOrder: item.row.productionorderno,
                                error: sErrorMessage
                            });
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message (reusing the existing function)
                this.showReleaseSummarybatch(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            // ============================================================
            // Helper to check order status (unchanged)
            // ============================================================
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData);
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            // ============================================================
            // Update mixing plan (renamed with Batch suffix for consistency)
            // ============================================================
            updatePlanTableBatch: function (oMixingPlanModel, row, bAlreadyReleased) {
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oMixingPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 Mixing Plan updated for ${row.sap_uuid}`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },

            // ============================================================
            // Existing showReleaseSummarybatch function (unchanged)
            // ============================================================
            showReleaseSummarybatch: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },





            onBatchValueHelp: function (oEvent) {
                const oView = this.getView();
                const oSource = oEvent.getSource();
                this._oBatchInputSource = oSource; // Save for setting value later

                // Load fragment if not already created
                if (!this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog = sap.ui.xmlfragment(
                        oView.getId(),
                        "bando.view.CommonFragments.ActualScreens.bombatchselect",
                        this
                    );
                    oView.addDependent(this._oBatchValueHelpDialog);
                }

                // Get current row data (for filtering)
                const oContext = oSource.getBindingContext("TabModel");
                if (!oContext) {
                    sap.m.MessageToast.show("No row context found.");
                    return;
                }

                const oRowData = oContext.getObject();
                const sMaterial = oRowData.Product;
                const sPlant = oRowData.Plant;
                const sStorageLoc = oRowData.StorageLocation;

                // Load data before opening
                this._loadBatchData(sMaterial, sPlant, sStorageLoc);
            },

            // ===========================================================
            // Load Batch Data and Bind to Fragment Table
            // ===========================================================
            _loadBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB"); // backend OData model

                // Build filters
                const aFilters = [
                    new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    // new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                const that = this;
                oModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        console.log("✅ Batch data received:", oData);

                        // Create JSON model from results array
                        const oJSONModel = new sap.ui.model.json.JSONModel(oData.results);

                        // Get table from fragment
                        const oTable = sap.ui.core.Fragment.byId(oView.getId(), "batchTable");
                        if (oTable) {
                            oTable.setModel(oJSONModel, "BatchModel");
                            console.log("✅ Bound rows:", oJSONModel.getData());
                            that._oBatchValueHelpDialog.open();
                        } else {
                            console.error("❌ batchTable not found in fragment");
                        }
                    },

                    error: function (oError) {
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // ===========================================================
            // Handle "Select" Button - Set Batch value in Input Field
            // ===========================================================

            // onBatchRowSelect: function (oEvent) {
            //     const oTable = oEvent.getSource();
            //     const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

            //     if (!oSelectedContext) {
            //         sap.m.MessageToast.show("No row selected.");
            //         return;
            //     }

            //     const oSelectedData = oSelectedContext.getObject();

            //     if (this._oBatchInputSource) {
            //         this._oBatchInputSource.setValue(oSelectedData.Batch); // Set selected batch
            //     }

            //     // Close and destroy the dialog to avoid reuse issues
            //     if (this._oBatchValueHelpDialog) {
            //         this._oBatchValueHelpDialog.close();
            //         this._oBatchValueHelpDialog.destroy();
            //         this._oBatchValueHelpDialog = null;
            //     }
            // },
            onBatchRowSelect: function (oEvent) {
                const oTable = oEvent.getSource();
                const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

                if (!oSelectedContext) {
                    sap.m.MessageToast.show("No row selected.");
                    return;
                }

                const oSelectedData = oSelectedContext.getObject();

                if (this._oBatchInputSource) {
                    // Get the current row context in the TabModel
                    const oRowContext = this._oBatchInputSource.getBindingContext("TabModel");

                    if (oRowContext) {
                        const oTabModel = oRowContext.getModel();
                        const sRowPath = oRowContext.getPath();

                        // Set both Batch and Storage Location
                        oTabModel.setProperty(sRowPath + "/Batch", oSelectedData.Batch);
                        oTabModel.setProperty(sRowPath + "/StorageLocation", oSelectedData.StorageLocation);

                        // Optional: If you want to update the input field value as well
                        this._oBatchInputSource.setValue(oSelectedData.Batch);
                    }
                }

                // Close and destroy the dialog to avoid reuse issues
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy();
                    this._oBatchValueHelpDialog = null;
                }
            },

            // ===========================================================
            // Handle "Cancel" Button
            // ===========================================================
            onValueHelpCancel: function () {
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy(); // cleanup
                    this._oBatchValueHelpDialog = null; // reset reference
                }
            },





            // onReverseReceiptPress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1"); //ZSB_REVERSE_PORD    // Reverse OData model

            //     const oMixingPlanModel = oView.getModel("ZSB_MIXING_PLAN1");   // For updating internal table
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
            //         return;
            //     }

            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
            //     if (aInvalidRows.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     const aFilters = [
            //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, aSelectedRows[0].productionorderno)
            //     ];
            //     oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             const aResults = oData.results;
            //             // const oEntry = aResults && aResults[0];
            //             // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

            //             // const mapped = aResults.map(entry => {
            //             //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
            //             //   });

            //             //   const oEntry = mapped.find(entry => entry !== null);
            //             var bExists = aResults.some(function (oItem) {
            //                 return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
            //             });

            //             // const iSelectedIndex = aRows.findIndex(row => row.__selected);



            //             if (bExists) {
            //                 console.log("Combination exists: I0002 and active.");
            //                 // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
            //                 sap.m.MessageToast.show("Teco already active, cant reverse");
            //                 sap.ui.core.BusyIndicator.hide();

            //                 return;
            //             }
            //             else {
            //                 aSelectedRows.forEach((row, index) => {
            //                     const oPayload = {
            //                         Materialdocument: row.grmaterialdocnumber,
            //                         Matdocyear: row.grmaterialdocyear, // You can make this dynamic if needed
            //                         Postingdate: new Date()
            //                     };

            //                     console.log(`📤 Sending Reverse Receipt Payload for row ${index + 1}:`, oPayload);

            //                     oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
            //                         success: function (oData) {
            //                             console.log(`✅ Reverse receipt success for row ${index + 1}:`, oData);

            //                             const sResponseValue = oData.Response || "";

            //                             // Update internal table field `grmaterialdocnumber`
            //                             const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";
            //                             const oUpdateEntry = {
            //                                 grmaterialdocnumber: sResponseValue,
            //                                 grmaterialdocyear: "",
            //                             };

            //                             oMixingPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                                 success: function () {
            //                                     console.log(`🔄 grmaterialdocnumber updated for row ${index + 1}`);
            //                                     row.grmaterialdocnumber = sResponseValue;
            //                                     row.grmaterialdocyear = "";
            //                                     checkCompletion();
            //                                 },
            //                                 error: function () {
            //                                     console.warn(`⚠️ Failed to update grmaterialdocnumber for row ${index + 1}`);
            //                                     checkCompletion();
            //                                 }
            //                             });
            //                         },
            //                         error: function (oError) {
            //                             console.error(`❌ Reverse receipt failed for row ${index + 1}`, oError);
            //                             checkCompletion();
            //                         }
            //                     });
            //                 });

            //                 function checkCompletion() {
            //                     iCompleted++;
            //                     if (iCompleted === aSelectedRows.length) {
            //                         oTableModel.setProperty("/Samples", aRows);
            //                         oTableModel.refresh();
            //                         sap.ui.core.BusyIndicator.hide();
            //                         sap.m.MessageToast.show("Reverse receipt process completed.");
            //                     }
            //                 }

            //             }

            //         }
            //     });

            // },


            checkUserHasGoodsRecieptReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },



            onReverseReceiptPress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1");
                const oTablePlanModel = oView.getModel("ZSB_MIXING_PLAN1");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Check missing GR fields
                const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    // Check TECO first
                    const aFilters = [
                        new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            aSelectedRows[0].productionorderno
                        )
                    ];

                    const oData = await new Promise((resolve, reject) => {
                        oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                            filters: aFilters,
                            success: resolve,
                            error: reject
                        });
                    });

                    const aResults = oData.results;

                    var bExists = aResults.some(function (oItem) {
                        return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
                    });

                    if (bExists) {
                        sap.m.MessageToast.show("Teco already active, cant reverse");
                        return;
                    }

                    // Process rows sequentially
                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Materialdocument: row.grmaterialdocnumber,
                            Matdocyear: row.grmaterialdocyear,
                            Postingdate: new Date()
                        };

                        console.log(`📤 Sending Reverse Receipt Payload for row ${i + 1}:`, oPayload);

                        // Reverse API
                        const oReverseData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse receipt success for row ${i + 1}:`, oReverseData);

                        const sResponseValue = oReverseData.Response || "";

                        const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            grmaterialdocnumber: sResponseValue,
                            grmaterialdocyear: ""
                        };

                        // Update API
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI
                        row.grmaterialdocnumber = sResponseValue;
                        row.grmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse receipt process completed.");

                } catch (error) {
                    console.error("❌ Reverse receipt error:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Receipt process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },




            // onReverseIssuePress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");//ZSB_CNFISSUEREVERSE // Reverse API model 
            //     const oMixingPlanModel = oView.getModel("ZSB_MIXING_PLAN1"); // For PATCH

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse issue.");
            //         return;
            //     }


            //     // ✅ New Validation: Prevent if any row has grmaterialdocnumber
            //     const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
            //     if (aHasGRRows.length > 0) {
            //         sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
            //         return;
            //     }


            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
            //     if (aInvalidRows1.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
            //         return;
            //     }
            //     // const aInvalidRows2 = aSelectedRows.filter(row => !row.grmaterialdocnumber);
            //     // if (aInvalidRows2.length > 0) {
            //     //     sap.ui.core.BusyIndicator.hide();
            //     //     sap.m.MessageBox.error("Cannot reverse Issue: Do Reciept reverse first.");
            //     //     return;
            //     // }





            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     aSelectedRows.forEach((row, index) => {
            //         const oPayload = {
            //             Porderno: row.productionorderno,
            //             ConfirmationGroup: row.gicnfconfirmationgroup,
            //             ConfirmationCount: row.gicnfconfirmationcount
            //         };

            //         console.log(`📤 Sending Reverse Issue Payload for row ${index + 1}:`, oPayload);

            //         oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
            //             success: function (oData) {
            //                 console.log(`✅ Reverse issue success for row ${index + 1}:`, oData);

            //                 // Get the returned material document number (assuming field is "Response")
            //                 const sResponseValue = oData.Response || "";

            //                 // Update Mixing Plan table with returned Response
            //                 const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";
            //                 const oUpdateEntry = {
            //                     gicnfmaterialdocnumber: "",
            //                     gicnfconfirmationgroup: "",
            //                     gicnfconfirmationcount: "",
            //                     gicnfmaterialdocyear: ""
            //                 };

            //                 oMixingPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                     success: function () {
            //                         console.log(`🔄 gicnfmaterialdocnumber updated for row ${index + 1}`);
            //                         row.gicnfmaterialdocnumber = "";
            //                         row.gicnfconfirmationgroup = "";
            //                         row.gicnfconfirmationcount = "";
            //                         row.gicnfmaterialdocyear = "";
            //                         checkCompletion();
            //                     },
            //                     error: function () {
            //                         console.warn(`⚠️ Failed to update gicnfmaterialdocnumber for row ${index + 1}`);
            //                         checkCompletion();
            //                     }
            //                 });
            //             },
            //             error: function (oError) {
            //                 console.error(`❌ Reverse issue failed for row ${index + 1}`, oError);
            //                 checkCompletion();
            //             }
            //         });
            //     });

            //     function checkCompletion() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Reverse issue process completed.");
            //         }
            //     }
            // },

            checkUserHasGoodsIssueReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReverseIssuePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");
                const oTablePlanModel = oView.getModel("ZSB_MIXING_PLAN1");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse issue.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Prevent if any row has GR material doc
                const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
                if (aHasGRRows.length > 0) {
                    sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
                    return;
                }

                // Check missing GI material doc
                const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
                if (aInvalidRows1.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Porderno: row.productionorderno,
                            ConfirmationGroup: row.gicnfconfirmationgroup,
                            ConfirmationCount: row.gicnfconfirmationcount
                        };

                        console.log(`📤 Sending Reverse Issue Payload for row ${i + 1}:`, oPayload);

                        // Wait for reverse API
                        const oData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse issue success for row ${i + 1}:`, oData);

                        const sUpdatePath = "/ZC_MIXING_PLAN1('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            gicnfmaterialdocnumber: "",
                            gicnfconfirmationgroup: "",
                            gicnfconfirmationcount: "",
                            gicnfmaterialdocyear: ""
                        };

                        // Wait for update
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI row
                        row.gicnfmaterialdocnumber = "";
                        row.gicnfconfirmationgroup = "";
                        row.gicnfconfirmationcount = "";
                        row.gicnfmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse issue process completed.");

                } catch (error) {
                    console.error("❌ Error during reverse issue:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Issue process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },


            onPrintPress: async function () {
                const oModel = this.getView().getModel("TabModel").getProperty("/Samples");
                const aSelectedRows = oModel.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                const { jsPDF } = window.jspdf;

                const loadImageAsBase64 = async (url) => {
                    const response = await fetch(url);
                    const blob = await response.blob();
                    return new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.onerror = reject;
                        reader.readAsDataURL(blob);
                    });
                };

                const svgLogoBase64 = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode.png"));
                const svgLogoBase64_ = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode2.png"));
                const svgLogoBase64_Bando = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/Bando.png"));

                const generateSectionHTML = (data) => {
                    const isEmpty = !data;
                    const lotbatchno = data?.lotbatchno || "";
                    // const batchweight = data?.batchweight || "";
                    const manufacturingdate = data?.manufacturingdate ? new Date(data.manufacturingdate).toLocaleDateString("en-GB") : "";
                    const productionordstartdate = data?.productionordstartdate ? new Date(data.productionordstartdate).toLocaleDateString("en-GB") : "";
                    const confirmedqty = data?.confirmedqty || "";
                    const compoundcode = data?.compoundcode || "";
                    const operator = data?.operator || "";
                    const expirydate = data?.expirydate ? new Date(data.expirydate).toLocaleDateString("en-GB") : "";
                    const inspector = data?.inspector || "";
                    const productionorderqty = data?.productionorderqty || "";
                    const productionorderno = data?.productionorderno || "";

                    return `
        <div class="row">
          <div class="column1">
            <table style="width:106%">
              <tr>
                <td colspan="7" style="text-align:left;">
                  <img src="${svgLogoBase64_Bando}" alt="Bando Logo" width="100" style="vertical-align: middle; margin-right: 10px;">
                  Mixing Process lot Guarantee Card
                </td>
              </tr>
              <tr>
                <td colspan="2">B I P L COMPOUND FORMULA</td>
                <td colspan="2">COMPOUND CODE</td>
                <td colspan="4" class="center-align">${compoundcode}</td>
              </tr>
              <tr>
                <td>Production ord No : ${productionorderno}</td>
                <td>Production Date :<br>${manufacturingdate}</td>
                <td>Lot No.</td>
                <td>${lotbatchno}</td>
                <td>EXPIRY DATE</td>
                <td>${expirydate}</td>
              </tr>
              <tr>
                <td>
                  <table>
                    <tr><td>Batch Wt. - kgs</td></tr>
                    <tr>
                      <td>
                        <table>
                          <tr><td>Spec.</td><td>${productionorderqty}</td></tr>
                          <tr><td>Actual</td><td>${confirmedqty}</td></tr>
                          <tr><td>Difference</td><td>${productionorderqty - confirmedqty}</td></tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
                <td colspan="4">
                  ${!isEmpty ? `<img src="${svgLogoBase64_}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td>Operator</td>
              </tr>
              <tr>
                <td colspan="2">
                  ${!isEmpty ? `<img src="${svgLogoBase64}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td colspan="4">
                  <table style="width:100%">
                    <tr>
                      <th class="center-align">Operator</th>
                      <th class="center-align">Inspector</th>
                    </tr>
                    <tr>
                      <td class="center-align"><br><br>${operator}<br><br></td>
                      <td class="center-align">${inspector}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>
          <div class="column2">
            <table style="width:118%">
              <tr><td class="center-align">Compound Code<br><br><br>${compoundcode}</td></tr>
              <tr><td class="center-align">Lot No<br><br><br>${lotbatchno}</td></tr>
              <tr><td class="center-align">Production Date<br><br><br>${manufacturingdate}</td></tr>
              <tr><td class="center-align">Operator Sign<br><br><br><br><br><br>${operator}</td></tr>
            </table>
          </div>
        </div>
        `;
                };

                // Modified function to handle single or multiple sections
                const generateFullHTML = (sections) => `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        * { box-sizing: border-box; }
        .row { display: flex; margin-left: -5px; margin-right: -5px; margin-bottom: 20px; }
        .column1 { flex: 120%; padding: 6px; }
        .column2 { flex: 110%; padding-left: 30px; padding-top: 5px; padding-right: 5px; }
        table, th, td {
          border: 1px solid black;
          border-collapse: collapse;
          text-align: left;
          padding: 5px;
        }
        .center-align { text-align: center; }
      </style>
    </head>
    <body>
      ${sections.map(section => generateSectionHTML(section)).join('')}
      ${sections.length === 1 ? '<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>' : ''}
    </body>
    </html>`;

                const doc = new jsPDF('l', 'mm', [297, 210]);
                const preparedData = aSelectedRows;
                const promises = [];

                for (let i = 0; i < preparedData.length; i += 2) {
                    const sectionsForThisPage = [];

                    // Add first section
                    sectionsForThisPage.push(preparedData[i]);

                    // Add second section only if it exists
                    if (i + 1 < preparedData.length) {
                        sectionsForThisPage.push(preparedData[i + 1]);
                    }

                    const htmlContent = generateFullHTML(sectionsForThisPage);

                    promises.push(new Promise((resolve, reject) => {
                        const iframe = document.createElement('iframe');
                        iframe.style.position = 'fixed';
                        iframe.style.top = '-100000px';
                        document.body.appendChild(iframe);

                        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        iframeDoc.open();
                        iframeDoc.write(htmlContent);
                        iframeDoc.close();

                        iframe.onload = () => {
                            html2canvas(iframeDoc.body, { scale: 3 }).then(canvas => {
                                const imgData = canvas.toDataURL('image/jpeg', 0.95);
                                doc.addImage(imgData, 'JPEG', 0, 0, 297, 210);
                                if (i + 2 < preparedData.length) {
                                    doc.addPage();
                                }
                                document.body.removeChild(iframe);
                                resolve();
                            }).catch(error => {
                                document.body.removeChild(iframe);
                                reject(error);
                            });
                        };
                    }));
                }

                await Promise.all(promises);

                const blob = doc.output('blob');
                const pdfUrl = URL.createObjectURL(blob);

                if (!this._PDFViewer) {
                    this._PDFViewer = new sap.m.PDFViewer({
                        source: pdfUrl,
                        title: "Mixing Guarantee Card",
                        width: "auto"
                    });
                    jQuery.sap.addUrlWhitelist("blob");
                }

                this._PDFViewer.setSource(pdfUrl);
                this._PDFViewer.open();
            },





            onOpenCamera: function () {
                sap.ndc.BarcodeScanner.scan(
                    (mResult) => {
                        try {
                            const text = mResult.text || "";

                            // Extract values with regex
                            const prodOrderMatch = text.match(/Prod Order No:\s*([^\s]+)/);
                            const startDateMatch = text.match(/Start Date:\s*([\d/]+)/);
                            const plantMatch = text.match(/Plant:\s*(\d+)/);
                            const materialMatch = text.match(/Material:\s*([^\s]+)/);

                            if (prodOrderMatch) {
                                this.byId("idProductionorderno").setValue(prodOrderMatch[1]);
                            }
                            if (startDateMatch) {
                                const parts = startDateMatch[1].split("/");
                                if (parts.length === 3) {
                                    const dateObj = new Date(parts[2], parts[1] - 1, parts[0]); // dd/mm/yyyy → Date

                                    // Set both start and end values to the same date
                                    this.byId("idDateRange").setDateValue(dateObj);
                                    this.byId("idDateRange").setSecondDateValue(dateObj);
                                }
                            }

                            if (plantMatch) {
                                this.byId("idPlant").setValue(plantMatch[1]);
                            }
                            if (materialMatch) {
                                this.byId("idMaterial").setValue(materialMatch[1]);
                            }

                            sap.m.MessageToast.show("Scan successful ✅");
                            this.GoMixingActualfilter();
                        } catch (err) {
                            sap.m.MessageToast.show("Scan parse error: " + err.message);
                        }
                    },
                    (Error) => {
                        sap.m.MessageToast.show("Scan failed: " + Error);
                    }
                );
            },


            onMaterialValueHelp: function (oEvent) {
                this._oMaterialInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);

                // Create fragment if not already created
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                        this
                    );
                    oView.addDependent(this._oMaterialDialog);
                }

                var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
                var that = this;

                // Only fetch materials with ProductGroup = "MIXING"
                oModel.read("/ZC_MATERIALMASTER1", {
                    filters: [
                        new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "MIXING")
                    ],
                    success: function (oData) {
                        // Create the model for the dialog
                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
                        that._oMaterialDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected materials
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                            "idMaterialTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedMaterials.forEach(material => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === material.Product) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedMaterials = [];

                        // Open the dialog after all processing is done
                        that._oMaterialDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Materials");
                    }
                });
            },

            onMaterialSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

                var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },

            onMaterialSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedMaterials = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onMaterialConfirm: function () {
                if (!this._oTempSelectedMaterials) return;

                // Store selected materials
                this._selectedMaterials = this._oTempSelectedMaterials.slice();

                // Clear old tokens first
                this._oMaterialInputField.removeAllTokens();

                // Add tokens for selected materials
                this._selectedMaterials.forEach(material => {
                    var oToken = new sap.m.Token({
                        key: material.Product,
                        text: material.Product,
                        tooltip: material.ProductName // Optional: show description on hover
                    });
                    this._oMaterialInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null;
                }
            },

            onMaterialTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedMaterials = this._selectedMaterials.filter(
                        material => material.Product !== token.getKey()
                    );
                });
            },

            onMaterialChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);

                        // Also add to selected materials array
                        if (!this._selectedMaterials.find(m => m.Product === sValue)) {
                            this._selectedMaterials.push({
                                Product: sValue,
                                ProductName: sValue // You might want to fetch the actual description if available
                            });
                        }
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },

            onMaterialVHClose: function () {
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null; // reset reference
                }
            },



            onProductionOrderValueHelp: function (oEvent) {
                this._oPOInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

                // Create fragment if not already created
                if (!this._oProductionOrderDialog) {
                    this._oProductionOrderDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                        this
                    );
                    oView.addDependent(this._oProductionOrderDialog);
                }

                var oModel = oView.getModel("ZSB_MIXING_PLAN1");
                var that = this;

                oModel.read("/ZC_MIXING_PLAN1", {
                    urlParameters: { "$top": 1000 }, // fetch top 1000 records
                    success: function (oData) {
                        // Filter out production orders where productionorderno is "0"
                        var aFilteredOrders = oData.results.filter(function (item) {
                            return item.productionorderno && item.productionorderno !== "0";
                        });

                        // Create the model for the dialog with the filtered results
                        var oJSON = new sap.ui.model.json.JSONModel({ Orders: aFilteredOrders });
                        that._oProductionOrderDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected orders
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                            "idProductionOrderTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedProductionOrders.forEach(po => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === po.productionorderno) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedOrders = [];

                        // Open the dialog after all processing is done
                        that._oProductionOrderDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Production Orders");
                    }
                });
            },

            onProductionOrderSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

                var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },
            onProductionOrderSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedOrders = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onProductionOrderConfirm: function () {
                if (!this._oTempSelectedOrders) return;

                // Store selected orders
                this._selectedProductionOrders = this._oTempSelectedOrders.slice();

                // Clear old tokens first
                this._oPOInputField.removeAllTokens();

                // Add tokens for selected production orders
                this._selectedProductionOrders.forEach(po => {
                    var oToken = new sap.m.Token({
                        key: po.productionorderno,
                        text: po.productionorderno
                    });
                    this._oPOInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null;
                }
            },

            onProductionOrderTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedProductionOrders = this._selectedProductionOrders.filter(
                        o => o.productionorderno !== token.getKey()
                    );
                });
            },
            onProductionOrderVHClose: function () {
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null; // reset reference
                }
            },

            onProductionOrderChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue // Display the same value as text for now
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },


            onGoodsIssueAndReceipt: async function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                const oGRModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Arrays to track results
                const aGIResults = {
                    success: [],
                    failed: [],
                    skipped: []
                };

                const aGRResults = {
                    success: [],
                    failed: [],
                    skipped: []
                };

                // ============ COMMON VALIDATIONS ============

                // 1. Check for already existing GI
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                if (aWithGI.length > 0) {
                    aWithGI.forEach(row => {
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Goods Issue already exists"
                        });
                    });
                    // Remove already GI rows from GI processing
                    aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));
                }

                // 2. Check release status
                const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
                if (aUnreleased.length > 0) {
                    aUnreleased.forEach(row => {
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Not released"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
                }

                // 3. Check update status
                const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
                if (aNotUpdated.length > 0) {
                    aNotUpdated.forEach(row => {
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Please enter the QTY & update the status"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
                }

                // 4. Check quantity values
                const aMissingQty = aSelectedRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined ||
                        isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });

                if (aMissingQty.length > 0) {
                    aMissingQty.forEach(row => {
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Invalid quantity values"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
                }

                // 5. Check quantity mismatch
                const aQtyMismatch = aSelectedRows.filter(row => {
                    const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
                    const iBalanceQty = parseFloat(row.scrapqty) || 0;
                    const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
                    const iTotalQty = iConfirmedQty + iBalanceQty;
                    const dTolerance = 0.0001;
                    return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
                });

                if (aQtyMismatch.length > 0) {
                    aQtyMismatch.forEach(row => {
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
                }

                // ============ MANUFACTURING DATE VALIDATION ============
                // Check manufacturing date for Goods Receipt
                let aValidationErrors = [];

                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);

                        // Add to skipped results
                        aGIResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Missing manufacturing date (required for Goods Receipt)"
                        });
                        aGRResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Missing manufacturing date"
                        });
                    }
                });

                if (aValidationErrors.length > 0) {
                    // Show error message and return
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // Remove rows with missing manufacturing date from processing
                aSelectedRows = aSelectedRows.filter(row => row.manufacturingdate);

                // ============ EXISTING GOODS RECEIPT VALIDATION ============
                // 6. Check for already existing GR
                const aWithGR = aSelectedRows.filter(row => row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "");
                if (aWithGR.length > 0) {
                    aWithGR.forEach(row => {
                        aGRResults.skipped.push({
                            productionOrder: row.productionorderno,
                            reason: "Goods Receipt already exists"
                        });
                    });
                }

                // Filter out rows with existing GR from processing
                const aRowsForGIAndGR = aSelectedRows.filter(row =>
                    !aWithGR.some(grRow => grRow.productionorderno === row.productionorderno)
                );

                // Check if any rows remain to process
                if (aRowsForGIAndGR.length === 0) {
                    this.showCombinedSummary(aGIResults, aGRResults);
                    return;
                }

                // ============ CONFIRM BEFORE PROCESSING ============
                sap.m.MessageBox.confirm("Do you want to post Goods Issue and Goods Receipt for selected rows?", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction === sap.m.MessageBox.Action.YES) {
                            // Show loading indicator
                            sap.ui.core.BusyIndicator.show(0);

                            // Process each row: First GI, then GR
                            for (let i = 0; i < aRowsForGIAndGR.length; i++) {
                                const oRow = aRowsForGIAndGR[i];
                                const sProdOrder = oRow.productionorderno;
                                let giSuccess = false;
                                let giMaterialDoc = null;

                                try {
                                    // ============ GOODS ISSUE ============
                                    const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                                    const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                    const oData = await new Promise((resolve, reject) => {
                                        oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                            filters: [oFilter1, oFilter2],
                                            success: function (OData) {
                                                resolve(OData);
                                            },
                                            error: function (error) {
                                                reject(error);
                                            }
                                        });
                                    });

                                    if (oData.results.length === 0) {
                                        aGIResults.failed.push({
                                            productionOrder: sProdOrder,
                                            error: `YBP4 data not found for order ${sProdOrder}`
                                        });
                                        aGRResults.skipped.push({
                                            productionOrder: sProdOrder,
                                            reason: "Goods Issue failed"
                                        });
                                        continue; // Skip to next row
                                    }

                                    // Calculate quantities
                                    const calcQty = (qty, total, scrap, ref) => {
                                        const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                                        return Number(result.toFixed(3));
                                    };

                                    const oResultData = oData.results[0];
                                    const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                    const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                    const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                    const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                    const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                    const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

                                    const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

                                    // Post Goods Issue
                                    const postResult = await that.ToConfirmIssueAPIPost(
                                        ManufacturingOrderOperation,
                                        opconfirmedworkquantity1,
                                        opconfirmedworkquantity2,
                                        opconfirmedworkquantity3,
                                        opconfirmedworkquantity4,
                                        opconfirmedworkquantity5,
                                        opconfirmedworkquantity6,
                                        oRow
                                    );

                                    const matDoc = postResult.materialdocument;

                                    if (!matDoc) {
                                        let ErrorMessage = "Some error occurred while posting Goods Issue.";
                                        try {
                                            const errorResponse = JSON.parse(postResult.errorresponse);
                                            ErrorMessage = errorResponse.error.message.value;
                                        } catch (e) { }

                                        aGIResults.failed.push({
                                            productionOrder: sProdOrder,
                                            error: ErrorMessage
                                        });
                                        aGRResults.skipped.push({
                                            productionOrder: sProdOrder,
                                            reason: "Goods Issue failed"
                                        });
                                        continue;
                                    }

                                    // Update row with GI material document
                                    oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                                    oRow.gicnfmaterialdocyear = postResult.matdocyear;
                                    oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                                    oRow.gicnfconfirmationcount = postResult.confirmationcount;

                                    // Update internal table for GI
                                    await that.ToUpdateIntTab(oRow, matDoc, postResult);

                                    aGIResults.success.push({
                                        productionOrder: sProdOrder,
                                        materialDocument: matDoc
                                    });

                                    giSuccess = true;
                                    giMaterialDoc = matDoc;

                                    // ============ GOODS RECEIPT ============
                                    // Note: Manufacturing date validation is already done at the beginning
                                    // Prepare GR payload
                                    const oPayload = {
                                        material: oRow.materialcode,
                                        plant: oRow.plant,
                                        storagelocation: oRow.storagelocation,
                                        goodsmovementtype: "101",
                                        manufacturingorder: oRow.productionorderno,
                                        manufacturedate: oRow.manufacturingdate ?
                                            new Date(oRow.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                        goodsmovementrefdoctype: "F",
                                        quantityinentryunit: String(oRow.confirmedqty),
                                        postingdate: new Date(),
                                        goodsmovementcode: "02"
                                    };

                                    // Post Goods Receipt
                                    const grResult = await new Promise((resolve, reject) => {
                                        oGRModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
                                            success: function (oData) {
                                                if (!oData.materialdocument && oData.errorresponse) {
                                                    let errorMessage = "Unknown error";
                                                    try {
                                                        const errorObj = JSON.parse(oData.errorresponse);
                                                        errorMessage = errorObj.error?.message?.value ||
                                                            errorObj.error?.message ||
                                                            oData.errorresponse;
                                                    } catch (e) {
                                                        errorMessage = oData.errorresponse;
                                                    }
                                                    reject(new Error(errorMessage));
                                                } else if (!oData.materialdocument) {
                                                    reject(new Error("No material document returned"));
                                                } else {
                                                    resolve(oData);
                                                }
                                            },
                                            error: reject
                                        });
                                    });

                                    // Update row with GR data
                                    oRow.grmaterialdocnumber = grResult.materialdocument;
                                    oRow.grmaterialdocyear = grResult.matdocyear;

                                    // Fetch expiration date
                                    const MatDocItemDatas = await that.ToFetchExpiredateGRTab(oRow, grResult.materialdocument, grResult);
                                    oRow.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

                                    // Update internal table for GR
                                    await that.ToUpdateGRTab(oRow, grResult.materialdocument, grResult, MatDocItemDatas[0]);

                                    aGRResults.success.push({
                                        productionOrder: sProdOrder,
                                        materialDocument: grResult.materialdocument,
                                        year: grResult.matdocyear
                                    });

                                } catch (error) {
                                    console.error(`Error processing order ${sProdOrder}:`, error);

                                    if (!giSuccess) {
                                        aGIResults.failed.push({
                                            productionOrder: sProdOrder,
                                            error: error.message || "Unknown error in Goods Issue"
                                        });
                                        aGRResults.skipped.push({
                                            productionOrder: sProdOrder,
                                            reason: "Goods Issue failed"
                                        });
                                    } else {
                                        aGRResults.failed.push({
                                            productionOrder: sProdOrder,
                                            error: error.message || "Unknown error in Goods Receipt"
                                        });
                                    }
                                }
                            }

                            // Refresh table
                            oTabModel.refresh();
                            sap.ui.core.BusyIndicator.hide();

                            // Show combined summary
                            that.showCombinedSummary(aGIResults, aGRResults);
                        }
                    }
                });
            },

            showCombinedSummary: function (aGIResults, aGRResults) {
                const controller = this; // Store reference to this
                let sMessage = "Goods Issue and Receipt Process Summary\n\n";

                // Goods Issue Summary
                sMessage += "📦 GOODS ISSUE:\n";
                sMessage += `✅ Successfully processed: ${aGIResults.success.length}\n`;
                aGIResults.success.forEach(row => {
                    sMessage += `   - ${row.productionOrder}`;
                    if (row.materialDocument) {
                        sMessage += ` (Material Doc: ${row.materialDocument})`;
                    }
                    sMessage += `\n`;
                });

                if (aGIResults.skipped.length > 0) {
                    sMessage += `\n⚠️ Skipped during validation: ${aGIResults.skipped.length}\n`;
                    aGIResults.skipped.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                }

                if (aGIResults.failed.length > 0) {
                    sMessage += `\n❌ Failed: ${aGIResults.failed.length}\n`;
                    aGIResults.failed.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Goods Receipt Summary
                sMessage += "\n\n📥 GOODS RECEIPT:\n";
                sMessage += `✅ Successfully processed: ${aGRResults.success.length}\n`;
                aGRResults.success.forEach(row => {
                    sMessage += `   - ${row.productionOrder}`;
                    if (row.materialDocument) {
                        sMessage += ` (Material Doc: ${row.materialDocument}/${row.year})`;
                    }
                    sMessage += `\n`;
                });

                if (aGRResults.skipped.length > 0) {
                    sMessage += `\n⚠️ Skipped: ${aGRResults.skipped.length}\n`;
                    aGRResults.skipped.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                }

                if (aGRResults.failed.length > 0) {
                    sMessage += `\n❌ Failed: ${aGRResults.failed.length}\n`;
                    aGRResults.failed.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine message type
                const bHasGIorGRFailed = aGIResults.failed.length > 0 || aGRResults.failed.length > 0;
                const bHasGIorGRSuccess = aGIResults.success.length > 0 || aGRResults.success.length > 0;
                const bHasSkipped = aGIResults.skipped.length > 0 || aGRResults.skipped.length > 0;

                setTimeout(() => {
                    if (bHasGIorGRFailed) {
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Combined Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: [...aGIResults.failed, ...aGRResults.failed]
                                    .map(f => `Production Order: ${f.productionOrder}\nError: ${f.error || f.reason}`)
                                    .join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Combined Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasGIorGRSuccess) {
                        // Update FinalStatus with the last successful GR material document
                        if (aGRResults.success.length > 0) {
                            const lastSuccess = aGRResults.success[aGRResults.success.length - 1];
                            // Use controller reference instead of that
                            controller.FinalStatus = new sap.ui.model.json.JSONModel({
                                MSGSTRIP: {
                                    visible: true,
                                    text: `Material Document No - Goods Receipt: ${lastSuccess.materialDocument}`,
                                    type: 'Success'
                                }
                            });
                            controller.getView().setModel(controller.FinalStatus, "FinalStatus");
                        }

                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Combined Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },







        });
    }
);
