// sap.ui.define([
//     "sap/ui/core/mvc/Controller",
//     "sap/ui/model/json/JSONModel",
//     "sap/ui/model/odata/v2/ODataModel",
//     "sap/m/MessageToast",
//     "sap/m/MessageBox",
//     "sap/ui/model/Filter",
//     "sap/ui/model/FilterOperator",
//     "sap/ui/core/IconPool",
//     "sap/ui/core/Component",
//     "sap/ui/core/UIComponent",
//     "sap/m/routing/Router",
//     "sap/ui/export/Spreadsheet",
//     "sap/ui/export/library",
//     "sap/m/PDFViewer",
//     "bando/util/importfile/importexcelfile",
//     "bando/util/pdf-lib/pdf-lib.min",
//     "sap/ui/core/Fragment",

// ], function (
//     Controller,
//     JSONModel,
//     ODataModel,
//     MessageToast,
//     MessageBox,
//     Filter,
//     FilterOperator,
//     IconPool,
//     Component,
//     UIComponent,
//     Router,
//     Spreadsheet,
//     exportLibrary,

//     PDFViewer,
//     importexcelfile,
//     PDFLibjs,
//     Fragment
// ) {
//     "use strict";

//     return Controller.extend("bando.controller.belts_production.Jointing.JointingActualReport.JointingActualReport", {

//                  /* ================= INIT ================= */
//         onInit: function () {
//             this.getView().setModel(new JSONModel({ ItemData: [] }), "TabModel");
//             this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL/"), "ZSB_REQ_ACTUAL");
//             this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_REQ_MOVEMENT_TYPE/"), "ZSB_REQ_MOVEMENT_TYPE");
//             this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_ORDER_TYPE/"), "ZSB_ORDER_TYPE");
//             this.getView().setModel(new ODataModel("/sap/opu/odata/sap/ZSB_JOINT_PLAN/"), "ZSB_JOINT_PLAN");
//         },

//         formatDate: function (vDate) {
//             if (!vDate) return "";
//             var oDate = vDate instanceof Date ? vDate : new Date(vDate);
//             if (isNaN(oDate.getTime())) return "";
//             return sap.ui.core.format.DateFormat
//                 .getDateInstance({ pattern: "dd/MM/yyyy" })
//                 .format(oDate);
//         },

//         /* ================= HELPERS ================= */
//         _normalizeOrder: function (s) {
//             return s ? s.replace(/^0+/, "") : "";
//         },

//         _formatProductionOrder: function (s) {
//             return s ? s.padStart(12, "0") : "";
//         },

//         _fetchAllData: function (oModel, sEntity, aFilters, skip, top, res, ok, err) {
//             oModel.read(sEntity, {
//                 filters: aFilters,
//                 urlParameters: { "$skip": skip, "$top": top },
//                 success: function (d) {
//                     res = res.concat(d.results || []);
//                     if (d.results && d.results.length === top) {
//                         this._fetchAllData(oModel, sEntity, aFilters, skip + top, top, res, ok, err);
//                     } else {
//                         ok(res);
//                     }
//                 }.bind(this),
//                 error: err
//             });
//         },

//                 GoStockReqTableOpen: function () {
//             var view = this.getView();
//             var tabModel = view.getModel("TabModel");                              
//             var tabModel = view.getModel("TabModel");
//             var oModel = view.getModel("ZSB_REQ_ACTUAL");
//             var oMixPlanModel = view.getModel("ZSB_JOINT_PLAN");
//             var oStatusModel = view.getModel("ZSB_PRODUCT_ORD1"); // Status check model

//             var oDate = view.byId("MIXJNT").getDateValue();
//             if (!oDate) {
//                 MessageToast.show("Please select a date");
//                 return;
//             }

//             var aTokens = view.byId("idmaterialdocumentJNT")?.getTokens() || [];
//             var sMaterialInput = view.byId("idMaterial_JNT")?.getValue()?.trim();
//             var sMachineInput = view.byId("idMachineNum_JNT")?.getValue()?.trim().toUpperCase();

//             var sDate = oDate.getFullYear() + "-" +
//                 String(oDate.getMonth() + 1).padStart(2, "0") + "-" +
//                 String(oDate.getDate()).padStart(2, "0");

//             view.setBusy(true);

//             // STEP 1: Fetch Mix Plan using Date
//             this._fetchAllData(oMixPlanModel, "/ZC_JOINT_PLAN", [new Filter("productionordstartdate", "EQ", sDate)], 0, 1000, [], function (allMixData) {
                
//                 // STEP 2: Filter out RELEASED orders locally first
//                 var unreleasedOrders = (allMixData || []).filter(o => !o.releasestatus || o.releasestatus.trim() === "");

//                 if (unreleasedOrders.length === 0) {
//                     view.setBusy(false);
//                     tabModel.setProperty("/ItemData", []);
//                     MessageToast.show("No unreleased orders found for this date.");
//                     return;
//                 }

//                 // STEP 2.5: Check for TECO (I0045) Status in ZSB_PRODUCT_ORD1
//                 var aOrderCheckFilters = unreleasedOrders.map(o => {
//                     return new Filter("ManufacturingOrder", "EQ", this._formatProductionOrder(o.productionorderno));
//                 });

//                 var oTecoQueryFilter = new Filter({
//                     filters: [
//                         new Filter({ filters: aOrderCheckFilters, and: false }), // Match any of our POs
//                         new Filter("StatusCode", "EQ", "I0045"),                 // AND status is TECO
//                         new Filter("StatusIsActive", "EQ", true)                 // AND it is active
//                     ],
//                     and: true
//                 });

//                 this._fetchAllData(oStatusModel, "/ZC_ORDER_CREATION1", [oTecoQueryFilter], 0, 1000, [], function (tecoResults) {
                    
//                     // Create a lookup Set of order numbers that are TECO'd
//                     var setTecoOrders = new Set(tecoResults.map(t => this._normalizeOrder(t.ManufacturingOrder)));

//                     // Keep only orders that are NOT in the TECO set
//                     var finalCandidateOrders = unreleasedOrders.filter(o => !setTecoOrders.has(this._normalizeOrder(o.productionorderno)));

//                     if (finalCandidateOrders.length === 0) {
//                         view.setBusy(false);
//                         tabModel.setProperty("/ItemData", []);
//                         MessageToast.show("Remaining orders are already Technically Completed (TECO).");
//                         return;
//                     }

//                     // Prepare maps for the join
//                     var aJoinFilters = [], machineMap = {}, orderDateMap = {}; 
//                     finalCandidateOrders.forEach(o => {
//                         var sPaddedPO = this._formatProductionOrder(o.productionorderno);
//                         machineMap[sPaddedPO] = o.machinenumber || "";
//                         orderDateMap[sPaddedPO] = o.productionordstartdate; 
//                         aJoinFilters.push(new Filter({
//                             filters: [
//                                 new Filter("productionorder", "EQ", sPaddedPO),
//                                 new Filter("BillOfOperationsMaterial", "EQ", o.materialcode)
//                             ],
//                             and: true
//                         }));
//                     });

//                     // STEP 3: Fetch Stock
//                     this._fetchAllData(oModel, "/ZC_REQ_ACT_srorage_loc", [], 0, 5000, [], function (stockResults) {
//                         var systemStockMap = {};
//                         stockResults.forEach(s => {
//                             var sKey = this._normalizeOrder(s.Product) + "|" + (s.Batch || "") + "|" + s.StorageLocation;
//                             systemStockMap[sKey] = +s.MatlWrhsStkQtyInMatlBaseUnit || 0;
//                         });

//                         // STEP 4: Fetch Requirements for final filtered orders
//                         this._fetchAllData(oModel, "/ZCE_REQ_ACTUAL", [new Filter({ filters: aJoinFilters, and: false })], 0, 5000, [], function (aResults) {
//                             var finalData = [], curKey = "", totals = {};
//                             var materialInitialStock = {}, materialRunningBalance = {}; 
//                             var groupProcessedBatches = {}, processedReqItems = {};

//                             // PASS 1: Totals & Balance Initialization
//                             aResults.forEach(function (o) {
//                                 var sNormPO = this._normalizeOrder(o.productionorder);
//                                 var sMatNorm = this._normalizeOrder(o.Material);
//                                 var groupKey = sNormPO + "_" + sMatNorm;
//                                 var sBatch = o.Batch || "";

//                                 if (!totals[groupKey]) {
//                                     totals[groupKey] = { req: 0, avb: 0, avbAlt: 0 };
//                                     groupProcessedBatches[groupKey] = new Set();
//                                 }

//                                 var reqKey = sNormPO + "|" + sMatNorm + "|" + (o.RESERVATION || "") + "|" + (o.RESERVATIONITEM || "");
//                                 if (!processedReqItems[reqKey]) {
//                                     totals[groupKey].req += (+o.RequiredQuantity || 0);
//                                     processedReqItems[reqKey] = true;
//                                 }

//                                 var k1 = sMatNorm + "|" + sBatch + "|" + (o.storagelocation || "");
//                                 var k2 = sMatNorm + "|" + sBatch + "|" + (o.ProductionInvtryManagedLoc || "");
//                                 if (!groupProcessedBatches[groupKey].has(sBatch)) {
//                                     totals[groupKey].avb += (systemStockMap[k1] || 0);
//                                     totals[groupKey].avbAlt += (systemStockMap[k2] || 0);
//                                     groupProcessedBatches[groupKey].add(sBatch);
//                                 }

//                                 if (materialInitialStock[sMatNorm] === undefined) {
//                                     var totalStock = 0, stockSeen = new Set();
//                                     aResults.forEach(r => {
//                                         if (this._normalizeOrder(r.Material) === sMatNorm) {
//                                             var sk = sMatNorm + "|" + (r.Batch || "") + "|" + (r.storagelocation || "");
//                                             if (!stockSeen.has(sk)) { totalStock += (systemStockMap[sk] || 0); stockSeen.add(sk); }
//                                         }
//                                     });
//                                     materialInitialStock[sMatNorm] = totalStock;
//                                     materialRunningBalance[sMatNorm] = totalStock;
//                                 }
//                             }.bind(this));

//                             // PASS 2: Assemble Rows
//                             var usedBatchesInPO = new Set();
//                             aResults.forEach(function (o) {
//                                 var sPaddedPO = o.productionorder;
//                                 var sNormPO = this._normalizeOrder(sPaddedPO);
//                                 var sMatNorm = this._normalizeOrder(o.Material);
//                                 var groupKey = sNormPO + "_" + sMatNorm;
//                                 var sBatch = o.Batch || "";
//                                 var isFirstInGrp = (groupKey !== curKey);

//                                 if (isFirstInGrp) usedBatchesInPO.clear();
//                                 if (usedBatchesInPO.has(sBatch)) return;

//                                 var sloc1 = o.storagelocation || "";
//                                 var sloc2 = o.ProductionInvtryManagedLoc || "";
//                                 var dq1 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1].toFixed(4) : "";
//                                 var dq2 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2].toFixed(4) : "";

//                                 if (!dq1 && !dq2) return;

//                                 if (isFirstInGrp) materialRunningBalance[sMatNorm] -= totals[groupKey].req;
//                                 if (curKey && isFirstInGrp) finalData.push(this._createSummaryRow(curKey, totals, finalData));

//                                 curKey = groupKey;
//                                 usedBatchesInPO.add(sBatch);

//                                 finalData.push({
//                                     ...o,
//                                     productionordstartdate: orderDateMap[sPaddedPO] || "", 
//                                     productionorderDisp: sNormPO,
//                                     machinenumber: machineMap[sPaddedPO] || "",
//                                     RequiredQuantity: isFirstInGrp ? totals[groupKey].req.toFixed(4) : "",
//                                     col2: dq1,
//                                     BatchForCol2: dq1 ? sBatch : "",
//                                     storagelocation: dq1 ? sloc1 : "",
//                                     MatlWrhsStkQtyInMatlBase1: dq2,
//                                     BatchForMatlWrhs: dq2 ? sBatch : "",
//                                     ProductionInvtryManagedLoc: dq2 ? sloc2 : "",
//                                     BalanceQuantity: isFirstInGrp ? materialRunningBalance[sMatNorm].toFixed(4) : "",
//                                     isSumRow: false
//                                 });
//                             }.bind(this));

//                             if (curKey) finalData.push(this._createSummaryRow(curKey, totals, finalData));

//                             // STEP 5: FINAL UI FILTER
//                             var filteredResults = finalData.filter(function (row, idx, arr) {
//                                 if (!sMachineInput && !sMaterialInput && aTokens.length === 0) return true;
//                                 var match = (r) => {
//                                     var mMachine = !sMachineInput || (r.machinenumber || "").toUpperCase() === sMachineInput;
//                                     var mMaterial = !sMaterialInput || this._normalizeOrder(r.Material) === this._normalizeOrder(sMaterialInput);
//                                     var mPO = aTokens.length === 0 || aTokens.some(t => this._normalizeOrder(t.getKey() || t.getText()) === this._normalizeOrder(r.productionorder));
//                                     return mMachine && mMaterial && mPO;
//                                 };
//                                 if (!row.isSumRow) return match(row);
//                                 var groupMatched = false;
//                                 for (var i = idx - 1; i >= 0; i--) {
//                                     if (arr[i].isSumRow) break;
//                                     if (match(arr[i])) { groupMatched = true; break; }
//                                 }
//                                 return groupMatched;
//                             }.bind(this));

//                             tabModel.setProperty("/ItemData", filteredResults);
//                             view.setBusy(false);

//                         }.bind(this), () => view.setBusy(false));
//                     }.bind(this), () => view.setBusy(false));

//                 }.bind(this), () => view.setBusy(false)); // Error in TECO check
//             }.bind(this), () => view.setBusy(false)); // Error in Mixing Plan
//         },

//         _createSummaryRow: function (key, totals, finalData) {
//             var lastBal = "";
//             for (var i = finalData.length - 1; i >= 0; i--) {
//                 if (finalData[i].BalanceQuantity) { lastBal = finalData[i].BalanceQuantity; break; }
//             }
//             return {
//                 Material: "Total",
//                 RequiredQuantity: totals[key].req.toFixed(4),
//                 col2: totals[key].avb > 0 ? totals[key].avb.toFixed(4) : "",
//                 MatlWrhsStkQtyInMatlBase1: totals[key].avbAlt > 0 ? totals[key].avbAlt.toFixed(4) : "",
//                 BatchForCol2: "",
//                 storagelocation: "",
//                 BatchForMatlWrhs: "",
//                 ProductionInvtryManagedLoc: "",
//                 BalanceQuantity: lastBal,
//                 isSumRow: true
//             };
//         },


//         onDownload_reqMat_JNT: function () {
//             var oTable = this.byId("_idREQ_VS_ACTjnt");
//             var oBinding = oTable.getBinding("rows");

//             var sDate = this._sMixDate || this.getView().byId("MIXJNT").getValue() || "";
//             if (!sDate) {
//                 sap.m.MessageToast.show("Please fetch data before downloading.");
//                 return;
//             }

//             var aDateParts = sDate.split("-");
//             var sDate_ = aDateParts.length === 3
//                 ? aDateParts[2].padStart(2, "0") + "-" +
//                 aDateParts[1].padStart(2, "0") + "-" +
//                 aDateParts[0]
//                 : sDate;

//             if (!oBinding) {
//                 sap.m.MessageToast.show("No data available");
//                 return;
//             }

//             var aContexts = oBinding.getContexts(0, oBinding.getLength());
//             if (!aContexts.length) {
//                 sap.m.MessageToast.show("No data after filtering");
//                 return;
//             }

//             var oMaterialMap = {};
//             var sCurrentMaterial = null;

//             aContexts.forEach(function (oCtx) {
//                 var o = oCtx.getObject();
//                 if (!o) return;

//                 if (o.Material !== "Total") {

//                     sCurrentMaterial = o.Material;

//                     if (!oMaterialMap[sCurrentMaterial]) {
//                         oMaterialMap[sCurrentMaterial] = {
//                             Material: sCurrentMaterial,
//                             ProductDescription: "",
//                             RequiredStorageLocation: "",
//                             AvailableStorageLocation: "",
//                             TotalRequiredQuantity: 0,
//                             TotalAvailableReqLoc: 0,
//                             TotalAvailable12RM: 0
//                         };
//                     }

//                     // Capture Product Description
//                     if (o.productdescription && !oMaterialMap[sCurrentMaterial].ProductDescription) {
//                         oMaterialMap[sCurrentMaterial].ProductDescription = o.productdescription;
//                     }

//                     // Capture Required Storage Location
//                     if (o.storagelocation && !oMaterialMap[sCurrentMaterial].RequiredStorageLocation) {
//                         oMaterialMap[sCurrentMaterial].RequiredStorageLocation = o.storagelocation;
//                     }

//                     // Capture Available Storage Location
//                     if (o.ProductionInvtryManagedLoc && !oMaterialMap[sCurrentMaterial].AvailableStorageLocation) {
//                         oMaterialMap[sCurrentMaterial].AvailableStorageLocation = o.ProductionInvtryManagedLoc;
//                     }

//                     oMaterialMap[sCurrentMaterial].TotalRequiredQuantity += parseFloat(o.RequiredQuantity) || 0;

//                 } else if (o.Material === "Total" && sCurrentMaterial) {

//                     oMaterialMap[sCurrentMaterial].TotalAvailableReqLoc = parseFloat(o.col2) || 0;
//                     oMaterialMap[sCurrentMaterial].TotalAvailable12RM = parseFloat(o.MatlWrhsStkQtyInMatlBase1) || 0;

//                 }
//             });

//             // ===== Prepare Export Data =====
//             var aExportData = Object.values(oMaterialMap).map(function (o) {
//                 return {
//                     Material: o.Material,
//                     ProductDescription: o.ProductDescription,
//                     TotalRequiredQuantity: o.TotalRequiredQuantity.toFixed(4),
//                     RequiredStorageLocation: o.RequiredStorageLocation,
//                     TotalAvailableReqLoc: o.TotalAvailableReqLoc.toFixed(4),
//                     TotalAvailable12RM: o.TotalAvailable12RM.toFixed(4),
//                     AvailableStorageLocation: o.AvailableStorageLocation,
//                     TotalBalance: (o.TotalAvailableReqLoc - o.TotalRequiredQuantity).toFixed(4)
//                 };
//             });

//             // ===== Grand Total =====
//             var fGrandReq = 0,
//                 fGrandReqLoc = 0,
//                 fGrand12RM = 0,
//                 fGrandBal = 0;

//             aExportData.forEach(function (o) {
//                 fGrandReq += parseFloat(o.TotalRequiredQuantity);
//                 fGrandReqLoc += parseFloat(o.TotalAvailableReqLoc);
//                 fGrand12RM += parseFloat(o.TotalAvailable12RM);
//                 fGrandBal += parseFloat(o.TotalBalance);
//             });

//             aExportData.push({
//                 Material: "Grand Total",
//                 ProductDescription: "",
//                 TotalRequiredQuantity: fGrandReq.toFixed(4),
//                 RequiredStorageLocation: "",
//                 TotalAvailableReqLoc: fGrandReqLoc.toFixed(4),
//                 TotalAvailable12RM: fGrand12RM.toFixed(4),
//                 AvailableStorageLocation: "",
//                 TotalBalance: fGrandBal.toFixed(4)
//             });

//             // ===== Excel Columns =====
//             var EdmType = sap.ui.export.EdmType;

//             var aColumns = [
//                 { label: "Material", property: "Material", type: EdmType.String },
//                 { label: "Product Description", property: "ProductDescription", type: EdmType.String },
//                 { label: "Req Qty", property: "TotalRequiredQuantity", type: EdmType.Number, scale: 4 },
//                 { label: "Required Storage Loc", property: "RequiredStorageLocation", type: EdmType.String },
//                 { label: "Avl QTY (Req Loc)", property: "TotalAvailableReqLoc", type: EdmType.Number, scale: 4 },
//                 { label: "Avl QTY (Avl Loc)", property: "TotalAvailable12RM", type: EdmType.Number, scale: 4 },
//                 { label: "Available Storage Loc", property: "AvailableStorageLocation", type: EdmType.String },
//                 { label: "Balance", property: "TotalBalance", type: EdmType.Number, scale: 4 }
//             ];

//             // ===== Export Settings =====
//             var oSettings = {
//                 workbook: {
//                     columns: aColumns
//                 },
//                 dataSource: aExportData,
//                 fileName: "Jointing_Req_Material_QTY_" + sDate_ + ".xlsx"
//             };

//             var oSheet = new sap.ui.export.Spreadsheet(oSettings);

//             oSheet.build().finally(function () {
//                 oSheet.destroy();
//             });
//         },

//         //                 onDownload_reqMat: function () {
//         //     var oTable = this.byId("_idREQ_VS_ACTjnt");                         
//         //     var oBinding = oTable.getBinding("rows");

//         //     var sDate = this._sMixDate || this.getView().byId("MIXJNT").getValue() || "";
//         //     if (!sDate) {
//         //         sap.m.MessageToast.show("Please fetch data before downloading.");
//         //         return;
//         //     }

//         //     var aDateParts = sDate.split("-");
//         //     var sDate_ = aDateParts.length === 3
//         //         ? aDateParts[2].padStart(2, "0") + "-" +
//         //           aDateParts[1].padStart(2, "0") + "-" +
//         //           aDateParts[0]
//         //         : sDate;

//         //     if (!oBinding) {
//         //         sap.m.MessageToast.show("No data available");
//         //         return;
//         //     }

//         //     var aContexts = oBinding.getContexts(0, oBinding.getLength());
//         //     if (!aContexts.length) {
//         //         sap.m.MessageToast.show("No data after filtering");
//         //         return;
//         //     }

//         //     var oMaterialMap = {};
//         //     var sCurrentMaterial = null;

//         //     aContexts.forEach(function (oCtx) {
//         //         var o = oCtx.getObject();
//         //         if (!o) return;

//         //         // If it's NOT a total row
//         //         if (o.Material !== "Total") {
//         //             sCurrentMaterial = o.Material;

//         //             if (!oMaterialMap[sCurrentMaterial]) {
//         //                 oMaterialMap[sCurrentMaterial] = {
//         //                     Material: sCurrentMaterial,
//         //                     RequiredStorageLocation: "",
//         //                     AvailableStorageLocation: "",
//         //                     TotalRequiredQuantity: 0,
//         //                     TotalAvailableReqLoc: 0,
//         //                     TotalAvailable12RM: 0
//         //                 };
//         //             }

//         //             // Capture Location ONLY if the current row has one (prevents overwriting with blanks)
//         //             if (o.storagelocation && !oMaterialMap[sCurrentMaterial].RequiredStorageLocation) {
//         //                 oMaterialMap[sCurrentMaterial].RequiredStorageLocation = o.storagelocation;
//         //             }
//         //             if (o.ProductionInvtryManagedLoc && !oMaterialMap[sCurrentMaterial].AvailableStorageLocation) {
//         //                 oMaterialMap[sCurrentMaterial].AvailableStorageLocation = o.ProductionInvtryManagedLoc;
//         //             }

//         //             oMaterialMap[sCurrentMaterial].TotalRequiredQuantity += parseFloat(o.RequiredQuantity) || 0;
//         //         } 
//         //         // If it IS a total row -> capture calculated totals from the UI
//         //         else if (o.Material === "Total" && sCurrentMaterial) {
//         //             oMaterialMap[sCurrentMaterial].TotalAvailableReqLoc = parseFloat(o.col2) || 0;
//         //             oMaterialMap[sCurrentMaterial].TotalAvailable12RM = parseFloat(o.MatlWrhsStkQtyInMatlBase1) || 0;
//         //         }
//         //     });

//         //     // ===== Prepare Export Data =====
//         //     var aExportData = Object.values(oMaterialMap).map(function (o) {
//         //         return {
//         //             Material: o.Material,
//         //             TotalRequiredQuantity: o.TotalRequiredQuantity.toFixed(4),
//         //             RequiredStorageLocation: o.RequiredStorageLocation, // Now guaranteed to be filled
//         //             TotalAvailableReqLoc: o.TotalAvailableReqLoc.toFixed(4),
//         //             TotalAvailable12RM: o.TotalAvailable12RM.toFixed(4),
//         //             AvailableStorageLocation: o.AvailableStorageLocation, // Now guaranteed to be filled
//         //             TotalBalance: (o.TotalAvailableReqLoc - o.TotalRequiredQuantity).toFixed(4)
//         //         };
//         //     });

//         //     // ===== Grand Total =====
//         //     var fGrandReq = 0, fGrandReqLoc = 0, fGrand12RM = 0, fGrandBal = 0;

//         //     aExportData.forEach(function (o) {
//         //         fGrandReq += parseFloat(o.TotalRequiredQuantity);
//         //         fGrandReqLoc += parseFloat(o.TotalAvailableReqLoc);
//         //         fGrand12RM += parseFloat(o.TotalAvailable12RM);
//         //         fGrandBal += parseFloat(o.TotalBalance);
//         //     });

//         //     aExportData.push({
//         //         Material: "Grand Total",
//         //         TotalRequiredQuantity: fGrandReq.toFixed(4),
//         //         RequiredStorageLocation: "",
//         //         TotalAvailableReqLoc: fGrandReqLoc.toFixed(4),
//         //         TotalAvailable12RM: fGrand12RM.toFixed(4),
//         //         AvailableStorageLocation: "",
//         //         TotalBalance: fGrandBal.toFixed(4)
//         //     });

//         //     var EdmType = sap.ui.export.EdmType;
//         //     var aColumns = [
//         //         { label: "Material", property: "Material", type: EdmType.String },
//         //         { label: "Req Qty", property: "TotalRequiredQuantity", type: EdmType.Number, scale: 4 },
//         //         { label: "Required Storage Loc", property: "RequiredStorageLocation", type: EdmType.String },
//         //         { label: "Avl QTY (Req Loc)", property: "TotalAvailableReqLoc", type: EdmType.Number, scale: 4 },
//         //         { label: "Avl QTY (Avl Loc)", property: "TotalAvailable12RM", type: EdmType.Number, scale: 4 },
//         //         { label: "Available Storage Loc", property: "AvailableStorageLocation", type: EdmType.String },
//         //         { label: "Balance", property: "TotalBalance", type: EdmType.Number, scale: 4 }
//         //     ];

//         //     var oSettings = {
//         //         workbook: { columns: aColumns },
//         //         dataSource: aExportData,
//         //         fileName: "Jointing_Req_Material_QTY_" + sDate_ + ".xlsx"
//         //     };

//         //     var oSheet = new sap.ui.export.Spreadsheet(oSettings);
//         //     oSheet.build().finally(function () {
//         //         oSheet.destroy();
//         //     });
//         // },


//         // onDownload_reqMat_JNT: function () {

//         //     var oTable = this.byId("_idREQ_VS_ACTjnt");
//         //     var oBinding = oTable.getBinding("rows");
//         //     var sDate = this._sMixDate;

//         //     var aDateParts = sDate.split("-");
//         //     var sDate_ = aDateParts[2].padStart(2, "0") + "-" +
//         //         aDateParts[1].padStart(2, "0") + "-" +
//         //         aDateParts[0];

//         //     if (!oBinding) {
//         //         MessageToast.show("No data available");
//         //         return;
//         //     }

//         //     var aContexts = oBinding.getContexts(0, oBinding.getLength());
//         //     if (!aContexts.length) {
//         //         MessageToast.show("No data after filtering");
//         //         return;
//         //     }

//         //     var aData = aContexts.map(function (oCtx) {
//         //         return oCtx.getObject();
//         //     });

//         //     // Remove Total rows from base dataset
//         //     aData = aData.filter(o => o.Material !== "Total");

//         //     // ================================
//         //     // ✅ NEW LOGIC FOR TWO COLUMNS ONLY
//         //     // ================================

//         //     var oGrouped = {};
//         //     var oFirstPOTaken = {};

//         //     // 1️⃣ Sum Required Quantity per Material (UNCHANGED)
//         //     aData.forEach(function (o) {

//         //         var sMat = o.Material;
//         //         var fReq = parseFloat(o.RequiredQuantity) || 0;

//         //         if (!oGrouped[sMat]) {
//         //             oGrouped[sMat] = {
//         //                 Material: sMat,
//         //                 RequiredStorageLocation: o.storagelocation || "",
//         //                 AvailableStorageLocation: o.ProductionInvtryManagedLoc || "",
//         //                 TotalRequiredQuantity: 0,
//         //                 FirstPOAvailableReqLoc: 0,
//         //                 FirstPOAvailable12RM: 0
//         //             };
//         //         }

//         //         oGrouped[sMat].TotalRequiredQuantity += fReq;
//         //     });

//         //     // 2️⃣ Take FIRST PRODUCTION ORDER TOTAL ROW values per material
//         //     for (var i = 0; i < aContexts.length; i++) {

//         //         var row = aContexts[i].getObject();

//         //         if (!row) continue;

//         //         // Identify TOTAL row
//         //         if (row.Material === "Total") {

//         //             var prevRow = aContexts[i - 1]?.getObject();
//         //             if (!prevRow || !prevRow.Material || prevRow.Material === "Total") {
//         //                 continue;
//         //             }

//         //             var sMat = prevRow.Material;

//         //             if (!oFirstPOTaken[sMat]) {

//         //                 oGrouped[sMat].FirstPOAvailableReqLoc =
//         //                     parseFloat(row.col2) || 0;

//         //                 oGrouped[sMat].FirstPOAvailable12RM =
//         //                     parseFloat(row.MatlWrhsStkQtyInMatlBase1) || 0;

//         //                 oFirstPOTaken[sMat] = true;
//         //             }
//         //         }
//         //     }

//         //     // 3️⃣ Prepare Export Data
//         //     var aExportData = Object.values(oGrouped).map(function (o) {

//         //         var totalRequired = o.TotalRequiredQuantity;
//         //         var firstPOReqLoc = o.FirstPOAvailableReqLoc;
//         //         var firstPOAlt = o.FirstPOAvailable12RM;

//         //         return {
//         //             Material: o.Material,
//         //             TotalRequiredQuantity: totalRequired.toFixed(4),
//         //             RequiredStorageLocation: o.RequiredStorageLocation,
//         //             TotalAvailableReqLoc: firstPOReqLoc.toFixed(4),   // ✅ FIRST PO TOTAL
//         //             TotalAvailable12RM: firstPOAlt.toFixed(4),        // ✅ FIRST PO TOTAL
//         //             AvailableStorageLocation: o.AvailableStorageLocation,
//         //             TotalBalance: (firstPOReqLoc - totalRequired).toFixed(4)
//         //         };
//         //     });

//         //     // ================================
//         //     // Grand Total (UNCHANGED)
//         //     // ================================

//         //     var fGrandReq = 0, fGrandCol2 = 0, fGrandAlt = 0, fGrandBal = 0;

//         //     aExportData.forEach(function (o) {
//         //         fGrandReq += parseFloat(o.TotalRequiredQuantity);
//         //         fGrandCol2 += parseFloat(o.TotalAvailableReqLoc);
//         //         fGrandAlt += parseFloat(o.TotalAvailable12RM);
//         //         fGrandBal += parseFloat(o.TotalBalance);
//         //     });

//         //     aExportData.push({
//         //         Material: "Total",
//         //         TotalRequiredQuantity: fGrandReq.toFixed(4),
//         //         RequiredStorageLocation: "",
//         //         TotalAvailableReqLoc: fGrandCol2.toFixed(4),
//         //         TotalAvailable12RM: fGrandAlt.toFixed(4),
//         //         AvailableStorageLocation: "",
//         //         TotalBalance: fGrandBal.toFixed(4)
//         //     });

//         //     // ================================
//         //     // Export to Excel (UNCHANGED)
//         //     // ================================

//         //     var EdmType = exportLibrary.EdmType;

//         //     var aColumns = [
//         //         { label: "Material", property: "Material", type: EdmType.String },
//         //         { label: "Req Qty", property: "TotalRequiredQuantity", type: EdmType.Decimal, scale: 4 },
//         //         { label: "Required Storage Loc", property: "RequiredStorageLocation", type: EdmType.String },
//         //         { label: "Avl QTY in Req Stroage Location", property: "TotalAvailableReqLoc", type: EdmType.Decimal, scale: 4 },
//         //         { label: "Avl QTY in Avl Storage Location", property: "TotalAvailable12RM", type: EdmType.Decimal, scale: 4 },
//         //         { label: "Available Storage Loc", property: "AvailableStorageLocation", type: EdmType.String },
//         //         { label: "Balance", property: "TotalBalance", type: EdmType.Decimal, scale: 4 }
//         //     ];

//         //     var oSettings = {
//         //         workbook: { columns: aColumns },
//         //         dataSource: aExportData,
//         //         fileName: "Jointing_Req_Material_QTY_" + sDate_ + ".xlsx"
//         //     };

//         //     var oSheet = new Spreadsheet(oSettings);

//         //     oSheet.build().finally(function () {
//         //         oSheet.destroy();
//         //     });
//         // },


//         onDownload: function () {
//             var aData = this.getView().getModel("TabModel").getProperty("/ItemData") || [];
//             if (!aData.length) {
//                 MessageToast.show("No data to export");
//                 return;
//             }

//             // Prepare export data
//             var aExportData = aData.map(o => {
//                 return Object.assign({}, o, {
//                     ProductionOrder: this._removeLeadingZeros(o.productionorder), // remove leading zeros
//                     BalanceQuantity: parseFloat(o.BalanceQuantity || 0).toFixed(4),
//                     BatchForCol2: o.BatchForCol2 || "",
//                     BatchForMatlWrhs: o.BatchForMatlWrhs || ""
//                 });
//             });

//             var aCols = this.createColumns();

//             var oSettings = {
//                 workbook: { columns: aCols },
//                 dataSource: aExportData,
//                 fileName: "JointingReport.xlsx"
//             };

//             var oSheet = new Spreadsheet(oSettings);
//             oSheet.build().finally(function () { oSheet.destroy(); });
//         },

//         createColumns: function () {
//             var EdmType = exportLibrary.EdmType;
//             return [
//                 { label: "Date", property: "MatlCompRequirementDate", type: EdmType.Date },
//                 { label: "Production Order", property: "ProductionOrder", type: EdmType.String }, // updated property
//                 { label: "Material", property: "Material", type: EdmType.String },
//                 { label: "Product Description", property: "productdescription", type: EdmType.String },
//                 { label: "Bill Of Operation Material", property: "BillOfOperationsMaterial", type: EdmType.String },
//                 { label: "Production Order Operation", property: "PRODUCTIONORDEROPERATION", type: EdmType.String },
//                 { label: "Reservation Item", property: "RESERVATIONITEM", type: EdmType.String },
//                 { label: "Plant", property: "Plant", type: EdmType.String },
//                 { label: "Required Quantity", property: "RequiredQuantity", type: EdmType.Decimal, scale: 4 },
//                 { label: "Base Unit", property: "BaseUnit", type: EdmType.String },
//                 { label: "Required Storage Location", property: "storagelocation", type: EdmType.String },
//                 { label: "Batch (Req Loc)", property: "BatchForCol2", type: EdmType.String },       // ✅ included
//                 { label: "Available Qty Required Storage Location", property: "col2", type: EdmType.Decimal, scale: 4 },
//                 { label: "Available Qty Available Storage Location", property: "MatlWrhsStkQtyInMatlBase1", type: EdmType.Decimal, scale: 4 },
//                 { label: "Batch (Avl Loc)", property: "BatchForMatlWrhs", type: EdmType.String },  // ✅ included
//                 { label: "Available Storage Location", property: "ProductionInvtryManagedLoc", type: EdmType.String },
//                 { label: "Material Base Unit", property: "BaseUnit", type: EdmType.String },
//                 { label: "Balance Quantity", property: "BalanceQuantity", type: EdmType.Decimal, scale: 4 },
//                 // { label: "Production Order Type", property: "ProductionOrderType", type: EdmType.String }
//             ];
//         },

//         /**
//          * Helper function to remove leading zeros from Production Order
//          */
//         _removeLeadingZeros: function (sOrder) {
//             if (!sOrder) return "";
//             return sOrder.replace(/^0+/, ""); // removes all leading zeros
//         },


//         onValueHelpRequest: function (oEvent) {

//             this._oMultiInput = oEvent.getSource();

//             // var Date = this.getView().byId("Dates_").getValue();

//             var Date = "";

//             // console.log(Date)
//             if (Date || Date.length == 0) {
//                 sap.ui.core.BusyIndicator.show();

//                 //   var oFilters1 = new sap.ui.model.Filter("Createdat", sap.ui.model.FilterOperator.EQ, Date);
//                 // Retrieve the model from the view
//                 var oModel = this.getView().getModel("ZSB_JOINT_PLAN");

//                 // Check if the model is valid
//                 if (!oModel) {
//                     console.error("OData model is not properly initialized.");
//                     sap.ui.core.BusyIndicator.hide();
//                     return;
//                 }

//                 //   var oFilters = [oFilters1];
//                 var that = this;
//                 var aAllItems = []; // Array to hold all retrieved items

//                 // Function to fetch data recursively
//                 function fetchData(skipCount) {
//                     // var that = this;
//                     // var oModel = that.getView().getModel();
//                     // that.getView().setModel(oModel);
//                     oModel.read("/ZC_JOINT_PLAN", {
//                         //   filters: oFilters,
//                         urlParameters: {
//                             $top: 5000,  // Request a chunk of 5000 records
//                             $skip: skipCount  // Start from the skipCount position
//                         },
//                         success: function (oData) {
//                             var aItems = oData.results;
//                             aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

//                             // Check if there are more records to fetch
//                             if (oData.results.length >= 5000) {
//                                 // If there are more records, fetch next chunk
//                                 fetchData(skipCount + 5000);
//                             } else {
//                                 // If no more records, all data is fetched
//                                 finishFetching();
//                             }
//                         },
//                         error: function (oError) {
//                             console.error("Error reading data: ", oError);
//                             sap.ui.core.BusyIndicator.hide();
//                         }
//                     });
//                 }

//                 function finishFetching() {


//                     // Once all data is fetched, proceed to display it
//                     that.oJSONModel = new sap.ui.model.json.JSONModel({
//                         Datas: aAllItems
//                     });
//                     that.getView().setModel(that.oJSONModel, "oJSONModel");
//                     console.log("that.oJSONModel:", that.oJSONModel)

//                     // Load the value help dialog fragment
//                     that._oBasicSearchField = new sap.m.SearchField();
//                     that.loadFragment({
//                         name: "bando.view.belts_production.Jointing.JointingActualReport.fragment.JointingActualReport",
//                     }).then(function (oDialog) {
//                         var oFilterBar = oDialog.getFilterBar();

//                         var oColumnProductCode, oColumnPostingDate, oColumnCompanyCode;
//                         that._oVHD = oDialog;
//                         that.getView().addDependent(oDialog);

//                         // Set key fields for filtering in the Define Conditions Tab
//                         oDialog.setRangeKeyFields([{
//                             label: "Production No.",
//                             key: "productionorderno",
//                             type: "string",
//                             typeInstance: new sap.ui.model.type.String({}, {
//                                 maxLength: 10
//                             })
//                         }]);

//                         // Set Basic Search for FilterBar
//                         oFilterBar.setFilterBarExpanded(false);
//                         oFilterBar.setBasicSearch(that._oBasicSearchField);

//                         // Trigger filter bar search when the basic search is fired
//                         that._oBasicSearchField.attachSearch(function () {
//                             oFilterBar.search();
//                         });

//                         oDialog.getTableAsync().then(function (oTable) {
//                             oTable.setModel(that.oJSONModel);

//                             // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
//                             if (oTable.bindRows) {
//                                 // Desktop/Table scenario (sap.ui.table.Table)
//                                 oTable.bindAggregation("rows", {
//                                     path: "oJSONModel>/Datas",
//                                     events: {
//                                         dataReceived: function () {
//                                             oDialog.update();
//                                         }
//                                     }
//                                 });

//                                 // Define columns for sap.ui.table.Table
//                                 oColumnProductCode = new sap.ui.table.Column({
//                                     label: new sap.m.Label({ text: "Production No." }),
//                                     template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>productionorderno}" })
//                                 });
//                                 oColumnProductCode.data({
//                                     fieldName: "productionorder"
//                                 });

//                                 oTable.addColumn(oColumnProductCode);


//                             } else if (oTable.bindItems) {
//                                 // Mobile scenario (sap.m.Table)
//                                 oTable.bindAggregation("items", {
//                                     path: "oJSONModel>/Datas",
//                                     template: new sap.m.ColumnListItem({
//                                         cells: [
//                                             new sap.m.Text({ text: "{oJSONModel>productionorderno}" }),

//                                         ]
//                                     }),
//                                     events: {
//                                         dataReceived: function () {
//                                             oDialog.update();
//                                         }
//                                     }
//                                 });

//                                 // Define columns for sap.m.Table (if necessary)
//                                 oTable.addColumn(new sap.m.Column({
//                                     header: new sap.m.Label({ text: "Production No." })
//                                 }));

//                             }

//                             oDialog.update();
//                             sap.ui.core.BusyIndicator.hide();
//                         });

//                         oDialog.open();
//                         sap.ui.core.BusyIndicator.hide();
//                     });
//                 }

//                 // Start fetching data from the beginning
//                 fetchData(0);
//             } else {
//                 //   sap.m.MessageBox.error("Please check Company Code / Fiscal Year");
//                 sap.ui.core.BusyIndicator.hide();
//             }
//         },

//         onValueHelpOkPress: function (oEvent) {
//             var aTokens = oEvent.getParameter("tokens");
//             console.log("aTokens:", aTokens);

//             if (!this._oMultiInput) {
//                 console.error("MultiInput not defined!");
//                 return;
//             }

//             if (aTokens.length <= 10) {
//                 this._oMultiInput.setTokens(aTokens); // now safe
//                 this._oVHD.close();
//             } else {
//                 sap.m.MessageBox.error("Please select max 15 items only!");
//             }
//         },

//         onValueHelpCancelPress: function () {
//             this._oVHD.close();
//         },

//         onValueHelpAfterClose: function () {
//             this._oVHD.destroy();
//         },

//         onFilterBarSearch: function (oEvent) {
//             var sSearchQuery = this._oBasicSearchField.getValue(),
//                 aSelectionSet = oEvent.getParameter("selectionSet");

//             var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
//                 if (oControl.getValue()) {
//                     aResult.push(new sap.ui.model.Filter({
//                         path: oControl.getName(),
//                         operator: FilterOperator.Contains,
//                         value1: oControl.getValue()
//                     }));
//                 }

//                 return aResult;
//             }, []);

//             aFilters.push(new sap.ui.model.Filter({
//                 filters: [
//                     new sap.ui.model.Filter({ path: "productionorderno", operator: sap.ui.model.FilterOperator.EQ, value1: sSearchQuery })

//                 ],
//                 and: false
//             }));

//             this._filterTable(new sap.ui.model.Filter({
//                 filters: aFilters,
//                 and: true
//             }));
//         },

//         _filterTable: function (oFilter) {
//             var oVHD = this._oVHD;

//             oVHD.getTableAsync().then(function (oTable) {
//                 if (oTable.bindRows) {
//                     oTable.getBinding("rows").filter(oFilter);
//                 }
//                 if (oTable.bindItems) {
//                     oTable.getBinding("items").filter(oFilter);
//                 }

//                 // This method must be called after binding update of the table.
//                 oVHD.update();
//             });
//         },

//         // Connect to the OData service and fetch suggestions
//         OnSuggest_User: function (oEvent) {
//             // Store the source MultiInput
//             this._oMultiInput = oEvent.getSource();

//             var sTerm = oEvent.getParameter("suggestValue");

//             this._connectToODataProductSearchService(sTerm)
//                 .then(function (aSuggestions) {
//                     // Clear previous suggestions
//                     this.destroySuggestionItems();

//                     // Add new suggestions to the input field
//                     for (var i = 0; i < aSuggestions.length; i++) {
//                         this.addSuggestionItem(new sap.ui.core.Item({
//                             text: aSuggestions[i]
//                         }));
//                     }
//                 }.bind(oEvent.getSource())); // bind the input
//         },


//         _connectToODataProductSearchService: function (sTerm) {
//             var oModel = this.getView().getModel('ZSB_JOINT_PLAN'); // OData Model
//             var aFilters = [
//                 new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sTerm) // Search based on Name
//             ];

//             return new Promise(function (fnResolve, fnReject) {
//                 // Perform OData read request
//                 oModel.read("/ZC_JOINT_PLAN", {  // Replace "/ProductSet" with your OData entity set
//                     filters: aFilters,
//                     urlParameters: {
//                         "$top": 5000
//                     },
//                     success: function (oData) {
//                         var aResults = oData.results.map(function (mProduct) {
//                             return mProduct.productionorderno;  // Assuming Name is the field you're interested in
//                         });

//                         // Resolve with the list of suggestions
//                         fnResolve(aResults);
//                     },
//                     error: function (oError) {
//                         console.error("Error fetching suggestions from OData service:", oError);
//                         fnReject(oError);
//                     }
//                 });
//             });
//         },

//         ondocumentsuggestselected: function (oEvent) {
//             sap.ui.core.BusyIndicator.show();

//             var oSelectedItem = oEvent.getParameter("selectedItem");

//             if (oSelectedItem) {
//                 var sSelectedText = oSelectedItem.getText();

//                 if (!this._oMultiInput) {
//                     console.error("MultiInput not defined!");
//                     sap.ui.core.BusyIndicator.hide();
//                     return;
//                 }

//                 // Set value into the stored MultiInput
//                 this._oMultiInput.setValue(sSelectedText);
//             }

//             sap.ui.core.BusyIndicator.hide();
//         },


//         // /* ================= INIT ================= */
//         // onInit: function () {
//         //     this.getView().setModel(new JSONModel({ ItemData: [] }), "TabModel");

//         //     this.getView().setModel(
//         //         new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL/"),
//         //         "ZSB_REQ_ACTUAL"
//         //     );
//         //     this.getView().setModel(
//         //         new ODataModel("/sap/opu/odata/sap/ZSB_REQ_MOVEMENT_TYPE/"),
//         //         "ZSB_REQ_MOVEMENT_TYPE"
//         //     );
//         //     this.getView().setModel(
//         //         new ODataModel("/sap/opu/odata/sap/ZSB_ORDER_TYPE/"),
//         //         "ZSB_ORDER_TYPE"
//         //     );
//         //     this.getView().setModel(
//         //         new ODataModel("/sap/opu/odata/sap/ZSB_JOINT_PLAN/"),
//         //         "ZSB_JOINT_PLAN"
//         //     );
//         // },

//         // formatDate: function (vDate) {
//         //     if (!vDate) return "";
//         //     var oDate = vDate instanceof Date ? vDate : new Date(vDate);
//         //     if (isNaN(oDate.getTime())) return "";
//         //     return sap.ui.core.format.DateFormat
//         //         .getDateInstance({ pattern: "dd/MM/yyyy" })
//         //         .format(oDate);
//         // },

//         // /* ================= HELPERS ================= */
//         // _normalizeOrder: function (s) {
//         //     return s ? s.replace(/^0+/, "") : "";
//         // },

//         // _formatProductionOrder: function (s) {
//         //     return s ? s.padStart(12, "0") : "";
//         // },

//         // _formatMaterial: function (s) {
//         //     return s ? s.padStart(18, "0") : "";
//         // },

//         // _fetchAllData: function (oModel, sEntity, aFilters, skip, top, res, ok, err) {
//         //     oModel.read(sEntity, {
//         //         filters: aFilters,
//         //         urlParameters: { "$skip": skip, "$top": top },
//         //         success: function (d) {
//         //             res = res.concat(d.results || []);
//         //             if (d.results && d.results.length === top) {
//         //                 this._fetchAllData(oModel, sEntity, aFilters, skip + top, top, res, ok, err);
//         //             } else {
//         //                 ok(res);
//         //             }
//         //         }.bind(this),
//         //         error: err
//         //     });
//         // },

//         // _buildMovementFilter: function (aData) {
//         //     var parts = [], seen = {};
//         //     aData.forEach(function (o) {
//         //         if (!o.productionorder || !o.Material) return;
//         //         var k = this._normalizeOrder(o.productionorder) + "_" + o.Material;
//         //         if (seen[k]) return;
//         //         seen[k] = true;
//         //         parts.push(
//         //             "(OrderID eq '" +
//         //             this._normalizeOrder(o.productionorder) +
//         //             "' and Material eq '" +
//         //             o.Material +
//         //             "')"
//         //         );
//         //     }.bind(this));
//         //     return parts.join(" or ");
//         // },

//         // _fetchMovementTypesByFilter: function (sFilter, ok, err) {
//         //     this.getView().getModel("ZSB_REQ_MOVEMENT_TYPE")
//         //         .read("/ZC_REQ_Movement_type", {
//         //             urlParameters: { "$filter": sFilter },
//         //             success: function (d) { ok(d.results || []); },
//         //             error: err
//         //         });
//         // },

//         // _fetchOrderTypesBulk: function (rows, ok, err) {
//         //     if (!rows.length) { ok([]); return; }
//         //     var orFilters = [];
//         //     rows.forEach(function (o) {
//         //         var ord = this._normalizeOrder(o.productionorder);
//         //         if (!ord || !o.Material) return;
//         //         orFilters.push(new Filter({
//         //             filters: [
//         //                 new Filter("ProductionOrder", FilterOperator.EQ, ord),
//         //                 new Filter("Material", FilterOperator.EQ, o.Material)
//         //             ],
//         //             and: true
//         //         }));
//         //     }.bind(this));
//         //     if (!orFilters.length) { ok([]); return; }

//         //     this.getView().getModel("ZSB_ORDER_TYPE")
//         //         .read("/ZC_ORDER_TYPE", {
//         //             filters: [new Filter({ filters: orFilters, and: false })],
//         //             success: function (d) { ok(d.results || []); },
//         //             error: err
//         //         });
//         // },

//         // GoStockReqTableOpen: function () {
//         //     var view = this.getView();
//         //     var tabModel = view.getModel("TabModel");
//         //     var oModel = view.getModel("ZSB_REQ_ACTUAL");
//         //     var oMixPlanModel = view.getModel("ZSB_JOINT_PLAN"); 
//         //     // ====== 1. DATE (mandatory) ======
//         //     var oDate = view.byId("MIXJNT").getDateValue();
//         //     if (!oDate) {
//         //         MessageToast.show("Please select a date");
//         //         return;
//         //     }

//         //     var sDate = oDate.getFullYear() + "-" +
//         //         String(oDate.getMonth() + 1).padStart(2, "0") + "-" +
//         //         String(oDate.getDate()).padStart(2, "0");

//         //     this._sMixDate = sDate;

//         //     // ====== 2. BUILD FILTERS FOR ZCE_REQ_ACTUAL ======
//         //     var aTokens = view.byId("idmaterialdocumentJNT")?.getTokens() || [];
//         //     var sMaterial = view.byId("idMaterial_JNT")?.getValue()?.trim();

//         //     var filters = [
//         //         new Filter("MatlCompRequirementDate", FilterOperator.EQ, sDate)
//         //     ];

//         //     if (aTokens.length) {
//         //         var poMaterialFilters = aTokens.map(function (t) {
//         //             var po = t.getKey() || t.getText();
//         //             if (!po) return null;

//         //             var poFilter = new Filter(
//         //                 "productionorder",
//         //                 FilterOperator.EQ,
//         //                 this._formatProductionOrder(po)
//         //             );

//         //             if (sMaterial) {
//         //                 return new Filter({
//         //                     filters: [
//         //                         poFilter,
//         //                         new Filter("Material", FilterOperator.EQ, sMaterial)
//         //                     ],
//         //                     and: true
//         //                 });
//         //             }
//         //             return poFilter;
//         //         }.bind(this)).filter(Boolean);

//         //         if (poMaterialFilters.length === 1) {
//         //             filters.push(poMaterialFilters[0]);
//         //         } else if (poMaterialFilters.length > 1) {
//         //             filters.push(new Filter({
//         //                 filters: poMaterialFilters,
//         //                 and: false
//         //             }));
//         //         }
//         //     } else if (sMaterial) {
//         //         filters.push(new Filter("Material", FilterOperator.EQ, sMaterial));
//         //     }

//         //     view.setBusy(true);

//         //     // ====== 3. FETCH MIXING PLAN (ONLY POs WITHOUT MATERIAL DOC) ======
//         //     var oMixPlanFilters = [
//         //         new Filter("productionordstartdate", FilterOperator.EQ, sDate),
//         //         new Filter({
//         //             filters: [
//         //                 new Filter("gicnfmaterialdocnumber", FilterOperator.EQ, ""),
//         //                 new Filter("gicnfmaterialdocnumber", FilterOperator.EQ, null)
//         //             ],
//         //             and: false
//         //         })
//         //     ];

//         //     this._fetchAllData(
//         //         oMixPlanModel,
//         //         "/ZC_JOINT_PLAN",
//         //         oMixPlanFilters,
//         //         0,
//         //         1000,
//         //         [],
//         //         function (mixData) {

//         //             // Normalize & collect only valid POs
//         //             var mixPOSet = new Set(
//         //                 (mixData || []).map(o =>
//         //                     this._normalizeOrder(o.productionorderno)
//         //                 )
//         //             );

//         //             if (!mixPOSet.size) {
//         //                 tabModel.setProperty("/ItemData", []);
//         //                 MessageToast.show("No Mixing Plan POs without material document");
//         //                 view.setBusy(false);
//         //                 return;
//         //             }

//         //             // ====== 4. FETCH ZCE_REQ_ACTUAL ======
//         //             this._fetchAllData(
//         //                 oModel,
//         //                 "/ZCE_REQ_ACTUAL",
//         //                 filters,
//         //                 0,
//         //                 1000,
//         //                 [],
//         //                 function (oData) {

//         //                     var aResults = (oData || []).filter(function (o) {
//         //                         return mixPOSet.has(
//         //                             this._normalizeOrder(o.productionorder)
//         //                         );
//         //                     }.bind(this));

//         //                     if (!aResults.length) {
//         //                         tabModel.setProperty("/ItemData", []);
//         //                         MessageToast.show("No matching records found");
//         //                         view.setBusy(false);
//         //                         return;
//         //                     }

//         //                     // ====== 5. SEPARATE SPECIAL / NORMAL ROWS ======
//         //                     var specialRows = [];
//         //                     var normalRows = [];

//         //                     aResults.forEach(function (o) {
//         //                         var normOrder = this._normalizeOrder(o.productionorder);
//         //                         if (mixPOSet.has(normOrder)) {
//         //                             specialRows.push(o);
//         //                         } else {
//         //                             normalRows.push(o);
//         //                         }
//         //                     }.bind(this));

//         //                     // ====== 6. PROCESS NORMAL ROWS ======
//         //                     var sMovFilter = this._buildMovementFilter(normalRows);

//         //                     this._fetchMovementTypesByFilter(
//         //                         sMovFilter,
//         //                         function (aMoves) {

//         //                             var movMap = {};
//         //                             aMoves.forEach(function (m) {
//         //                                 movMap[m.OrderID + "_" + m.Material] =
//         //                                     m.MovementType;
//         //                             });

//         //                             normalRows.forEach(function (o) {
//         //                                 o.MovementType =
//         //                                     movMap[
//         //                                     this._normalizeOrder(o.productionorder) +
//         //                                     "_" + o.Material
//         //                                     ] || "";
//         //                             }.bind(this));

//         //                             var aFiltered = normalRows.filter(
//         //                                 o => o.MovementType !== "261"
//         //                             );

//         //                             this._fetchOrderTypesBulk(
//         //                                 aFiltered,
//         //                                 function (aTypes) {

//         //                                     var typeMap = {};
//         //                                     aTypes.forEach(function (t) {
//         //                                         typeMap[
//         //                                             this._normalizeOrder(t.ProductionOrder) +
//         //                                             "_" + t.Material
//         //                                         ] = t.ProductionOrderType;
//         //                                     }.bind(this));

//         //                                     aFiltered.forEach(function (o) {
//         //                                         o.ProductionOrderType =
//         //                                             typeMap[
//         //                                             this._normalizeOrder(o.productionorder) +
//         //                                             "_" + o.Material
//         //                                             ] || "";
//         //                                     }.bind(this));

//         //                                     aFiltered = aFiltered.filter(
//         //                                         o => o.ProductionOrderType === "ZMI1"
//         //                                     );

//         //                                     // ====== 7. COMBINE ROWS ======
//         //                                     var finalRows = [
//         //                                         ...specialRows,
//         //                                         ...aFiltered
//         //                                     ];

//         //                                     // ====== 8. SORT ======
//         //                                     finalRows.sort(function (a, b) {
//         //                                         return (
//         //                                             this._normalizeOrder(a.productionorder) +
//         //                                             "_" + a.Material
//         //                                         ).localeCompare(
//         //                                             this._normalizeOrder(b.productionorder) +
//         //                                             "_" + b.Material
//         //                                         );
//         //                                     }.bind(this));

//         //                                     // ====== 9. TOTAL CALCULATION ======
//         //                                     var totals = {};
//         //                                     finalRows.forEach(function (o) {
//         //                                         var k =
//         //                                             this._normalizeOrder(o.productionorder) +
//         //                                             "_" + o.Material;

//         //                                         if (!totals[k]) {
//         //                                             totals[k] = {
//         //                                                 req: +o.RequiredQuantity || 0,
//         //                                                 avb: 0,
//         //                                                 avbAlt: 0
//         //                                             };
//         //                                         }

//         //                                         if (o.storagelocation === o.storagelocation1) {
//         //                                             totals[k].avb +=
//         //                                                 +o.MatlWrhsStkQtyInMatlBase || 0;
//         //                                         }

//         //                                         if (o.storagelocation1 === "12RM") {
//         //                                             totals[k].avbAlt +=
//         //                                                 +o.MatlWrhsStkQtyInMatlBase || 0;
//         //                                         }
//         //                                     }.bind(this));

//         //                                     // ====== 10. FINAL TABLE DATA ======
//         //                                     var finalData = [];
//         //                                     var curKey = "";

//         //                                     finalRows.forEach(function (o) {
//         //                                         var key =
//         //                                             this._normalizeOrder(o.productionorder) +
//         //                                             "_" + o.Material;
//         //                                         var firstRow = key !== curKey;

//         //                                         if (curKey && firstRow) {
//         //                                             finalData.push({
//         //                                                 Material: "Total",
//         //                                                 RequiredQuantity: totals[curKey].req.toFixed(4),
//         //                                                 col2: totals[curKey].avb.toFixed(4),
//         //                                                 MatlWrhsStkQtyInMatlBase1: totals[curKey].avbAlt.toFixed(4),
//         //                                                 BalanceQuantity:
//         //                                                     (totals[curKey].avb - totals[curKey].req).toFixed(4),
//         //                                                 isSumRow: true
//         //                                             });
//         //                                         }

//         //                                         curKey = key;

//         //                                         var avb =
//         //                                             o.storagelocation === o.storagelocation1
//         //                                                 ? +o.MatlWrhsStkQtyInMatlBase || 0
//         //                                                 : 0;

//         //                                         var avbAlt =
//         //                                             o.storagelocation1 === "12RM"
//         //                                                 ? +o.MatlWrhsStkQtyInMatlBase || 0
//         //                                                 : 0;

//         //                                         finalData.push({
//         //                                             ...o,
//         //                                             productionorderDisp:
//         //                                                 this._normalizeOrder(o.productionorder),
//         //                                             RequiredQuantity:
//         //                                                 firstRow ? totals[key].req.toFixed(4) : "",
//         //                                             col2: avb ? avb.toFixed(4) : "",
//         //                                             MatlWrhsStkQtyInMatlBase1:
//         //                                                 avbAlt ? avbAlt.toFixed(4) : "",
//         //                                             BalanceQuantity:
//         //                                                 firstRow
//         //                                                     ? (totals[key].avb - totals[key].req).toFixed(4)
//         //                                                     : "",
//         //                                             BatchForCol2: avb ? o.Batch : "",
//         //                                             BatchForMatlWrhs: avbAlt ? o.Batch : "",
//         //                                             isSumRow: false
//         //                                         });
//         //                                     }.bind(this));

//         //                                     if (curKey) {
//         //                                         finalData.push({
//         //                                             Material: "Total",
//         //                                             RequiredQuantity: totals[curKey].req.toFixed(4),
//         //                                             col2: totals[curKey].avb.toFixed(4),
//         //                                             MatlWrhsStkQtyInMatlBase1: totals[curKey].avbAlt.toFixed(4),
//         //                                             BalanceQuantity:
//         //                                                 (totals[curKey].avb - totals[curKey].req).toFixed(4),
//         //                                             isSumRow: true
//         //                                         });
//         //                                     }

//         //                                     tabModel.setProperty("/ItemData", finalData);
//         //                                     view.setBusy(false);

//         //                                 }.bind(this),
//         //                                 function () {
//         //                                     MessageToast.show("Error fetching order types");
//         //                                     view.setBusy(false);
//         //                                 }
//         //                             );
//         //                         }.bind(this),
//         //                         function () {
//         //                             MessageToast.show("Error fetching movement types");
//         //                             view.setBusy(false);
//         //                         }
//         //                     );
//         //                 }.bind(this),
//         //                 function () {
//         //                     MessageToast.show("Error fetching data");
//         //                     view.setBusy(false);
//         //                 }
//         //             );
//         //         }.bind(this),
//         //         function () {
//         //             MessageToast.show("Error fetching Mixing Plan data");
//         //             view.setBusy(false);
//         //         }
//         //     );
//         // },




//     }
//     );
// }
// );










sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/IconPool",
    "sap/ui/core/Component",
    "sap/ui/core/UIComponent",
    "sap/m/routing/Router",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library",
    "sap/m/PDFViewer",
    "bando/util/importfile/importexcelfile",
    "bando/util/pdf-lib/pdf-lib.min",
    "sap/ui/core/Fragment"
], function (
    BaseController,
    JSONModel,
    ODataModel,
    MessageToast,
    MessageBox,
    Filter,
    FilterOperator,
    IconPool,
    Component,
    UIComponent,
    Router,
    Spreadsheet,
    exportLibrary,
    PDFViewer,
    importexcelfile,
    PDFLibjs,
    Fragment
) {
    "use strict";

    return BaseController.extend("bando.controller.belts_production.BeltFGPlanReport", {

        onInit: function () {
            // Table model
            this.getView().setModel(
                new JSONModel({ ItemData: [] }),
                "TabModel"
            );

            // Mixing Plan OData model
            this.getView().setModel(
                new ODataModel("/sap/opu/odata/sap/ZSB_FG_PROCESS_PLAN/"),
                "ZSB_FG_PROCESS_PLAN"
            );
            this.getView().setModel(
                new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL/"),
                "ZSB_REQ_ACTUAL"
            );
            this.getView().setModel(
                new ODataModel("/sap/opu/odata/sap/ZSB_PRODUCT_ORD1/"),
                "ZSB_PRODUCT_ORD1"
            );
            // ✅ Register dedicated Jointing Actual FG OData service model pointing to ZSB_REQ_ACTUAL_JNT
            this.getView().setModel(
                new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL_JNT/"),
                "ZSB_REQ_ACTUAL_JNT"
            );
        },

        /* ================= FORMATTERS ================= */
        formatDate: function (vDate) {
            if (!vDate) {
                return "";
            }
            var oDate = vDate instanceof Date ? vDate : new Date(vDate);
            if (isNaN(oDate.getTime())) {
                return "";
            }
            return sap.ui.core.format.DateFormat
                .getDateInstance({ pattern: "dd/MM/yyyy" })
                .format(oDate);
        },

        /* ================= HELPERS ================= */
        _normalizeOrder: function (s) {
            return s ? s.replace(/^0+/, "") : "";
        },

        _formatProductionOrder: function (s) {
            return s ? s.padStart(12, "0") : "";
        },

        _fetchAllData: function (oModel, sEntity, aFilters, skip, top, res, ok, err) {
            oModel.read(sEntity, {
                filters: aFilters,
                urlParameters: { "$skip": skip, "$top": top },
                success: function (d) {
                    res = res.concat(d.results || []);
                    if (d.results && d.results.length === top) {
                        this._fetchAllData(oModel, sEntity, aFilters, skip + top, top, res, ok, err);
                    } else {
                        ok(res);
                    }
                }.bind(this),
                error: err
            });
        },

GoStockReqTableOpen: function () {
            var view = this.getView();
            var tabModel = view.getModel("TabModel");                           
            var oModel = view.getModel("ZSB_REQ_ACTUAL_JNT");
            var oMixPlanModel = view.getModel("ZSB_JOINT_PLAN");
            var oStatusModel = view.getModel("ZSB_PRODUCT_ORD1"); 

            var oDatePicker = view.byId("MIXJNT");
            if (!oDatePicker) {
                MessageToast.show("Date control 'MIXJNT' not found in view.");
                return;
            }

            var oDate = typeof oDatePicker.getDateValue === "function" ? oDatePicker.getDateValue() : null;
            if (!oDate && typeof oDatePicker.getValue === "function" && oDatePicker.getValue()) {
                oDate = new Date(oDatePicker.getValue());
            }

            if (!oDate || isNaN(oDate.getTime())) {
                MessageToast.show("Please select a valid date");
                return;
            }

            var aTokens = view.byId("idmaterialdocumentJNT")?.getTokens() || [];
            var sMaterialInput = view.byId("idMaterial_JNT")?.getValue()?.trim();
            var sMachineInput = view.byId("idMachineNum_JNT")?.getValue()?.trim().toUpperCase();

            var sDate = oDate.getFullYear() + "-" +
                String(oDate.getMonth() + 1).padStart(2, "0") + "-" +
                String(oDate.getDate()).padStart(2, "0");

            view.setBusy(true);

            // STEP 1: Fetch Mix Plan using Date
            this._fetchAllData(oMixPlanModel, "/ZC_JOINT_PLAN", [new Filter("productionordstartdate", "EQ", sDate)], 0, 1000, [], function (allMixData) {
                
                // STEP 2: Filter out RELEASED orders locally first
                var unreleasedOrders = (allMixData || []).filter(o => !o.releasestatus || o.releasestatus.trim() === "");

                if (unreleasedOrders.length === 0) {
                    view.setBusy(false);
                    tabModel.setProperty("/ItemData", []);
                    MessageToast.show("No unreleased orders found for this date.");
                    return;
                }

                // STEP 2.5: Check for TECO (I0045) Status in ZSB_PRODUCT_ORD1
                var aOrderCheckFilters = unreleasedOrders.map(o => {
                    return new Filter("ManufacturingOrder", "EQ", this._formatProductionOrder(o.productionorderno));
                });

                var oTecoQueryFilter = new Filter({
                    filters: [
                        new Filter({ filters: aOrderCheckFilters, and: false }), 
                        new Filter("StatusCode", "EQ", "I0045"),                 
                        new Filter("StatusIsActive", "EQ", true)                 
                    ],
                    and: true
                });

                this._fetchAllData(oStatusModel, "/ZC_ORDER_CREATION1", [oTecoQueryFilter], 0, 1000, [], function (tecoResults) {
                    
                    var setTecoOrders = new Set(tecoResults.map(t => this._normalizeOrder(t.ManufacturingOrder)));
                    var finalCandidateOrders = unreleasedOrders.filter(o => !setTecoOrders.has(this._normalizeOrder(o.productionorderno)));

                    if (finalCandidateOrders.length === 0) {
                        view.setBusy(false);
                        tabModel.setProperty("/ItemData", []);
                        MessageToast.show("Remaining orders are already Technically Completed (TECO).");
                        return;
                    }

                    var aJoinFilters = [], machineMap = {}, orderDateMap = {}; 
                    finalCandidateOrders.forEach(o => {
                        var sPaddedPO = this._formatProductionOrder(o.productionorderno);
                        machineMap[sPaddedPO] = o.machinenumber || "";
                        orderDateMap[sPaddedPO] = o.productionordstartdate; 
                        aJoinFilters.push(new Filter({
                            filters: [
                                new Filter("productionorder", "EQ", sPaddedPO),
                                new Filter("BillOfOperationsMaterial", "EQ", o.materialcode)
                            ],
                            and: true
                        }));
                    });

                    // STEP 3: Fetch Stock
                    this._fetchAllData(view.getModel("ZSB_REQ_ACTUAL"), "/ZC_REQ_ACT_srorage_loc", [], 0, 5000, [], function (stockResults) {
                        var systemStockMap = {};
                        stockResults.forEach(s => {
                            var sKey = this._normalizeOrder(s.Product) + "|" + (s.Batch || "") + "|" + s.StorageLocation;
                            systemStockMap[sKey] = +s.MatlWrhsStkQtyInMatlBaseUnit || 0;
                        });

                        // STEP 4: Fetch Requirements using ZCE_REQ_ACTUAL_JOIN
                        this._fetchAllData(oModel, "/ZCE_REQ_ACTUAL_JOIN", [new Filter({ filters: aJoinFilters, and: false })], 0, 5000, [], function (aResults) {
                            var finalData = [], curKey = "", totals = {};
                            var materialInitialStock = {}, materialRunningBalance = {}; 
                            var groupProcessedBatches = {}, processedReqItems = {};

                            // PASS 1: Totals & Balance Initialization
                            aResults.forEach(function (o) {
                                var sNormPO = this._normalizeOrder(o.productionorder);
                                var sMatNorm = this._normalizeOrder(o.Material);
                                var groupKey = sNormPO + "_" + sMatNorm;
                                var sBatch = o.Batch || "";

                                if (!totals[groupKey]) {
                                    totals[groupKey] = { req: 0, avb: 0, avbAlt: 0 };
                                    groupProcessedBatches[groupKey] = new Set();
                                }

                                var reqKey = sNormPO + "|" + sMatNorm + "|" + (o.RESERVATION || "") + "|" + (o.RESERVATIONITEM || "");
                                if (!processedReqItems[reqKey]) {
                                    totals[groupKey].req += (+o.RequiredQuantity || 0);
                                    processedReqItems[reqKey] = true;
                                }

                                var k1 = sMatNorm + "|" + sBatch + "|" + (o.storagelocation || "");
                                var k2 = sMatNorm + "|" + sBatch + "|" + (o.ProductionInvtryManagedLoc || "");
                                if (!groupProcessedBatches[groupKey].has(sBatch)) {
                                    totals[groupKey].avb += (systemStockMap[k1] || 0);
                                    totals[groupKey].avbAlt += (systemStockMap[k2] || 0);
                                    groupProcessedBatches[groupKey].add(sBatch);
                                }

                                if (materialInitialStock[sMatNorm] === undefined) {
                                    var totalStock = 0, stockSeen = new Set();
                                    aResults.forEach(r => {
                                        if (this._normalizeOrder(r.Material) === sMatNorm) {
                                            var sk = sMatNorm + "|" + (r.Batch || "") + "|" + (r.storagelocation || "");
                                            if (!stockSeen.has(sk)) { totalStock += (systemStockMap[sk] || 0); stockSeen.add(sk); }
                                        }
                                    });
                                    materialInitialStock[sMatNorm] = totalStock;
                                    materialRunningBalance[sMatNorm] = totalStock;
                                }
                            }.bind(this));

                            // PASS 2: Assemble Rows
                            var usedBatchesInPO = new Set();
                            aResults.forEach(function (o) {
                                var sPaddedPO = o.productionorder;
                                var sNormPO = this._normalizeOrder(sPaddedPO);
                                var sMatNorm = this._normalizeOrder(o.Material);
                                var groupKey = sNormPO + "_" + sMatNorm;
                                var sBatch = o.Batch || "";
                                var isFirstInGrp = (groupKey !== curKey);

                                if (isFirstInGrp) usedBatchesInPO.clear();
                                if (usedBatchesInPO.has(sBatch)) return;

                                var sloc1 = o.storagelocation || "";
                                var sloc2 = o.ProductionInvtryManagedLoc || "";
                                var dq1 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc1].toFixed(4) : "";
                                var dq2 = systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2] ? systemStockMap[sMatNorm + "|" + sBatch + "|" + sloc2].toFixed(4) : "";

                                if (!dq1 && !dq2) return;

                                if (isFirstInGrp) materialRunningBalance[sMatNorm] -= totals[groupKey].req;
                                if (curKey && isFirstInGrp) finalData.push(this._createSummaryRow(curKey, totals, finalData));

                                curKey = groupKey;
                                usedBatchesInPO.add(sBatch);

                                finalData.push({
                                    ...o,
                                    productionordstartdate: orderDateMap[sPaddedPO] || "", 
                                    productionorderDisp: sNormPO,
                                    machinenumber: machineMap[sPaddedPO] || "",
                                    RequiredQuantity: isFirstInGrp ? totals[groupKey].req.toFixed(4) : "",
                                    col2: dq1,
                                    BatchForCol2: dq1 ? sBatch : "",
                                    storagelocation: dq1 ? sloc1 : "",
                                    MatlWrhsStkQtyInMatlBase1: dq2,
                                    BatchForMatlWrhs: dq2 ? sBatch : "",
                                    ProductionInvtryManagedLoc: dq2 ? sloc2 : "",
                                    BalanceQuantity: isFirstInGrp ? materialRunningBalance[sMatNorm].toFixed(4) : "",
                                    isSumRow: false
                                });
                            }.bind(this));

                            if (curKey) finalData.push(this._createSummaryRow(curKey, totals, finalData));

                            // STEP 5: FINAL UI FILTER
                            var filteredResults = finalData.filter(function (row, idx, arr) {
                                if (!sMachineInput && !sMaterialInput && aTokens.length === 0) return true;
                                var match = (r) => {
                                    var mMachine = !sMachineInput || (r.machinenumber || "").toUpperCase() === sMachineInput;
                                    var mMaterial = !sMaterialInput || this._normalizeOrder(r.Material) === this._normalizeOrder(sMaterialInput);
                                    var mPO = aTokens.length === 0 || aTokens.some(t => this._normalizeOrder(t.getKey() || t.getText()) === this._normalizeOrder(r.productionorder));
                                    return mMachine && mMaterial && mPO;
                                };
                                if (!row.isSumRow) return match(row);
                                var groupMatched = false;
                                for (var i = idx - 1; i >= 0; i--) {
                                    if (arr[i].isSumRow) break;
                                    if (match(arr[i])) { groupMatched = true; break; }
                                }
                                return groupMatched;
                            }.bind(this));

                            tabModel.setProperty("/ItemData", filteredResults);
                            view.setBusy(false);

                        }.bind(this), () => view.setBusy(false));
                    }.bind(this), () => view.setBusy(false));
                }.bind(this), () => view.setBusy(false));
            }.bind(this), () => view.setBusy(false));
        },

        _removeLeadingZeros: function(sVal) {
            if (!sVal) return "";
            return sVal.replace(/^0+/, "");
        },

        onDownload: function () {
            var oView = this.getView();
            var aData = oView.getModel("TabModel").getProperty("/ItemData") || [];

            if (!aData.length) {
                sap.m.MessageToast.show("No data to export");
                return;
            }

            var aExportData = aData.map(function (o) {
                return {
                    Date: o.productionordstartdate ? 
                        sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd/MM/yyyy" }).format(new Date(o.productionordstartdate)) 
                        : "",
                    ProductionOrder: o.productionorderno || "",
                    Material: o.materialcode || "",
                    BIPLLotNo: o.bipllotno || "",
                    Shift: o.shift || "",
                    Description: o.description || "",
                    Machine: o.machinenumber || "",
                    Plant: o.plant || "",
                    LotBatchNo: o.lotbatchno || "",
                    ProductionOrderQty: o.productionorderqty != null ? parseFloat(o.productionorderqty).toFixed(4) : "0.0000",
                    StorageLoc: o.storagelocation || ""
                };
            });

            var EdmType = exportLibrary.EdmType;
            var aCols = [
                { label: "Date", property: "Date", type: EdmType.String },
                { label: "Production Order", property: "ProductionOrder", type: EdmType.String },
                { label: "Material", property: "Material", type: EdmType.String },
                { label: "BIPL Lot No.", property: "BIPLLotNo", type: EdmType.String },
                { label: "Shift", property: "Shift", type: EdmType.String },
                { label: "Description", property: "Description", type: EdmType.String },
                { label: "Machine", property: "Machine", type: EdmType.String },
                { label: "Plant", property: "Plant", type: EdmType.String },
                { label: "Lot Batch No", property: "LotBatchNo", type: EdmType.String },
                { label: "Production Order Qty", property: "ProductionOrderQty", type: EdmType.Decimal, scale: 4 },
                { label: "Storage Loc", property: "StorageLoc", type: EdmType.String }
            ];

            var oSettings = {
                workbook: { columns: aCols },
                dataSource: aExportData,
                fileName: "BeltFGActualReport.xlsx"
            };

            var oSheet = new sap.ui.export.Spreadsheet(oSettings);
            oSheet.build()
                .finally(function () {
                    oSheet.destroy();
                });
        },

        onValueHelpRequest: function (oEvent) {
            this._oMultiInput = oEvent.getSource();
            var Date = "";

            if (Date || Date.length == 0) {
                sap.ui.core.BusyIndicator.show();

                var oModel = this.getView().getModel("ZSB_FG_PROCESS_PLAN");

                if (!oModel) {
                    console.error("OData model is not properly initialized.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                var that = this;
                var aAllItems = []; 

                function fetchData(skipCount) {
                    oModel.read("/ZC_FG_PROCESS_PLAN", {
                        urlParameters: {
                            $top: 5000,  
                            $skip: skipCount  
                        },
                        success: function (oData) {
                            var aItems = oData.results;
                            aAllItems = aAllItems.concat(aItems); 

                            if (oData.results.length >= 5000) {
                                fetchData(skipCount + 5000);
                            } else {
                                finishFetching();
                            }
                        },
                        error: function (oError) {
                            console.error("Error reading data: ", oError);
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });
                }

                function finishFetching() {
                    that.oJSONModel = new sap.ui.model.json.JSONModel({
                        Datas: aAllItems
                    });
                    that.getView().setModel(that.oJSONModel, "oJSONModel");

                    that._oBasicSearchField = new sap.m.SearchField();
                    that.loadFragment({
                        name: "bando.view.belts_production.FGProcess.BeltFGPlanReport.fragment.BeltFgPlanFrag",
                    }).then(function (oDialog) {
                        var oFilterBar = oDialog.getFilterBar();

                        var oColumnProductCode;
                        that._oVHD = oDialog;
                        that.getView().addDependent(oDialog);

                        oDialog.setRangeKeyFields([{
                            label: "Production No.",
                            key: "productionorderno",
                            type: "string",
                            typeInstance: new sap.ui.model.type.String({}, {
                                maxLength: 10
                            })
                        }]);

                        oFilterBar.setFilterBarExpanded(false);
                        oFilterBar.setBasicSearch(that._oBasicSearchField);

                        that._oBasicSearchField.attachSearch(function () {
                            oFilterBar.search();
                        });

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(that.oJSONModel);

                            if (oTable.bindRows) {
                                oTable.bindAggregation("rows", {
                                    path: "oJSONModel>/Datas",
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                oColumnProductCode = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "Production No." }),
                                    template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>productionorderno}" })
                                });
                                oColumnProductCode.data({
                                    fieldName: "productionorder"
                                });

                                oTable.addColumn(oColumnProductCode);

                            } else if (oTable.bindItems) {
                                oTable.bindAggregation("items", {
                                    path: "oJSONModel>/Datas",
                                    template: new sap.m.ColumnListItem({
                                        cells: [
                                            new sap.m.Text({ text: "{oJSONModel>productionorderno}" }),
                                        ]
                                    }),
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                oTable.addColumn(new sap.m.Column({
                                    header: new sap.m.Label({ text: "Production No." })
                                }));
                            }

                            oDialog.update();
                            sap.ui.core.BusyIndicator.hide();
                        });

                        oDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    });
                }

                fetchData(0);
            } else {
                sap.ui.core.BusyIndicator.hide();
            }
        },

        onValueHelpOkPress: function(oEvent) {
            var aTokens = oEvent.getParameter("tokens");

            if (!this._oMultiInput) {
                console.error("MultiInput not defined!");
                return;
            }

            if (aTokens.length <= 10) {
                this._oMultiInput.setTokens(aTokens); 
                this._oVHD.close();
            } else {
                sap.m.MessageBox.error("Please select max 15 items only!");
            }
        },

        onValueHelpCancelPress: function () {
            this._oVHD.close();
        },

        onValueHelpAfterClose: function () {
            this._oVHD.destroy();
        },

        onFilterBarSearch: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }
                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "productionorderno", operator: sap.ui.model.FilterOperator.EQ, value1: sSearchQuery })
                ],
                and: false
            }));

            this._filterTable(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },

        _filterTable: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }
                oVHD.update();
            });
        },

        OnSuggest_User: function(oEvent) {
            this._oMultiInput = oEvent.getSource();
            var sTerm = oEvent.getParameter("suggestValue");

            this._connectToODataProductSearchService(sTerm)
                .then(function(aSuggestions) {
                    this.destroySuggestionItems();

                    for (var i = 0; i < aSuggestions.length; i++) {
                        this.addSuggestionItem(new sap.ui.core.Item({
                            text: aSuggestions[i]
                        }));
                    }
                }.bind(oEvent.getSource()));
        },

        _connectToODataProductSearchService: function (sTerm) {
            var oModel = this.getView().getModel('ZSB_FG_PROCESS_PLAN'); 
            var aFilters = [
                new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sTerm) 
            ];

            return new Promise(function (fnResolve, fnReject) {
                oModel.read("/ZC_FG_PROCESS_PLAN", {  
                    filters: aFilters,
                    urlParameters: {
                        "$top": 5000
                    },
                    success: function (oData) {
                        var aResults = oData.results.map(function (mProduct) {
                            return mProduct.productionorderno;  
                        });
                        fnResolve(aResults);
                    },
                    error: function (oError) {
                        console.error("Error fetching suggestions from OData service:", oError);
                        fnReject(oError);
                    }
                });
            });
        },

        ondocumentsuggestselected: function(oEvent) {
            sap.ui.core.BusyIndicator.show();
            var oSelectedItem = oEvent.getParameter("selectedItem");

            if (oSelectedItem) {
                var sSelectedText = oSelectedItem.getText();

                if (!this._oMultiInput) {
                    console.error("MultiInput not defined!");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                this._oMultiInput.setValue(sSelectedText);
            }

            sap.ui.core.BusyIndicator.hide();
        }

    });
});