sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/IconPool",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Component",
    "sap/ui/core/UIComponent",
    "sap/m/routing/Router",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "sap/m/PDFViewer",
    "bando/util/jspdf/html2canvasmin",
    "bando/util/jspdf/jspdfmin",
    "bando/util/importfile/importexcelfile",
  ],
  function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
    "use strict";

    return BaseController.extend("bando.controller.belts_production.BeltFGActual", {
      onInit: function () {


        var TabModel = new sap.ui.model.json.JSONModel({
          Samples: [

          ]

        });

        this.getView().setModel(TabModel, "TabModel");

        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }

        });

        this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");

        this._selectedProductionOrders = [];
        this._selectedMaterials = [];


        const screenModel = new JSONModel({
          openscreen: "screen1"
        });
        this.getView().setModel(screenModel, "ScreenVisible");

        // this.getView().setModel(new JSONModel({}), "SelectedRow");



        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.getRoute("BeltFGActual").attachMatched(this._onRouteMatched, this);

      },

      // _onRouteMatched: function () {
      //   // Clear filters
      //   // this.byId("idDateRange").setDateValue(null);
      //   // this.byId("idDateRange").setSecondDateValue(null);
      //   // this.byId("idPlant").setValue("");
      //   // this.byId("idMaterial").setValue("");
      //   // this.byId("idProductGroup").setValue("");

      //   // Optionally: clear or re-fetch table data
      //   this.getView().getModel("TabModel").setProperty("/Samples", []);
      //   this.HeaderModel = new sap.ui.model.json.JSONModel({

      //     HeaderData: {
      //       idDateRange: "",
      //       idPlant: "",
      //       idMaterial: "",
      //       // idProductGroup: "",
      //       idProductionorderno: "",

      //     }
      //   })

      //   this.getView().setModel(this.HeaderModel, "HeaderModel");
      // },



      _onRouteMatched: function () {
        // Clear table data
        this.getView().getModel("TabModel").setProperty("/Samples", []);

        // Reset header model (if needed)
        this.HeaderModel = new sap.ui.model.json.JSONModel({
          HeaderData: {
            idDateRange: "",
            idPlant: "",
            idMaterial: "",
            idProductionorderno: "",
          }
        });
        this.getView().setModel(this.HeaderModel, "HeaderModel");

        // 🔥 CLEAR INPUT FIELDS BY ID (this is what fixes your issue)
        this.byId("idDateRange").setDateValue(null);
        this.byId("idDateRange").setSecondDateValue(null);

        this.byId("idPlant").setValue("");

        // this.byId("idMaterial").setValue("");
        var oMaterialInput = this.byId("idMaterial");
        oMaterialInput.setValue("");  // Clear the value
        oMaterialInput.removeAllTokens();  // Clear all tokens

        // this.byId("idProductionorderno").setValue("");
        var oPOInput = this.byId("idProductionorderno");
        oPOInput.setValue("");  // Clear the value
        oPOInput.removeAllTokens();  // Clear all tokens
      },




      // onSelectRowNavigate: function (oEvent) {
      //   // Get row data from binding context
      //   const oRowContext = oEvent.getSource().getBindingContext("TabModel");
      //   if (!oRowContext) {
      //     sap.m.MessageToast.show("Unable to read selected row.");
      //     return;
      //   }

      //   const oRowData = oRowContext.getObject();

      //   // Set selected row data to SelectedRow model
      //   const oSelectedRowModel = this.getView().getModel("SelectedRow");
      //   if (oSelectedRowModel) {
      //     oSelectedRowModel.setData(oRowData);
      //   } else {
      //     this.getView().setModel(new sap.ui.model.json.JSONModel(oRowData), "SelectedRow");
      //   }

      //   // Set visible screen to screen2
      //   this.getView().getModel("ScreenVisible").setProperty("/openscreen", "screen2");
      // },

      onGoToScreen1: function () {
        this.getView().getModel("ScreenVisible").setProperty("/openscreen", "screen1");
      },
      
      // ================================================================================
      // ================================================================================
      // ================================================================================


      onSelectAll: function (oEvent) {
        const bSelected = oEvent.getParameter("selected");
        const oTableModel = this.getView().getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples") || [];

        aRows.forEach(row => {
          row.__selected = bSelected;
        });

        oTableModel.setProperty("/Samples", aRows);
      },


      // GoBeltFGActual: function () {
      //   const oView = this.getView();
      //   const oModel = oView.getModel("ZSB_BELTFG_PLAN"); // OData model
      //   const oTabModel = oView.getModel("TabModel");     // Local model

      //   // Get filter inputs
      //   const oDateRange = oView.byId("idDateRange");
      //   const oPlant = oView.byId("idPlant").getValue().trim();
      //   const oMaterial = oView.byId("idMaterial").getValue().trim();
      //   // const oProductGroup = oView.byId("idProductGroup").getValue().trim();
      //   const oProductionOrder = oView.byId("idProductionorderno").getValue().trim();

      //   const oStartDate = oDateRange.getDateValue();
      //   const oEndDate = oDateRange.getSecondDateValue();

      //   // At least one filter is required

      //   // && !oProductGroup
      //   if (
      //     !oStartDate && !oEndDate &&
      //     !oPlant && !oMaterial && !oProductionOrder
      //   ) {
      //     sap.m.MessageBox.warning("Please enter at least one filter criteria.");
      //     return;
      //   }

      //   const aFilters = [];

      //   // Date Range filter (optional)
      //   // if (oStartDate && oEndDate) {
      //   //     const oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
      //   //         pattern: "yyyy-MM-ddTHH:mm:ss"
      //   //     });

      //   //     const sStartDate = oDateFormat.format(new Date(oStartDate.setHours(0, 0, 0, 0)));
      //   //     const sEndDate = oDateFormat.format(new Date(oEndDate.setHours(23, 59, 59, 999)));

      //   //     aFilters.push(new sap.ui.model.Filter({
      //   //         path: "productionordstartdate",
      //   //         operator: sap.ui.model.FilterOperator.BT,
      //   //         value1: sStartDate,
      //   //         value2: sEndDate
      //   //     }));
      //   // }

      //   if (oStartDate && oEndDate) {
      //     const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

      //     const sStartDate = oDateFormat.format(oStartDate); // 'yyyy-MM-dd'
      //     const sEndDate = oDateFormat.format(oEndDate);     // 'yyyy-MM-dd'

      //     aFilters.push(new sap.ui.model.Filter({
      //       path: "productionordstartdate",
      //       operator: sap.ui.model.FilterOperator.BT,
      //       value1: sStartDate,
      //       value2: sEndDate
      //     }));
      //   }


      //   // Add filters only if values are entered
      //   if (oPlant) {
      //     aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
      //   }
      //   if (oMaterial) {
      //     aFilters.push(new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, oMaterial));
      //   }
      //   // if (oProductGroup) {
      //   //     aFilters.push(new sap.ui.model.Filter("productgroup", sap.ui.model.FilterOperator.EQ, oProductGroup));
      //   // }
      //   if (oProductionOrder) {
      //     aFilters.push(new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, oProductionOrder));
      //   }

      //   const oDynamicPage = this.byId("idBeltFGActualDynamic");
      //   if (oDynamicPage) {
      //     oDynamicPage.setShowFooter(true);
      //   }

      //   sap.ui.core.BusyIndicator.show(0);

      //   oModel.read("/ZC_BELTFG_PLAN", {
      //     filters: aFilters,
      //     success: function (oData) {
      //       sap.ui.core.BusyIndicator.hide();

      //       const aFiltered = oData.results.filter(row => {
      //         const prodOrder = row.productionorderno;
      //         return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
      //       });

      //       oTabModel.setProperty("/Samples", aFiltered);
      //       oView.byId("idBeltFGActualtablescreen").setVisible(true);

      //       var Tab_SelectAll = new sap.ui.model.json.JSONModel({
      //         Samples: {
      //           selectall: false
      //         }
      //       });
      //       oView.setModel(Tab_SelectAll, "Tab_SelectAll");

      //     },
      //     error: function () {
      //       sap.ui.core.BusyIndicator.hide();
      //       sap.m.MessageBox.error("Error fetching data. Please try again.");

      //       var Tab_SelectAll = new sap.ui.model.json.JSONModel({
      //         Samples: {
      //           selectall: false
      //         }
      //       });
      //       oView.setModel(Tab_SelectAll, "Tab_SelectAll");

      //     }
      //   });
      // },


      // GoBeltFGActual: function () {
      //   const oView = this.getView();
      //   const oModel = oView.getModel("ZSB_BELTFG_PLAN"); // OData model
      //   const oTabModel = oView.getModel("TabModel");     // Local model

      //   // Get filter inputs
      //   const oDateRange = oView.byId("idDateRange");
      //   const oPlant = oView.byId("idPlant").getValue().trim();


      //   // const oMaterial = oView.byId("idMaterial").getValue().trim();
      //   const oMaterialInput = oView.byId("idMaterial");
      //   const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
      //   const aMaterials = aMaterialTokens.map(t => t.getKey());

      //   const oMI = oView.byId("idProductionorderno");
      //   const aTokens = oMI.getTokens(); // array of sap.m.Token
      //   const aProductionOrders = aTokens.map(t => t.getKey());

      //   const oStartDate = oDateRange.getDateValue();
      //   const oEndDate = oDateRange.getSecondDateValue();

      //   // At least one filter is required
      //   if (!oStartDate && !oEndDate && !oPlant && !aMaterials && aProductionOrders.length === 0) {
      //     sap.m.MessageBox.warning("Please enter at least one filter criteria.");
      //     return;
      //   }

      //   const aFilters = [];

      //   // Date range filter
      //   if (oStartDate && oEndDate) {
      //     const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //     const sStartDate = oDateFormat.format(oStartDate);
      //     const sEndDate = oDateFormat.format(oEndDate);

      //     aFilters.push(new sap.ui.model.Filter({
      //       path: "productionordstartdate",
      //       operator: sap.ui.model.FilterOperator.BT,
      //       value1: sStartDate,
      //       value2: sEndDate
      //     }));
      //   }

      //   // Plant and Material filters
      //   if (oPlant) {
      //     aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
      //   }
      //   // if (oMaterial) {
      //   //     aFilters.push(new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, oMaterial));
      //   // }
      //   // CHANGED: Material filter (multiple materials handled as OR) - same as production orders
      //   if (aMaterials.length > 0) {
      //     const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
      //     const oMaterialCombinedFilter = new sap.ui.model.Filter({
      //       filters: aMaterialFilters,
      //       and: false // OR logic
      //     });
      //     aFilters.push(oMaterialCombinedFilter);
      //   }
      //   // Production order filter (multiple POs handled as OR)
      //   if (aProductionOrders.length > 0) {
      //     const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
      //     const oPOCombinedFilter = new sap.ui.model.Filter({
      //       filters: aPOFilters,
      //       and: false // OR logic
      //     });
      //     aFilters.push(oPOCombinedFilter);
      //   }

      //   const oDynamicPage = this.byId("idBeltFGActualDynamic");
      //   if (oDynamicPage) {
      //     oDynamicPage.setShowFooter(true);
      //   }

      //   sap.ui.core.BusyIndicator.show(0);

      //   oModel.read("/ZC_BELTFG_PLAN", {
      //     filters: aFilters,
      //     success: function (oData) {
      //       sap.ui.core.BusyIndicator.hide();

      //       const aFiltered = oData.results.filter(row => {
      //         const prodOrder = row.productionorderno;
      //         return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
      //       });

      //       oTabModel.setProperty("/Samples", aFiltered);
      //       oView.byId("idBeltFGActualtablescreen").setVisible(true);

      //       const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
      //       oView.setModel(Tab_SelectAll, "Tab_SelectAll");

      //     },
      //     error: function () {
      //       sap.ui.core.BusyIndicator.hide();
      //       sap.m.MessageBox.error("Error fetching data. Please try again.");

      //       const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
      //       oView.setModel(Tab_SelectAll, "Tab_SelectAll");
      //     }
      //   });
      // },


      GoBeltFGActual: function (callback) {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_BELTFG_PLAN"); // OData model
        const oTabModel = oView.getModel("TabModel");     // Local model

        // Get filter inputs
        const oDateRange = oView.byId("idDateRange");
        const oPlant = oView.byId("idPlant").getValue().trim();
        const oShiftComboBox = oView.byId("idshift");
        const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

        const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

        // const oMaterial = oView.byId("idMaterial").getValue().trim();
        const oMaterialInput = oView.byId("idMaterial");
        const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
        const aMaterials = aMaterialTokens.map(t => t.getKey());

        const oMI = oView.byId("idProductionorderno");
        const aTokens = oMI.getTokens(); // array of sap.m.Token
        const aProductionOrders = aTokens.map(t => t.getKey());

        const oStartDate = oDateRange.getDateValue();
        const oEndDate = oDateRange.getSecondDateValue();

        // At least one filter is required
        if (!oStartDate && !oEndDate && !oPlant && !aMaterials && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
          sap.m.MessageBox.warning("Please enter at least one filter criteria.");
          return;
        }

        const aFilters = [];

        // Date range filter
        if (oStartDate && oEndDate) {
          const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          const sStartDate = oDateFormat.format(oStartDate);
          const sEndDate = oDateFormat.format(oEndDate);

          aFilters.push(new sap.ui.model.Filter({
            path: "productionordstartdate",
            operator: sap.ui.model.FilterOperator.BT,
            value1: sStartDate,
            value2: sEndDate
          }));
        }

        // Plant filter
        if (oPlant) {
          aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
        }

        // Shift filter (if a shift is selected)
        if (sSelectedShift) {
          aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
        }

        // BIPL LOT No filter - Added this section
        if (sBiplLotNo) {
          aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
        }

        // Material filter (multiple materials handled as OR)
        if (aMaterials.length > 0) {
          const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
          const oMaterialCombinedFilter = new sap.ui.model.Filter({
            filters: aMaterialFilters,
            and: false // OR logic
          });
          aFilters.push(oMaterialCombinedFilter);
        }

        // Production order filter (multiple POs handled as OR)
        if (aProductionOrders.length > 0) {
          const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
          const oPOCombinedFilter = new sap.ui.model.Filter({
            filters: aPOFilters,
            and: false // OR logic
          });
          aFilters.push(oPOCombinedFilter);
        }

        const oDynamicPage = this.byId("idBeltFGActualDynamic");
        if (oDynamicPage) {
          oDynamicPage.setShowFooter(true);
        }

        sap.ui.core.BusyIndicator.show(0);

        // Call the read function with increased limit
        oModel.read("/ZC_BELTFG_PLAN", {
          filters: aFilters,
          urlParameters: {
            "$top": 10000  // Increased from default to 10,000 records
          },
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            const aFiltered = oData.results.filter(row => {
              const prodOrder = row.productionorderno;
              return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            });

            oTabModel.setProperty("/Samples", aFiltered);
            oView.byId("idBeltFGActualtablescreen").setVisible(true);

            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            // Optional: Log how many records were loaded
            console.log("Loaded " + (aFiltered ? aFiltered.length : 0) + " records after filtering");

            // Call the callback if provided
            if (callback && typeof callback === 'function') {
              callback(aFiltered);
            }

          }.bind(this),

          error: function (oError) {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Error fetching data. Please try again.");
            console.error("OData read error:", oError);

            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            // Call callback with empty array on error
            if (callback && typeof callback === 'function') {
              callback([]);
            }
          }
        });
      },

      onFilterReleaseStatus: function () {
        const oView = this.getView();
        const oComboBox = oView.byId("comboReleaseStatusFilter");
        const sSelectedStatus = oComboBox.getSelectedKey();
        const oTabModel = oView.getModel("TabModel");

        // If "All" is selected or no status, just reload data
        if (!sSelectedStatus || sSelectedStatus === "") {
          this.GoBeltFGActual();
          return;
        }

        // Show loading
        sap.ui.core.BusyIndicator.show(0);

        // Fetch data with callback for filtering
        this.GoBeltFGActual(function (fetchedData) {
          sap.ui.core.BusyIndicator.hide();

          if (!fetchedData || fetchedData.length === 0) {
            sap.m.MessageToast.show("No data available to filter");
            return;
          }

          // Filter data based on selected status
          const aFilteredData = fetchedData.filter(item => {
            if (sSelectedStatus === "RELEASED") {
              // For released: status must be exactly "RELEASED"
              return item.releasestatus === "RELEASED";
            } else {
              // For unreleased: status is empty, null, undefined, or just whitespace
              return !item.releasestatus ||
                item.releasestatus.trim() === "" ||
                item.releasestatus === " ";
            }
          });

          // Update the model
          oTabModel.setProperty("/Samples", aFilteredData);

          // Show message
          if (sSelectedStatus === "RELEASED") {
            sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} released records`);
          } else {
            sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} unreleased records`);
          }
        });
      },


      // ontypeconfirmedqty: function (oEvent) {
      //   const oInput = oEvent.getSource();
      //   const sNewValue = oInput.getValue();

      //   // Get the binding context and row data
      //   const oContext = oInput.getBindingContext("TabModel");
      //   const oRowData = oContext.getObject();

      //   const iConfirmedQty = parseFloat(sNewValue);
      //   const iProductionOrderQty = parseFloat(oRowData.productionorderqty);

      //   // Validate inputs
      //   // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
      //   //   sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
      //   //   oInput.setValue(""); // Clear the input
      //   //   oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
      //   //   oContext.getModel().refresh(); // Reflect change in UI
      //   //   return;
      //   // }

      //   if (iConfirmedQty > iProductionOrderQty) {
      //     sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
      //     oInput.setValue("");
      //     // oRowData.balanceqty = oRowData.productionorderqty || 0;
      //     oContext.getModel().refresh();
      //     return;
      //   }

      //   // Set Confirmed QTY explicitly if needed
      //   oRowData.confirmedqty = iConfirmedQty;

      //   // Calculate and update Balance QTY
      //   const iBalanceQty = iProductionOrderQty - iConfirmedQty;
      //   // oRowData.balanceqty = iBalanceQty;
      //   oRowData.scrapqty = Number(iBalanceQty.toFixed(3));

      //   // Refresh the model to update UI
      //   oContext.getModel().refresh();
      // },


      ontypeconfirmedqty: function (oEvent) {
        const oInput = oEvent.getSource();
        const sNewValue = oInput.getValue();

        // Get the binding context and row data
        const oContext = oInput.getBindingContext("TabModel");
        const oRowData = oContext.getObject();

        // Handle empty or invalid input - replace with 0
        let iConfirmedQty = parseFloat(sNewValue);
        if (isNaN(iConfirmedQty)) {
          iConfirmedQty = 0;
        }

        const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;

        // Validate inputs
        // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
        //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
        //     oInput.setValue(""); // Clear the input
        //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
        //     oContext.getModel().refresh(); // Reflect change in UI
        //     return;
        // }

        // if (iConfirmedQty > iProductionOrderQty) {
        //     sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
        //     oInput.setValue("");
        //     // oRowData.balanceqty = oRowData.productionorderqty || 0;
        //     oContext.getModel().refresh();
        //     return;
        // }

        // Set Confirmed QTY explicitly if needed
        oRowData.confirmedqty = iConfirmedQty;

        // Calculate and update Balance QTY
        const iBalanceQty = iProductionOrderQty - iConfirmedQty;
        // oRowData.balanceqty = iBalanceQty;
        oRowData.scrapqty = isNaN(iBalanceQty) ? 0.000 : Number(iBalanceQty.toFixed(3));

        // Refresh the model to update UI
        oContext.getModel().refresh();
      },

      ontypescrapqty: function (oEvent) {
        const oInput = oEvent.getSource();
        const sNewValue = oInput.getValue();

        // Get row context
        const oContext = oInput.getBindingContext("TabModel");
        const oRowData = oContext.getObject();

        const iScrapQty = parseFloat(sNewValue);              // this is scrapqty entered
        const iConfirmedQty = parseFloat(oRowData.confirmedqty);

        // Validate confirmed qty exists
        if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
          sap.m.MessageBox.error("Please enter a valid Confirmed QTY before entering Scrap QTY.");
          oInput.setValue("");
          return;
        }

        // Validate scrap qty value
        if (isNaN(iScrapQty) || iScrapQty < 0) {
          sap.m.MessageBox.error("Scrap QTY must be a valid positive number.");
          oInput.setValue("");
          return;
        }

        // Core Rule: Scrap QTY ≤ Confirmed QTY
        if (iScrapQty > iConfirmedQty) {
          sap.m.MessageBox.error("Scrap QTY must be less than or equal to Confirmed QTY.");
          oInput.setValue("");
          return;
        }

        // Update the model properly using setProperty
        oContext.getModel().setProperty(oContext.getPath() + "/scrapqty", iScrapQty);
      },



      onNumericLiveChange: function (oEvent) {
        var sValue = oEvent.getParameter("value");

        // Allow digits, commas, and periods
        var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

        // Optional (if you want to normalize double dots or commas)
        // Limit to only one dot and one comma max
        var hasDot = false;
        var hasComma = false;
        sCleanedValue = sCleanedValue
          .split("")
          .filter(char => {
            if (char === "." && !hasDot) {
              hasDot = true;
              return true;
            } else if (char === "," && !hasComma) {
              hasComma = true;
              return true;
            } else if (/\d/.test(char)) {
              return true;
            }
            return false;
          })
          .join("");

        // Set the cleaned value back if changed
        if (sValue !== sCleanedValue) {
          oEvent.getSource().setValue(sCleanedValue);
        }
      },



      // onImportExl: function () {
      //   const that = this;
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oODataModel = oView.getModel("ZSB_BELTFG_PLAN");

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) {
      //       return cb();
      //     }

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = new Uint8Array(e.target.result);
      //       const workbook = XLSX.read(data, { type: "array" });
      //       const sheetName = workbook.SheetNames[0];
      //       const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const aSamples = oTabModel.getProperty("/Samples") || [];
      //       const aNotFound = [];

      //       sap.ui.core.BusyIndicator.show(0);

      //       const aUpdatePromises = jsonData.map((importRow) => {
      //         const plant = importRow["Plant"];
      //         const prodOrder = importRow["Production Order No"];

      //         const matchedRow = aSamples.find(item =>
      //           item.plant === plant && item.productionorderno === prodOrder
      //         );

      //         if (!matchedRow || !matchedRow.sap_uuid) {
      //           aNotFound.push(prodOrder);
      //           return null;
      //         }

      //         const parseDecimal = (val) => {
      //           const parsed = parseFloat(val);
      //           return isNaN(parsed) ? "0.000" : parsed.toFixed(3);
      //         };

      //         const oPayload = {
      //           confirmedqty: parseDecimal(importRow["Confirmed Qty"]),
      //           compoundcode: parseDecimal(importRow["compoundcode"]),
      //           // defectqty: parseDecimal(importRow["Defect Qty"]),
      //           balanceqty: parseDecimal(importRow["Balance Qty"]),
      //           // manufacturingdate: importRow["Manufacturing Date"] ? new Date(importRow["Manufacturing Date"]) : null,
      //           // batchweight: String(importRow["Batch Weight"] || ""),
      //           operator: String(importRow["Operator"] || ""),
      //           inspector: String(importRow["Inspector"] || "")
      //         };



      //         // ✅ Update model row for UI (safe now)
      //         matchedRow.confirmedqty = oPayload.confirmedqty;
      //         matchedRow.compoundcode = oPayload.compoundcode;
      //         // matchedRow.defectqty = oPayload.defectqty;
      //         matchedRow.balanceqty = oPayload.balanceqty;
      //         // matchedRow.manufacturingdate = oPayload.manufacturingdate;
      //         // matchedRow.batchweight = oPayload.batchweight;
      //         matchedRow.operator = oPayload.operator;
      //         matchedRow.inspector = oPayload.inspector;

      //         // 🔑 Construct OData entity key
      //         const sKey = oODataModel.createKey("/ZC_BELTFG_PLAN", {
      //           sap_uuid: matchedRow.sap_uuid
      //         });

      //         // 🔁 Return update promise
      //         return new Promise((resolve, reject) => {
      //           oODataModel.update(sKey, oPayload, {
      //             success: resolve,
      //             error: reject
      //           });
      //         });
      //       }).filter(Boolean); // remove any nulls (not found rows)

      //       Promise.allSettled(aUpdatePromises).then(results => {
      //         sap.ui.core.BusyIndicator.hide();

      //         const aFailed = results.filter(r => r.status === "rejected");
      //         let msg = `${results.length - aFailed.length} rows updated successfully.`;
      //         if (aFailed.length > 0) msg += `\n${aFailed.length} rows failed to update.`;
      //         if (aNotFound.length > 0) {
      //           msg += `\n\nThe following Production Orders were not found or missing sap_uuid:\n${aNotFound.join(", ")}`;
      //         }

      //         sap.m.MessageBox.information(msg);
      //         oTabModel.refresh(true);
      //       });
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsArrayBuffer(file);
      //   }

      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";
      //   fileInput.onchange = function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   };
      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },



      onExportExl: function () {
        const oModel = this.getView().getModel("TabModel");
        const aData = oModel.getProperty("/Samples");

        if (!aData || aData.length === 0) {
          sap.m.MessageBox.warning("No data to export.");
          return;
        }

        // Filter selected rows
        const aSelectedRows = aData.filter(row => row.__selected);

        // Use selected rows if available, else use all rows
        const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

        const aColumns = [
          { label: "Plant", property: "plant" },
          { label: "Production Order No", property: "productionorderno" },
          { label: "bipllotno", property: "bipllotno" },
          { label: "shift", property: "shift" },
          { label: "Material Code", property: "materialcode" },
          { label: "Description", property: "description" },
          { label: "Machine Number", property: "machinenumber" },
          { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
          { label: "Production Order Qty", property: "productionorderqty" },
          // { label: "Lot/Batch-No", property: "lotbatchno" },
          { label: "Storage Location", property: "storagelocation" },
          { label: "compoundcode", property: "compoundcode" },
          { label: "Confirmed Qty", property: "confirmedqty" },
          { label: "Scrap Qty", property: "scrapqty" },

          // { label: "Defect Qty", property: "defectQty" },
          // { label: "Balance Qty", property: "balanceQty" },
          // { label: "UOM", property: "uom" },
          // { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
          // { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
          // { label: "Batch Weight", property: "batchweight" },
          { label: "Operator", property: "operator" },
          { label: "Inspector", property: "inspector" },
          { label: "Released Status", property: "releasestatus" },
          { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
          { label: "Confirmation Count", property: "gicnfconfirmationcount" },
          { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
          { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
          { label: "GR Material Doc Year", property: "grmaterialdocyear" },
          { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
          // { label: "Status of Production Order", property: "statusOfProdOrd" }
        ];

        const oSpreadsheet = new sap.ui.export.Spreadsheet({
          workbook: {
            columns: aColumns,
            context: {
              sheetName: "BeltFG Acyual"
            }
          },
          dataSource: aExportData,
          fileName: "BeltFG_Actual_Export.xlsx"
        });

        oSpreadsheet.build()
          .then(() => {
            sap.m.MessageToast.show("Export completed.");
          })
          .catch(function (oError) {
            sap.m.MessageBox.error("Export failed: " + oError.message);
          });
      },



      // onExporttoImport: function () {
      //   const oModel = this.getView().getModel("TabModel");
      //   const aData = oModel.getProperty("/Samples");

      //   if (!aData || aData.length === 0) {
      //     sap.m.MessageBox.warning("No data to export.");
      //     return;
      //   }

      //   // 🔍 Check for selected rows
      //   const aSelectedRows = aData.filter(row => row.__selected);
      //   const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

      //   const aColumns = [
      //     { label: "Plant", property: "plant" },
      //     { label: "Production Order No", property: "productionorderno" },
      //     { label: "Confirmed Qty", property: "confirmedQty" },
      //     { label: "compoundcode", property: "compoundcode" },
      //     // { label: "Defect Qty", property: "defectQty" },
      //     { label: "Balance Qty", property: "balanceQty" },
      //     // { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
      //     // { label: "Batch Weight", property: "batchweight" },
      //     { label: "Operator", property: "operator" },
      //     { label: "Inspector", property: "inspector" },
      //   ];

      //   const oSpreadsheet = new sap.ui.export.Spreadsheet({
      //     workbook: {
      //       columns: aColumns,
      //       context: {
      //         sheetName: "BeltFG Plan"
      //       }
      //     },
      //     dataSource: aExportData,
      //     fileName: "Export_to_Import.xlsx"
      //   });

      //   oSpreadsheet.build()
      //     .then(() => {
      //       sap.m.MessageToast.show("Export completed.");
      //     })
      //     .catch(function (oError) {
      //       sap.m.MessageBox.error("Export failed: " + oError.message);
      //     });
      // },



      onExporttoImport: function () {
        const oModel = this.getView().getModel("TabModel");
        const aData = oModel.getProperty("/Samples");

        if (!aData || aData.length === 0) {
          sap.m.MessageBox.warning("No data to export.");
          return;
        }

        // 🔍 Check for selected rows
        const aSelectedRows = aData.filter(row => row.__selected);
        const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

        const aColumns = [
          { label: "Plant", property: "plant" },
          { label: "Production Order No", property: "productionorderno" },
          { label: "Confirmed Qty", property: "confirmedqty" },
          // { label: "compoundcode", property: "compoundcode" },
          // { label: "Defect Qty", property: "defectQty" },
          // { label: "Scrap Qty", property: "balanceqty" },
          { label: "Scrap Qty", property: "scrapqty" },
          { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
          // { label: "Batch Weight", property: "batchweight" },
          // { label: "Operator", property: "operator" },
          // { label: "Inspector", property: "inspector" },
        ];

        const oSpreadsheet = new sap.ui.export.Spreadsheet({
          workbook: {
            columns: aColumns,
            context: {
              sheetName: "BeltFG Actual"
            }
          },
          dataSource: aExportData,
          fileName: "BeltFGActualExporttoImport.xlsx"
        });

        oSpreadsheet.build()
          .then(() => {
            sap.m.MessageToast.show("Export completed.");
          })
          .catch(function (oError) {
            sap.m.MessageBox.error("Export failed: " + oError.message);
          });
      },

      onImportExl: function () {
        const that = this;
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oODataModel = oView.getModel("ZSB_BELTFG_PLAN");

        function ensureXLSX(cb) {
          if (window.XLSX) {
            return cb();
          }

          const script = document.createElement("script");
          script.src = importexcelfile;
          script.onload = cb;
          script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
          document.head.appendChild(script);
        }

        function doImport(file) {
          const reader = new FileReader();
          reader.onload = function (e) {
            const data = new Uint8Array(e.target.result);

            // IMPORTANT FIXES
            const workbook = XLSX.read(data, {
              type: "array",
              raw: true,          // DO NOT let XLSX auto-convert dates
              cellDates: false    // Prevent JS Date creation
            });

            const sheetName = workbook.SheetNames[0];

            const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
              raw: true,          // return raw Excel values
              defval: ""          // avoid undefined
            });

            if (!jsonData.length) {
              sap.m.MessageToast.show("No data found in the Excel sheet.");
              return;
            }

            const aSamples = oTabModel.getProperty("/Samples") || [];
            const aUpdatedRows = [];
            const aNotFound = [];
            const aUpdatePromises = []; // Array to hold OData update promises

            sap.ui.core.BusyIndicator.show(0);

            jsonData.forEach((importRow) => {
              const plant = importRow["Plant"];
              const prodOrder = importRow["Production Order No"];

              // MATCH THE ROW
              const matchedRowIndex = aSamples.findIndex(item =>
                item.plant === plant && item.productionorderno === prodOrder
              );

              if (matchedRowIndex === -1) {
                aNotFound.push(prodOrder);
                return;
              }

              const matchedRow = aSamples[matchedRowIndex];

              // Check if row has sap_uuid (required for OData update)
              if (!matchedRow.sap_uuid) {
                aNotFound.push(prodOrder + " (missing sap_uuid)");
                return;
              }

              // DECIMAL PARSER
              const parseDecimal = (val) => {
                if (val === undefined || val === null) return "0.000";
                const cleaned = String(val).replace(/[^\d.-]/g, '');
                const parsed = parseFloat(cleaned);
                return isNaN(parsed) ? "0.000" : parsed.toFixed(3);
              };

              // FIXED DATE HANDLING — ALWAYS DD-MM-YYYY
              let manufacturingDate = null;
              const rawDateValue = importRow["Manufacturing Date"];

              if (rawDateValue) {
                // CASE 1: Excel stored as number (Excel serial date)
                if (typeof rawDateValue === "number") {
                  const excelEpoch = new Date(1899, 11, 30);
                  manufacturingDate = new Date(excelEpoch.getTime() + rawDateValue * 86400000);
                }
                // CASE 2: dd-mm-yyyy string
                else if (typeof rawDateValue === "string" && /^\d{1,2}-\d{1,2}-\d{4}$/.test(rawDateValue)) {
                  const [day, month, year] = rawDateValue.split("-").map(Number);
                  manufacturingDate = new Date(year, month - 1, day);
                }
                // CASE 3: yyyy-mm-dd
                else if (typeof rawDateValue === "string" && /^\d{4}-\d{1,2}-\d{1,2}$/.test(rawDateValue)) {
                  const [year, month, day] = rawDateValue.split("-").map(Number);
                  manufacturingDate = new Date(year, month - 1, day);
                }
                // fallback
                else {
                  const parsed = new Date(rawDateValue);
                  if (!isNaN(parsed)) manufacturingDate = parsed;
                }
              }

              // FINAL VALIDATION
              if (manufacturingDate && isNaN(manufacturingDate.getTime())) {
                manufacturingDate = null;
              }

              // Prepare payload for OData update
              const oPayload = {
                confirmedqty: parseDecimal(importRow["Confirmed Qty"]),
                scrapqty: parseDecimal(importRow["Scrap Qty"]),
                manufacturingdate: manufacturingDate,
                // Include other fields if needed
                compoundcode: parseDecimal(importRow["compoundcode"]),
                operator: String(importRow["Operator"] || ""),
                inspector: String(importRow["Inspector"] || "")
              };

              // UPDATE UI MODEL
              aSamples[matchedRowIndex] = {
                ...aSamples[matchedRowIndex],
                confirmedqty: oPayload.confirmedqty,
                scrapqty: oPayload.scrapqty,
                manufacturingdate: oPayload.manufacturingdate,
                // compoundcode: oPayload.compoundcode,
                // operator: oPayload.operator,
                // inspector: oPayload.inspector
              };

              // Create OData update promise
              const sKey = oODataModel.createKey("/ZC_BELTFG_PLAN", {
                sap_uuid: matchedRow.sap_uuid
              });

              const updatePromise = new Promise((resolve, reject) => {
                oODataModel.update(sKey, oPayload, {
                  success: function (oData) {
                    resolve({
                      prodOrder: prodOrder,
                      status: "success"
                    });
                  },
                  error: function (oError) {
                    reject({
                      prodOrder: prodOrder,
                      error: oError.message || "Unknown error"
                    });
                  }
                });
              });

              aUpdatePromises.push(updatePromise);
              aUpdatedRows.push(prodOrder);
            });

            // Update UI model immediately for better UX
            oTabModel.setProperty("/Samples", aSamples);
            oTabModel.refresh(true);

            // Execute all OData updates
            Promise.allSettled(aUpdatePromises)
              .then(function (results) {
                sap.ui.core.BusyIndicator.hide();

                const aSuccessful = results.filter(r => r.status === "fulfilled");
                const aFailed = results.filter(r => r.status === "rejected");

                // Build result message
                let msg = `UI Updated: ${aUpdatedRows.length} row(s).\n`;
                msg += `Database Updated: ${aSuccessful.length} row(s) successfully.\n`;

                if (aFailed.length > 0) {
                  msg += `Database Failed: ${aFailed.length} row(s) failed to update:\n`;
                  aFailed.forEach((failed, index) => {
                    msg += `${failed.reason.prodOrder}: ${failed.reason.error}\n`;
                  });
                }

                if (aNotFound.length > 0) {
                  msg += `\nNot Found: ${aNotFound.length} Production Order(s):\n${aNotFound.join(", ")}`;
                }

                sap.m.MessageBox.information(msg, {
                  title: "Import Results",
                  details: aFailed.length > 0 ?
                    aFailed.map(f => `${f.reason.prodOrder}: ${f.reason.error}`).join('\n') :
                    "All updates completed successfully"
                });
              })
              .catch(function (error) {
                sap.ui.core.BusyIndicator.hide();
                sap.m.MessageBox.error("Error during database update: " + error.message);
              });

          };

          reader.onerror = function () {
            sap.m.MessageToast.show("Error reading Excel file.");
            sap.ui.core.BusyIndicator.hide();
          };

          reader.readAsArrayBuffer(file);
        }

        // FILE INPUT TRIGGER
        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".xlsx,.xls";
        fileInput.style.display = "none";

        fileInput.onchange = function (e) {
          const file = e.target.files[0];
          if (!file) return;
          ensureXLSX(() => doImport(file));
          document.body.removeChild(fileInput);
        };

        document.body.appendChild(fileInput);
        fileInput.click();
      },




      // ------------------------------------------------------------------------------------------------------------------------------------------
      // For Goods issue Confirmation - Start
      // ------------------------------------------------------------------------------------------------------------------------------------------


      // OnAPIPost_Confirmation: async function () {
      //   const that = this;
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // Confirmation OData //ZSB_TB_FT_PRODCONF

      //   const aRows = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aRows.filter(row => row.__selected);

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("Please select at least one row.");
      //     return;
      //   }

      //   const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");

      //   if (aWithGI.length > 0) {
      //     // Extract production order numbers from those rows
      //     const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);

      //     // Create message string
      //     const sMessage =
      //       "Goods Issue already exists for the following Production Orders:\n\n" +
      //       aProdOrders.join(", ") +
      //       "\n\nPlease unselect them before proceeding.";

      //     sap.m.MessageBox.warning(sMessage);
      //     return;
      //   }

      //   // Check if all selected rows are released
      //   const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
      //   if (aUnreleased.length > 0) {
      //     sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
      //     return;
      //   }


      //   // const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
      //   // if (aWithGI.length > 0) {
      //   //     sap.m.MessageBox.warning("Goods Issue already exists for one or more selected rows. Cannot proceed.");
      //   //     return;
      //   // }



      //   const aMissingQty = aSelectedRows.filter(row => {
      //     const val = row.confirmedqty;
      //     return val === "" || val === null || val === undefined || isNaN(val) || parseFloat(val) <= 0;
      //   });

      //   if (aMissingQty.length > 0) {
      //     sap.m.MessageBox.error("Please enter a valid Confirmed QTY (greater than 0) for all selected rows.");
      //     return;
      //   }

      //   // const aMissingQty = aSelectedRows.filter(row => !row.confirmedqty);

      //   // if (aMissingQty.length > 0) {
      //   //     sap.m.MessageBox.error("Please enter Confirmed QTY for all selected rows.");
      //   //     return;
      //   // }




      //   sap.ui.core.BusyIndicator.show(0);

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const oRow = aSelectedRows[i];

      //     try {
      //       // Apply filters
      //       const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
      //       const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

      //       await new Promise((resolve, reject) => {
      //         oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
      //           filters: [oFilter1, oFilter2],
      //           success: async function (OData) {
      //             if (OData.results.length === 0) {
      //               sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
      //               return resolve();
      //             }

      //             const oData = OData.results[0];

      //             // Calculate work quantities
      //             const calcQty = (qty, total, ref) => (qty * total) / ref;
      //             const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oData.OperationReferenceQuantity);
      //             const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oData.OperationReferenceQuantity);
      //             const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oData.OperationReferenceQuantity);
      //             const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oData.OperationReferenceQuantity);
      //             const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oData.OperationReferenceQuantity);
      //             const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oData.OperationReferenceQuantity);

      //             // Call Confirm Issue API
      //             let ManufacturingOrderOperation = oData.ManufacturingOrderOperation;
      //             let GR_NO = await that.ToConfirmIssueAPIPost(
      //               ManufacturingOrderOperation,
      //               opconfirmedworkquantity1,
      //               opconfirmedworkquantity2,
      //               opconfirmedworkquantity3,
      //               opconfirmedworkquantity4,
      //               opconfirmedworkquantity5,
      //               opconfirmedworkquantity6,
      //               oRow // <-- pass the row
      //             );

      //             const matDoc = GR_NO[0].materialdocument;
      //             oRow.gicnfmaterialdocnumber = GR_NO[0].materialdocument;
      //             oRow.gicnfmaterialdocyear = GR_NO[0].matdocyear;
      //             oRow.gicnfconfirmationgroup = GR_NO[0].confirmationgroup;
      //             oRow.gicnfconfirmationcount = GR_NO[0].confirmationcount;

      //             oTabModel.refresh();

      //             if (!matDoc) {
      //               let ErrorMessage = "Some error occurred while posting.";
      //               try {
      //                 const kk = JSON.parse(GR_NO[0].errorresponse);
      //                 ErrorMessage = kk.error.message.value;
      //               } catch (e) {
      //                 // ignore
      //               }
      //               sap.m.MessageBox.error(ErrorMessage);
      //             } else {
      //               await that.ToUpdateIntTab(oRow, matDoc, GR_NO[0]);
      //               sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
      //               that.FinalStatus = new sap.ui.model.json.JSONModel({
      //                 MSGSTRIP: {
      //                   visible: true,
      //                   text: "Material Document No - Goods Issue : " + matDoc,
      //                   type: 'Success'
      //                 }
      //               });
      //               oView.setModel(that.FinalStatus, "FinalStatus");
      //             }

      //             resolve();
      //           },
      //           error: function (error) {
      //             console.log(error);
      //             sap.ui.core.BusyIndicator.hide();
      //             reject(error);
      //           }
      //         });
      //       });

      //     } catch (e) {
      //       console.error("Error in confirmation:", e);
      //     }
      //   }

      //   sap.ui.core.BusyIndicator.hide();
      // },


      // ToConfirmIssueAPIPost: function (ManufacturingOrderOperation, opconfirmedworkquantity1, opconfirmedworkquantity2, opconfirmedworkquantity3, opconfirmedworkquantity4, opconfirmedworkquantity5, opconfirmedworkquantity6) {

      //   return new Promise(async (resolve, reject) => {
      //     sap.ui.core.BusyIndicator.show();



      //     const oView = this.getView();
      //     const oTabModel = oView.getModel("TabModel");

      //     const aRows = oTabModel.getProperty("/Samples");
      //     const iSelectedIndex = aRows.findIndex(row => row.__selected);

      //     if (iSelectedIndex === -1) {
      //       sap.m.MessageToast.show("Please select a row.");
      //       return;
      //     }

      //     const oSelectedRow = aRows[iSelectedIndex];



      //     var that = this;
      //     sap.ui.core.BusyIndicator.hide();
      //     sap.m.MessageBox.information("Do you want to post this data.", {
      //       actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
      //       emphasizedAction: sap.m.MessageBox.Action.YES,
      //       onClose: async function (sAction) {
      //         if (sAction === "YES") {

      //           sap.ui.core.BusyIndicator.show();

      //           // ************** Start For Header *********************
      //           const postIDTableLevel = new Promise((resolve, reject) => {

      //             var oEntry = {
      //               orderid: oSelectedRow.productionorderno,
      //               orderoperation: ManufacturingOrderOperation,
      //               ordersuboperation: "0000",
      //               // "ConfirmationUnit"  : "KG",
      //               //  "ConfirmationUnitISOCode" : "PCE",
      //               confirmationyieldquantity: String(oSelectedRow.confirmedqty),
      //               //  "ConfirmationScrapQuantity" : "0",
      //               //  "OpWorkQuantityUnit1" : "HR",
      //               //  "WorkQuantityUnit1ISOCode"  : "HR",
      //               opconfirmedworkquantity1: String(opconfirmedworkquantity1),
      //               opconfirmedworkquantity2: String(opconfirmedworkquantity2),
      //               opconfirmedworkquantity3: String(opconfirmedworkquantity3),
      //               opconfirmedworkquantity4: String(opconfirmedworkquantity4),
      //               opconfirmedworkquantity5: String(opconfirmedworkquantity5),
      //               opconfirmedworkquantity6: String(opconfirmedworkquantity6),
      //               // uom:"",
      //               materialdocument: "",
      //               matdocyear: "",
      //               sequence: "0000",
      //               // "response" : ""
      //               confirmationgroup: "",
      //               confirmationcount: "",
      //               finalconfirmationtype: "X",
      //               scrapqty: parseFloat(oSelectedRow.balanceqty).toFixed(3)

      //             };
      //             console.log("oEntryoEntry:", oEntry);

      //             that.getView().setModel();

      //             var oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");//ZSB_TB_FT_PRODCONF

      //             oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
      //               success: function (oData, oResponse) {

      //                 console.log(oData);
      //                 console.log(oData.response);

      //                 console.log(oData)
      //                 // oModelGet.refresh(true);
      //                 sap.ui.core.BusyIndicator.hide();
      //                 resolve(oData);
      //               },

      //               error: function (error) {
      //                 console.log("error");
      //                 sap.ui.core.BusyIndicator.hide();
      //                 sap.m.MessageBox.error("Process Failed...")
      //                 reject(error)
      //               }
      //             });

      //           });
      //           // / ************** End For Header *********************

      //           let OutPutData = await Promise.all([postIDTableLevel]);

      //           // ************************************************************

      //           resolve(OutPutData);

      //         } else {
      //           sap.m.MessageToast.show("Cancelled");
      //           sap.ui.core.BusyIndicator.hide();
      //         }
      //       }
      //     });
      //   });
      // },

      // ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

      //   return new Promise((resolve, reject) => {
      //     sap.ui.core.BusyIndicator.show();
      //     var that = this;
      //     var oModelGet = that.getView().getModel("ZSB_BELTFG_PLAN");
      //     // oModelGet.setHeaders({
      //     //     "X-Requested-With": "X",
      //     //     "Content-Type": "application/json"
      //     // });

      //     var oEntry = {
      //       confirmedqty: String(HeaderModel.confirmedqty),
      //       // confirmedqty: String(HeaderModel.confirmedqty),
      //       balanceqty: String(HeaderModel.balanceqty), // ✅ Added balanceqty
      //       gicnfmaterialdocnumber: resp.materialdocument,
      //       gicnfmaterialdocyear: resp.matdocyear,
      //       gicnfconfirmationgroup: resp.confirmationgroup,
      //       gicnfconfirmationcount: resp.confirmationcount,


      //     };

      //     oModelGet.update("/ZC_BELTFG_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
      //       success: function (oData, oResponse) {
      //         console.log("Goods Issue No Updated Successfully...")
      //         resolve(oData);
      //       },

      //       error: function (error) {
      //         console.log("error");
      //         sap.ui.core.BusyIndicator.hide();
      //         sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
      //         reject(error)
      //       }
      //     });

      //   });
      // },


      // OnAPIPost_Confirmation: async function () {
      //   const that = this;
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
      //   const aRows = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aRows.filter(row => row.__selected);

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("Please select at least one row.");
      //     return;
      //   }

      //   const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
      //   if (aWithGI.length > 0) {
      //     const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
      //     const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
      //       aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";
      //     sap.m.MessageBox.warning(sMessage);
      //     return;
      //   }

      //   const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
      //   if (aUnreleased.length > 0) {
      //     sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
      //     return;
      //   }


      //   const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");

      //   if (aNotUpdated.length > 0) {
      //     // Extract Production Orders that are not updated
      //     const aNotUpdatedProdOrders = aNotUpdated.map(row => row.productionorderno).filter(Boolean);

      //     const sMessage = "The following Production Orders are not updated:\n\n" +
      //       aNotUpdatedProdOrders.join(", ") + "\n\nPlease ensure these rows are updated before proceeding.";

      //     sap.m.MessageBox.error(sMessage);
      //     return;
      //   }

      //   // const aMissingQty = aSelectedRows.filter(row => {
      //   //     const val = row.confirmedqty;
      //   //     return val === "" || val === null || val === undefined || isNaN(val) || parseFloat(val) <= 0;
      //   // });

      //   // if (aMissingQty.length > 0) {
      //   //     sap.m.MessageBox.error("Please enter a valid Confirmed QTY (greater than 0) for all selected rows.");
      //   //     return;
      //   // }

      //   const aMissingQty = aSelectedRows.filter(row => {
      //     const confirmedVal = row.confirmedqty;
      //     const balanceVal = row.scrapqty;

      //     // Function to check zero or empty values for qty fields
      //     const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;

      //     // Check if confirmedqty invalid (null, empty, NaN, or negative)
      //     const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;

      //     // Check if BOTH confirmedqty and scrapqty are zero/null (or equivalent)
      //     const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);

      //     // Return true if either:
      //     // 1) confirmedqty is invalid (negative, missing, NaN)
      //     // OR
      //     // 2) both confirmedqty and scrapqty are zero/null
      //     return confirmedInvalid || bothZeroOrNull;
      //   });

      //   if (aMissingQty.length > 0) {
      //     sap.m.MessageBox.error("Please enter a valid Confirmed QTY (0 or greater) for all selected rows. If the value is empty, please add 0.");
      //     return;
      //   }
      //   // NEW VALIDATION: Check if sum of confirmedqty + scrapqty equals productionorderqty
      //   const aQtyMismatch = aSelectedRows.filter(row => {
      //     const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
      //     const iBalanceQty = parseFloat(row.scrapqty) || 0;
      //     const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;

      //     const iTotalQty = iConfirmedQty + iBalanceQty;

      //     // Use tolerance for floating point comparison
      //     const dTolerance = 0.0001;
      //     return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
      //   });

      //   if (aQtyMismatch.length > 0) {
      //     const aProdOrders = aQtyMismatch.map(row => row.productionorderno).filter(Boolean);
      //     const sMessage = `The sum of Confirmed QTY and Scrap QTY must equal Production Order QTY for the following Production Orders:\n\n${aProdOrders.join(", ")}\n\nPlease adjust the quantities before proceeding.`;
      //     sap.m.MessageBox.error(sMessage);
      //     return;
      //   }

      //   // ✅ Confirm before processing
      //   sap.m.MessageBox.confirm("Do you want to post the selected data?", {
      //     actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
      //     emphasizedAction: sap.m.MessageBox.Action.YES,
      //     onClose: async function (sAction) {
      //       if (sAction === sap.m.MessageBox.Action.YES) {
      //         sap.ui.core.BusyIndicator.show(0);

      //         let allSuccessful = true;

      //         for (let i = 0; i < aSelectedRows.length; i++) {
      //           const oRow = aSelectedRows[i];

      //           try {
      //             const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
      //             const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

      //             await new Promise((resolve, reject) => {
      //               oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
      //                 filters: [oFilter1, oFilter2],
      //                 success: async function (OData) {
      //                   if (OData.results.length === 0) {
      //                     sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
      //                     allSuccessful = false;
      //                     return resolve();
      //                   }

      //                   const oData = OData.results[0];
      //                   const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;

      //                   const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
      //                   const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
      //                   const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
      //                   const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
      //                   const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
      //                   const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);

      //                   const ManufacturingOrderOperation = oData.ManufacturingOrderOperation;

      //                   const postResult = await that.ToConfirmIssueAPIPost(
      //                     ManufacturingOrderOperation,
      //                     opconfirmedworkquantity1,
      //                     opconfirmedworkquantity2,
      //                     opconfirmedworkquantity3,
      //                     opconfirmedworkquantity4,
      //                     opconfirmedworkquantity5,
      //                     opconfirmedworkquantity6,
      //                     oRow
      //                   );

      //                   const matDoc = postResult.materialdocument;
      //                   oRow.gicnfmaterialdocnumber = postResult.materialdocument;
      //                   oRow.gicnfmaterialdocyear = postResult.matdocyear;
      //                   oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
      //                   oRow.gicnfconfirmationcount = postResult.confirmationcount;

      //                   oTabModel.refresh();

      //                   if (!matDoc) {
      //                     let ErrorMessage = "Some error occurred while posting.";
      //                     try {
      //                       const kk = JSON.parse(postResult.errorresponse);
      //                       ErrorMessage = kk.error.message.value;
      //                     } catch (e) { }
      //                     sap.m.MessageBox.error(ErrorMessage);
      //                     allSuccessful = false;
      //                   } else {
      //                     await that.ToUpdateIntTab(oRow, matDoc, postResult);
      //                     that.FinalStatus = new sap.ui.model.json.JSONModel({
      //                       MSGSTRIP: {
      //                         visible: true,
      //                         text: "Material Document No - Goods Issue : " + matDoc,
      //                         type: 'Success'
      //                       }
      //                     });
      //                     oView.setModel(that.FinalStatus, "FinalStatus");
      //                   }

      //                   resolve();
      //                 },
      //                 error: function (error) {
      //                   console.log(error);
      //                   sap.ui.core.BusyIndicator.hide();
      //                   allSuccessful = false;
      //                   reject(error);
      //                 }
      //               });
      //             });

      //           } catch (e) {
      //             console.error("Error in confirmation:", e);
      //             allSuccessful = false;
      //           }
      //         }

      //         sap.ui.core.BusyIndicator.hide();

      //         // ✅ Final message at the end
      //         if (allSuccessful) {
      //           sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
      //         } else {
      //           sap.m.MessageBox.warning("Process completed with some errors. Check details.");
      //         }
      //       }
      //     }
      //   });
      // },


      // ToConfirmIssueAPIPost: function (
      //   ManufacturingOrderOperation,
      //   opconfirmedworkquantity1,
      //   opconfirmedworkquantity2,
      //   opconfirmedworkquantity3,
      //   opconfirmedworkquantity4,
      //   opconfirmedworkquantity5,
      //   opconfirmedworkquantity6,
      //   oSelectedRow
      // ) {
      //   return new Promise(async (resolve, reject) => {
      //     sap.ui.core.BusyIndicator.show();

      //     const that = this;
      //     const oEntry = {
      //       orderid: oSelectedRow.productionorderno,
      //       orderoperation: ManufacturingOrderOperation,
      //       ordersuboperation: "0000",
      //       confirmationyieldquantity: String(oSelectedRow.confirmedqty),
      //       opconfirmedworkquantity1: String(opconfirmedworkquantity1),
      //       opconfirmedworkquantity2: String(opconfirmedworkquantity2),
      //       opconfirmedworkquantity3: String(opconfirmedworkquantity3),
      //       opconfirmedworkquantity4: String(opconfirmedworkquantity4),
      //       opconfirmedworkquantity5: String(opconfirmedworkquantity5),
      //       opconfirmedworkquantity6: String(opconfirmedworkquantity6),
      //       materialdocument: "",
      //       matdocyear: "",
      //       sequence: "0000",
      //       confirmationgroup: "",
      //       confirmationcount: "",
      //       finalconfirmationtype: "X",
      //       scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3)
      //     };
      //     console.log("payload bring posrted: ", oEntry)

      //     const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");

      //     oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
      //       success: function (oData) {
      //         sap.ui.core.BusyIndicator.hide();
      //         resolve(oData); // ✅ Return the object directly
      //       },
      //       error: function (error) {
      //         sap.ui.core.BusyIndicator.hide();
      //         sap.m.MessageBox.error("Process Failed...");
      //         reject(error);
      //       }
      //     });
      //   });
      // },



      // ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

      //   return new Promise((resolve, reject) => {
      //     sap.ui.core.BusyIndicator.show();
      //     var that = this;
      //     var oModelGet = that.getView().getModel("ZSB_BELTFG_PLAN");
      //     // oModelGet.setHeaders({
      //     //     "X-Requested-With": "X",
      //     //     "Content-Type": "application/json"
      //     // });

      //     var oEntry = {
      //       confirmedqty: String(HeaderModel.confirmedqty),
      //       // confirmedqty: String(HeaderModel.confirmedqty),
      //       scrapqty: String(HeaderModel.scrapqty), // ✅ Added scrapqty
      //       gicnfmaterialdocnumber: resp.materialdocument,
      //       gicnfmaterialdocyear: resp.matdocyear,
      //       gicnfconfirmationgroup: resp.confirmationgroup,
      //       gicnfconfirmationcount: resp.confirmationcount,


      //     };

      //     oModelGet.update("/ZC_BELTFG_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
      //       success: function (oData, oResponse) {
      //         console.log("Goods Issue No Updated Successfully...")
      //         resolve(oData);
      //       },

      //       error: function (error) {
      //         console.log("error");
      //         sap.ui.core.BusyIndicator.hide();
      //         sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
      //         reject(error)
      //       }
      //     });

      //   });
      // },



      OnAPIPost_Confirmation: async function () {
        const that = this;
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
        const aRows = oTabModel.getProperty("/Samples");
        let aSelectedRows = aRows.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        // Arrays to track results
        const aSuccessRows = [];
        const aFailedRows = [];
        const aSkippedRows = [];

        // Run validations first
        const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
        if (aWithGI.length > 0) {
          const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
          const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
            aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";

          // Track skipped rows
          aWithGI.forEach(row => {
            aSkippedRows.push({
              productionOrder: row.productionorderno,
              reason: "Goods Issue already exists"
            });
          });

          // Remove already GI rows from processing
          aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));

          if (aSelectedRows.length === 0) {
            this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            return;
          }
        }

        const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
        if (aUnreleased.length > 0) {
          // Track unreleased rows
          aUnreleased.forEach(row => {
            aSkippedRows.push({
              productionOrder: row.productionorderno,
              reason: "Not released"
            });
          });

          // Remove unreleased rows from processing
          aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
        }

        const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
        if (aNotUpdated.length > 0) {
          // Track not updated rows
          aNotUpdated.forEach(row => {
            aSkippedRows.push({
              productionOrder: row.productionorderno,
              reason: "Not updated (status not GT)"
            });
          });

          // Remove not updated rows from processing
          aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
        }

        const aMissingQty = aSelectedRows.filter(row => {
          const confirmedVal = row.confirmedqty;
          const balanceVal = row.scrapqty;
          const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
          const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
          const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
          return confirmedInvalid || bothZeroOrNull;
        });

        if (aMissingQty.length > 0) {
          // Track missing quantity rows
          aMissingQty.forEach(row => {
            aSkippedRows.push({
              productionOrder: row.productionorderno,
              reason: "Invalid quantity values"
            });
          });

          // Remove missing quantity rows from processing
          aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
        }

        const aQtyMismatch = aSelectedRows.filter(row => {
          const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
          const iBalanceQty = parseFloat(row.scrapqty) || 0;
          const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
          const iTotalQty = iConfirmedQty + iBalanceQty;
          const dTolerance = 0.0001;
          return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
        });

        if (aQtyMismatch.length > 0) {
          // Track quantity mismatch rows
          aQtyMismatch.forEach(row => {
            aSkippedRows.push({
              productionOrder: row.productionorderno,
              reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
            });
          });

          // Remove quantity mismatch rows from processing
          aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
        }

        // Check if any rows remain to process
        if (aSelectedRows.length === 0) {
          // Show summary if all rows were skipped during validation
          this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
          return;
        }

        // ✅ Confirm before processing
        sap.m.MessageBox.confirm("Do you want to post the selected data?", {
          actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
          emphasizedAction: sap.m.MessageBox.Action.YES,
          onClose: async function (sAction) {
            if (sAction === sap.m.MessageBox.Action.YES) {
              // Show loading indicator ONCE at the beginning
              sap.ui.core.BusyIndicator.show(0);

              // Process each row individually
              for (let i = 0; i < aSelectedRows.length; i++) {
                const oRow = aSelectedRows[i];

                try {
                  const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                  const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                  const oData = await new Promise((resolve, reject) => {
                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                      filters: [oFilter1, oFilter2],
                      success: function (OData) {
                        resolve(OData);
                      },
                      error: function (error) {
                        reject(error);
                      }
                    });
                  });

                  console.log("Response:", oData);

                  if (oData.results.length === 0) {
                    aFailedRows.push({
                      productionOrder: oRow.productionorderno,
                      error: `YBP4 data not found for order ${oRow.productionorderno}`
                    });
                    continue; // Skip to next row
                  }

                  // Activity - Confirmation qty + Scrap qty * Operation qty/base qty
                  const oResultData = oData.results[0];
                  // const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;
                  // const calcQty = (qty, total, scrap, ref) =>
                  //   (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

                  const calcQty = (qty, total, scrap, ref) => {
                    const result =
                      (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

                    // round to 3 decimals and return as NUMBER
                    return Number(result.toFixed(3));
                  };

                  const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                  const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                  const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                  const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                  const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                  const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

                  const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

                  const postResult = await that.ToConfirmIssueAPIPost(
                    ManufacturingOrderOperation,
                    opconfirmedworkquantity1,
                    opconfirmedworkquantity2,
                    opconfirmedworkquantity3,
                    opconfirmedworkquantity4,
                    opconfirmedworkquantity5,
                    opconfirmedworkquantity6,
                    oRow
                  );

                  const matDoc = postResult.materialdocument;

                  if (!matDoc) {
                    let ErrorMessage = "Some error occurred while posting.";
                    try {
                      const kk = JSON.parse(postResult.errorresponse);
                      ErrorMessage = kk.error.message.value;
                    } catch (e) { }

                    aFailedRows.push({
                      productionOrder: oRow.productionorderno,
                      error: ErrorMessage
                    });
                  } else {
                    // Update row with material document
                    oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                    oRow.gicnfmaterialdocyear = postResult.matdocyear;
                    oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                    oRow.gicnfconfirmationcount = postResult.confirmationcount;

                    // Update internal table
                    await that.ToUpdateIntTab(oRow, matDoc, postResult);

                    aSuccessRows.push({
                      productionOrder: oRow.productionorderno,
                      materialDocument: matDoc
                    });
                  }

                } catch (error) {
                  console.error("Error in confirmation for order:", oRow.productionorderno, error);
                  aFailedRows.push({
                    productionOrder: oRow.productionorderno,
                    error: error.message || "Unknown error"
                  });
                }
              }

              // Refresh table once at the end
              oTabModel.refresh();

              // Hide loading indicator only after all processing is complete
              sap.ui.core.BusyIndicator.hide();

              // Show summary
              that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            }
          }
        });
      },

      // Show confirmation summary
      showConfirmationSummary: function (aSuccessRows, aFailedRows, aSkippedRows) {
        const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `Confirmation process completed.\n\n`;
        let bHasSuccess = aSuccessRows.length > 0;
        let bHasSkipped = aSkippedRows.length > 0;
        let bHasFailed = aFailedRows.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
          aSuccessRows.forEach(row => {
            sMessage += `   - ${row.productionOrder}`;
            if (row.materialDocument) {
              sMessage += ` (Material Doc: ${row.materialDocument})`;
            }
            sMessage += `\n`;
          });
          sMessage += "\n";

          // Update FinalStatus with last successful material document
          if (aSuccessRows.length > 0) {
            const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
            this.FinalStatus = new sap.ui.model.json.JSONModel({
              MSGSTRIP: {
                visible: true,
                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                type: 'Success'
              }
            });
            this.getView().setModel(this.FinalStatus, "FinalStatus");
          }
        }

        if (bHasSkipped) {
          sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
          aSkippedRows.forEach(row => {
            sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
          aFailedRows.forEach(row => {
            sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
          });
        }

        // Determine which type of message to show
        setTimeout(() => {
          if (bHasFailed) {
            // Show detailed error dialog with summary
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.ERROR,
                title: "Confirmation Process Summary",
                actions: [sap.m.MessageBox.Action.OK],
                details: aFailedRows.map(f =>
                  `Production Order: ${f.productionOrder}\nError: ${f.error}`
                ).join('\n\n')
              }
            );
          } else if (bHasSkipped) {
            // Show warning dialog with summary
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.WARNING,
                title: "Confirmation Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          } else if (bHasSuccess) {
            // Show success dialog with summary (big section for all cases)
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.SUCCESS,
                title: "Confirmation Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          }
        }, 100);
      },

      ToConfirmIssueAPIPost: function (
        ManufacturingOrderOperation,
        opconfirmedworkquantity1,
        opconfirmedworkquantity2,
        opconfirmedworkquantity3,
        opconfirmedworkquantity4,
        opconfirmedworkquantity5,
        opconfirmedworkquantity6,
        oSelectedRow
      ) {
        return new Promise((resolve, reject) => {
          const that = this;
          const oEntry = {
            orderid: oSelectedRow.productionorderno,
            orderoperation: ManufacturingOrderOperation,
            ordersuboperation: "0000",
            confirmationyieldquantity: String(oSelectedRow.confirmedqty),
            opconfirmedworkquantity1: String(opconfirmedworkquantity1),
            opconfirmedworkquantity2: String(opconfirmedworkquantity2),
            opconfirmedworkquantity3: String(opconfirmedworkquantity3),
            opconfirmedworkquantity4: String(opconfirmedworkquantity4),
            opconfirmedworkquantity5: String(opconfirmedworkquantity5),
            opconfirmedworkquantity6: String(opconfirmedworkquantity6),
            materialdocument: "",
            matdocyear: "",
            sequence: "0000",
            confirmationgroup: "",
            confirmationcount: "",
            finalconfirmationtype: "X",
            scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3)
          };

          console.log("payload being posted: ", oEntry);

          const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");

          oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
            success: function (oData) {
              resolve(oData);
            },
            error: function (error) {
              reject(error);
            }
          });
        });
      },

      ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {
        return new Promise((resolve, reject) => {
          var that = this;
          var oModelGet = that.getView().getModel("ZSB_BELTFG_PLAN");

          var oEntry = {
            confirmedqty: String(HeaderModel.confirmedqty),
            scrapqty: String(HeaderModel.scrapqty),
            gicnfmaterialdocnumber: resp.materialdocument,
            gicnfmaterialdocyear: resp.matdocyear,
            gicnfconfirmationgroup: resp.confirmationgroup,
            gicnfconfirmationcount: resp.confirmationcount,
          };

          oModelGet.update("/ZC_BELTFG_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            success: function (oData, oResponse) {
              console.log("Goods Issue No Updated Successfully...");
              resolve(oData);
            },
            error: function (error) {
              console.log("Error updating internal table:", error);
              reject(error);
            }
          });
        });
      },


      // ------------------------------------------------------------------------------------------------------------------------------------------
      // Goods reciept start
      // ------------------------------------------------------------------------------------------------------------------------------------------




      // onGoodsReceiptPress: async function () {
      //   const oView = this.getView();
      //   const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
      //   const oTabModel = oView.getModel("TabModel");
      //   const aRows = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aRows.filter(row => row.__selected);

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("Please select at least one row.");
      //     return;
      //   }

      //   let aBlockerErrors = [];

      //   aSelectedRows.forEach((row) => {
      //     let errors = [];

      //     if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
      //       errors.push("Missing Goods Issue Confirmation");
      //     }

      //     if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
      //       errors.push("Goods Receipt already exists");
      //     }

      //     if (errors.length > 0) {
      //       const sProdOrder = row.productionorderno || "(No Production Order)";
      //       aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
      //     }
      //   });

      //   if (aBlockerErrors.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
      //     );
      //     return;
      //   }

      //   // --- 🧪 VALIDATION (field completeness)
      //   let aValidationErrors = [];

      //   aSelectedRows.forEach((row) => {
      //     let missingFields = [];

      //     // if (!row.batchweight) missingFields.push("Batch Weight");
      //     if (!row.operator) missingFields.push("Operator");
      //     if (!row.inspector) missingFields.push("Inspector");
      //     // if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

      //     if (missingFields.length > 0) {
      //       const sProdOrder = row.productionorderno || "(No Production Order)";
      //       aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
      //     }
      //   });

      //   if (aValidationErrors.length > 0) {
      //     sap.m.MessageBox.error(
      //       "Missing required fields:\n\n" + aValidationErrors.join("\n")
      //     );
      //     return;
      //   }


      //   // --- ✅ PROCESSING (all validations passed)
      //   sap.ui.core.BusyIndicator.show(0);

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     const oPayload = {
      //       material: row.materialcode,
      //       plant: row.plant,
      //       storagelocation: row.storagelocation,
      //       goodsmovementtype: "101",
      //       manufacturingorder: row.productionorderno,
      //       // manufacturedate:null,
      //       // manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //       goodsmovementrefdoctype: "F",
      //       quantityinentryunit: String(row.confirmedqty),
      //       postingdate: new Date(),
      //       goodsmovementcode: "02"
      //     };

      //     try {
      //       const oData = await new Promise((resolve, reject) => {
      //         oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       row.grmaterialdocnumber = oData.materialdocument;
      //       row.grmaterialdocyear = oData.matdocyear;
      //       // row.batchweight = String(row.confirmedqty);

      //       const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
      //       // row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

      //       await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

      //     } catch (oError) {
      //       console.error(`❌ GR Failed for row ${i + 1}:`, oError);
      //       sap.m.MessageBox.error(`Goods Receipt failed for row ${i + 1}. See console for details.`);
      //       continue; // Optionally stop or continue
      //     }
      //   }

      //   oTabModel.setProperty("/Samples", aRows);
      //   oTabModel.refresh();
      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("Goods Receipt process completed.");
      // },









      // sap.ui.core.BusyIndicator.hide();
      // ------------------------------------------------------------------------------------------------------------------------------------------
      // Update 
      // ------------------------------------------------------------------------------------------------------------------------------------------

      onUpdatePress: function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oODataModel = oView.getModel("ZSB_BELTFG_PLAN");
        const aSamples = oTabModel.getProperty("/Samples") || [];

        const aSelectedRows = aSamples.filter(item => item.__selected === true);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row to update.");
          return;
        }

        sap.ui.core.BusyIndicator.show(0);

        const aUpdatePromises = aSelectedRows.map(item => {

          const sKey = oODataModel.createKey("/ZC_BELTFG_PLAN", {
            sap_uuid: item.sap_uuid,
          });

          // Prepare payload with only editable fields
          const oPayload = {
            // confirmedqty: String(parseInt(item.confirmedqty)),
            // scrapqty: String(parseInt(item.scrapqty)),
            confirmedqty: String(item.confirmedqty),
            scrapqty: String(item.scrapqty),
            manufacturingdate: item.manufacturingdate ? new Date(item.manufacturingdate.toLocaleDateString('en-CA')) : null,
            updatestatusgistatus: "GT"
          };

          return new Promise((resolve, reject) => {
            oODataModel.update(sKey, oPayload, {
              success: resolve,
              error: reject
            });
          });
        });

        Promise.allSettled(aUpdatePromises).then(results => {
          sap.ui.core.BusyIndicator.hide();

          const aFailed = results.filter(r => r.status === "rejected");
          const aSuccess = results.filter(r => r.status === "fulfilled");

          let sMsg = `${aSuccess.length} row(s) updated successfully.`;
          if (aFailed.length > 0) {
            sMsg += `\n${aFailed.length} row(s) failed to update.`;
          }

          sap.m.MessageBox.information(sMsg);
          oTabModel.refresh(true);
          this.GoBeltFGActual()
        });
      },



      // onReleasePress: async function () {
      //           const oView = this.getView();
      //           const oTableModel = oView.getModel("TabModel");
      //           const aRows = oTableModel.getProperty("/Samples");
      //           const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
      //           const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN");
      //           const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

      //           const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

      //           if (aSelectedRows.length === 0) {
      //               sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
      //               return;
      //           }

      //           sap.ui.core.BusyIndicator.show(0);

      //           // Process rows one by one
      //           for (let i = 0; i < aSelectedRows.length; i++) {
      //               const row = aSelectedRows[i];
      //               const sManufacturingOrder = row.productionorderno;

      //               if (!sManufacturingOrder) {
      //                   console.warn(`Row ${i + 1} skipped: No production order.`);
      //                   row.releasestatus = "";
      //                   oTableModel.refresh();
      //                   continue;
      //               }

      //               try {
      //                   // Step 1: Check status from ZC_ORDER_CREATION - wait for response
      //                   const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

      //                   if (bStatusActive) {
      //                       console.log(`Row ${i + 1}: Status I0002 is active - already released.`);

      //                       // Update BeltFG plan
      //                       await this.updateBeltFGPlan(oBeltFGPlanModel, row, true);

      //                       // Update UI
      //                       row.releasestatus = "RELEASED";
      //                       oTableModel.refresh();

      //                       sap.m.MessageToast.show(`Row ${i + 1}: Already released.`);
      //                       continue; // Skip to next row
      //                   }

      //                   // Step 2: Create release - wait for response
      //                   const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

      //                   if (bReleaseSuccess) {
      //                       // Step 3: Update BeltFG plan - wait for response
      //                       await this.updateBeltFGPlan(oBeltFGPlanModel, row, false);

      //                       // Update UI
      //                       row.releasestatus = "RELEASED";
      //                       oTableModel.refresh();

      //                       console.log(`✅ Row ${i + 1} released successfully`);
      //                       sap.m.MessageToast.show(`Row ${i + 1}: Released successfully`);
      //                   } else {
      //                       row.releasestatus = "";
      //                       oTableModel.refresh();
      //                       console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
      //                   }

      //               } catch (error) {
      //                   console.error(`❌ Error processing row ${i + 1}:`, error);
      //                   row.releasestatus = "";
      //                   oTableModel.refresh();
      //               }
      //           }

      //           // Final refresh and cleanup
      //           oTableModel.setProperty("/Samples", aRows);
      //           oTableModel.refresh();
      //           sap.ui.core.BusyIndicator.hide();
      //           sap.m.MessageToast.show("Release process completed.");
      //       },

      //       // Helper function to check order status
      //       checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
      //           return new Promise((resolve, reject) => {
      //               const aFilters = [
      //                   new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
      //               ];

      //               oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
      //                   filters: aFilters,
      //                   success: function (oData) {
      //                       const aResults = oData.results;
      //                       const bExists = aResults.some(function (oItem) {
      //                           return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
      //                       });
      //                       resolve(bExists);
      //                   },
      //                   error: function (oError) {
      //                       reject(oError);
      //                   }
      //               });
      //           });
      //       },

      //       // Helper function to create release
      //       createRelease: function (oModel, sManufacturingOrder) {
      //           return new Promise((resolve, reject) => {
      //               const oPayload = {
      //                   ManufacturingOrder: sManufacturingOrder
      //               };

      //               oModel.create("/ZC_PROD_STATUS1", oPayload, {
      //                   success: function (oData) {
      //                       if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
      //                           sap.m.MessageToast.show("Check material availability");
      //                           resolve(false);
      //                           return;
      //                       }
      //                       resolve(true);
      //                   },
      //                   error: function (oError) {
      //                       reject(oError);
      //                   }
      //               });
      //           });
      //       },

      //       // Helper function to update BeltFG plan
      //       updateBeltFGPlan: function (oBeltFGPlanModel, row, bAlreadyReleased) {
      //           return new Promise((resolve, reject) => {
      //               const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
      //               const oUpdateEntry = {
      //                   releasestatus: "RELEASED",
      //                   batchweight: row.batchweight || "",
      //                   operator: row.operator || "",
      //                   inspector: row.inspector || "",
      //                   manufacturingdate: row.manufacturingdate ?
      //                       new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //                   confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
      //               };

      //               oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
      //                   success: function () {
      //                       console.log(`🔄 BeltFG Plan updated`);
      //                       resolve(true);
      //                   },
      //                   error: function (oError) {
      //                       if (!bAlreadyReleased) {
      //                           reject(oError);
      //                       } else {
      //                           // If already released, still resolve (don't fail the process)
      //                           resolve(true);
      //                       }
      //                   }
      //               });
      //           });
      //       },





      onReleasePress: async function () {
        const oView = this.getView();
        const oTableModel = oView.getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples");
        const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
        const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN");
        const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

        const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
          return;
        }

        sap.ui.core.BusyIndicator.show(0);

        // Arrays to track results
        const aSuccessRows = [];
        const aFailedRows = [];
        const aAlreadyReleasedRows = [];

        // Process rows one by one
        for (let i = 0; i < aSelectedRows.length; i++) {
          const row = aSelectedRows[i];
          const sManufacturingOrder = row.productionorderno;

          if (!sManufacturingOrder) {
            console.warn(`Row ${i + 1} skipped: No production order.`);
            row.releasestatus = "";
            aFailedRows.push({
              rowNumber: i + 1,
              productionOrder: "No Production Order",
              error: "No production order number"
            });
            continue;
          }

          try {
            // Step 1: Check status from ZC_ORDER_CREATION
            const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

            if (bStatusActive) {
              console.log(`Row ${i + 1}: Status I0002 is active - already released.`);
              aAlreadyReleasedRows.push({
                rowNumber: i + 1,
                productionOrder: sManufacturingOrder
              });

              // Update BeltFG plan
              await this.updateBeltFGPlan(oBeltFGPlanModel, row, true);

              // Update UI
              row.releasestatus = "RELEASED";
              continue;
            }

            // Step 2: Create release
            const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

            if (bReleaseSuccess) {
              // Step 3: Update BeltFG plan
              await this.updateBeltFGPlan(oBeltFGPlanModel, row, false);

              // Update UI
              row.releasestatus = "RELEASED";
              aSuccessRows.push({
                rowNumber: i + 1,
                productionOrder: sManufacturingOrder
              });
              console.log(`✅ Row ${i + 1} released successfully`);
            } else {
              row.releasestatus = "";
              aFailedRows.push({
                rowNumber: i + 1,
                productionOrder: sManufacturingOrder,
                error: "Release creation failed - check material availability"
              });
              console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
            }

          } catch (error) {
            console.error(`❌ Error processing row ${i + 1}:`, error);
            row.releasestatus = "";
            aFailedRows.push({
              rowNumber: i + 1,
              productionOrder: sManufacturingOrder,
              error: error.message || "Unknown error"
            });
          }
        }

        // Final refresh and cleanup
        oTableModel.setProperty("/Samples", aRows);
        oTableModel.refresh();
        sap.ui.core.BusyIndicator.hide();

        // Show summary message
        this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
      },

      // New function to show summary
      // showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
      //   const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

      //   let sMessage = `Release process completed for ${sTotal} rows.\n\n`;

      //   if (aSuccessRows.length > 0) {
      //     sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
      //     aSuccessRows.forEach(row => {
      //       sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
      //     });
      //     sMessage += "\n";
      //   }

      //   if (aAlreadyReleasedRows.length > 0) {
      //     sMessage += `ℹ️ Already released: ${aAlreadyReleasedRows.length}\n`;
      //     aAlreadyReleasedRows.forEach(row => {
      //       sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
      //     });
      //     sMessage += "\n";
      //   }

      //   if (aFailedRows.length > 0) {
      //     sMessage += `❌ Failed to release: ${aFailedRows.length}\n`;
      //     aFailedRows.forEach(row => {
      //       sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
      //       if (row.error) {
      //         sMessage += `     Error: ${row.error}\n`;
      //       }
      //     });

      //     // Show failed rows in a more detailed dialog
      //     sap.m.MessageBox.show(
      //       sMessage,
      //       {
      //         icon: sap.m.MessageBox.Icon.ERROR,
      //         title: "Release Process Summary",
      //         actions: [sap.m.MessageBox.Action.OK],
      //         details: aFailedRows.map(f =>
      //           `Row ${f.rowNumber} - Production Order: ${f.productionOrder}\nError: ${f.error}`
      //         ).join('\n\n')
      //       }
      //     );
      //   } else {
      //     // If no failures, show success toast
      //     if (aSuccessRows.length > 0 || aAlreadyReleasedRows.length > 0) {
      //       const sSuccessMsg = `${aSuccessRows.length} released successfully, ${aAlreadyReleasedRows.length} were already released.`;
      //       sap.m.MessageToast.show(sSuccessMsg);
      //     }
      //   }
      // },

      showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
        const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `Release process completed for ${sTotal} rows.\n\n`;
        let bHasSuccess = aSuccessRows.length > 0;
        let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
        let bHasFailed = aFailedRows.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
          aSuccessRows.forEach(row => {
            sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
          });
          sMessage += "\n";
        }

        if (bHasAlreadyReleased) {
          sMessage += `ℹ️ Already released: ${aAlreadyReleasedRows.length}\n`;
          aAlreadyReleasedRows.forEach(row => {
            sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to release: ${aFailedRows.length}\n`;
          aFailedRows.forEach(row => {
            sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            if (row.error) {
              sMessage += `     Error: ${row.error}\n`;
            }
          });
        }

        // Always show MessageBox for all cases
        setTimeout(() => {
          if (bHasFailed) {
            // Show error dialog with details
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.ERROR,
                title: "Release Process Summary",
                actions: [sap.m.MessageBox.Action.OK],
                details: aFailedRows.map(f =>
                  `Row ${f.rowNumber} - Production Order: ${f.productionOrder}\nError: ${f.error || "Unknown error"}`
                ).join('\n\n')
              }
            );
          } else {
            // Show success dialog (even if only already released rows)
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.SUCCESS,
                title: "Release Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          }
        }, 100);
      },

      // Helper function to check order status (unchanged)
      checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
        return new Promise((resolve, reject) => {
          const aFilters = [
            new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
          ];

          oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            filters: aFilters,
            success: function (oData) {
              const aResults = oData.results;
              const bExists = aResults.some(function (oItem) {
                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
              });
              resolve(bExists);
            },
            error: function (oError) {
              reject(oError);
            }
          });
        });
      },

      // Helper function to create release (unchanged)
      createRelease: function (oModel, sManufacturingOrder) {
        return new Promise((resolve, reject) => {
          const oPayload = {
            ManufacturingOrder: sManufacturingOrder
          };

          oModel.create("/ZC_PROD_STATUS1", oPayload, {
            success: function (oData) {
              if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
                resolve(false);
                return;
              }
              resolve(true);
            },
            error: function (oError) {
              reject(oError);
            }
          });
        });
      },

      // Helper function to update BeltFG plan (unchanged)
      updateBeltFGPlan: function (oBeltFGPlanModel, row, bAlreadyReleased) {
        return new Promise((resolve, reject) => {
          const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
          const oUpdateEntry = {
            releasestatus: "RELEASED",
            batchweight: row.batchweight || "",
            operator: row.operator || "",
            inspector: row.inspector || "",
            manufacturingdate: row.manufacturingdate ?
              new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
          };

          oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
            success: function () {
              console.log(`🔄 BeltFG Plan updated`);
              resolve(true);
            },
            error: function (oError) {
              if (!bAlreadyReleased) {
                reject(oError);
              } else {
                // If already released, still resolve (don't fail the process)
                resolve(true);
              }
            }
          });
        });
      },





      // onReleasePress: function () {
      //           const oView = this.getView();
      //           const oTableModel = oView.getModel("TabModel");
      //           const aRows = oTableModel.getProperty("/Samples");
      //           const oModel = oView.getModel("ZSB_PRODUCT_ORD1");//ZSD_PRODUCT_ORD // OData backend
      //           const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN"); // For PATCH
      //           const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");//ZSD_PRODUCT_ORD // Using same model for read from ZC_ORDER_CREATION

      //           const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

      //           if (aSelectedRows.length === 0) {
      //               sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
      //               return;
      //           }

      //           sap.ui.core.BusyIndicator.show(0);
      //           const that = this;
      //           let iCompleted = 0;

      //           aSelectedRows.forEach((row, index) => {
      //               const sManufacturingOrder = row.productionorderno;
      //               // debugger


      //               if (!sManufacturingOrder) {
      //                   console.warn(`Row ${index + 1} skipped: No production order.`);
      //                   iCompleted++;
      //                   checkCompletion();
      //                   return;
      //               }

      //               // Step 1: Check status from ZC_ORDER_CREATION
      //               // const sFilter = `/ZC_ORDER_CREATION?$filter=ManufacturingOrder eq '${sManufacturingOrder}'`;
      //               const aFilters = [
      //                   new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
      //               ];
      //               //check
      //               oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
      //                   filters: aFilters,
      //                   success: function (oData) {
      //                       const aResults = oData.results;
      //                       // const oEntry = aResults && aResults[0];
      //                       // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

      //                       // const mapped = aResults.map(entry => {
      //                       //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
      //                       //   });

      //                       //   const oEntry = mapped.find(entry => entry !== null);
      //                       // debugger
      //                       var bExists = aResults.some(function (oItem) {
      //                           return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
      //                       });

      //                       // const iSelectedIndex = aRows.findIndex(row => row.__selected);



      //                       if (bExists) {
      //                           console.log("Combination exists: I0002 and active.");
      //                           // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
      //                           sap.m.MessageToast.show("Rows may already be released.");

      //                           const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
      //                           const oUpdateEntry = {
      //                               releasestatus: "RELEASED",
      //                               // releasestatus: "RELEASED",
      //                               batchweight: row.batchweight || "", // use value if filled
      //                               operator: row.operator || "",
      //                               inspector: row.inspector || "",
      //                               manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //                               confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""

      //                           };
      //                           // debugger

      //                           oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
      //                               success: function () {
      //                                   console.log(`🔄 BeltFGPlan Plan updated for row ${index + 1}`);
      //                                   // checkCompletion();
      //                                   // oTableModel.refresh();
      //                                   row.releasestatus = "RELEASED";
      //                                   oTableModel.setProperty("/Samples", aRows);
      //                                   oTableModel.refresh();


      //                                   checkCompletion01()

      //                               },
      //                               error: function () {
      //                                   row.releasestatus = ""; // revert
      //                                   // console.warn(`⚠️ BeltFGPlan Plan update failed for row ${index + 1}`);
      //                                   // checkCompletion();
      //                                   // oTableModel.setProperty("/Samples", aRows);
      //                                   // oTableModel.refresh();
      //                                   // aRows[iSelectedIndex].releasestatus = "RELEASED";
      //                                   checkCompletion01()

      //                               }
      //                           });

      //                           sap.ui.core.BusyIndicator.hide(0);
      //                           return
      //                       }


      //                       // StatusCode
      //                       //StatusIsActive
      //                       // debugger

      //                       // // Check if status should skip this row
      //                       // if (oEntry && oEntry.StatusCode === "10002" && oEntry.StatusIsActive === true) {
      //                       //     console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
      //                       //     // debugger
      //                       //     // iCompleted++;
      //                       //     // checkCompletion();
      //                       //     return;
      //                       // }

      //                       // Continue with create + update logic

      //                       const oPayload = {
      //                           ManufacturingOrder: sManufacturingOrder
      //                       };
      //                       // debugger

      //                       oModel.create("/ZC_PROD_STATUS1", oPayload, {
      //                           success: function (oData) {
      //                               // debugger
      //                               console.log(`✅ Release POST success for row ${index + 1}`, oData);
      //                               if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
      //                                   // 🚫 Stop release and just inform user
      //                                   sap.m.MessageToast.show("Check material availability");
      //                                   row.releasestatus = ""; // keep as not released
      //                                   sap.ui.core.BusyIndicator.hide();

      //                                   // checkCompletion();
      //                                   return;
      //                               }
      //                               row.releasestatus = "RELEASED";

      //                               const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
      //                               const oUpdateEntry = {
      //                                   releasestatus: "RELEASED",
      //                                   // releasestatus: "RELEASED",
      //                                   batchweight: row.batchweight || "", // use value if filled
      //                                   operator: row.operator || "",
      //                                   inspector: row.inspector || "",
      //                                   manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //                                   confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""

      //                               };
      //                               // debugger


      //                               oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
      //                                   success: function () {
      //                                       console.log(`🔄 BeltFGPlan Plan updated for row ${index + 1}`);
      //                                       checkCompletion();
      //                                   },
      //                                   error: function () {
      //                                       row.releasestatus = ""; // revert
      //                                       console.log(`⚠️ BeltFGPlan Plan update failed for row ${index + 1}`);
      //                                       checkCompletion();
      //                                   }
      //                               });
      //                           },
      //                           error: function (oError) {
      //                               row.releasestatus = ""; // revert
      //                               console.error(`❌ Release POST failed for row ${index + 1}`, oError);
      //                               checkCompletion();
      //                           }
      //                       });
      //                   },
      //                   error: function (oError) {
      //                       console.error(`🔍 Status check failed for row ${index + 1}`, oError);
      //                       iCompleted++;
      //                       checkCompletion();
      //                   }
      //               });
      //           });

      //           function checkCompletion() {
      //               iCompleted++;
      //               if (iCompleted === aSelectedRows.length) {
      //                   oTableModel.setProperty("/Samples", aRows);
      //                   oTableModel.refresh();
      //                   sap.ui.core.BusyIndicator.hide();
      //                   sap.m.MessageToast.show("Release process completed.");
      //               }
      //           }
      //           function checkCompletion01() {
      //               iCompleted++;
      //               if (iCompleted === aSelectedRows.length) {
      //                   oTableModel.setProperty("/Samples", aRows);

      //                   oTableModel.refresh();
      //                   sap.ui.core.BusyIndicator.hide();
      //                   // sap.m.MessageToast.show("Release process completed.");
      //               }
      //           }
      //       },

      // ===========================================================================================================
      // ===========================================================================================================
      // ===========================================================================================================
      // onReleaseFragmentPress: function () {
      //   const oView = this.getView();
      //   const oTableModel = oView.getModel("TabModel");
      //   const aRows = oTableModel.getProperty("/Samples");

      //   // Get selected rows from main table
      //   const aSelectedRows = aRows.filter(row => row.__selected);

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("Please select a row first.");
      //     return;
      //   }
      //   if (aSelectedRows.length > 1) {
      //     sap.m.MessageToast.show("Please select only one row.");
      //     return;
      //   }

      //   // ✅ Save selected rows for later use
      //   oTableModel.setProperty("/SelectedRowData", aSelectedRows);

      //   sap.ui.core.BusyIndicator.show(0);

      //   // Step 1: Get Manufacturing Order (production order number)
      //   const sProdOrderNo = aSelectedRows[0].productionorderno;
      //   const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

      //   // Step 2: First fetch Reservation from ZC_RESERVATION_COMPONENT
      //   const aReservationFilter = [
      //     new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
      //   ];

      //   oODataModel.read("/ZC_RESERVATION_COMPONENT", {
      //     filters: aReservationFilter,
      //     success: function (oReservationData) {
      //       const aResults = oReservationData.results;

      //       if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
      //         sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
      //         return;
      //       }

      //       const sReservation = aResults[0].Reservation;

      //       // Step 3: Now fetch BOM data from ZC_RELEASE_BOM using Reservation
      //       // const aBomFilters = [
      //       //   new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
      //       // ];

      //       // oODataModel.read("/ZC_RELEASE_BOM", {
      //       //   filters: aBomFilters,
      //       //   success: function (oBomData) {
      //       //     oTableModel.setProperty("/BomRelease", oBomData.results || []);

      //       //     // Open fragment if not already open
      //       //     if (!this._oBomReleaseDialog) {
      //       //       this._oBomReleaseDialog = sap.ui.xmlfragment(
      //       //         "bando.view.CommonFragments.ActualScreens.BomRelease",
      //       //         this
      //       //         // bando.view.CommonFragments.ActualScreens.BomRelease
      //       //       );
      //       //       oView.addDependent(this._oBomReleaseDialog);
      //       //     }
      //       //     this._oBomReleaseDialog.open();
      //       //     sap.ui.core.BusyIndicator.hide();
      //       //   }.bind(this),
      //       //   error: function (oError) {
      //       //     sap.m.MessageToast.show("Error fetching BOM Release data.");
      //       //     console.error(oError);
      //       //   }
      //       // });
      //       const aBomFilters = [
      //         new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
      //       ];

      //       oODataModel.read("/ZC_RELEASE_BOM", {
      //         filters: aBomFilters,
      //         success: function (oBomData) {
      //           // Filter out items where the Quantity (ResvnItmRequiredQtyInBaseUnit) is essentially 0
      //           const aFilteredBomData = oBomData.results.filter(function (item) {
      //             // Explicitly check if the quantity is not zero (allow for floating-point precision issues)
      //             return parseFloat(item.ResvnItmRequiredQtyInBaseUnit) !== 0;
      //           });

      //           // If no valid data exists after filtering, show a message
      //           if (aFilteredBomData.length === 0) {
      //             sap.m.MessageToast.show("No valid BOM data with non-zero quantities.");
      //           }





      //           // Set the filtered data to the model
      //           oTableModel.setProperty("/BomRelease", aFilteredBomData || []);

      //           // Open the fragment dialog if it's not already open
      //           if (!this._oBomReleaseDialog) {
      //             this._oBomReleaseDialog = sap.ui.xmlfragment(
      //               "bando.view.CommonFragments.ActualScreens.BomRelease",
      //               this
      //             );
      //             oView.addDependent(this._oBomReleaseDialog);
      //           }

      //           this._oBomReleaseDialog.open();
      //           sap.ui.core.BusyIndicator.hide();
      //         }.bind(this),
      //         error: function (oError) {
      //           sap.m.MessageToast.show("Error fetching BOM Release data.");
      //           console.error(oError);
      //         }
      //       });

      //     }.bind(this),
      //     error: function (oError) {
      //       sap.m.MessageToast.show("Error fetching Reservation.");
      //       console.error(oError);
      //     }
      //   });
      // },


      // onReleaseCancel: function () {
      //   if (this._oBomReleaseDialog) {
      //     this._oBomReleaseDialog.close();
      //     this._oBomReleaseDialog.destroy();
      //     this._oBomReleaseDialog = null; // reset reference
      //   }
      // },


      // onReleasePress: function () {
      //   const that = this;
      //   const oView = this.getView();
      //   const oTableModel = oView.getModel("TabModel");
      //   const aRows = oTableModel.getProperty("/Samples");
      //   const oModel = oView.getModel("ZSB_PRODUCT_ORD1"); // OData backend for release
      //   const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN"); // For PATCH
      //   const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Same model for status check

      //   // ✅ Use filtered selected rows
      //   const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
      //     return;
      //   }

      //   sap.ui.core.BusyIndicator.show(0);
      //   let iCompleted = 0;

      //   aSelectedRows.forEach((row, index) => {
      //     const sManufacturingOrder = row.productionorderno;
      //     // debugger;

      //     if (!sManufacturingOrder) {
      //       console.warn(`Row ${index + 1} skipped: No production order.`);
      //       iCompleted++;
      //       checkCompletion();
      //       return;
      //     }

      //     // Step 1: Check status from ZC_ORDER_CREATION
      //     const aFilters = [
      //       new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
      //     ];

      //     oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
      //       filters: aFilters,
      //       success: function (oData) {
      //         const aResults = oData.results;
      //         // debugger;

      //         var bExists = aResults.some(function (oItem) {
      //           return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
      //         });

      //         if (bExists) {
      //           console.log("Combination exists: I0002 and active.");
      //           sap.m.MessageToast.show("Rows may already be released.");

      //           // Update BeltFG plan as RELEASED anyway
      //           const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
      //           const oUpdateEntry = {
      //             releasestatus: "RELEASED",
      //             // batchweight: row.batchweight || "",
      //             operator: row.operator || "",
      //             inspector: row.inspector || "",
      //             // manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || "",
      //             scrapqty: parseFloat(row.scrapqty).toFixed(3) || "",
      //           };
      //           // debugger;

      //           oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
      //             success: function () {
      //               console.log(`🔄 BeltFG Plan updated for row ${index + 1}`);
      //               row.releasestatus = "RELEASED";
      //               oTableModel.setProperty("/Samples", aRows);
      //               oTableModel.refresh();
      //               checkCompletion01();
      //             },
      //             error: function () {
      //               row.releasestatus = ""; // revert
      //               checkCompletion01();
      //             }
      //           });

      //           sap.ui.core.BusyIndicator.hide(0);
      //           return;
      //         }

      //         // Step 2: Continue with create logic
      //         const oPayload = { ManufacturingOrder: sManufacturingOrder };
      //         // debugger;

      //         oModel.create("/ZC_PROD_STATUS1", oPayload, {
      //           success: function (oData) {
      //             console.log(`✅ Release POST success for row ${index + 1}`, oData);

      //             if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
      //               sap.m.MessageToast.show("Check material availability");
      //               row.releasestatus = ""; // not released
      //               sap.ui.core.BusyIndicator.hide();
      //               return;
      //             }

      //             row.releasestatus = "RELEASED";

      //             const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
      //             const oUpdateEntry = {
      //               releasestatus: "RELEASED",
      //               // batchweight: row.batchweight || "",
      //               operator: row.operator || "",
      //               inspector: row.inspector || "",
      //               // manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //               confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || "",
      //               scrapqty: parseFloat(row.scrapqty).toFixed(3) || "",
      //             };
      //             // debugger;

      //             oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
      //               success: function () {
      //                 console.log(`🔄 BeltFG Plan updated for row ${index + 1}`);
      //                 checkCompletion();
      //               },
      //               error: function () {
      //                 row.releasestatus = "";
      //                 console.log(`⚠️ BeltFG Plan update failed for row ${index + 1}`);
      //                 checkCompletion();
      //               }
      //             });
      //           },
      //           error: function (oError) {
      //             row.releasestatus = "";
      //             console.error(`❌ Release POST failed for row ${index + 1}`, oError);
      //             checkCompletion();
      //           }
      //         });
      //       },
      //       error: function (oError) {
      //         console.error(`🔍 Status check failed for row ${index + 1}`, oError);
      //         iCompleted++;
      //         checkCompletion();
      //       }
      //     });
      //   });

      //   // function checkCompletion() {
      //   //     iCompleted++;
      //   //     if (iCompleted === aSelectedRows.length) {
      //   //         oTableModel.setProperty("/Samples", aRows);
      //   //         oTableModel.refresh();
      //   //         sap.ui.core.BusyIndicator.hide();
      //   //         sap.m.MessageToast.show("Release process completed.");
      //   //     }
      //   // }
      //   function checkCompletion() {
      //     iCompleted++;
      //     if (iCompleted === aSelectedRows.length) {
      //       oTableModel.setProperty("/Samples", aRows);
      //       oTableModel.refresh();
      //       sap.ui.core.BusyIndicator.hide();

      //       sap.m.MessageToast.show("Release process completed.");

      //       // 🔁 Refresh the BOM data in the fragment
      //       that._refreshBomData();
      //     }
      //   }


      //   function checkCompletion01() {
      //     iCompleted++;
      //     if (iCompleted === aSelectedRows.length) {
      //       oTableModel.setProperty("/Samples", aRows);
      //       oTableModel.refresh();
      //       sap.ui.core.BusyIndicator.hide();
      //       // Optional: sap.m.MessageToast.show("Release process completed.");
      //     }
      //   }
      // },

      // //refetching data after release such that batch is fetched in the bom
      // _refreshBomData: function () {
      //   const oView = this.getView();
      //   const oTableModel = oView.getModel("TabModel");
      //   const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

      //   const aSelectedRows = oTableModel.getProperty("/SelectedRowData");
      //   if (!aSelectedRows || aSelectedRows.length === 0) return;

      //   const sProdOrderNo = aSelectedRows[0].productionorderno;

      //   const aReservationFilter = [
      //     new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
      //   ];

      //   // Step 1: Get Reservation
      //   oODataModel.read("/ZC_RESERVATION_COMPONENT", {
      //     filters: aReservationFilter,
      //     success: function (oReservationData) {
      //       const aResults = oReservationData.results;
      //       if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
      //         sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
      //         return;
      //       }

      //       const sReservation = aResults[0].Reservation;

      //       // Step 2: Fetch BOM
      //       const aBomFilters = [
      //         new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
      //       ];

      //       oODataModel.read("/ZC_RELEASE_BOM", {
      //         filters: aBomFilters,
      //         success: function (oBomData) {
      //           oTableModel.setProperty("/BomRelease", oBomData.results || []);
      //           oTableModel.refresh();
      //           sap.m.MessageToast.show("BOM data refreshed successfully.");
      //         },
      //         error: function (oError) {
      //           console.error("Error fetching refreshed BOM data:", oError);
      //         }
      //       });
      //     },
      //     error: function (oError) {
      //       console.error("Error fetching reservation:", oError);
      //     }
      //   });
      // },

      //===============================================================================================================================
      //===============================================================================================================================
      //===============================================================================================================================


      onRowSelectionChange: async function (oEvent) {
        const oCheckBox = oEvent.getSource();
        const oView = this.getView();

        // Get the table model and all rows
        const oTableModel = oView.getModel("TabModel");
        const aRows = oTableModel.getProperty("/BomRelease");

        // Get the binding context path of the checkbox
        const sPath = oCheckBox.getBindingContext("TabModel").getPath(); // e.g., "/BomRelease/3"
        const iIndex = parseInt(sPath.split("/").pop());

        // Get the selected row data
        const oSelectedRowData = aRows[iIndex];
        console.log("Selected Row Data:", oSelectedRowData);

        // --- Prepare Data for Barcode ---
        const barcodeData = `
                    ManufacturingOrder: ${oSelectedRowData.ManufacturingOrder || ""}
                    Product: ${oSelectedRowData.Product || ""}
                    Plant: ${oSelectedRowData.Plant || ""}
                    StorageLocation: ${oSelectedRowData.StorageLocation || ""}
                    Batch: ${oSelectedRowData.Batch || ""}
                    Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}
                    UOM: ${oSelectedRowData.BaseUnit || ""}
                `;

        // --- Generate Barcode ---
        const canvas = document.createElement("canvas");
        JsBarcode(canvas, oSelectedRowData.ManufacturingOrder || "N/A", {
          format: "CODE128",
          width: 2,
          height: 60,
          displayValue: true
        });

        const barcodeBase64 = canvas.toDataURL("image/png");

        // --- Generate PDF with Barcode ---
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        doc.setFontSize(12);
        doc.text(`Manufacturing Order: ${oSelectedRowData.ManufacturingOrder || ""}`, 20, 30);
        doc.text(`Product: ${oSelectedRowData.Product || ""}`, 20, 40);
        doc.text(`Plant: ${oSelectedRowData.Plant || ""}`, 20, 50);
        doc.text(`Storage Location: ${oSelectedRowData.StorageLocation || ""}`, 20, 60);
        doc.text(`Batch: ${oSelectedRowData.Batch || ""}`, 20, 70);
        doc.text(`Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}`, 20, 80);
        doc.text(`UOM: ${oSelectedRowData.BaseUnit || ""}`, 20, 90);

        // Add Barcode image to PDF
        doc.addImage(barcodeBase64, "PNG", 140, 20, 50, 20);

        // Open PDF in new tab
        const blob = doc.output("blob");
        const pdfUrl = URL.createObjectURL(blob);
        window.open(pdfUrl, "_blank");
      },

      // ======================================================================================
      // ======================================================================================
      // ======================================================================================


      onBatchValueHelp: function (oEvent) {
        const oView = this.getView();
        const oSource = oEvent.getSource();
        this._oBatchInputSource = oSource; // Save for setting value later

        // Load fragment if not already created
        if (!this._oBatchValueHelpDialog) {
          this._oBatchValueHelpDialog = sap.ui.xmlfragment(
            oView.getId(),
            "bando.view.CommonFragments.ActualScreens.bombatchselect",
            this
          );
          oView.addDependent(this._oBatchValueHelpDialog);
        }

        // Get current row data (for filtering)
        const oContext = oSource.getBindingContext("TabModel");
        if (!oContext) {
          sap.m.MessageToast.show("No row context found.");
          return;
        }

        const oRowData = oContext.getObject();
        const sMaterial = oRowData.Product;
        const sPlant = oRowData.Plant;
        const sStorageLoc = oRowData.StorageLocation;

        // Load data before opening
        this._loadBatchData(sMaterial, sPlant, sStorageLoc);
      },

      // ===========================================================
      // Load Batch Data and Bind to Fragment Table
      // ===========================================================
      _loadBatchData: function (sMaterial, sPlant, sStorageLoc) {
        const oView = this.getView();
        const oModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB"); // backend OData model

        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
          new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
          new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
        ];

        const that = this;
        oModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
          filters: aFilters,
          success: function (oData) {
            console.log("✅ Batch data received:", oData);

            // Create JSON model from results array
            const oJSONModel = new sap.ui.model.json.JSONModel(oData.results);

            // Get table from fragment
            const oTable = sap.ui.core.Fragment.byId(oView.getId(), "batchTable");
            if (oTable) {
              oTable.setModel(oJSONModel, "BatchModel");
              console.log("✅ Bound rows:", oJSONModel.getData());
              that._oBatchValueHelpDialog.open();
            } else {
              console.error("❌ batchTable not found in fragment");
            }
          },

          error: function (oError) {
            sap.m.MessageToast.show("Failed to load batch data.");
            console.error("❌ OData Error:", oError);
          }
        });
      },

      // ===========================================================
      // Handle "Select" Button - Set Batch value in Input Field
      // ===========================================================

      // onBatchRowSelect: function (oEvent) {
      //   const oTable = oEvent.getSource();
      //   const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

      //   if (!oSelectedContext) {
      //     sap.m.MessageToast.show("No row selected.");
      //     return;
      //   }

      //   const oSelectedData = oSelectedContext.getObject();

      //   if (this._oBatchInputSource) {
      //     this._oBatchInputSource.setValue(oSelectedData.Batch); // Set selected batch
      //   }

      //   // Close and destroy the dialog to avoid reuse issues
      //   if (this._oBatchValueHelpDialog) {
      //     this._oBatchValueHelpDialog.close();
      //     this._oBatchValueHelpDialog.destroy();
      //     this._oBatchValueHelpDialog = null;
      //   }
      // },

      onBatchRowSelect: function (oEvent) {
        const oTable = oEvent.getSource();
        const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

        if (!oSelectedContext) {
          sap.m.MessageToast.show("No row selected.");
          return;
        }

        const oSelectedData = oSelectedContext.getObject();

        if (this._oBatchInputSource) {
          // Get the current row context in the TabModel
          const oRowContext = this._oBatchInputSource.getBindingContext("TabModel");

          if (oRowContext) {
            const oTabModel = oRowContext.getModel();
            const sRowPath = oRowContext.getPath();

            // Set both Batch and Storage Location
            oTabModel.setProperty(sRowPath + "/Batch", oSelectedData.Batch);
            oTabModel.setProperty(sRowPath + "/StorageLocation", oSelectedData.StorageLocation);

            // Optional: If you want to update the input field value as well
            this._oBatchInputSource.setValue(oSelectedData.Batch);
          }
        }

        // Close and destroy the dialog to avoid reuse issues
        if (this._oBatchValueHelpDialog) {
          this._oBatchValueHelpDialog.close();
          this._oBatchValueHelpDialog.destroy();
          this._oBatchValueHelpDialog = null;
        }
      },

      // ===========================================================
      // Handle "Cancel" Button
      // ===========================================================
      onValueHelpCancel: function () {
        if (this._oBatchValueHelpDialog) {
          this._oBatchValueHelpDialog.close();
          this._oBatchValueHelpDialog.destroy(); // cleanup
          this._oBatchValueHelpDialog = null; // reset reference
        }
      },






      // ------------------------------------------------------------------------------------------------------------------------------------------
      // Release END
      // ------------------------------------------------------------------------------------------------------------------------------------------





      // ------------------------------------------------------------------------------------------------------------------------------------------
      // Reverse reciept start
      // ------------------------------------------------------------------------------------------------------------------------------------------













      onReverseReceiptPress: function () {
        const oView = this.getView();
        const oTableModel = oView.getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples");

        const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1"); //ZSB_REVERSE_PORD    // Reverse OData model

        const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN");   // For updating internal table
        const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD

        // Get selected rows
        const aSelectedRows = aRows.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
          return;
        }

        // Check for missing GR Material Document Number or Year
        const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
        if (aInvalidRows.length > 0) {
          sap.ui.core.BusyIndicator.hide();
          sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
          return;
        }

        sap.ui.core.BusyIndicator.show(0);
        let iCompleted = 0;

        const aFilters = [
          new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, aSelectedRows[0].productionorderno)
        ];
        oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
          filters: aFilters,
          success: function (oData) {
            const aResults = oData.results;
            // const oEntry = aResults && aResults[0];
            // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

            // const mapped = aResults.map(entry => {
            //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
            //   });

            //   const oEntry = mapped.find(entry => entry !== null);
            var bExists = aResults.some(function (oItem) {
              return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
            });

            // const iSelectedIndex = aRows.findIndex(row => row.__selected);



            if (bExists) {
              console.log("Combination exists: I0002 and active.");
              // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
              sap.m.MessageToast.show("Teco already active, cant reverse");
              sap.ui.core.BusyIndicator.hide();

              return;
            }
            else {
              aSelectedRows.forEach((row, index) => {
                const oPayload = {
                  Materialdocument: row.grmaterialdocnumber,
                  Matdocyear: row.grmaterialdocyear, // You can make this dynamic if needed
                  Postingdate: new Date()
                };

                console.log(`📤 Sending Reverse Receipt Payload for row ${index + 1}:`, oPayload);

                oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
                  success: function (oData) {
                    console.log(`✅ Reverse receipt success for row ${index + 1}:`, oData);

                    const sResponseValue = oData.Response || "";

                    // Update internal table field `grmaterialdocnumber`
                    const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                      grmaterialdocnumber: sResponseValue,
                      grmaterialdocyear: "",
                    };

                    oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
                      success: function () {
                        console.log(`🔄 grmaterialdocnumber updated for row ${index + 1}`);
                        row.grmaterialdocnumber = sResponseValue;
                        row.grmaterialdocyear = "";
                        checkCompletion();
                      },
                      error: function () {
                        console.warn(`⚠️ Failed to update grmaterialdocnumber for row ${index + 1}`);
                        checkCompletion();
                      }
                    });
                  },
                  error: function (oError) {
                    console.error(`❌ Reverse receipt failed for row ${index + 1}`, oError);
                    checkCompletion();
                  }
                });
              });

              function checkCompletion() {
                iCompleted++;
                if (iCompleted === aSelectedRows.length) {
                  oTableModel.setProperty("/Samples", aRows);
                  oTableModel.refresh();
                  sap.ui.core.BusyIndicator.hide();
                  sap.m.MessageToast.show("Reverse receipt process completed.");
                }
              }

            }

          }
        });

      },










      // ------------------------------------------------------------------------------------------------------------------------------------------
      // Reverse issue start
      // ------------------------------------------------------------------------------------------------------------------------------------------





      // onReverseIssuePress: function () {
      //     const oView = this.getView();
      //     const oModel = oView.getModel("ZSB_CNFISSUEREVERSE"); // Backend OData model for reverse

      //     // 🔁 Static test payload
      //     const oPayload = {
      //         Porderno: "110000150",            // Replace with actual Production Order number
      //         ConfirmationGroup: "0000000176",     // Replace with actual Confirmation Group
      //         ConfirmationCount: "00000005"      // Replace with actual Confirmation Count
      //     };


      //     console.log("📤 Sending Reverse issue Payload:", oPayload);
      //     sap.ui.core.BusyIndicator.show(0);

      //     oModel.create("/ZDD_CNFISSUERSV", oPayload, {
      //         success: function (oData) {
      //             sap.ui.core.BusyIndicator.hide();
      //             console.log("✅ Reverse issue POST Success:", oData);
      //             sap.m.MessageToast.show("Reverse issue request posted successfully.");
      //         },
      //         error: function (oError) {
      //             sap.ui.core.BusyIndicator.hide();
      //             console.error("❌ Reverse issue POST Failed:", oError);
      //             sap.m.MessageBox.error("Reverse issue failed. Check console for details.");
      //         }
      //     });
      // },



      onReverseIssuePress: function () {
        const oView = this.getView();
        const oTableModel = oView.getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples");

        const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");//ZSB_CNFISSUEREVERSE // Reverse API model 
        const oBeltFGPlanModel = oView.getModel("ZSB_BELTFG_PLAN"); // For PATCH

        // Get selected rows
        const aSelectedRows = aRows.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row to reverse issue.");
          return;
        }


        // ✅ New Validation: Prevent if any row has grmaterialdocnumber
        const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
        if (aHasGRRows.length > 0) {
          sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
          return;
        }


        // Check for missing GR Material Document Number or Year
        const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
        if (aInvalidRows1.length > 0) {
          sap.ui.core.BusyIndicator.hide();
          sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
          return;
        }
        // const aInvalidRows2 = aSelectedRows.filter(row => !row.grmaterialdocnumber);
        // if (aInvalidRows2.length > 0) {
        //     sap.ui.core.BusyIndicator.hide();
        //     sap.m.MessageBox.error("Cannot reverse Issue: Do Reciept reverse first.");
        //     return;
        // }





        sap.ui.core.BusyIndicator.show(0);
        let iCompleted = 0;

        aSelectedRows.forEach((row, index) => {
          const oPayload = {
            Porderno: row.productionorderno,
            ConfirmationGroup: row.gicnfconfirmationgroup,
            ConfirmationCount: row.gicnfconfirmationcount
          };

          console.log(`📤 Sending Reverse Issue Payload for row ${index + 1}:`, oPayload);

          oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
            success: function (oData) {
              console.log(`✅ Reverse issue success for row ${index + 1}:`, oData);

              // Get the returned material document number (assuming field is "Response")
              const sResponseValue = oData.Response || "";

              // Update BeltFG Plan table with returned Response
              const sUpdatePath = "/ZC_BELTFG_PLAN('" + row.sap_uuid + "')";
              const oUpdateEntry = {
                gicnfmaterialdocnumber: "",
                gicnfconfirmationgroup: "",
                gicnfconfirmationcount: "",
                gicnfmaterialdocyear: ""
              };

              oBeltFGPlanModel.update(sUpdatePath, oUpdateEntry, {
                success: function () {
                  console.log(`🔄 gicnfmaterialdocnumber updated for row ${index + 1}`);
                  row.gicnfmaterialdocnumber = "";
                  row.gicnfconfirmationgroup = "";
                  row.gicnfconfirmationcount = "";
                  row.gicnfmaterialdocyear = "";
                  checkCompletion();
                },
                error: function () {
                  console.warn(`⚠️ Failed to update gicnfmaterialdocnumber for row ${index + 1}`);
                  checkCompletion();
                }
              });
            },
            error: function (oError) {
              console.error(`❌ Reverse issue failed for row ${index + 1}`, oError);
              checkCompletion();
            }
          });
        });

        function checkCompletion() {
          iCompleted++;
          if (iCompleted === aSelectedRows.length) {
            oTableModel.setProperty("/Samples", aRows);
            oTableModel.refresh();
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageToast.show("Reverse issue process completed.");
          }
        }
      },

      //srikar

      onPrintPress: async function () {
        const oModel = this.getView().getModel("TabModel").getProperty("/Samples");
        const aSelectedRows = oModel.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row to print.");
          return;
        }

        const { jsPDF } = window.jspdf;

        const loadImageAsBase64 = async (url) => {
          const response = await fetch(url);
          const blob = await response.blob();
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        };

        const svgLogoBase64 = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode.png"));
        const svgLogoBase64_ = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode2.png"));
        const svgLogoBase64_Bando = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/Bando.png"));

        const generateSectionHTML = (data) => {
          const isEmpty = !data;
          // const lotbatchno = data?.lotbatchno || "";
          // const batchweight = data?.batchweight || "";
          // const manufacturingdate = data?.manufacturingdate ? new Date(data.manufacturingdate).toLocaleDateString("en-GB") : "";
          const productionordstartdate = data?.productionordstartdate ? new Date(data.productionordstartdate).toLocaleDateString("en-GB") : "";
          const confirmedqty = data?.confirmedqty || "";
          const compoundcode = data?.compoundcode || "";
          const operator = data?.operator || "";
          // const expirydate = data?.expirydate ? new Date(data.expirydate).toLocaleDateString("en-GB") : "";
          const inspector = data?.inspector || "";
          const productionorderqty = data?.productionorderqty || "";
          const productionorderno = data?.productionorderno || "";

          return `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            * { box-sizing: border-box; }
            .row { display: flex; margin: 0; }
            .column1 { flex: 120%; padding: 6px; }
            .column2 { flex: 110%; padding-left: 30px; padding-top: 5px; padding-right: 5px; }
            table, th, td {
              border: 1px solid black;
              border-collapse: collapse;
              text-align: left;
              padding: 5px;
            }
            .center-align { text-align: center; }
          </style>
        </head>
        <body>
        <div class="row">
          <div class="column1">
            <table style="width:106%">
              <tr>
                <td colspan="7" style="text-align:left;">
                  <img src="${svgLogoBase64_Bando}" alt="Bando Logo" width="100" style="vertical-align: middle; margin-right: 10px;">
                  Mixing Process lot Guarantee Card
                </td>
              </tr>
              <tr>
                <td colspan="2">B I P L COMPOUND FORMULA</td>
                <td colspan="2">COMPOUND CODE</td>
                <td colspan="4" class="center-align">${compoundcode}</td>
              </tr>
              <tr>
                <td>Production ord No : ${productionorderno}</td>
                <td>Production Date :<br>${manufacturingdate}</td>
                <td>Lot No.</td>
                <td>${lotbatchno}</td>
                <td>EXPIRY DATE</td>
                <td>${expirydate}</td>
              </tr>
              <tr>
                <td>
                  <table>
                    <tr><td>Batch Wt. - kgs</td></tr>
                    <tr>
                      <td>
                        <table>
                          <tr><td>Spec.</td><td>${productionorderqty}</td></tr>
                          <tr><td>Actual</td><td>${confirmedqty}</td></tr>
                          <tr><td>Difference</td><td>${productionorderqty - confirmedqty}</td></tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
                <td colspan="4">
                  ${!isEmpty ? `<img src="${svgLogoBase64_}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td>Operator</td>
              </tr>
              <tr>
                <td colspan="2">
                  ${!isEmpty ? `<img src="${svgLogoBase64}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td colspan="4">
                  <table style="width:100%">
                    <tr>
                      <th class="center-align">Operator</th>
                      <th class="center-align">Inspector</th>
                    </tr>
                    <tr>
                      <td class="center-align"><br><br>${operator}<br><br></td>
                      <td class="center-align">${inspector}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>
          <div class="column2">
            <table style="width:118%">
              <tr><td class="center-align">Compound Code<br><br><br>${compoundcode}</td></tr>
              <tr><td class="center-align">Lot No<br><br><br>${lotbatchno}</td></tr>
              <tr><td class="center-align">Production Date<br><br><br>${manufacturingdate}</td></tr>
              <tr><td class="center-align">Operator Sign<br><br><br><br><br><br>${operator}</td></tr>
            </table>
          </div>
        </div>
        </body>
        </html>
        `;
        };

        const doc = new jsPDF('l', 'mm', [297, 148.5]); // Half A4 landscape

        const promises = aSelectedRows.map((row, idx) => {
          return new Promise((resolve, reject) => {
            const htmlContent = generateSectionHTML(row);

            const iframe = document.createElement('iframe');
            iframe.style.position = 'fixed';
            iframe.style.top = '-100000px';
            document.body.appendChild(iframe);

            const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
            iframeDoc.open();
            iframeDoc.write(htmlContent);
            iframeDoc.close();

            iframe.onload = () => {
              html2canvas(iframeDoc.body, { scale: 3 }).then(canvas => {
                const imgData = canvas.toDataURL('image/jpeg', 0.95);
                doc.addImage(imgData, 'JPEG', 0, 0, 297, 148.5);
                if (idx !== aSelectedRows.length - 1) {
                  doc.addPage();
                }
                document.body.removeChild(iframe);
                resolve();
              }).catch(error => {
                document.body.removeChild(iframe);
                reject(error);
              });
            };
          });
        });

        await Promise.all(promises);

        const blob = doc.output('blob');
        const pdfUrl = URL.createObjectURL(blob);

        if (!this._PDFViewer) {
          this._PDFViewer = new sap.m.PDFViewer({
            source: pdfUrl,
            title: "BeltFG Guarantee Card",
            width: "auto"
          });
          jQuery.sap.addUrlWhitelist("blob");
        }

        this._PDFViewer.setSource(pdfUrl);
        this._PDFViewer.open();
      },




      // ==========================================================================================
      // ====================================MATERIAL FRAGMENT=================================
      // ==========================================================================================
      // onMaterialFragmentOpenSimple: function (oEvent) {
      //   this._oInputField = oEvent.getSource();
      //   var oView = this.getView();

      //   if (!this._oMaterialDialog) {
      //     this._oMaterialDialog = sap.ui.xmlfragment(
      //       "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
      //       this
      //     );
      //     oView.addDependent(this._oMaterialDialog);
      //   }

      //   var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
      //   var that = this;

      //   // Only fetch materials with ProductGroup = "38"
      //   oModel.read("/ZC_MATERIALMASTER1", {
      //     filters: [
      //       new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT")
      //     ],
      //     success: function (oData) {
      //       var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
      //       that._oMaterialDialog.setModel(oJSON, "VHModel");
      //       that._oMaterialDialog.open();
      //     },
      //     error: function () {
      //       sap.m.MessageToast.show("Error fetching materials");
      //     }
      //   });
      // },

      // onMaterialSelected: function (oEvent) {
      //   var oSelectedItem = oEvent.getSource();
      //   var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

      //   if (this._oInputField) {
      //     // If input is inside a table row (has a binding context)
      //     var oRowCtx = this._oInputField.getBindingContext("TabModel");
      //     if (oRowCtx) {
      //       oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialcode", oCtx.Product);
      //       oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialname", oCtx.ProductName);
      //     } else {
      //       // If it’s a standalone input field (like yours)
      //       this.getView().getModel("TabModel").setProperty("/materialcode", oCtx.Product);
      //       this.getView().getModel("TabModel").setProperty("/materialname", oCtx.ProductName);

      //       // Update input field value directly
      //       this._oInputField.setValue(oCtx.Product);
      //     }
      //   }

      //   // this._oMaterialDialog.close();
      //   if (this._oMaterialDialog) {
      //     this._oMaterialDialog.close();
      //     this._oMaterialDialog.destroy();
      //     this._oMaterialDialog = null; // reset reference
      //   }
      // },


      // onMaterialSearch: function (oEvent) {
      //   var sValue = oEvent.getParameter("newValue");
      //   if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

      //   var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
      //   if (!oTable) return;

      //   var oBinding = oTable.getBinding("items");
      //   if (sValue) {
      //     var oFilter = new sap.ui.model.Filter({
      //       filters: [
      //         new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
      //         new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
      //       ],
      //       and: false
      //     });
      //     oBinding.filter([oFilter]);
      //   } else {
      //     oBinding.filter([]);
      //   }
      // },

      // onVHClose: function () {
      //   if (this._oMaterialDialog) {
      //     this._oMaterialDialog.close();
      //     this._oMaterialDialog.destroy();
      //     this._oMaterialDialog = null; // reset reference
      //   }
      // },

      onMaterialValueHelp: function (oEvent) {
        this._oMaterialInputField = oEvent.getSource();
        var oView = this.getView();

        // Show Busy Indicator when the dialog starts loading
        sap.ui.core.BusyIndicator.show(0);

        // Create fragment if not already created
        if (!this._oMaterialDialog) {
          this._oMaterialDialog = sap.ui.xmlfragment(
            "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
            this
          );
          oView.addDependent(this._oMaterialDialog);
        }

        var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
        var that = this;

        // Only fetch materials with ProductGroup = "MIXING"
        oModel.read("/ZC_MATERIALMASTER1", {
          filters: [
            new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "FG BELT")
          ],
          success: function (oData) {
            // Create the model for the dialog
            var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
            that._oMaterialDialog.setModel(oJSON, "VHModel");

            // Pre-select already selected materials
            var oTable = sap.ui.core.Fragment.byId(
              "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
              "idMaterialTable"
            );

            if (oTable) {
              oTable.removeSelections();
              that._selectedMaterials.forEach(material => {
                var aItems = oTable.getItems();
                aItems.forEach(item => {
                  if (item.getCells()[0].getText() === material.Product) {
                    oTable.setSelectedItem(item, true);
                  }
                });
              });
            }

            // Temporary storage for current dialog session
            that._oTempSelectedMaterials = [];

            // Open the dialog after all processing is done
            that._oMaterialDialog.open();

            // Hide Busy Indicator after the dialog is fully loaded
            sap.ui.core.BusyIndicator.hide();
          },
          error: function () {
            // Hide the busy indicator if there was an error
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageToast.show("Error fetching Materials");
          }
        });
      },

      onMaterialSearch: function (oEvent) {
        var sValue = oEvent.getParameter("newValue");
        if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

        var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
        if (!oTable) return;

        var oBinding = oTable.getBinding("items");
        if (sValue) {
          var oFilter = new sap.ui.model.Filter({
            filters: [
              new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
              new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
            ],
            and: false
          });
          oBinding.filter([oFilter]);
        } else {
          oBinding.filter([]);
        }
      },

      onMaterialSelectionChange: function (oEvent) {
        var oTable = oEvent.getSource();
        var aSelectedItems = oTable.getSelectedItems();
        this._oTempSelectedMaterials = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
      },

      onMaterialConfirm: function () {
        if (!this._oTempSelectedMaterials) return;

        // Store selected materials
        this._selectedMaterials = this._oTempSelectedMaterials.slice();

        // Clear old tokens first
        this._oMaterialInputField.removeAllTokens();

        // Add tokens for selected materials
        this._selectedMaterials.forEach(material => {
          var oToken = new sap.m.Token({
            key: material.Product,
            text: material.Product,
            tooltip: material.ProductName // Optional: show description on hover
          });
          this._oMaterialInputField.addToken(oToken);
        });

        // Close dialog
        if (this._oMaterialDialog) {
          this._oMaterialDialog.close();
          this._oMaterialDialog.destroy();
          this._oMaterialDialog = null;
        }
      },

      onMaterialTokenUpdate: function (oEvent) {
        var aRemovedTokens = oEvent.getParameter("removedTokens");

        aRemovedTokens.forEach(token => {
          this._selectedMaterials = this._selectedMaterials.filter(
            material => material.Product !== token.getKey()
          );
        });
      },

      onMaterialChange: function (oEvent) {
        const oInput = oEvent.getSource();  // Get the MultiInput field
        const sValue = oInput.getValue().trim();  // Get the typed value

        if (sValue) {
          // Get current tokens in the MultiInput
          const aTokens = oInput.getTokens().map(t => t.getKey());

          // Only add the token if it doesn't already exist
          if (!aTokens.includes(sValue)) {
            const oToken = new sap.m.Token({
              key: sValue,
              text: sValue
            });

            // Add the token to the MultiInput field
            oInput.addToken(oToken);

            // Also add to selected materials array
            if (!this._selectedMaterials.find(m => m.Product === sValue)) {
              this._selectedMaterials.push({
                Product: sValue,
                ProductName: sValue // You might want to fetch the actual description if available
              });
            }
          }
        }

        // Optionally clear the input field after adding the token
        oInput.setValue("");  // Clear the input after adding
      },

      onMaterialVHClose: function () {
        if (this._oMaterialDialog) {
          this._oMaterialDialog.close();
          this._oMaterialDialog.destroy();
          this._oMaterialDialog = null; // reset reference
        }
      },



      // ==========================================================================================
      // ========================PRODUCTION ORDER NUMBER FRAGMENT=================================
      // ==========================================================================================

      // onProductionOrderValueHelp: function (oEvent) {
      //   this._oPOInputField = oEvent.getSource();
      //   var oView = this.getView();

      //   if (!this._oProductionOrderDialog) {
      //     this._oProductionOrderDialog = sap.ui.xmlfragment(
      //       "bando.view.CommonFragments.ActualScreens.productionorder_simple",
      //       this
      //     );
      //     oView.addDependent(this._oProductionOrderDialog);
      //   }

      //   var oModel = this.getView().getModel("ZSB_BELTFG_PLAN");
      //   var that = this;

      //   oModel.read("/ZC_BELTFG_PLAN", {
      //     urlParameters: {
      //       "$top": 1000 // fetch top 1000 for scrollable table; can adjust
      //     },
      //     success: function (oData) {
      //       var oJSON = new sap.ui.model.json.JSONModel({ Orders: oData.results });
      //       that._oProductionOrderDialog.setModel(oJSON, "VHModel");
      //       that._oProductionOrderDialog.open();
      //     },
      //     error: function () {
      //       sap.m.MessageToast.show("Error fetching Production Orders");
      //     }
      //   });
      // },

      // onProductionOrderSelected: function (oEvent) {
      //   var oSelectedItem = oEvent.getSource();
      //   var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

      //   if (this._oPOInputField) {
      //     // Set the selected Production Order No directly to the input field
      //     this._oPOInputField.setValue(oCtx.productionorderno);
      //   }

      //   // this._oProductionOrderDialog.close();
      //   if (this._oProductionOrderDialog) {
      //     this._oProductionOrderDialog.close();
      //     this._oProductionOrderDialog.destroy();
      //     this._oProductionOrderDialog = null; // reset reference
      //   }
      // },


      // onProductionOrderSearch: function (oEvent) {
      //   var sValue = oEvent.getParameter("newValue");
      //   if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

      //   var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
      //   if (!oTable) return;

      //   var oBinding = oTable.getBinding("items");
      //   if (sValue) {
      //     var oFilter = new sap.ui.model.Filter({
      //       filters: [
      //         new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
      //         new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
      //       ],
      //       and: false
      //     });
      //     oBinding.filter([oFilter]);
      //   } else {
      //     oBinding.filter([]);
      //   }
      // },

      // onProductionOrderVHClose: function () {
      //   if (this._oProductionOrderDialog) {
      //     this._oProductionOrderDialog.close();
      //     this._oProductionOrderDialog.destroy();
      //     this._oProductionOrderDialog = null; // reset reference
      //   }
      // },

      // onProductionOrderValueHelp: function (oEvent) {
      //     this._oPOInputField = oEvent.getSource();
      //     var oView = this.getView();

      //     // Show Busy Indicator when the dialog starts loading
      //     sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

      //     // Create fragment if not already created
      //     if (!this._oProductionOrderDialog) {
      //         this._oProductionOrderDialog = sap.ui.xmlfragment(
      //             "bando.view.CommonFragments.ActualScreens.productionorder_simple",
      //             this
      //         );
      //         oView.addDependent(this._oProductionOrderDialog);
      //     }

      //     var oModel = oView.getModel("ZSB_BELTFG_PLAN");
      //     var that = this;

      //     oModel.read("/ZC_BELTFG_PLAN", {
      //         urlParameters: { "$top": 1000 }, // fetch top 1000 records
      //         success: function (oData) {
      //             var oJSON = new sap.ui.model.json.JSONModel({ Orders: oData.results });
      //             that._oProductionOrderDialog.setModel(oJSON, "VHModel");

      //             // Pre-select already selected orders
      //             var oTable = sap.ui.core.Fragment.byId(
      //                 "bando.view.CommonFragments.ActualScreens.productionorder_simple",
      //                 "idProductionOrderTable"
      //             );

      //             if (oTable) {
      //                 oTable.removeSelections();
      //                 that._selectedProductionOrders.forEach(po => {
      //                     var aItems = oTable.getItems();
      //                     aItems.forEach(item => {
      //                         if (item.getCells()[0].getText() === po.productionorderno) {
      //                             oTable.setSelectedItem(item, true);
      //                         }
      //                     });
      //                 });
      //             }

      //             // Temporary storage for current dialog session
      //             that._oTempSelectedOrders = [];

      //             // Open the dialog after all processing is done
      //             that._oProductionOrderDialog.open();

      //             // Hide Busy Indicator after the dialog is fully loaded
      //             sap.ui.core.BusyIndicator.hide();
      //         },
      //         error: function () {
      //             // Hide the busy indicator if there was an error
      //             sap.ui.core.BusyIndicator.hide();
      //             sap.m.MessageToast.show("Error fetching Production Orders");
      //         }
      //     });
      // },


      onProductionOrderValueHelp: function (oEvent) {
        this._oPOInputField = oEvent.getSource();
        var oView = this.getView();

        // Show Busy Indicator when the dialog starts loading
        sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

        // Create fragment if not already created
        if (!this._oProductionOrderDialog) {
          this._oProductionOrderDialog = sap.ui.xmlfragment(
            "bando.view.CommonFragments.ActualScreens.productionorder_simple",
            this
          );
          oView.addDependent(this._oProductionOrderDialog);
        }

        var oModel = oView.getModel("ZSB_BELTFG_PLAN");
        var that = this;

        oModel.read("/ZC_BELTFG_PLAN", {
          urlParameters: { "$top": 1000 }, // fetch top 1000 records
          success: function (oData) {
            // Filter out production orders where productionorderno is "0"
            var aFilteredOrders = oData.results.filter(function (item) {
              return item.productionorderno && item.productionorderno !== "0";
            });

            // Create the model for the dialog with the filtered results
            var oJSON = new sap.ui.model.json.JSONModel({ Orders: aFilteredOrders });
            that._oProductionOrderDialog.setModel(oJSON, "VHModel");

            // Pre-select already selected orders
            var oTable = sap.ui.core.Fragment.byId(
              "bando.view.CommonFragments.ActualScreens.productionorder_simple",
              "idProductionOrderTable"
            );

            if (oTable) {
              oTable.removeSelections();
              that._selectedProductionOrders.forEach(po => {
                var aItems = oTable.getItems();
                aItems.forEach(item => {
                  if (item.getCells()[0].getText() === po.productionorderno) {
                    oTable.setSelectedItem(item, true);
                  }
                });
              });
            }

            // Temporary storage for current dialog session
            that._oTempSelectedOrders = [];

            // Open the dialog after all processing is done
            that._oProductionOrderDialog.open();

            // Hide Busy Indicator after the dialog is fully loaded
            sap.ui.core.BusyIndicator.hide();
          },
          error: function () {
            // Hide the busy indicator if there was an error
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageToast.show("Error fetching Production Orders");
          }
        });
      },

      onProductionOrderSearch: function (oEvent) {
        var sValue = oEvent.getParameter("newValue");
        if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

        var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
        if (!oTable) return;

        var oBinding = oTable.getBinding("items");
        if (sValue) {
          var oFilter = new sap.ui.model.Filter({
            filters: [
              new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
              new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
            ],
            and: false
          });
          oBinding.filter([oFilter]);
        } else {
          oBinding.filter([]);
        }
      },
      onProductionOrderSelectionChange: function (oEvent) {
        var oTable = oEvent.getSource();
        var aSelectedItems = oTable.getSelectedItems();
        this._oTempSelectedOrders = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
      },

      onProductionOrderConfirm: function () {
        if (!this._oTempSelectedOrders) return;

        // Store selected orders
        this._selectedProductionOrders = this._oTempSelectedOrders.slice();

        // Clear old tokens first
        this._oPOInputField.removeAllTokens();

        // Add tokens for selected production orders
        this._selectedProductionOrders.forEach(po => {
          var oToken = new sap.m.Token({
            key: po.productionorderno,
            text: po.productionorderno
          });
          this._oPOInputField.addToken(oToken);
        });

        // Close dialog
        if (this._oProductionOrderDialog) {
          this._oProductionOrderDialog.close();
          this._oProductionOrderDialog.destroy();
          this._oProductionOrderDialog = null;
        }
      },

      onProductionOrderTokenUpdate: function (oEvent) {
        var aRemovedTokens = oEvent.getParameter("removedTokens");

        aRemovedTokens.forEach(token => {
          this._selectedProductionOrders = this._selectedProductionOrders.filter(
            o => o.productionorderno !== token.getKey()
          );
        });
      },
      onProductionOrderVHClose: function () {
        if (this._oProductionOrderDialog) {
          this._oProductionOrderDialog.close();
          this._oProductionOrderDialog.destroy();
          this._oProductionOrderDialog = null; // reset reference
        }
      },

      onProductionOrderChange: function (oEvent) {
        const oInput = oEvent.getSource();  // Get the MultiInput field
        const sValue = oInput.getValue().trim();  // Get the typed value

        if (sValue) {
          // Get current tokens in the MultiInput
          const aTokens = oInput.getTokens().map(t => t.getKey());

          // Only add the token if it doesn't already exist
          if (!aTokens.includes(sValue)) {
            const oToken = new sap.m.Token({
              key: sValue,
              text: sValue // Display the same value as text for now
            });

            // Add the token to the MultiInput field
            oInput.addToken(oToken);
          }
        }

        // Optionally clear the input field after adding the token
        oInput.setValue("");  // Clear the input after adding
      },















      // onSelectRowNavigate: function (oEvent) {
      //     const oView = this.getView();
      //     const oTableModel = oView.getModel("TabModel");
      //     const oODataModel = oView.getModel("ZSB_RELEASE_BOM"); // Backend model

      //     // ✅ Extract clicked row data directly
      //     const oRowData = oEvent.getSource().getBindingContext("TabModel").getObject();

      //     if (!oRowData) {
      //         sap.m.MessageToast.show("Unable to fetch row data!");
      //         return;
      //     }

      //     sap.ui.core.BusyIndicator.show(0);

      //     // ✅ Save for later use
      //     oTableModel.setProperty("/SelectedRowData", oRowData);

      //     // Step 1: Manufacturing Order
      //     const sProdOrderNo = oRowData.productionorderno;

      //     if (!sProdOrderNo) {
      //         sap.m.MessageToast.show("No production order found!");
      //         sap.ui.core.BusyIndicator.hide();
      //         return;
      //     }

      //     // Step 2: Fetch Reservation
      //     const aReservationFilter = [
      //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
      //     ];

      //     oODataModel.read("/ZC_RESERVATION_COMPONENT", {
      //         filters: aReservationFilter,
      //         success: function (oReservationData) {
      //             const aResults = oReservationData.results;

      //             if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
      //                 sap.m.MessageToast.show("No reservation found!");
      //                 sap.ui.core.BusyIndicator.hide();
      //                 return;
      //             }

      //             const sReservation = aResults[0].Reservation;

      //             // Step 3: Fetch BOM/GR details
      //             const aGRFilters = [
      //                 new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
      //             ];

      //             oODataModel.read("/ZC_RELEASE_BOM", {
      //                 filters: aGRFilters,
      //                 success: function (oGRData) {

      //                     // ✅ Bind results to fragment table
      //                     oTableModel.setProperty("/GRScreenData", oGRData.results || []);

      //                     // ✅ Create fragment only once
      //                     if (!this._oGRDialog) {
      //                         this._oGRDialog = sap.ui.xmlfragment(
      //                             "bando.view.CommonFragments.ActualScreens.beltfg_gr_screen",
      //                             this
      //                         );
      //                         oView.addDependent(this._oGRDialog);
      //                     }

      //                     this._oGRDialog.open();
      //                     sap.ui.core.BusyIndicator.hide();
      //                 }.bind(this),
      //                 error: function (oError) {
      //                     sap.m.MessageToast.show("Error fetching GR Screen data.");
      //                     sap.ui.core.BusyIndicator.hide();
      //                     console.error(oError);
      //                 }
      //             });

      //         }.bind(this),
      //         error: function (oError) {
      //             sap.m.MessageToast.show("Error fetching Reservation.");
      //             sap.ui.core.BusyIndicator.hide();
      //             console.error(oError);
      //         }
      //     });
      // },


      // onSelectRowNavigate: function (oEvent) {
      //     const oView = this.getView();
      //     const oTableModel = oView.getModel("TabModel");

      //     // ✅ Get clicked row data
      //     const oRowData = oEvent.getSource().getBindingContext("TabModel").getObject();

      //     if (!oRowData) {
      //         sap.m.MessageToast.show("Unable to fetch row data!");
      //         return;
      //     }

      //     sap.ui.core.BusyIndicator.show(0);

      //     // ✅ Reset fragment data
      //     oTableModel.setProperty("/GRScreenData", []);

      //     // ✅ Build fragment row
      //     const oFragmentRow = {
      //         sap_uuid: oRowData.sap_uuid,
      //         materialcode: oRowData.materialcode,
      //         description: oRowData.description,
      //         productionorderno: oRowData.productionorderno,
      //         productionorderqty: oRowData.productionorderqty,
      //         confirmedqty: oRowData.confirmedqty,
      //         // boxno: "",
      //         // fromserialno: "",
      //         // toserialno: "",
      //         // GRquantity: ""

      //     };

      //     // ✅ Push row into fragment table array
      //     const aFragmentData = oTableModel.getProperty("/GRScreenData");
      //     aFragmentData.push(oFragmentRow);
      //     oTableModel.setProperty("/GRScreenData", aFragmentData);

      //     // ✅ Create fragment only once
      //     if (!this._oGRDialog) {
      //         this._oGRDialog = sap.ui.xmlfragment(
      //             "bando.view.CommonFragments.ActualScreens.beltfg_gr_screen",
      //             this
      //         );
      //         oView.addDependent(this._oGRDialog);
      //     }

      //     // ✅ Open dialog
      //     this._oGRDialog.open();
      //     sap.ui.core.BusyIndicator.hide();
      // },




      onSelectRowNavigate: function (oEvent) {
        const oView = this.getView();
        const oTableModel = oView.getModel("TabModel");

        // 1️⃣ Get clicked row data
        const oRowData = oEvent.getSource().getBindingContext("TabModel").getObject();
        if (!oRowData) {
          sap.m.MessageToast.show("Unable to fetch row data!");
          return;
        }





        // validation
        // 2️⃣ Validate mandatory fields before opening fragment
        const missingFields = [];
        // if (!oRowData.operator || oRowData.operator.trim() === "") missingFields.push("Operator");
        // if (!oRowData.inspector || oRowData.inspector.trim() === "") missingFields.push("Inspector");
        if (!oRowData.confirmedqty || oRowData.confirmedqty <= 0) missingFields.push("Confirmed Quantity");

        //     if (oRowData.confirmedqty === undefined || oRowData.confirmedqty === null) 
        // missingFields.push("Confirmed Quantity");

        if (missingFields.length > 0) {
          sap.m.MessageBox.warning(
            `Please fill the following fields before proceeding:\n\n${missingFields.join(", ")}`
          );
          return; // Stop opening the fragment
        }
        // validation complete




        sap.ui.core.BusyIndicator.show(0);

        // 2️⃣ Reset fragment table data
        oTableModel.setProperty("/GRScreenData", []);

        // 3️⃣ Prepare minimal fragment row
        const oFragmentRow = {
          sap_uuid: oRowData.sap_uuid,
          materialcode: oRowData.materialcode,
          description: oRowData.description,
          productionorderno: oRowData.productionorderno,
          productionorderqty: oRowData.productionorderqty,
          confirmedqty: oRowData.confirmedqty,

          // for gr needed extra fields
          plant: oRowData.plant,
          storagelocation: oRowData.storagelocation,

          gicnfmaterialdocnumber: oRowData.gicnfmaterialdocnumber,
          grmaterialdocnumber: oRowData.grmaterialdocnumber,
          operator: oRowData.operator,
          inspector: oRowData.inspector,
          confirmedqty: String(oRowData.confirmedqty),

        };

        // 4️⃣ Fetch additional fields from OData
        const oModel = oView.getModel("ZSB_BELTFG_PLAN");
        const oFilter = new sap.ui.model.Filter("sap_uuid", sap.ui.model.FilterOperator.EQ, oRowData.sap_uuid);

        oModel.read("/ZC_BELTFG_PLAN", {
          filters: [oFilter],
          success: (oData) => {
            const oFetchedData = oData.results?.[0];
            if (oFetchedData) {
              oFragmentRow.boxno = oFetchedData.boxno || "";
              oFragmentRow.fromserialno = oFetchedData.fromserialno || "";
              oFragmentRow.toserialno = oFetchedData.toserialno || "";
              oFragmentRow.grquantity = oFetchedData.grquantity || "";
            }
            openFragment.call(this);
          },
          error: () => {
            // If fetch fails, still open fragment with minimal data
            openFragment.call(this);
          }
        });

        // 5️⃣ Helper function to push data and open fragment
        function openFragment() {
          const aFragmentData = oTableModel.getProperty("/GRScreenData");
          aFragmentData.push(oFragmentRow);
          oTableModel.setProperty("/GRScreenData", aFragmentData);

          if (!this._oGRDialog) {
            this._oGRDialog = sap.ui.xmlfragment(
              "bando.view.CommonFragments.ActualScreens.beltfg_gr_screen",
              this
            );
            oView.addDependent(this._oGRDialog);
          }
          this._oGRDialog.open();
          sap.ui.core.BusyIndicator.hide();
        }
      },

      onUpdateToBeltFGTable: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_BELTFG_PLAN"); // OData model
        const oTableModel = oView.getModel("TabModel");

        // 1️⃣ Get the single row from fragment table
        const aData = oTableModel.getProperty("/GRScreenData");
        if (!aData || aData.length === 0) {
          sap.m.MessageToast.show("No data to save.");
          return;
        }

        const oRow = aData[0]; // only one row

        if (!oRow.sap_uuid) {
          sap.m.MessageToast.show("sap_uuid is missing. Cannot save.");
          return;
        }


        // fields needed before coming to this screen


        sap.ui.core.BusyIndicator.show(0);

        // 2️⃣ Prepare payload for OData update
        const oPayload = {
          boxno: oRow.boxno,
          fromserialno: oRow.fromserialno,
          toserialno: oRow.toserialno,
          grquantity: oRow.grquantity
        };

        // 3️⃣ Update existing entry in OData service
        oModel.update(`/ZC_BELTFG_PLAN('${oRow.sap_uuid}')`, oPayload, {
          success: function () {
            sap.m.MessageToast.show("Data saved successfully!");
            sap.ui.core.BusyIndicator.hide();
            if (this._oGRDialog) {
              this._oGRDialog.close();
            }
          }.bind(this),
          error: function (oError) {
            sap.m.MessageToast.show("Failed to save data.");
            console.error(oError);
            sap.ui.core.BusyIndicator.hide();
          }
        });
      },

      // ==========================================================================================
      // ==========================================================================================
      // ==========================================================================================

      // onGoodsReceiptPressGRScreen: async function () {
      //   const oView = this.getView();
      //   // const oGRModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
      //   const oGRModel = oView.getModel("ZSB_BELTFG_GR");
      //   const oTabModel = oView.getModel("TabModel");

      //   const aData = oTabModel.getProperty("/GRScreenData");
      //   if (!aData || aData.length === 0) {
      //     sap.m.MessageToast.show("No data available for Goods Receipt.");
      //     return;
      //   }
      //   const oRow = aData[0];

      //   // Validation
      //   if (!oRow.sap_uuid) {
      //     sap.m.MessageBox.error("Cannot proceed: Row not saved.");
      //     return;
      //   }

      //   if (oRow.grmaterialdocnumber) {
      //     sap.m.MessageBox.warning("Goods Receipt already exists for this row.");
      //     return;
      //   }

      //   const oPayload = {
      //     material: oRow.materialcode,
      //     plant: oRow.plant,
      //     storagelocation: oRow.storagelocation,
      //     goodsmovementtype: "101",
      //     manufacturingorder: oRow.productionorderno,
      //     goodsmovementrefdoctype: "F",
      //     quantityinentryunit: String(oRow.confirmedqty),
      //     postingdate: new Date(),
      //     goodsmovementcode: "02"
      //   };
      //   console.log("payload to gr api:", oPayload)

      //   sap.ui.core.BusyIndicator.show(0);

      //   try {
      //     const oGRData = await new Promise((resolve, reject) => {
      //       // oGRModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
      //       oGRModel.create("/ZC_BELTFG_GR", oPayload, {
      //         success: resolve,
      //         error: reject
      //       });
      //     });

      //     const aMatDocItems = await this.ToFetchExpiredateGRTab(oRow, oGRData.materialdocument, oGRData);
      //     // debugger
      //     console.log("GR response:", oGRData);


      //     await this.ToUpdateGRTab(oRow, oGRData.materialdocument, oGRData, aMatDocItems?.[0]);

      //     // Update fragment model with GR numbers
      //     oRow.grmaterialdocnumber = oGRData.materialdocument;
      //     oRow.grmaterialdocyear = oGRData.matdocyear;
      //     oTabModel.refresh();

      //     sap.m.MessageToast.show("Goods Receipt completed successfully!");

      //     // --- Update main table row as well
      //     const aSamples = oTabModel.getProperty("/Samples");
      //     const iIndex = aSamples.findIndex(r => r.sap_uuid === oRow.sap_uuid);
      //     if (iIndex !== -1) {
      //       aSamples[iIndex].grmaterialdocnumber = oGRData.materialdocument;
      //       aSamples[iIndex].grmaterialdocyear = oGRData.matdocyear;
      //       oTabModel.setProperty("/Samples", aSamples);
      //     }


      //   } catch (oError) {
      //     console.error("Goods Receipt failed:", oError);
      //     sap.m.MessageBox.error("Goods Receipt failed. Check console for details.");
      //   } finally {
      //     sap.ui.core.BusyIndicator.hide();
      //   }
      // },

      // onGoodsReceiptPress: async function () {
      //   const oView = this.getView();
      //   const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
      //   const oTabModel = oView.getModel("TabModel");
      //   const aRows = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aRows.filter(row => row.__selected);

      //   if (aSelectedRows.length === 0) {
      //     sap.m.MessageToast.show("Please select at least one row.");
      //     return;
      //   }

      //   let aBlockerErrors = [];

      //   aSelectedRows.forEach((row) => {
      //     let errors = [];

      //     if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
      //       errors.push("Missing Goods Issue Confirmation");
      //     }

      //     if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
      //       errors.push("Goods Receipt already exists");
      //     }

      //     if (errors.length > 0) {
      //       const sProdOrder = row.productionorderno || "(No Production Order)";
      //       aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
      //     }
      //   });

      //   if (aBlockerErrors.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
      //     );
      //     return;
      //   }

      //   // --- 🧪 VALIDATION (field completeness)
      //   let aValidationErrors = [];

      //   aSelectedRows.forEach((row) => {
      //     let missingFields = [];

      //     // if (!row.batchweight) missingFields.push("Batch Weight");
      //     // if (!row.operator) missingFields.push("Operator");
      //     // if (!row.inspector) missingFields.push("Inspector");
      //     if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

      //     if (missingFields.length > 0) {
      //       const sProdOrder = row.productionorderno || "(No Production Order)";
      //       aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
      //     }
      //   });

      //   if (aValidationErrors.length > 0) {
      //     sap.m.MessageBox.error(
      //       "Missing required fields:\n\n" + aValidationErrors.join("\n")
      //     );
      //     return;
      //   }

      //   // --- ✅ PROCESSING (all validations passed)
      //   sap.ui.core.BusyIndicator.show(0);

      //   // Arrays to collect results
      //   const aSuccessResults = [];
      //   const aErrorResults = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];
      //     const sProdOrder = row.productionorderno || `Row ${i + 1}`;

      //     const oPayload = {
      //       material: row.materialcode,
      //       plant: row.plant,
      //       storagelocation: row.storagelocation,
      //       goodsmovementtype: "101",
      //       manufacturingorder: row.productionorderno,
      //       manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
      //       goodsmovementrefdoctype: "F",
      //       quantityinentryunit: String(row.confirmedqty),
      //       postingdate: new Date(),
      //       goodsmovementcode: "02"
      //     };

      //     try {
      //       const oData = await new Promise((resolve, reject) => {
      //         oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       console.log("response:", oData);

      //       // Check if the response contains an error in errorresponse field
      //       if (oData.errorresponse) {
      //         // Parse the error response
      //         let sErrorMessage = "Unknown error from backend";

      //         try {
      //           const oErrorObj = JSON.parse(oData.errorresponse);
      //           if (oErrorObj.error && oErrorObj.error.message) {
      //             sErrorMessage = oErrorObj.error.message.value || oErrorObj.error.message;
      //           }
      //         } catch (e) {
      //           sErrorMessage = oData.errorresponse;
      //         }

      //         // Check if material document was created despite the error
      //         if (!oData.materialdocument || oData.materialdocument.trim() === "" || oData.materialdocument === "0") {
      //           // No material document created - treat as failure
      //           throw new Error(sErrorMessage);
      //         } else {
      //           // Material document was created but with warnings - treat as success with warning
      //           console.warn(`Warning for Production Order ${sProdOrder}: ${sErrorMessage}`);

      //           // Continue processing as success but note the warning
      //           row.grmaterialdocnumber = oData.materialdocument;
      //           row.grmaterialdocyear = oData.matdocyear;

      //           const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
      //           row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

      //           await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

      //           // Add to success list with warning note
      //           aSuccessResults.push({
      //             productionOrder: sProdOrder,
      //             materialDocument: oData.materialdocument,
      //             year: oData.matdocyear,
      //             warning: sErrorMessage
      //           });

      //           continue;
      //         }
      //       }

      //       // If we reach here, it's a clean success
      //       row.grmaterialdocnumber = oData.materialdocument;
      //       row.grmaterialdocyear = oData.matdocyear;

      //       const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
      //       row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

      //       await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

      //       // Add to success list
      //       aSuccessResults.push({
      //         productionOrder: sProdOrder,
      //         materialDocument: oData.materialdocument,
      //         year: oData.matdocyear
      //       });

      //     } catch (oError) {
      //       console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

      //       // Extract error message
      //       let sErrorMessage = oError.message || "Unknown error";

      //       // For specific ShelfLifeExpirationDate error
      //       if (sErrorMessage.includes("ShelfLifeExpirationDate")) {
      //         sErrorMessage = "Missing Shelf Life Expiration Date in material document";
      //       }

      //       // For OData errors
      //       if (oError.responseText) {
      //         try {
      //           const oErrorResponse = JSON.parse(oError.responseText);
      //           if (oErrorResponse.error && oErrorResponse.error.message) {
      //             sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
      //           }
      //         } catch (e) {
      //           // If can't parse JSON, use response text
      //           sErrorMessage = oError.responseText;
      //         }
      //       }

      //       // Add to error list
      //       aErrorResults.push({
      //         productionOrder: sProdOrder,
      //         error: sErrorMessage
      //       });
      //     }
      //   }

      //   // Update the model with processed rows
      //   oTabModel.setProperty("/Samples", aRows);
      //   oTabModel.refresh();
      //   sap.ui.core.BusyIndicator.hide();

      //   // Show summary message
      //   this.showGRSummary(aSuccessResults, aErrorResults);
      // },

      // showGRSummary: function (aSuccessResults, aErrorResults) {
      //   let sMessage = "Goods Receipt Process Summary\n\n";

      //   // Add successful results
      //   if (aSuccessResults.length > 0) {
      //     sMessage += `✅ SUCCESSFUL (${aSuccessResults.length}):\n`;
      //     aSuccessResults.forEach(result => {
      //       sMessage += `   • Production Order ${result.productionOrder}: Material Document ${result.materialDocument}/${result.year}`;
      //       if (result.warning) {
      //         sMessage += ` (Warning: ${result.warning.substring(0, 50)}...)`;
      //       }
      //       sMessage += `\n`;
      //     });
      //     sMessage += "\n";
      //   }

      //   // Add error results
      //   if (aErrorResults.length > 0) {
      //     sMessage += `❌ FAILED (${aErrorResults.length}):\n`;
      //     aErrorResults.forEach(result => {
      //       // Truncate long error messages
      //       let sErrorMsg = result.error;
      //       if (sErrorMsg.length > 100) {
      //         sErrorMsg = sErrorMsg.substring(0, 100) + "...";
      //       }
      //       sMessage += `   • Production Order ${result.productionOrder}: ${sErrorMsg}\n`;
      //     });
      //     sMessage += "\n";
      //   }

      //   // Add totals
      //   const iTotalProcessed = aSuccessResults.length + aErrorResults.length;
      //   sMessage += `Total Processed: ${iTotalProcessed}\n`;
      //   sMessage += `Successful: ${aSuccessResults.length}\n`;
      //   sMessage += `Failed: ${aErrorResults.length}`;

      //   // Create a detailed message for dialog
      //   let sDetailedMessage = "";
      //   if (aErrorResults.length > 0) {
      //     sDetailedMessage = "Detailed Errors:\n\n";
      //     aErrorResults.forEach(result => {
      //       sDetailedMessage += `Production Order ${result.productionOrder}:\n`;
      //       sDetailedMessage += `${result.error}\n\n`;
      //     });
      //   }

      //   // Add warnings to detailed message
      //   const aWarnings = aSuccessResults.filter(result => result.warning);
      //   if (aWarnings.length > 0) {
      //     sDetailedMessage += "\nWarnings:\n\n";
      //     aWarnings.forEach(result => {
      //       sDetailedMessage += `Production Order ${result.productionOrder}:\n`;
      //       sDetailedMessage += `${result.warning}\n\n`;
      //     });
      //   }

      //   if (aErrorResults.length === 0 && aWarnings.length === 0) {
      //     // All successful without warnings
      //     sap.m.MessageBox.success(sMessage, {
      //       title: "Process Complete"
      //     });
      //   } else if (aSuccessResults.length === 0) {
      //     // All failed
      //     sap.m.MessageBox.error(sMessage, {
      //       title: "Process Failed",
      //       details: sDetailedMessage,
      //       contentWidth: "600px"
      //     });
      //   } else if (aWarnings.length > 0 && aErrorResults.length === 0) {
      //     // Some warnings but no errors
      //     sap.m.MessageBox.warning(sMessage, {
      //       title: "Process Completed with Warnings",
      //       details: sDetailedMessage,
      //       contentWidth: "600px"
      //     });
      //   } else {
      //     // Mixed results (both errors and successes)
      //     sap.m.MessageBox.warning(sMessage, {
      //       title: "Process Completed with Errors",
      //       details: sDetailedMessage,
      //       contentWidth: "600px"
      //     });
      //   }

      //   // Show toast message
      //   if (aSuccessResults.length > 0) {
      //     sap.m.MessageToast.show(`Goods Receipt completed for ${aSuccessResults.length} production order(s).`);
      //   }
      // },


      onGoodsReceiptPress: async function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
        const oTabModel = oView.getModel("TabModel");
        const aRows = oTabModel.getProperty("/Samples");
        const aSelectedRows = aRows.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        let aBlockerErrors = [];

        aSelectedRows.forEach((row) => {
          let errors = [];

          if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            errors.push("Missing Goods Issue Confirmation");
          }

          if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            errors.push("Goods Receipt already exists");
          }

          if (errors.length > 0) {
            const sProdOrder = row.productionorderno || "(No Production Order)";
            aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
          }
        });

        if (aBlockerErrors.length > 0) {
          sap.m.MessageBox.warning(
            "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
          );
          return;
        }

        // --- 🧪 VALIDATION (field completeness)
        let aValidationErrors = [];

        aSelectedRows.forEach((row) => {
          let missingFields = [];
          if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

          if (missingFields.length > 0) {
            const sProdOrder = row.productionorderno || "(No Production Order)";
            aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
          }
        });

        if (aValidationErrors.length > 0) {
          sap.m.MessageBox.error(
            "Missing required fields:\n\n" + aValidationErrors.join("\n")
          );
          return;
        }

        // --- ✅ PROCESSING (all validations passed)
        sap.ui.core.BusyIndicator.show(0);

        // Arrays to collect results
        const aSuccessResults = [];
        const aErrorResults = [];

        for (let i = 0; i < aSelectedRows.length; i++) {
          const row = aSelectedRows[i];
          const sProdOrder = row.productionorderno || `Row ${i + 1}`;

          const oPayload = {
            material: row.materialcode,
            plant: row.plant,
            storagelocation: row.storagelocation,
            goodsmovementtype: "101",
            manufacturingorder: row.productionorderno,
            manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            goodsmovementrefdoctype: "F",
            quantityinentryunit: String(row.confirmedqty),
            postingdate: new Date(),
            goodsmovementcode: "02"
          };
          console.log("payload:", oPayload);

          try {
            const oData = await new Promise((resolve, reject) => {
              oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
                success: function (oData) {
                  console.log("result:", oData);
                  // Check if material document exists AND if errorresponse is present
                  if (!oData.materialdocument && oData.errorresponse) {
                    // This is an error returned in success response
                    let errorMessage = "Unknown error";
                    try {
                      const errorObj = JSON.parse(oData.errorresponse);
                      errorMessage = errorObj.error?.message?.value || errorObj.error?.message || oData.errorresponse;
                    } catch (e) {
                      errorMessage = oData.errorresponse;
                    }
                    reject(new Error(errorMessage));
                  } else if (!oData.materialdocument) {
                    // No material document and no error response
                    reject(new Error("No material document returned"));
                  } else {
                    resolve(oData);
                  }
                },
                error: reject
              });
            });

            console.log("result:", oData);

            // If we get here, we have a valid material document
            row.grmaterialdocnumber = oData.materialdocument;
            row.grmaterialdocyear = oData.matdocyear;

            const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
            row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

            await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

            // Add to success list
            aSuccessResults.push({
              productionOrder: sProdOrder,
              materialDocument: oData.materialdocument,
              year: oData.matdocyear
            });

          } catch (oError) {
            console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

            // Extract error message
            let sErrorMessage = oError.message || "Unknown error";

            // For OData errors
            if (oError.responseText) {
              try {
                const oErrorResponse = JSON.parse(oError.responseText);
                if (oErrorResponse.error && oErrorResponse.error.message) {
                  sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                }
              } catch (e) {
                sErrorMessage = oError.responseText;
              }
            }

            // Add to error list
            aErrorResults.push({
              productionOrder: sProdOrder,
              error: sErrorMessage
            });
          }
        }

        // Update the model with processed rows
        oTabModel.setProperty("/Samples", aRows);
        oTabModel.refresh();
        sap.ui.core.BusyIndicator.hide();

        // Show summary message
        this.showGRSummary(aSuccessResults, aErrorResults);
      },

      // Also update the showGRSummary to be consistent with our other summaries:
      showGRSummary: function (aSuccessResults, aErrorResults) {
        const sTotal = aSuccessResults.length + aErrorResults.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
        let bHasSuccess = aSuccessResults.length > 0;
        let bHasFailed = aErrorResults.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
          aSuccessResults.forEach(result => {
            sMessage += `   - Production Order ${result.productionOrder}`;
            if (result.materialDocument) {
              sMessage += ` (Material Doc: ${result.materialDocument}/${result.year})`;
            }
            sMessage += `\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
          aErrorResults.forEach(result => {
            sMessage += `   - Production Order ${result.productionOrder}: ${result.error}\n`;
          });
        }

        // Always show MessageBox for all cases (consistent with other summaries)
        setTimeout(() => {
          if (bHasFailed) {
            // Show detailed error dialog with summary
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.ERROR,
                title: "Goods Receipt Process Summary",
                actions: [sap.m.MessageBox.Action.OK],
                details: aErrorResults.map(f =>
                  `Production Order: ${f.productionOrder}\nError: ${f.error}`
                ).join('\n\n')
              }
            );
          } else {
            // Show success dialog
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.SUCCESS,
                title: "Goods Receipt Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          }
        }, 100);
      },



      ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
        return new Promise((resolve, reject) => {
          sap.ui.core.BusyIndicator.show();
          var that = this;
          var oModelGet = that.getView().getModel("ZSB_BELTFG_PLAN");

          var oEntry = {
            grmaterialdocnumber: resp.materialdocument,
            grmaterialdocyear: resp.matdocyear,
            // manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
            // batchweight: HeaderModel.batchweight,
            operator: HeaderModel.operator,
            inspector: HeaderModel.inspector,
            // confirmedqty:HeaderModel.confirmedqty,
            // batchweight: String(parseInt(HeaderModel.confirmedqty)),
            // expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

          };
          // debugger
          // console.log("uuid:",HeaderModel.sap_uuid)
          console.log("Updating Internal Table for UUID:", HeaderModel.sap_uuid, oEntry);
          if (!HeaderModel.sap_uuid) {
            sap.m.MessageBox.error("UUID is missing! Cannot update internal table.");
            return;
          }

          // it is skipping this full section and not updadtin to table
          oModelGet.update("/ZC_BELTFG_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            success: function (oData) {
              console.log("✅ Internal Table Updated Successfully.");
              sap.ui.core.BusyIndicator.hide();
              resolve(oData);
            },
            error: function (error) {
              console.error("❌ Internal Table Update Failed");
              sap.ui.core.BusyIndicator.hide();
              sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
              reject(error);
            }
          });
        });
      },

      ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
        // debugger
        var that = this;
        return new Promise((resolve, reject) => {
          var oView = that.getView();

          // Safely get the backend model
          var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
          if (!oModel) {
            sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
            return;
          }
          var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
          // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
          var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
          // Call the read function
          oModel.read("/ZC_MAT_DOC_ITEM", {
            filters: [oFilterMatDoco, oFilterMatDocyear],
            success: function (oData) {

              resolve(oData.results)

            },
            error: function (oError) {
              oView.setBusy(false);
              sap.m.MessageBox.error("Failed to retrieve BeltFG Plan data.");
              console.error("OData read error:", oError);
              reject(oError)
            }
          });
        });
      },




      onGRScreenCancel: function () {
        if (this._oGRDialog) {
          this._oGRDialog.close();
          this._oGRDialog.destroy();
          this._oGRDialog = null;
        }
      }





    });
  }
);
