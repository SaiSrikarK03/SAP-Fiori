sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/odata/v2/ODataModel",
        "sap/m/MessageToast",
        "sap/m/MessageBox",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/IconPool",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/ui/export/Spreadsheet",
        "sap/ui/export/library",
        "sap/m/PDFViewer",
        "bando/util/importfile/importexcelfile",
        "bando/util/pdf-lib/pdf-lib.min",
        "sap/ui/core/Fragment",
    ],
    function (
        BaseController,
        JSONModel,
        ODataModel,
        MessageToast,
        MessageBox,
        Filter,
        FilterOperator,
        IconPool,
        Component,
        UIComponent,
        Router,
        Spreadsheet,
        exportLibrary,

        PDFViewer,
        importexcelfile,
        PDFLibjs,
        Fragment
    ) {
        "use strict";

        return BaseController.extend(
            "bando.controller.REQ_QTY_Vs_ACT_QTY.REQ_QTY_Vs_ACT_QTY",
            {
                onInit: function () {
                    this._oMultiInput = this.byId("idmaterialdocument");

                    this.getView().setModel(
                        new JSONModel({ ItemData: [] }),
                        "TabModel"
                    );

                    this.getView().setModel(
                        new ODataModel("/sap/opu/odata/sap/ZSB_REQ_ACTUAL/"),
                        "ZSB_REQ_ACTUAL"
                    );

                    this.getView().setModel(
                        new ODataModel("/sap/opu/odata/sap/ZSB_REQ_MOVEMENT_TYPE/"),
                        "ZSB_REQ_MOVEMENT_TYPE"
                    );
                },

                _normalizeOrder: function (sOrder) {
                    return sOrder ? sOrder.replace(/^0+/, "") : "";
                },

                _fetchAllData: function (
                    oModel,
                    sEntitySet,
                    aFilters,
                    iSkip,
                    iTop,
                    aResult,
                    fnSuccess,
                    fnError
                ) {
                    oModel.read(sEntitySet, {
                        filters: aFilters,
                        urlParameters: {
                            "$skip": iSkip,
                            "$top": iTop
                        },
                        success: function (oData) {
                            aResult = aResult.concat(oData.results || []);
                            if (oData.results && oData.results.length === iTop) {
                                this._fetchAllData(
                                    oModel,
                                    sEntitySet,
                                    aFilters,
                                    iSkip + iTop,
                                    iTop,
                                    aResult,
                                    fnSuccess,
                                    fnError
                                );
                            } else {
                                fnSuccess(aResult);
                            }
                        }.bind(this),
                        error: fnError
                    });
                },

                _buildMovementFilter: function (aFinalData) {
                    var aParts = [];
                    var oSeen = {};

                    aFinalData.forEach(function (oRow) {
                        if (oRow.isSumRow || !oRow.productionorder || !oRow.Material) {
                            return;
                        }

                        var sOrder = this._normalizeOrder(oRow.productionorder);
                        var sKey = sOrder + "_" + oRow.Material;

                        if (oSeen[sKey]) return;
                        oSeen[sKey] = true;

                        aParts.push(
                            "(OrderID eq '" + sOrder + "' and Material eq '" + oRow.Material + "')"
                        );
                    }.bind(this));

                    return aParts.join(" or ");
                },

                _fetchMovementTypesByFilter: function (sFilter, fnSuccess, fnError) {
                    var oMovModel = this.getView().getModel("ZSB_REQ_MOVEMENT_TYPE");

                    oMovModel.read("/ZC_REQ_Movement_type", {
                        urlParameters: {
                            "$filter": sFilter
                        },
                        success: function (oData) {
                            fnSuccess(oData.results || []);
                        },
                        error: fnError
                    });
                },

                GoStockReqTableOpen: function () {
                    var oView = this.getView();
                    var oModel = oView.getModel("ZSB_REQ_ACTUAL");
                    var oTabModel = oView.getModel("TabModel");

                    var sMaterial = oView.byId("idMaterial_")?.getValue()?.trim() || "";
                    var aTokens = oView.byId("idmaterialdocument")?.getTokens() || [];
                    var oDate = oView.byId("idOrder").getDateValue();

                    if (!oDate) {
                        MessageToast.show("Please select a date");
                        return;
                    }

                    var sDate =
                        oDate.getFullYear() + "-" +
                        String(oDate.getMonth() + 1).padStart(2, "0") + "-" +
                        String(oDate.getDate()).padStart(2, "0");

                    var aFilters = [];

                    if (sMaterial) {
                        aFilters.push(new Filter("Material", FilterOperator.EQ, sMaterial));
                    }

                    if (aTokens.length > 0) {
                        var aOrderFilters = aTokens.map(function (oToken) {
                            var sOrder = oToken.getKey() || oToken.getText();
                            return new Filter(
                                "productionorder",
                                FilterOperator.EQ,
                                sOrder.startsWith("000") ? sOrder : "000" + sOrder
                            );
                        });
                        aFilters.push(new Filter({ filters: aOrderFilters, and: false }));
                    }

                    aFilters.push(new Filter("MatlCompRequirementDate", FilterOperator.EQ, sDate));

                    oView.setBusy(true);

                    // ==== Read OData with $top large number ====
                    oModel.read("/ZCE_REQ_ACTUAL", {
                        filters: aFilters,
                        urlParameters: { "$top": 9999 },
                        success: function (oData) {
                            var aResults = oData.results || [];

                            if (!aResults.length) {
                                oTabModel.setProperty("/ItemData", []);
                                MessageToast.show("No records found");
                                oView.setBusy(false);
                                return;
                            }

                            // ===== Build MovementType filter =====
                            var sMovFilter = this._buildMovementFilter(aResults);
                            if (!sMovFilter) {
                                oTabModel.setProperty("/ItemData", []);
                                oView.setBusy(false);
                                return;
                            }

                            // ===== Fetch Movement Types =====
                            this._fetchMovementTypesByFilter(
                                sMovFilter,
                                function (aMoves) {
                                    var oMovMap = {};
                                    aMoves.forEach(function (oMove) {
                                        oMovMap[oMove.OrderID + "_" + oMove.Material] = oMove.MovementType;
                                    });

                                    // Merge MovementType
                                    aResults.forEach(function (oRow) {
                                        var sKey = this._normalizeOrder(oRow.productionorder) + "_" + oRow.Material;
                                        oRow.MovementType = oMovMap[sKey] || "";
                                    }.bind(this));

                                    // Filter out 261
                                    var aFilteredResults = aResults.filter(o => o.MovementType !== "261");

                                    if (!aFilteredResults.length) {
                                        oTabModel.setProperty("/ItemData", []);
                                        oView.setBusy(false);
                                        MessageToast.show("No records after filtering 261");
                                        return;
                                    }

                                    // ===== Group totals & final table build =====
                                    var oGroupTotals = {};
                                    aFilteredResults.forEach(function (oItem) {
                                        var sKey = oItem.productionorder + "_" + oItem.Material;
                                        if (!oGroupTotals[sKey]) {
                                            oGroupTotals[sKey] = {
                                                totalAVB: 0,
                                                totalAVN: 0,
                                                requiredQty: parseFloat(oItem.RequiredQuantity) || 0
                                            };
                                        }

                                        if (oItem.storagelocation === oItem.storagelocation1) {
                                            oGroupTotals[sKey].totalAVB += parseFloat(oItem.MatlWrhsStkQtyInMatlBase) || 0;
                                        }

                                        if (oItem.storagelocation1 === "12RM") {
                                            oGroupTotals[sKey].totalAVN += parseFloat(oItem.MatlWrhsStkQtyInMatlBase) || 0;
                                        }
                                    });

                                    // Build final array with sum rows
                                    var aFinalData = [];
                                    var currentKey = "";
                                    var sumReq = 0, sumAVB = 0, sumAVN = 0;
                                    var oReqShown = {}, oBalShown = {};

                                    aFilteredResults.forEach(function (oItem) {
                                        var sKey = oItem.productionorder + "_" + oItem.Material;

                                        // Push sum row if new key
                                        if (currentKey && currentKey !== sKey) {
                                            aFinalData.push({
                                                Material: "Total",
                                                RequiredQuantity: sumReq.toFixed(4),
                                                col2: sumAVB.toFixed(4),
                                                MatlWrhsStkQtyInMatlBase1: sumAVN.toFixed(4),
                                                BalanceQuantity: (sumAVB - sumReq).toFixed(4),
                                                isSumRow: true
                                            });
                                            sumReq = sumAVB = sumAVN = 0;
                                        }

                                        currentKey = sKey;

                                        var reqQty = 0, dispReq = "";
                                        if (!oReqShown[sKey]) {
                                            reqQty = oGroupTotals[sKey].requiredQty;
                                            dispReq = reqQty.toFixed(4);
                                            oReqShown[sKey] = true;
                                        }

                                        var dispBal = "";
                                        if (!oBalShown[sKey]) {
                                            dispBal = (oGroupTotals[sKey].totalAVB - oGroupTotals[sKey].requiredQty).toFixed(4);
                                            oBalShown[sKey] = true;
                                        }

                                        var avbQty = oItem.storagelocation === oItem.storagelocation1
                                            ? parseFloat(oItem.MatlWrhsStkQtyInMatlBase) || 0
                                            : 0;

                                        var avbAlt = oItem.storagelocation1 === "12RM"
                                            ? parseFloat(oItem.MatlWrhsStkQtyInMatlBase) || 0
                                            : 0;

                                        aFinalData.push({
                                            ...oItem,
                                            RequiredQuantity: dispReq,
                                            col2: avbQty ? avbQty.toFixed(4) : "",
                                            MatlWrhsStkQtyInMatlBase1: avbAlt ? avbAlt.toFixed(4) : "",
                                            BalanceQuantity: dispBal,
                                            BatchForCol2: avbQty ? oItem.Batch : "",
                                            BatchForMatlWrhs: avbAlt ? oItem.Batch : "",
                                            isSumRow: false
                                        });

                                        sumReq += reqQty;
                                        sumAVB += avbQty;
                                        sumAVN += avbAlt;
                                    });

                                    // Push final sum row
                                    if (currentKey) {
                                        aFinalData.push({
                                            Material: "Total",
                                            RequiredQuantity: sumReq.toFixed(4),
                                            col2: sumAVB.toFixed(4),
                                            MatlWrhsStkQtyInMatlBase1: sumAVN.toFixed(4),
                                            BalanceQuantity: (sumAVB - sumReq).toFixed(4),
                                            isSumRow: true
                                        });
                                    }

                                    oTabModel.setProperty("/ItemData", aFinalData);
                                    oView.setBusy(false);

                                }.bind(this),
                                function (oError) {
                                    oView.setBusy(false);
                                    MessageBox.error("Failed to fetch Movement Types");
                                    console.error(oError);
                                }
                            );

                        }.bind(this),
                        error: function (oError) {
                            oView.setBusy(false);
                            MessageBox.error("Error fetching data");
                            console.error(oError);
                        }
                    });
                },


                absTwoDecimals_: function (value) {
                    if (!value || parseFloat(value) === 0) return "";
                    return parseFloat(value).toFixed(4);
                },

                absTwoDecimals: function (v) {
                    var n = parseFloat(v);
                    return isNaN(n) ? "0.00" : n.toFixed(2);
                },

                formatTwoDecimals: function (value) {
                    return isNaN(value) ? "0.00" : parseFloat(value).toFixed(2);
                },

                formatDate: function (sDate) {
                    if (!sDate) return "";
                    var oDate = new Date(sDate);
                    return sap.ui.core.format.DateFormat
                        .getDateInstance({ pattern: "dd/MM/yyyy" })
                        .format(oDate);
                },

                onNavGroupSelect: function (oEvent) {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("REQ_QTY_Vs_ACT_QTY");
                },

                onDownload: function () {
                var oTable = this.getView().byId("_idREQ_VS_ACT");
                var aData = oTable.getBinding("rows").getModel().getProperty("/ItemData");

                // Prepare export data
                var aExportData = aData.map(o => {
                    return Object.assign({}, o, {
                        BalanceQuantity: Math.abs(parseFloat(o.BalanceQuantity || 0)).toFixed(4)
                    });
                });

                var aCols = this.createColumns();

                var oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aExportData,
                    fileName: "REQ_VS_ACT_Report.xlsx"
                };

                var oSheet = new Spreadsheet(oSettings);
                oSheet.build().finally(function () {
                    oSheet.destroy();
                });
            },

            createColumns: function () {
            var EdmType = exportLibrary.EdmType;

            return [

                {
                    label: "Date",
                    property: "MatlCompRequirementDate",
                    type: EdmType.Date
                },

                {
                    label: "Production Order",
                    property: "productionorder",
                    type: EdmType.String
                },

                {
                    label: "Material",
                    property: "Material",
                    type: EdmType.String
                },

                {
                    label: "Product Description",
                    property: "productdescription",
                    type: EdmType.String
                },

                {
                    label: "Bill Of Operation Material",
                    property: "BillOfOperationsMaterial",
                    type: EdmType.String
                },

                {
                    label: "Production Order Operation",
                    property: "PRODUCTIONORDEROPERATION",
                    type: EdmType.String
                },

                {
                    label: "Reservation Item",
                    property: "RESERVATIONITEM",
                    type: EdmType.String
                },

                {
                    label: "Plant",
                    property: "Plant",
                    type: EdmType.String
                },

                {
                    label: "Required Quantity",
                    property: "RequiredQuantity",
                    type: EdmType.Decimal,
                    scale: 4
                },

                {
                    label: "Base Unit",
                    property: "BaseUnit",
                    type: EdmType.String
                },

                {
                    label: "Required Storage Location",
                    property: "storagelocation",
                    type: EdmType.String
                },

                /* 🔹 SHIFTED BATCH (col1) */
                {
                    label: "Batch",
                    property: "col1",
                    type: EdmType.String
                },

                /* 🔹 SHIFTED AVAILABLE QTY (col2) */
                {
                    label: "Available Quantity (Required SLoc)",
                    property: "col2",
                    type: EdmType.Decimal,
                    scale: 4
                },

                {
                    label: "Available Quantity (Available SLoc)",
                    property: "MatlWrhsStkQtyInMatlBase1",
                    type: EdmType.Decimal,
                    scale: 4
                },

                {
                    label: "Available Storage Location",
                    property: "ProductionInvtryManagedLoc",
                    type: EdmType.String
                },

                {
                    label: "Material Base Unit",
                    property: "MaterialBaseUnit",
                    type: EdmType.String
                },

                {
                    label: "Balance Quantity",
                    property: "BalanceQuantity",
                    type: EdmType.Decimal,
                    scale: 4
                }
            ];
        },

            onValueHelpRequest: function () {

                // var Date = this.getView().byId("Dates_").getValue();

                var Date = "";

                // console.log(Date)
                if (Date || Date.length == 0) {
                    sap.ui.core.BusyIndicator.show();

                    //   var oFilters1 = new sap.ui.model.Filter("Createdat", sap.ui.model.FilterOperator.EQ, Date);
                    // Retrieve the model from the view
                    var oModel = this.getView().getModel("ZSB_REQ_ACTUAL");

                    // Check if the model is valid
                    if (!oModel) {
                        console.error("OData model is not properly initialized.");
                        sap.ui.core.BusyIndicator.hide();
                        return;
                    }

                    //   var oFilters = [oFilters1];
                    var that = this;
                    var aAllItems = []; // Array to hold all retrieved items

                    // Function to fetch data recursively
                    function fetchData(skipCount) {
                        // var that = this;
                        // var oModel = that.getView().getModel();
                        // that.getView().setModel(oModel);
                        oModel.read("/ZC_REQ_F4HELP", {
                            //   filters: oFilters,
                            urlParameters: {
                                $top: 5000,  // Request a chunk of 5000 records
                                $skip: skipCount  // Start from the skipCount position
                            },
                            success: function (oData) {
                                var aItems = oData.results;
                                aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                                // Check if there are more records to fetch
                                if (oData.results.length >= 5000) {
                                    // If there are more records, fetch next chunk
                                    fetchData(skipCount + 5000);
                                } else {
                                    // If no more records, all data is fetched
                                    finishFetching();
                                }
                            },
                            error: function (oError) {
                                console.error("Error reading data: ", oError);
                                sap.ui.core.BusyIndicator.hide();
                            }
                        });
                    }

                    function finishFetching() {


                        // Once all data is fetched, proceed to display it
                        that.oJSONModel = new sap.ui.model.json.JSONModel({
                            Datas: aAllItems
                        });
                        that.getView().setModel(that.oJSONModel, "oJSONModel");
                        console.log("that.oJSONModel:", that.oJSONModel)

                        // Load the value help dialog fragment
                        that._oBasicSearchField = new sap.m.SearchField(); 
                        that.loadFragment({
                            name: "bando.view.REQ_QTY_Vs_ACT_QTY.fragment.REQ_QTY_Vs_ACT_QTY_",
                        }).then(function (oDialog) {
                            var oFilterBar = oDialog.getFilterBar();

                            var oColumnProductCode, oColumnPostingDate, oColumnCompanyCode;
                            that._oVHD = oDialog;
                            that.getView().addDependent(oDialog);

                            // Set key fields for filtering in the Define Conditions Tab
                            oDialog.setRangeKeyFields([{
                                label: "Production No.",
                                key: "productionorder",
                                type: "string",
                                typeInstance: new sap.ui.model.type.String({}, {
                                    maxLength: 10
                                })
                            }]);

                            // Set Basic Search for FilterBar
                            oFilterBar.setFilterBarExpanded(false);
                            oFilterBar.setBasicSearch(that._oBasicSearchField);

                            // Trigger filter bar search when the basic search is fired
                            that._oBasicSearchField.attachSearch(function () {
                                oFilterBar.search();
                            });

                            oDialog.getTableAsync().then(function (oTable) {
                                oTable.setModel(that.oJSONModel);

                                // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                                if (oTable.bindRows) {
                                    // Desktop/Table scenario (sap.ui.table.Table)
                                    oTable.bindAggregation("rows", {
                                        path: "oJSONModel>/Datas",
                                        events: {
                                            dataReceived: function () {
                                                oDialog.update();
                                            }
                                        }
                                    });

                                    // Define columns for sap.ui.table.Table
                                    oColumnProductCode = new sap.ui.table.Column({
                                        label: new sap.m.Label({ text: "Production No." }),
                                        template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>productionorder}" })
                                    });
                                    oColumnProductCode.data({
                                        fieldName: "productionorder"
                                    });

                                    oTable.addColumn(oColumnProductCode);


                                } else if (oTable.bindItems) {
                                    // Mobile scenario (sap.m.Table)
                                    oTable.bindAggregation("items", {
                                        path: "oJSONModel>/Datas",
                                        template: new sap.m.ColumnListItem({
                                            cells: [
                                                new sap.m.Text({ text: "{oJSONModel>productionorder}" }),

                                            ]
                                        }),
                                        events: {
                                            dataReceived: function () {
                                                oDialog.update();
                                            }
                                        }
                                    });

                                    // Define columns for sap.m.Table (if necessary)
                                    oTable.addColumn(new sap.m.Column({
                                        header: new sap.m.Label({ text: "Production No." })
                                    }));

                                }

                                oDialog.update();
                                sap.ui.core.BusyIndicator.hide();
                            });

                            oDialog.open();
                            sap.ui.core.BusyIndicator.hide();
                        });
                    }

                    // Start fetching data from the beginning
                    fetchData(0);
                } else {
                    //   sap.m.MessageBox.error("Please check Company Code / Fiscal Year");
                    sap.ui.core.BusyIndicator.hide();
                }
            },

            onValueHelpOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");
                console.log("aTokens:", aTokens)
                this.SelectInputType = 'fragment'
                if (aTokens.length <= 10) {
                    this._oMultiInput.setTokens(aTokens);
                    this._oVHD.close();
                } else {
                    // sap.m.MessageToast.show("Please Select max 10 Accounting documents only...!");
                    sap.m.MessageBox.error("Please Select max 15 Accounting documents only...!");
                }

            },

            onValueHelpCancelPress: function () {
                this._oVHD.close();
            },

            onValueHelpAfterClose: function () {
                this._oVHD.destroy();
            },

            onFilterBarSearch: function (oEvent) {
                var sSearchQuery = this._oBasicSearchField.getValue(),
                    aSelectionSet = oEvent.getParameter("selectionSet");

                var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                    if (oControl.getValue()) {
                        aResult.push(new sap.ui.model.Filter({
                            path: oControl.getName(),
                            operator: FilterOperator.Contains,
                            value1: oControl.getValue()
                        }));
                    }

                    return aResult;
                }, []);

                aFilters.push(new sap.ui.model.Filter({
                    filters: [
                        new sap.ui.model.Filter({ path: "productionorder", operator: sap.ui.model.FilterOperator.EQ, value1: sSearchQuery })

                    ],
                    and: false
                }));

                this._filterTable(new sap.ui.model.Filter({
                    filters: aFilters,
                    and: true
                }));
            },

            _filterTable: function (oFilter) {
                var oVHD = this._oVHD;

                oVHD.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.getBinding("rows").filter(oFilter);
                    }
                    if (oTable.bindItems) {
                        oTable.getBinding("items").filter(oFilter);
                    }

                    // This method must be called after binding update of the table.
                    oVHD.update();
                });
            },

            OnSuggest_User: function (oEvent) {
                var sTerm = oEvent.getParameter("suggestValue");
                console.log("Press")

                this._connectToODataProductSearchService(sTerm)
                    .then(function (aSuggestions) {
                        // Clear previous suggestions
                        this.destroySuggestionItems();
                        // Add new suggestions to the input field
                        for (var i = 0; i < aSuggestions.length; i++) {
                            this.addSuggestionItem(new sap.ui.core.Item({
                                text: aSuggestions[i]
                            }));
                        }
                    }.bind(oEvent.getSource()));
            },

            // Connect to the OData service and fetch suggestions
            _connectToODataProductSearchService: function (sTerm) {
                var oModel = this.getView().getModel('ZSB_REQ_ACTUAL'); // OData Model
                var aFilters = [
                    new sap.ui.model.Filter("productionorder", sap.ui.model.FilterOperator.Contains, sTerm) // Search based on Name
                ];

                return new Promise(function (fnResolve, fnReject) {
                    // Perform OData read request
                    oModel.read("/ZC_REQ_F4HELP", {  // Replace "/ProductSet" with your OData entity set
                        filters: aFilters,
                        urlParameters: {
                            "$top": 5000
                        },
                        success: function (oData) {
                            var aResults = oData.results.map(function (mProduct) {
                                return mProduct.productionorder;  // Assuming Name is the field you're interested in
                            });

                            // Resolve with the list of suggestions
                            fnResolve(aResults);
                        },
                        error: function (oError) {
                            console.error("Error fetching suggestions from OData service:", oError);
                            fnReject(oError);
                        }
                    });
                });
            },

            // // // // Event handler for suggestion item selection
            ondocumentsuggestselected: function (oEvent) {
                // Show the busy indicator as soon as the item is selected
                sap.ui.core.BusyIndicator.show();

                var oSelectedItem = oEvent.getParameter("selectedItem");
                if (oSelectedItem) {
                    var sSelectedKey = oSelectedItem.getKey();
                    var sSelectedText = oSelectedItem.getText();
                    console.log("Selected Item:", sSelectedKey, sSelectedText);
                    this.SelectInputType = 'select'
                    // Set the selected key into the input field
                    var oMultiInput = this.getView().byId("idmaterialdocument");
                    oMultiInput.setValue(sSelectedText); // Set the selected key into the MultiInput field
                }

                // Hide the busy indicator after the update
                sap.ui.core.BusyIndicator.hide();
            },

            // Excel download (optional)
            
            // onDownload: function () {
            //     var oTable = this.getView().byId("_idREQ_VS_ACT");
            //     var oBinding = oTable.getBinding("rows");
            //     var aCols = this.createColumns();

            //     var oSettings = {
            //         workbook: { columns: aCols },
            //         dataSource: oBinding,
            //         fileName: "REQ_VS_ACT_Report.xlsx"
            //     };

            //     var oSheet = new Spreadsheet(oSettings);
            //     oSheet.build().finally(function () {
            //         oSheet.destroy();
            //     });
            // },

            }
        );
    }
);
