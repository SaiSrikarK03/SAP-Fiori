sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";
  return Controller.extend("bando.controller.master.SpecMasterDetails", {
    onInit() {
      // any init logic
    }
  });
});
