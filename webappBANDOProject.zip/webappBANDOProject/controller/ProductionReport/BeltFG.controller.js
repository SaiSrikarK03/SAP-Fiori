// sap.ui.define([
//     "sap/ui/core/mvc/Controller",
//     "sap/ui/core/Fragment",
//     "sap/ui/model/json/JSONModel",
//     "sap/ui/model/odata/v2/ODataModel",
//     "sap/ui/model/Filter",
//     "sap/ui/model/FilterOperator",
//     "sap/m/MessageToast",
//     "sap/ui/export/Spreadsheet"
// ], function (
//     Controller,
//     Fragment,
//     JSONModel,
//     ODataModel,
//     Filter,
//     FilterOperator,
//     MessageToast,
//     Spreadsheet
// ) {
//     "use strict";

//     return Controller.extend("bando.controller.ProductionReport.BeltFG", {

//         onInit: function () {
//             console.log("-> [INIT] BeltFG Controller initialized.");
//             this.getView().setModel(new JSONModel({ openscreen: "screen1" }), "ScreenVisible");
//             this.getView().setModel(new JSONModel({ Samples: [] }), "TabModel");

//             // Register OData models explicitly
//             var oProdReportModel = new ODataModel("/sap/opu/odata/sap/ZSB_PRODUCTION_REPORT/");
//             this.getView().setModel(oProdReportModel, "ZSB_PRODUCTION_REPORT");

//             var oMatMovModel = new ODataModel("/sap/opu/odata/sap/ZSB_MATMOVTTYPE/");
//             this.getView().setModel(oMatMovModel, "ZSB_MATMOVTTYPE");

//             var oUserModel = new JSONModel({});
//             if (sap.ushell && sap.ushell.Container) {
//                 var oUserInfo = sap.ushell.Container.getService("UserInfo");
//                 oUserModel.setData({
//                     id: oUserInfo.getId(),
//                     fullName: oUserInfo.getFullName()
//                 });
//             }
//             this.getView().setModel(oUserModel, "User");

//             var oUserMap = new JSONModel({
//                 "CB9980000061": "Sachin Kumar",
//                 "CB9980000039": "Rajesh",
//                 "CB9980000047": "Production",
//                 "CB9980000038": "PPC",
//                 "CB9980000052": "CHANNAPPA",
//                 "CB9980000050": "AJIS",
//                 "CB9980000090": "MADAN",
//                 "CB9980000067": "Vishwanath",
//                 "CB9980000068": "PPC-common",
//                 "CB9980000069": "Rajesh Naik",
//                 "CB9980000070": "Sachin",
//                 "CB9980000077": "Production Common",
//                 "CB9980000100": "Sachin Kumar",
//                 "CB9980000002": "Channappa Nidoni",
//                 "CB9980000010": "Ajis Kumar",
//                 "CB9980000007": "Basavaraj BS",
//                 "CB9980000109": "Vishwanath Maruti Madiwal",
//                 "CB9980000110": "Madan Pattar",
//                 "CB9980000111": "Manikandan C",
//                 "CB9980000015": "Vinod Kumar"
//             });
//             this.getView().setModel(oUserMap, "UserMap");
//         },

//         formatCreatedBy: function (sUserId) {
//             if (!sUserId) return "";
//             var oUserMap = this.getView().getModel("UserMap");
//             var sName = oUserMap.getProperty("/" + sUserId);
//             return sName ? sName : sUserId;
//         },

//         formatDate: function (vDate) {
//             if (!vDate) return "";
//             if (typeof vDate === "string" && vDate.indexOf("Date") !== -1) {
//                 vDate = parseInt(vDate.replace(/\/Date\((\d+)\)\//, "$1"), 10);
//             }
//             var oDate = new Date(vDate);
//             if (isNaN(oDate.getTime())) return "";
//             return sap.ui.core.format.DateFormat
//                 .getDateInstance({ pattern: "dd/MM/yyyy" })
//                 .format(oDate);
//         },

//         formatQty3Decimals: function (vValue) {
//             return (vValue === null || vValue === undefined || vValue === "")
//                 ? ""
//                 : Number(vValue).toFixed(3);
//         },

//         /* ================= NAVIGATION ================= */
//         onGoToScreen2: function () {
//             console.log("-> [NAVIGATION] Navigating to Screen 2 and executing precise relational mapping flow.");
//             this.getView().getModel("ScreenVisible").setProperty("/openscreen", "screen2");
//             this.getView().getModel("TabModel").setProperty("/Samples", []);
//             this.getView().setBusy(true);
//             this._loadProductionReportData();
//         },

//         onGoToScreen1: function () {
//             console.log("-> [NAVIGATION] Navigating back to Screen 1.");
//             this.getView().getModel("ScreenVisible").setProperty("/openscreen", "screen1");
//             this.getView().getModel("TabModel").setProperty("/Samples", []);
//         },

//         /* ================= BUILD SERVER-SIDE FILTERS ================= */
//         _buildProductionReportFilters: function () {
//             var oView = this.getView();
//             var aFilters = [];

//             var sFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
//             var sTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";
//             if (sFrom && sTo) {
//                 aFilters.push(new Filter("bomexplosiondate", FilterOperator.BT, sFrom + "T00:00:00", sTo + "T23:59:59"));
//             }

//             var oOrderTypeInput = oView.byId("idOrderType");
//             var sOrderType = oOrderTypeInput ? oOrderTypeInput.getValue().trim() : "";
//             if (sOrderType) {
//                 aFilters.push(new Filter("manufacturingordertype", FilterOperator.EQ, sOrderType));
//             }

//             var oStorLocInput = oView.byId("idStorLoc");
//             var sStorLoc = oStorLocInput ? oStorLocInput.getValue().trim() : "";
//             if (sStorLoc) {
//                 aFilters.push(new Filter("storagelocation", FilterOperator.EQ, sStorLoc));
//             }

//             var oProdOrdInput = oView.byId("idProductionOrder");
//             var sProdOrd = oProdOrdInput ? oProdOrdInput.getValue().trim() : "";
//             if (sProdOrd) {
//                 aFilters.push(new Filter("manufacturingorder", FilterOperator.EQ, sProdOrd));
//             }

//             var oMatCodeInput = oView.byId("idMaterialCode");
//             var sMatCode = oMatCodeInput ? oMatCodeInput.getValue().trim() : "";
//             if (sMatCode) {
//                 aFilters.push(new Filter("billofoperationsmaterial", FilterOperator.EQ, sMatCode));
//             }

//             console.log("-> [FILTERS] Production report filters count:", aFilters.length);
//             return aFilters;
//         },

//         _buildPlanFilters: function () {
//             var oView = this.getView();
//             var aFilters = [];

//             var sFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
//             var sTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";
//             if (sFrom && sTo) {
//                 aFilters.push(new Filter("productionordstartdate", FilterOperator.BT, sFrom + "T00:00:00", sTo + "T23:59:59"));
//             }

//             var oProdOrdInput = oView.byId("idProductionOrder");
//             var sProdOrd = oProdOrdInput ? oProdOrdInput.getValue().trim() : "";
//             if (sProdOrd) {
//                 aFilters.push(new Filter("productionorderno", FilterOperator.EQ, sProdOrd));
//             }

//             var oMatCodeInput = oView.byId("idMaterialCode");
//             var sMatCode = oMatCodeInput ? oMatCodeInput.getValue().trim() : "";
//             if (sMatCode) {
//                 aFilters.push(new Filter("materialcode", FilterOperator.EQ, sMatCode));
//             }

//             console.log("-> [FILTERS] Plan filters count:", aFilters.length);
//             return aFilters;
//         },

//         /* ================= COMPREHENSIVE FETCH & RELATIONAL MATCHING FLOW ================= */
//         _loadProductionReportData: function () {
//             var oView = this.getView();
//             var oTabModel = oView.getModel("TabModel");
//             var oProdRepModel = oView.getModel("ZSB_PRODUCTION_REPORT");
//             var oMatMovModel = oView.getModel("ZSB_MATMOVTTYPE");

//             var sRawFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
//             var sRawTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";

//             var aPlanServices = [
//                 { model: "ZSB_FG_PROCESS_PLAN", entity: "/ZC_FG_PROCESS_PLAN", source: "BELT" },
//                 { model: "ZSB_MOULDING_FG_PLAN", entity: "/ZC_MOULDING_FG_PLAN", source: "FG" },
//                 { model: "ZSB_MOULD_PLAN", entity: "/ZC_MOULD_PLAN", source: "SFG" },
//                 { model: "ZSB_CALEN_PLAN", entity: "/ZC_CALEN_PLAN", source: "CALEN" },
//                 { model: "ZSB_JOINT_PLAN", entity: "/ZC_JOINT_PLAN", source: "JOINT" },
//                 { model: "ZSB_MIXING_PLAN1", entity: "/ZC_MIXING_PLAN1", source: "MIXING" },
//                 { model: "ZSB_GEAR_PLAN", entity: "/ZC_GEAR_PLAN", source: "GEAR" },
//                 { model: "ZSB_WEIGHTROLLER_PLAN", entity: "/ZC_WEIGTHROLLER_PLAN", source: "WEIGHTROLLER" },
//                 { model: "ZSB_KIT_PLAN", entity: "/ZC_KIT_PLAN", source: "KIT" }
//             ];

//             var aPlanFilters = this._buildPlanFilters();
//             var aProdFilters = this._buildProductionReportFilters();

//             console.log("-> [STEP 1] Fetching all 9 plan services and ZCE_PRODUCTION_REPORT concurrently.");

//             var aPlanPromises = aPlanServices.map(function (srv) {
//                 var oModel = oView.getModel(srv.model);
//                 if (!oModel) {
//                     console.warn("-> [WARNING] Model not found for service:", srv.model);
//                     return Promise.resolve([]);
//                 }
//                 return this._fetchAllPages(oModel, srv.entity, aPlanFilters, 0).then(function (aResults) {
//                     return aResults.map(function (item) {
//                         item.__serviceSource = srv.source;
//                         return item;
//                     });
//                 });
//             }.bind(this));

//             var aProdPromise = oProdRepModel ? this._fetchAllPages(oProdRepModel, "/ZCE_PRODUCTION_REPORT", aProdFilters, 0) : Promise.resolve([]);

//             Promise.all([Promise.all(aPlanPromises), aProdPromise]).then(function (aResponses) {
//                 var aPlanResultsArrays = aResponses[0];
//                 var aAllMergedPlans = [].concat.apply([], aPlanResultsArrays);
//                 var aProdRecords = aResponses[1];

//                 // Build foolproof hash lookup map for Production Report records indexed by order variants
//                 var oProdRepMap = {};
//                 aProdRecords.forEach(function (pRec) {
//                     var sMfgOrder = pRec.manufacturingorder || pRec.ManufacturingOrder || pRec.PRODUCTIONORDERNO || pRec.ProductionOrderNo || "";
//                     sMfgOrder = sMfgOrder.toString().trim();
                    
//                     var sCodes = pRec.statuscodes || pRec.StatusCodes || pRec.STATUSCODES || "";
//                     if (sCodes && sCodes.indexOf("%2C") !== -1) {
//                         sCodes = decodeURIComponent(sCodes);
//                     }

//                     if (sMfgOrder) {
//                         var oNorm = {
//                             manufacturingorder: sMfgOrder,
//                             statuscodes: sCodes,
//                             manufacturingordertype: pRec.manufacturingordertype || pRec.ManufacturingOrderType || "ZJO1",
//                             productdesc: pRec.productdesc || pRec.ProductDesc || "",
//                             mfgorderitemactualdeliverydate: pRec.mfgorderitemactualdeliverydate || pRec.MfgOrderItemActualDeliveryDate || null,
//                             productionplant: pRec.productionplant || pRec.ProductionPlant || "",
//                             productionversion: pRec.productionversion || pRec.ProductionVersion || "",
//                             storagelocation: pRec.storagelocation || pRec.StorageLocation || "",
//                             mrpcontroller: pRec.mrpcontroller || pRec.MrpController || "",
//                             productionsupervisor: pRec.productionsupervisor || pRec.ProductionSupervisor || "",
//                             batch: pRec.batch || pRec.Batch || "",
//                             mfgorderplannedtotalqty: pRec.mfgorderplannedtotalqty || pRec.MfgOrderPlannedTotalQty || "0.00",
//                             mfgorderplannedscarpqty: pRec.mfgorderplannedscarpqty || pRec.MfgOrderPlannedScarpQty || "0.00",
//                             actualdeliveredquantity: pRec.actualdeliveredquantity || pRec.ActualDeliveredQuantity || "0.00"
//                         };
//                         oProdRepMap[sMfgOrder] = oNorm;
//                         oProdRepMap[sMfgOrder.replace(/^0+/, '')] = oNorm;
//                         oProdRepMap[String(parseInt(sMfgOrder, 10))] = oNorm;
//                         oProdRepMap[sMfgOrder.padStart(12, "0")] = oNorm;
//                         oProdRepMap[sMfgOrder.padStart(10, "0")] = oNorm;
//                     }
//                 });

//                 // Initial candidates mapping & Strict Date Window Crop Check
//                 var dStartDateObj = sRawFrom ? new Date(sRawFrom.split("/").reverse().join("-")) : null;
//                 var dEndDateObj = sRawTo ? new Date(sRawTo.split("/").reverse().join("-")) : null;
//                 if (dStartDateObj) dStartDateObj.setHours(0, 0, 0, 0);
//                 if (dEndDateObj) dEndDateObj.setHours(23, 59, 59, 999);

//                 var aCandidateRows = [];
//                 aAllMergedPlans.forEach(function (planItem) {
//                     var sProdOrd = planItem.productionorderno || planItem.ProductionOrderNo || "";
//                     sProdOrd = sProdOrd.toString().trim();
//                     planItem.productionorderno = sProdOrd;

//                     // Strict Date Boundary Verification (ensures dates outside range are dropped)
//                     var sItemDateVal = planItem.productionordstartdate || planItem.ProductionOrdStartDate || "";
//                     if (sItemDateVal && dStartDateObj && dEndDateObj) {
//                         var dItemDate = new Date(sItemDateVal);
//                         if (!isNaN(dItemDate.getTime())) {
//                             dItemDate.setHours(12, 0, 0, 0); // normalize timezone drift
//                             if (dItemDate < dStartDateObj || dItemDate > dEndDateObj) {
//                                 return; // Skip item completely if it falls outside filter boundary
//                             }
//                         }
//                     }

//                     var sStripped = sProdOrd.replace(/^0+/, '');
//                     var sParsed = String(parseInt(sProdOrd, 10));
//                     var sPad12 = sProdOrd.padStart(12, "0");
//                     var sPad10 = sProdOrd.padStart(10, "0");

//                     var oMatchedProd = oProdRepMap[sProdOrd] || 
//                                        oProdRepMap[sStripped] || 
//                                        oProdRepMap[sParsed] || 
//                                        oProdRepMap[sPad12] || 
//                                        oProdRepMap[sPad10];

//                     if (oMatchedProd) {
//                         planItem.manufacturingorder = oMatchedProd.manufacturingorder;
//                         planItem.statuscodes = oMatchedProd.statuscodes;
//                         planItem.manufacturingordertype = oMatchedProd.manufacturingordertype;
                        
//                         planItem.productdesc = oMatchedProd.productdesc;
//                         planItem.mfgorderitemactualdeliverydate = oMatchedProd.mfgorderitemactualdeliverydate;
//                         planItem.productionplant = oMatchedProd.productionplant;
//                         planItem.productionversion = oMatchedProd.productionversion;
//                         planItem.storagelocation = oMatchedProd.storagelocation;
//                         planItem.mrpcontroller = oMatchedProd.mrpcontroller;
//                         planItem.productionsupervisor = oMatchedProd.productionsupervisor;
//                         planItem.batch = oMatchedProd.batch;
//                         planItem.mfgorderplannedtotalqty = oMatchedProd.mfgorderplannedtotalqty;
//                         planItem.mfgorderplannedscarpqty = oMatchedProd.mfgorderplannedscarpqty;
//                         planItem.actualdeliveredquantity = oMatchedProd.actualdeliveredquantity;

//                         this._processRejectCodes(planItem);
//                         aCandidateRows.push(planItem);
//                     }
//                 }.bind(this));

//                 if (!aCandidateRows.length) {
//                     oTabModel.setProperty("/Samples", []);
//                     oView.setBusy(false);
//                     MessageToast.show("No data found matching criteria.");
//                     return;
//                 }

//                 // Batch Check: Validate GoodsMovementType == '101' using ManufacturingOrder & Material filters
//                 var aMovChecks = aCandidateRows.map(function (row) {
//                     var sProdOrd = row.productionorderno || "";
//                     var sMatCode = row.materialcode || "";
//                     if (!sProdOrd || !sMatCode) return Promise.resolve({ row: row, isValid: false });

//                     return new Promise(function (resolveMov) {
//                         oMatMovModel.read("/ZCE__MatProd_MovTyp", {
//                             filters: [
//                                 new Filter("ManufacturingOrder", FilterOperator.EQ, sProdOrd),
//                                 new Filter("Material", FilterOperator.EQ, sMatCode)
//                             ],
//                             urlParameters: { "$top": 1 },
//                             success: function (oMovData) {
//                                 var aResults = oMovData.results || [];
//                                 var bIs101 = aResults.some(function (m) {
//                                     return (m.GoodsMovementType || m.goodsMovementType || "") === "101";
//                                 });
//                                 resolveMov({ row: row, isValid: bIs101 });
//                             },
//                             error: function () {
//                                 resolveMov({ row: row, isValid: false });
//                             }
//                         });
//                     });
//                 });

//                 Promise.all(aMovChecks).then(function (aCheckedResults) {
//                     var aValidRows = [];
//                     aCheckedResults.forEach(function (res) {
//                         if (res.isValid) {
//                             aValidRows.push(res.row);
//                         }
//                     });

//                     // --- Reject Code Filter Logic ---
//                     var oRejectInput = oView.byId("idRejectCode");
//                     var sRejectInputVal = oRejectInput ? oRejectInput.getValue().trim() : "";
                    
//                     if (sRejectInputVal) {
//                         var aTargetCodes = sRejectInputVal.split(",").map(function(s) {
//                             return s.trim();
//                         }).filter(Boolean);

//                         aValidRows = aValidRows.filter(function(row) {
//                             var sCodesStr = row.RejectCodes || row.rejectcodes || "";
//                             if (!sCodesStr) return false;

//                             var aPairs = sCodesStr.split(",");
//                             return aTargetCodes.some(function(targetCode) {
//                                 return aPairs.some(function(pair) {
//                                     var parts = pair.split("/");
//                                     var codeKey = parts[0] ? parts[0].trim() : "";
//                                     return codeKey === targetCode;
//                                 });
//                             });
//                         });
//                     }
//                     // --------------------------------

//                     // Sort valid rows in strict ascending order of production order
//                     aValidRows.sort(function (a, b) {
//                         var ordA = parseInt(a.productionorderno, 10) || 0;
//                         var ordB = parseInt(b.productionorderno, 10) || 0;
//                         return ordA - ordB;
//                     });

//                     console.log("-> [STEP 2 COMPLETE] Total rows retained where MovementType == '101' & Reject filter matches: " + aValidRows.length);

//                     if (!aValidRows.length) {
//                         MessageToast.show("No records found matching criteria.");
//                     }

//                     oTabModel.setProperty("/Samples", aValidRows);
//                     oView.setBusy(false);
//                 });

//             }.bind(this)).catch(function (oErr) {
//                 console.error("-> [ERROR] Failed during fetch and matching flow:", oErr);
//                 oView.setBusy(false);
//                 MessageToast.show("Failed to load report data.");
//             });
//         },

//         /* ================= PROCESS & NUMERICALLY SORT REJECT CODES ================= */
//         _processRejectCodes: function (row) {
//             if (!row) return;
            
//             var aPairs = [];
//             var sCodes = row.RejectCodes || row.rejectcodes || "";
//             if (sCodes) {
//                 sCodes.split(",").forEach(function (pair) {
//                     var parts = pair.split("/");
//                     if (!parts[0]) return;
//                     var nIndex = parseInt(parts[0].trim(), 10);
//                     if (!isNaN(nIndex)) {
//                         aPairs.push({
//                             index: nIndex,
//                             value: parts[1] !== undefined ? parts[1] : ""
//                         });
//                     }
//                 });
//             }

//             aPairs.sort(function (a, b) {
//                 return a.index - b.index;
//             });

//             for (let i = 1; i <= 62; i++) {
//                 row[`Code${i}`] = "";
//             }

//             let used = new Set();
//             aPairs.forEach(function (item) {
//                 if (!used.has(item.index) && item.index >= 1 && item.index <= 62) {
//                     row[`Code${item.index}`] = item.value;
//                     used.add(item.index);
//                 }
//             });
//         },

//         /* ================= FAST RECURSIVE PAGINATION ($top 5000, skip 0) ================= */
//         _fetchAllPages: function (oModel, sEntity, aFilters, iSkip, aAccum) {
//             var that = this;
//             iSkip = iSkip || 0;
//             aAccum = aAccum || [];
//             var iTop = 5000;

//             return new Promise(function (resolve) {
//                 if (!oModel) {
//                     resolve(aAccum);
//                     return;
//                 }
//                 oModel.read(sEntity, {
//                     filters: aFilters || [],
//                     urlParameters: { "$skip": iSkip, "$top": iTop },
//                     success: function (oData) {
//                         var aResults = oData.results || [];
//                         aAccum = aAccum.concat(aResults);

//                         if (aResults.length === iTop) {
//                             resolve(that._fetchAllPages(oModel, sEntity, aFilters, iSkip + iTop, aAccum));
//                         } else {
//                             resolve(aAccum);
//                         }
//                     },
//                     error: function (oErr) {
//                         console.warn("-> [PAGINATION ERROR] Failed fetching batch page at skip " + iSkip + " for " + sEntity, oErr);
//                         resolve(aAccum);
//                     }
//                 });
//             });
//         },

//         /* ================= VALUE HELPS & EXPORT ================= */
//         onOrderTypeValueHelp: function (oEvent) {
//             console.log("-> [VALUE HELP] Opening Order Type Value Help.");
//             this._valueHelpInput = oEvent.getSource();
//             if (!this._orderTypeDialog) {
//                 Fragment.load({
//                     name: "bando.view.ProductionReport.fragments.OrderTypeValueHelp",
//                     controller: this
//                 }).then(function (oDialog) {
//                     this._orderTypeDialog = oDialog;
//                     this.getView().addDependent(oDialog);
//                     var oModel = new JSONModel({
//                         orderTypes: [
//                             { key: "ZMI1", description: "MIXING" },
//                             { key: "ZCLI1", description: "CALENDERING" },
//                             { key: "ZJO1", description: "JOINTING" },
//                             { key: "ZFG1", description: "FG BELT" },
//                             { key: "ZGM1", description: "GEAR PROCESS" },
//                             { key: "ZKT1", description: "KIT PROCESS" },
//                             { key: "ZMO1", description: "MOULDING" },
//                             { key: "ZWR1", description: "WEIGHT ROLLER" }
//                         ]
//                     });
//                     oDialog.setModel(oModel);
//                     oDialog.open();
//                 }.bind(this));
//             } else {
//                 this._orderTypeDialog.open();
//             }
//         },

//         onOrderTypeConfirm: function (oEvent) {
//             var oSelectedItem = oEvent.getParameter("selectedItem");
//             if (oSelectedItem) {
//                 var sKey = oSelectedItem.getBindingContext().getProperty("key");
//                 console.log("-> [VALUE HELP] Selected Order Type:", sKey);
//                 if (this._valueHelpInput) {
//                     this._valueHelpInput.setValue(sKey);
//                 }
//             }
//             if (this._orderTypeDialog) {
//                 this._orderTypeDialog.close();
//                 this._orderTypeDialog.destroy();
//                 this._orderTypeDialog = null;
//             }
//         },

//         onOrderTypeCancel: function () {
//             console.log("-> [VALUE HELP] Cancelled Order Type selection.");
//             if (this._orderTypeDialog) {
//                 this._orderTypeDialog.close();
//                 this._orderTypeDialog.destroy();
//                 this._orderTypeDialog = null;
//             }
//         },

//         onOrderTypeSearch: function (oEvent) {
//             var sValue = oEvent.getParameter("value");
//             var oFilter = new Filter("description", FilterOperator.Contains, sValue);
//             this._orderTypeDialog.getBinding("items").filter([oFilter]);
//         },

//         onStorageLocationValueHelp: function (oEvent) {
//             console.log("-> [VALUE HELP] Opening Storage Location Value Help.");
//             sap.ui.core.BusyIndicator.show();
//             this._storLocInput = oEvent.getSource();
//             if (!this._oStorageLocationDialog) {
//                 Fragment.load({
//                     id: this.getView().getId(),
//                     name: "bando.view.ProductionReport.fragments.StorageLocationValueHelp",
//                     controller: this
//                 }).then(function (oDialog) {
//                     this._oStorageLocationDialog = oDialog;
//                     this.getView().addDependent(oDialog);
//                     this._loadStorageLocationData();
//                 }.bind(this));
//             } else {
//                 this._loadStorageLocationData();
//             }
//         },

//         _loadStorageLocationData: function () {
//             var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
//             if (!oModel) {
//                 sap.ui.core.BusyIndicator.hide();
//                 return;
//             }
//             var oFilter = new Filter({ path: "StorageLocation", operator: FilterOperator.StartsWith, value1: "12" });
//             oModel.read("/ZC_STORAGE_LOC_F4", {
//                 filters: [oFilter],
//                 urlParameters: { "$orderby": "StorageLocation", "$top": "5000" },
//                 success: function (oData) {
//                     const aStorageLocs = oData.results
//                         .map(item => (item.StorageLocation || "").trim())
//                         .filter(s => /[A-Za-z]/.test(s))
//                         .map(s => ({ StorageLocation: s }));

//                     const oJSON = new JSONModel({ StorageLocs: aStorageLocs });
//                     this._oStorageLocationDialog.setModel(oJSON, "VHModel");
//                     this._oStorageLocationDialog.open();
//                     sap.ui.core.BusyIndicator.hide();
//                 }.bind(this)
//             });
//         },

//         onStorageLocationSelected: function (oEvent) {
//             const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
//             if (oSelectedItem) {
//                 const sStorageLoc = oSelectedItem.getBindingContext("VHModel").getObject().StorageLocation;
//                 console.log("-> [VALUE HELP] Selected Storage Location:", sStorageLoc);
//                 const oInput = this._storLocInput || this.byId("idStorLoc");
//                 if (oInput) {
//                     oInput.setValue(sStorageLoc);
//                 }
//             }
//             this.onStorageLocationVHClose();
//         },

//         onStorageLocationSearch: function (oEvent) {
//             const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
//             const oBinding = this.byId("idStorageLocationTable").getBinding("items");
//             if (sValue) {
//                 oBinding.filter([new Filter("StorageLocation", FilterOperator.Contains, sValue.toUpperCase())]);
//             } else {
//                 oBinding.filter([]);
//             }
//         },

//         onStorageLocationVHClose: function () {
//             if (this._oStorageLocationDialog) {
//                 this._oStorageLocationDialog.close();
//                 this.byId("idStorageLocationTable").removeSelections();
//             }
//         },

//         onProdOrderHelp: function (oEvent) {
//             console.log("-> [VALUE HELP] Opening Production Order Value Help.");
//             sap.ui.core.BusyIndicator.show();
//             this._Prodorder = oEvent.getSource();
//             if (!this._oProdOrderDialog) {
//                 Fragment.load({
//                     id: this.getView().getId(),
//                     name: "bando.view.ProductionReport.fragments.ProdOrder",
//                     controller: this
//                 }).then(function (oDialog) {
//                     this._oProdOrderDialog = oDialog;
//                     this.getView().addDependent(oDialog);
//                     this._loadProdOrderData();
//                 }.bind(this));
//             } else {
//                 this._loadProdOrderData();
//             }
//         },

//         _loadProdOrderData: function () {
//             var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
//             oModel.read("/ZC_PROD_ORDER_F4", {
//                 urlParameters: { "$orderby": "Productionorder", "$top": "5000" },
//                 success: function (oData) {
//                     const aProdorders = oData.results.map(item => ({ Productionorder: (item.Productionorder || "").trim() }));
//                     this._oProdOrderDialog.setModel(new JSONModel({ Prodorders: aProdorders }), "VHModelProd");
//                     this._oProdOrderDialog.open();
//                     sap.ui.core.BusyIndicator.hide();
//                 }.bind(this)
//             });
//         },

//         onProdOrderSelected: function (oEvent) {
//             const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
//             if (oSelectedItem) {
//                 const sLoc = oSelectedItem.getBindingContext("VHModelProd").getObject().Productionorder;
//                 console.log("-> [VALUE HELP] Selected Production Order:", sLoc);
//                 const oInput = this._Prodorder || this.byId("idProductionOrder");
//                 if (oInput) oInput.setValue(sLoc);
//             }
//             this.onProdOrderVHClose();
//         },

//         onProductionOrderSearch: function (oEvent) {
//             const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
//             const oBinding = this.byId("idProdOrderTable").getBinding("items");
//             if (sValue) {
//                 oBinding.filter([new Filter("Productionorder", FilterOperator.Contains, sValue.toUpperCase())]);
//             } else {
//                 oBinding.filter([]);
//             }
//         },

//         onProdOrderVHClose: function () {
//             if (this._oProdOrderDialog) {
//                 this._oProdOrderDialog.close();
//                 this.byId("idProdOrderTable").removeSelections();
//             }
//         },

//         onMatCodHelp: function (oEvent) {
//             console.log("-> [VALUE HELP] Opening Material Code Value Help.");
//             sap.ui.core.BusyIndicator.show();
//             this._MaterialCodeInput = oEvent.getSource();
//             if (!this._oMatCodeDialog) {
//                 Fragment.load({
//                     id: this.getView().getId(),
//                     name: "bando.view.ProductionReport.fragments.MatcodValueHelp",
//                     controller: this
//                 }).then(function (oDialog) {
//                     this._oMatCodeDialog = oDialog;
//                     this.getView().addDependent(oDialog);
//                     this._loadMatCodeData();
//                 }.bind(this));
//             } else {
//                 this._loadMatCodeData();
//             }
//         },

//         _loadMatCodeData: function () {
//             var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
//             oModel.read("/ZC_MATERIAL_NO_F4", {
//                 urlParameters: { "$filter": "startswith(Material,'WIN') or startswith(Material,'2IN')", "$orderby": "Material", "$top": "5000" },
//                 success: function (oData) {
//                     const aMaterials = oData.results.map(item => ({ Material: (item.Material || "").trim() }));
//                     this._oMatCodeDialog.setModel(new JSONModel({ Materials: aMaterials }), "VHModelMat");
//                     this._oMatCodeDialog.open();
//                     sap.ui.core.BusyIndicator.hide();
//                 }.bind(this)
//             });
//         },

//         onMatCodeSelected: function (oEvent) {
//             const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
//             if (oSelectedItem) {
//                 const sMat = oSelectedItem.getBindingContext("VHModelMat").getObject().Material;
//                 console.log("-> [VALUE HELP] Selected Material Code:", sMat);
//                 const oInput = this._MaterialCodeInput || this.byId("idMaterialCode");
//                 if (oInput) oInput.setValue(sMat);
//             }
//             this.onMatCodeVHClose();
//         },

//         onMatCodeSearch: function (oEvent) {
//             const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
//             const oBinding = this.byId("idMatCodeTable").getBinding("items");
//             if (sValue) {
//                 oBinding.filter([new Filter("Material", FilterOperator.Contains, sValue.toUpperCase())]);
//             } else {
//                 oBinding.filter([]);
//             }
//         },

//         onMatCodeVHClose: function () {
//             if (this._oMatCodeDialog) {
//                 this._oMatCodeDialog.close();
//                 this.byId("idMatCodeTable").removeSelections();
//             }
//         },

//         /* ================= EXPORT TO EXCEL ================= */
//         onDownload: function () {
//             console.log("-> [EXPORT] Starting Excel spreadsheet generation.");
//             var oView = this.getView();
//             var oTable = oView.byId("idResultTable");
//             var aData = oView.getModel("TabModel").getProperty("/Samples") || [];

//             if (!aData.length) {
//                 console.warn("-> [EXPORT WARNING] No data available to export.");
//                 MessageToast.show("No data to export");
//                 return;
//             }

//             var oUserMap = oView.getModel("UserMap");
//             var aExportData = aData.map(function (row) {
//                 var oCopy = Object.assign({}, row);
//                 if (row.bomexplosiondate) {
//                     oCopy.bomexplosiondate = this.formatDate(row.bomexplosiondate);
//                 }
//                 if (row.manufacturingdate) {
//                     oCopy.manufacturingdate = this.formatDate(row.manufacturingdate);
//                 }
//                 if (row.productionordstartdate) {
//                     oCopy.productionordstartdate = this.formatDate(row.productionordstartdate);
//                 }
//                 if (row.CREATIONDATE) {
//                     oCopy.CREATIONDATE = this.formatDate(row.CREATIONDATE);
//                 }
//                 if (row.mfgorderitemactualdeliverydate) {
//                     oCopy.mfgorderitemactualdeliverydate = this.formatDate(row.mfgorderitemactualdeliverydate);
//                 }
//                 if (row.createdby) {
//                     var sName = oUserMap.getProperty("/" + row.createdby);
//                     oCopy.createdby = sName ? sName : row.createdby;
//                 }
//                 if (row.MFGORDERPLANNEDTOTALQTY) {
//                     oCopy.MFGORDERPLANNEDTOTALQTY = Number(row.MFGORDERPLANNEDTOTALQTY).toFixed(3);
//                 }
//                 if (row.MFGORDERCONFIRMEDSCRAPQTY) {
//                     oCopy.MFGORDERCONFIRMEDSCRAPQTY = Number(row.MFGORDERCONFIRMEDSCRAPQTY).toFixed(3);
//                 }
//                 if (row.mfgorderplannedtotalqty) {
//                     oCopy.mfgorderplannedtotalqty = Number(row.mfgorderplannedtotalqty).toFixed(3);
//                 }
//                 if (row.actualdeliveredquantity) {
//                     oCopy.actualdeliveredquantity = Number(row.actualdeliveredquantity).toFixed(3);
//                 }
//                 return oCopy;
//             }.bind(this));

//             var aColumns = [];
//             oTable.getColumns().forEach(function (oColumn) {
//                 var oLabel = oColumn.getLabel();
//                 var sLabel = oLabel ? oLabel.getText() : "";
//                 var oTemplate = oColumn.getTemplate();
//                 var sBindingPath = "";

//                 if (oTemplate && oTemplate.getBindingInfo("text")) {
//                     sBindingPath = oTemplate.getBindingInfo("text").parts[0].path;
//                 }
//                 if (sBindingPath) {
//                     aColumns.push({ label: sLabel, property: sBindingPath, type: "string" });
//                 }
//             });

//             var oSettings = {
//                 workbook: { columns: aColumns },
//                 dataSource: aExportData,
//                 fileName: "Production_Report.xlsx"
//             };

//             var oSheet = new Spreadsheet(oSettings);
//             oView.setBusy(true);
//             oSheet.build().finally(function () {
//                 console.log("-> [EXPORT COMPLETE] Spreadsheet successfully built.");
//                 oSheet.destroy();
//                 oView.setBusy(false);
//             });
//         },

//         onExit: function () {
//             console.log("-> [EXIT] Destroying dialog instances.");
//             if (this._oStorageLocationDialog) this._oStorageLocationDialog.destroy();
//             if (this._oProdOrderDialog) this._oProdOrderDialog.destroy();
//             if (this._oMatCodeDialog) this._oMatCodeDialog.destroy();
//         }
//     });
// });
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/odata/v2/ODataModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet"
], function (
    Controller,
    Fragment,
    JSONModel,
    ODataModel,
    Filter,
    FilterOperator,
    MessageToast,
    MessageBox,
    Spreadsheet
) {
    "use strict";

    return Controller.extend("bando.controller.ProductionReport.BeltFG", {

        onInit: function () {
            console.log("-> [INIT] BeltFG Controller initialized.");
            this.getView().setModel(new JSONModel({ openscreen: "screen1" }), "ScreenVisible");
            this.getView().setModel(new JSONModel({ Samples: [] }), "TabModel");

            // Register OData models explicitly
            var oProdReportModel = new ODataModel("/sap/opu/odata/sap/ZSB_PRODUCTION_REPORT/");
            this.getView().setModel(oProdReportModel, "ZSB_PRODUCTION_REPORT");

            var oMatMovModel = new ODataModel("/sap/opu/odata/sap/ZSB_MATMOVTTYPE/");
            this.getView().setModel(oMatMovModel, "ZSB_MATMOVTTYPE");

            var oUserModel = new JSONModel({});
            if (sap.ushell && sap.ushell.Container) {
                var oUserInfo = sap.ushell.Container.getService("UserInfo");
                oUserModel.setData({
                    id: oUserInfo.getId(),
                    fullName: oUserInfo.getFullName()
                });
            }
            this.getView().setModel(oUserModel, "User");

            var oUserMap = new JSONModel({
                "CB9980000061": "Sachin Kumar",
                "CB9980000039": "Rajesh",
                "CB9980000047": "Production",
                "CB9980000038": "PPC",
                "CB9980000052": "CHANNAPPA",
                "CB9980000050": "AJIS",
                "CB9980000090": "MADAN",
                "CB9980000067": "Vishwanath",
                "CB9980000068": "PPC-common",
                "CB9980000069": "Rajesh Naik",
                "CB9980000070": "Sachin",
                "CB9980000077": "Production Common",
                "CB9980000100": "Sachin Kumar",
                "CB9980000002": "Channappa Nidoni",
                "CB9980000010": "Ajis Kumar",
                "CB9980000007": "Basavaraj BS",
                "CB9980000109": "Vishwanath Maruti Madiwal",
                "CB9980000110": "Madan Pattar",
                "CB9980000111": "Manikandan C",
                "CB9980000015": "Vinod Kumar"
            });
            this.getView().setModel(oUserMap, "UserMap");
        },

        formatCreatedBy: function (sUserId) {
            if (!sUserId) return "";
            var oUserMap = this.getView().getModel("UserMap");
            var sName = oUserMap.getProperty("/" + sUserId);
            return sName ? sName : sUserId;
        },

        formatDate: function (vDate) {
            if (!vDate) return "";
            if (typeof vDate === "string" && vDate.indexOf("Date") !== -1) {
                vDate = parseInt(vDate.replace(/\/Date\((\d+)\)\//, "$1"), 10);
            }
            var oDate = new Date(vDate);
            if (isNaN(oDate.getTime())) return "";
            return sap.ui.core.format.DateFormat
                .getDateInstance({ pattern: "dd/MM/yyyy" })
                .format(oDate);
        },

        formatQty3Decimals: function (vValue) {
            return (vValue === null || vValue === undefined || vValue === "")
                ? ""
                : Number(vValue).toFixed(3);
        },

        /* ================= NAVIGATION ================= */
        onGoToScreen2: function () {
            var oView = this.getView();
            var sRawFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue().trim() : "";
            var sRawTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue().trim() : "";
            var sOrdType = oView.byId("idOrderType").getValue();

            // Strict Validation: Both fields are completely mandatory
            if (sRawFrom && !sRawTo) {
                MessageBox.error("Both Start Date and End Date are mandatory. Please provide both.");
                return;
            }
            if (!sRawFrom && sRawTo) {
                MessageBox.error("Both Start Date and End Date are mandatory. Please provide both.");
                return;
            }

            if(!sRawFrom && !sRawTo){
                MessageBox.error("Please Enter Both From and To dates");
                return;
            }

            if(!sOrdType){
                MessageBox.error("Please Enter OrderType");
                return;
            }
            
            // if (!sRawFrom) {
            //     MessageBox.error("Start Date is mandatory.");
            //     return;
            // }
            // if (!sRawTo) {
            //     MessageBox.error("End Date is mandatory.");
            //     return;
            // }

            // Parse dates assuming "dd/MM/yyyy" format
            var dStartDateObj = new Date(sRawFrom.split("/").reverse().join("-"));
            var dEndDateObj = new Date(sRawTo.split("/").reverse().join("-"));

            // Validate that From Date is not greater than To Date
            if (dStartDateObj > dEndDateObj) {
                MessageBox.error("Start Date cannot be greater than End Date.");
                return;
            }

            console.log("-> [NAVIGATION] Navigating to Screen 2 and executing precise relational mapping flow.");
            oView.getModel("ScreenVisible").setProperty("/openscreen", "screen2");
            oView.getModel("TabModel").setProperty("/Samples", []);
            oView.setBusy(true);
            this._loadProductionReportData();
        },

        onGoToScreen1: function () {
            console.log("-> [NAVIGATION] Navigating back to Screen 1.");
            this.getView().getModel("ScreenVisible").setProperty("/openscreen", "screen1");
            this.getView().getModel("TabModel").setProperty("/Samples", []);
        },

        /* ================= BUILD SERVER-SIDE FILTERS ================= */
        _buildProductionReportFilters: function () {
            var oView = this.getView();
            var aFilters = [];

            var sFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
            var sTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";
            if (sFrom && sTo) {
                var formattedFrom = sFrom.split("/").reverse().join("-");
                var formattedTo = sTo.split("/").reverse().join("-");
                aFilters.push(new Filter("bomexplosiondate", FilterOperator.BT, formattedFrom + "T00:00:00", formattedTo + "T23:59:59"));
            }

            var oOrderTypeInput = oView.byId("idOrderType");
            var sOrderType = oOrderTypeInput ? oOrderTypeInput.getValue().trim() : "";
            if (sOrderType) {
                aFilters.push(new Filter("manufacturingordertype", FilterOperator.EQ, sOrderType));
            }

            var oStorLocInput = oView.byId("idStorLoc");
            var sStorLoc = oStorLocInput ? oStorLocInput.getValue().trim() : "";
            if (sStorLoc) {
                aFilters.push(new Filter("storagelocation", FilterOperator.EQ, sStorLoc));
            }

            var oProdOrdInput = oView.byId("idProductionOrder");
            var sProdOrd = oProdOrdInput ? oProdOrdInput.getValue().trim() : "";
            if (sProdOrd) {
                aFilters.push(new Filter("manufacturingorder", FilterOperator.EQ, sProdOrd));
            }

            var oMatCodeInput = oView.byId("idMaterialCode");
            var sMatCode = oMatCodeInput ? oMatCodeInput.getValue().trim() : "";
            if (sMatCode) {
                aFilters.push(new Filter("billofoperationsmaterial", FilterOperator.EQ, sMatCode));
            }

            console.log("-> [FILTERS] Production report filters count:", aFilters.length);
            return aFilters;
        },

        _buildPlanFilters: function () {
            var oView = this.getView();
            var aFilters = [];

            var sFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
            var sTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";
            if (sFrom && sTo) {
                var formattedFrom = sFrom.split("/").reverse().join("-");
                var formattedTo = sTo.split("/").reverse().join("-");
                aFilters.push(new Filter("productionordstartdate", FilterOperator.BT, formattedFrom + "T00:00:00", formattedTo + "T23:59:59"));
            }

            var oProdOrdInput = oView.byId("idProductionOrder");
            var sProdOrd = oProdOrdInput ? oProdOrdInput.getValue().trim() : "";
            if (sProdOrd) {
                aFilters.push(new Filter("productionorderno", FilterOperator.EQ, sProdOrd));
            }

            var oMatCodeInput = oView.byId("idMaterialCode");
            var sMatCode = oMatCodeInput ? oMatCodeInput.getValue().trim() : "";
            if (sMatCode) {
                aFilters.push(new Filter("materialcode", FilterOperator.EQ, sMatCode));
            }

            console.log("-> [FILTERS] Plan filters count:", aFilters.length);
            return aFilters;
        },

        /* ================= COMPREHENSIVE FETCH & RELATIONAL MATCHING FLOW ================= */
        _loadProductionReportData: function () {
            var oView = this.getView();
            var oTabModel = oView.getModel("TabModel");
            var oProdRepModel = oView.getModel("ZSB_PRODUCTION_REPORT");
            var oMatMovModel = oView.getModel("ZSB_MATMOVTTYPE");

            var sRawFrom = oView.byId("idStartDate") ? oView.byId("idStartDate").getValue() : "";
            var sRawTo = oView.byId("idEndDate") ? oView.byId("idEndDate").getValue() : "";

            var aPlanServices = [
                { model: "ZSB_FG_PROCESS_PLAN", entity: "/ZC_FG_PROCESS_PLAN", source: "BELT" },
                { model: "ZSB_MOULDING_FG_PLAN", entity: "/ZC_MOULDING_FG_PLAN", source: "FG" },
                { model: "ZSB_MOULD_PLAN", entity: "/ZC_MOULD_PLAN", source: "SFG" },
                { model: "ZSB_CALEN_PLAN", entity: "/ZC_CALEN_PLAN", source: "CALEN" },
                { model: "ZSB_JOINT_PLAN", entity: "/ZC_JOINT_PLAN", source: "JOINT" },
                { model: "ZSB_MIXING_PLAN1", entity: "/ZC_MIXING_PLAN1", source: "MIXING" },
                { model: "ZSB_GEAR_PLAN", entity: "/ZC_GEAR_PLAN", source: "GEAR" },
                { model: "ZSB_WEIGHTROLLER_PLAN", entity: "/ZC_WEIGTHROLLER_PLAN", source: "WEIGHTROLLER" },
                { model: "ZSB_KIT_PLAN", entity: "/ZC_KIT_PLAN", source: "KIT" }
            ];

            var aPlanFilters = this._buildPlanFilters();
            var aProdFilters = this._buildProductionReportFilters();

            console.log("-> [STEP 1] Fetching all 9 plan services and ZCE_PRODUCTION_REPORT concurrently.");

            var aPlanPromises = aPlanServices.map(function (srv) {
                var oModel = oView.getModel(srv.model);
                if (!oModel) {
                    console.warn("-> [WARNING] Model not found for service:", srv.model);
                    return Promise.resolve([]);
                }
                return this._fetchAllPages(oModel, srv.entity, aPlanFilters, 0).then(function (aResults) {
                    return aResults.map(function (item) {
                        item.__serviceSource = srv.source;
                        return item;
                    });
                });
            }.bind(this));

            var aProdPromise = oProdRepModel ? this._fetchAllPages(oProdRepModel, "/ZCE_PRODUCTION_REPORT", aProdFilters, 0) : Promise.resolve([]);

            Promise.all([Promise.all(aPlanPromises), aProdPromise]).then(function (aResponses) {
                var aPlanResultsArrays = aResponses[0];
                var aAllMergedPlans = [].concat.apply([], aPlanResultsArrays);
                var aProdRecords = aResponses[1];

                var oProdRepMap = {};
                aProdRecords.forEach(function (pRec) {
                    var sMfgOrder = pRec.manufacturingorder || pRec.ManufacturingOrder || pRec.PRODUCTIONORDERNO || pRec.ProductionOrderNo || "";
                    sMfgOrder = sMfgOrder.toString().trim();
                    
                    var sCodes = pRec.statuscodes || pRec.StatusCodes || pRec.STATUSCODES || "";
                    if (sCodes && sCodes.indexOf("%2C") !== -1) {
                        sCodes = decodeURIComponent(sCodes);
                    }

                    if (sMfgOrder) {
                        var oNorm = {
                            manufacturingorder: sMfgOrder,
                            statuscodes: sCodes,
                            manufacturingordertype: pRec.manufacturingordertype || pRec.ManufacturingOrderType || "ZJO1",
                            productdesc: pRec.productdesc || pRec.ProductDesc || "",
                            mfgorderitemactualdeliverydate: pRec.mfgorderitemactualdeliverydate || pRec.MfgOrderItemActualDeliveryDate || null,
                            productionplant: pRec.productionplant || pRec.ProductionPlant || "",
                            productionversion: pRec.productionversion || pRec.ProductionVersion || "",
                            storagelocation: pRec.storagelocation || pRec.StorageLocation || "",
                            mrpcontroller: pRec.mrpcontroller || pRec.MrpController || "",
                            productionsupervisor: pRec.productionsupervisor || pRec.ProductionSupervisor || "",
                            batch: pRec.batch || pRec.Batch || "",
                            mfgorderplannedtotalqty: pRec.mfgorderplannedtotalqty || pRec.MfgOrderPlannedTotalQty || "0.00",
                            mfgorderplannedscarpqty: pRec.mfgorderplannedscarpqty || pRec.MfgOrderPlannedScarpQty || "0.00",
                            actualdeliveredquantity: pRec.actualdeliveredquantity || pRec.ActualDeliveredQuantity || "0.00"
                        };
                        oProdRepMap[sMfgOrder] = oNorm;
                        oProdRepMap[sMfgOrder.replace(/^0+/, '')] = oNorm;
                        oProdRepMap[String(parseInt(sMfgOrder, 10))] = oNorm;
                        oProdRepMap[sMfgOrder.padStart(12, "0")] = oNorm;
                        oProdRepMap[sMfgOrder.padStart(10, "0")] = oNorm;
                    }
                });

                var dStartDateObj = sRawFrom ? new Date(sRawFrom.split("/").reverse().join("-")) : null;
                var dEndDateObj = sRawTo ? new Date(sRawTo.split("/").reverse().join("-")) : null;
                if (dStartDateObj) dStartDateObj.setHours(0, 0, 0, 0);
                if (dEndDateObj) dEndDateObj.setHours(23, 59, 59, 999);

                var aCandidateRows = [];
                aAllMergedPlans.forEach(function (planItem) {
                    var sProdOrd = planItem.productionorderno || planItem.ProductionOrderNo || "";
                    sProdOrd = sProdOrd.toString().trim();
                    planItem.productionorderno = sProdOrd;

                    var sItemDateVal = planItem.productionordstartdate || planItem.ProductionOrdStartDate || "";
                    if (sItemDateVal && dStartDateObj && dEndDateObj) {
                        var dItemDate = new Date(sItemDateVal);
                        if (!isNaN(dItemDate.getTime())) {
                            dItemDate.setHours(12, 0, 0, 0);
                            if (dItemDate < dStartDateObj || dItemDate > dEndDateObj) {
                                return;
                            }
                        }
                    }

                    var sStripped = sProdOrd.replace(/^0+/, '');
                    var sParsed = String(parseInt(sProdOrd, 10));
                    var sPad12 = sProdOrd.padStart(12, "0");
                    var sPad10 = sProdOrd.padStart(10, "0");

                    var oMatchedProd = oProdRepMap[sProdOrd] || 
                                       oProdRepMap[sStripped] || 
                                       oProdRepMap[sParsed] || 
                                       oProdRepMap[sPad12] || 
                                       oProdRepMap[sPad10];

                    if (oMatchedProd) {
                        planItem.manufacturingorder = oMatchedProd.manufacturingorder;
                        planItem.statuscodes = oMatchedProd.statuscodes;
                        planItem.manufacturingordertype = oMatchedProd.manufacturingordertype;
                        
                        planItem.productdesc = oMatchedProd.productdesc;
                        planItem.mfgorderitemactualdeliverydate = oMatchedProd.mfgorderitemactualdeliverydate;
                        planItem.productionplant = oMatchedProd.productionplant;
                        planItem.productionversion = oMatchedProd.productionversion;
                        planItem.storagelocation = oMatchedProd.storagelocation;
                        planItem.mrpcontroller = oMatchedProd.mrpcontroller;
                        planItem.productionsupervisor = oMatchedProd.productionsupervisor;
                        planItem.batch = oMatchedProd.batch;
                        planItem.mfgorderplannedtotalqty = oMatchedProd.mfgorderplannedtotalqty;
                        planItem.mfgorderplannedscarpqty = oMatchedProd.mfgorderplannedscarpqty;
                        planItem.actualdeliveredquantity = oMatchedProd.actualdeliveredquantity;

                        this._processRejectCodes(planItem);
                        aCandidateRows.push(planItem);
                    }
                }.bind(this));

                if (!aCandidateRows.length) {
                    oTabModel.setProperty("/Samples", []);
                    oView.setBusy(false);
                    MessageToast.show("No data found matching criteria.");
                    return;
                }

                var aMovChecks = aCandidateRows.map(function (row) {
                    var sProdOrd = row.productionorderno || "";
                    var sMatCode = row.materialcode || "";
                    if (!sProdOrd || !sMatCode) return Promise.resolve({ row: row, isValid: false });

                    return new Promise(function (resolveMov) {
                        oMatMovModel.read("/ZCE__MatProd_MovTyp", {
                            filters: [
                                new Filter("ManufacturingOrder", FilterOperator.EQ, sProdOrd),
                                new Filter("Material", FilterOperator.EQ, sMatCode)
                            ],
                            urlParameters: { "$top": 1 },
                            success: function (oMovData) {
                                var aResults = oMovData.results || [];
                                var bIs101 = aResults.some(function (m) {
                                    return (m.GoodsMovementType || m.goodsMovementType || "") === "101";
                                });
                                resolveMov({ row: row, isValid: bIs101 });
                            },
                            error: function () {
                                resolveMov({ row: row, isValid: false });
                            }
                        });
                    });
                });

                Promise.all(aMovChecks).then(function (aCheckedResults) {
                    var aValidRows = [];
                    aCheckedResults.forEach(function (res) {
                        if (res.isValid) {
                            aValidRows.push(res.row);
                        }
                    });

                    var oRejectInput = oView.byId("idRejectCode");
                    var sRejectInputVal = oRejectInput ? oRejectInput.getValue().trim() : "";
                    
                    if (sRejectInputVal) {
                        var aTargetCodes = sRejectInputVal.split(",").map(function(s) {
                            return s.trim();
                        }).filter(Boolean);

                        aValidRows = aValidRows.filter(function(row) {
                            var sCodesStr = row.RejectCodes || row.rejectcodes || "";
                            if (!sCodesStr) return false;

                            var aPairs = sCodesStr.split(",");
                            return aTargetCodes.some(function(targetCode) {
                                return aPairs.some(function(pair) {
                                    var parts = pair.split("/");
                                    var codeKey = parts[0] ? parts[0].trim() : "";
                                    return codeKey === targetCode;
                                });
                            });
                        });
                    }

                    aValidRows.sort(function (a, b) {
                        var ordA = parseInt(a.productionorderno, 10) || 0;
                        var ordB = parseInt(b.productionorderno, 10) || 0;
                        return ordA - ordB;
                    });

                    console.log("-> [STEP 2 COMPLETE] Total rows retained where MovementType == '101' & Reject filter matches: " + aValidRows.length);

                    if (!aValidRows.length) {
                        MessageToast.show("No records found matching criteria.");
                    }

                    oTabModel.setProperty("/Samples", aValidRows);
                    oView.setBusy(false);
                });

            }.bind(this)).catch(function (oErr) {
                console.error("-> [ERROR] Failed during fetch and matching flow:", oErr);
                oView.setBusy(false);
                MessageToast.show("Failed to load report data.");
            });
        },

        _processRejectCodes: function (row) {
            if (!row) return;
            
            var aPairs = [];
            var sCodes = row.RejectCodes || row.rejectcodes || "";
            if (sCodes) {
                sCodes.split(",").forEach(function (pair) {
                    var parts = pair.split("/");
                    if (!parts[0]) return;
                    var nIndex = parseInt(parts[0].trim(), 10);
                    if (!isNaN(nIndex)) {
                        aPairs.push({
                            index: nIndex,
                            value: parts[1] !== undefined ? parts[1] : ""
                        });
                    }
                });
            }

            aPairs.sort(function (a, b) {
                return a.index - b.index;
            });

            for (let i = 1; i <= 62; i++) {
                row[`Code${i}`] = "";
            }

            let used = new Set();
            aPairs.forEach(function (item) {
                if (!used.has(item.index) && item.index >= 1 && item.index <= 62) {
                    row[`Code${item.index}`] = item.value;
                    used.add(item.index);
                }
            });
        },

        _fetchAllPages: function (oModel, sEntity, aFilters, iSkip, aAccum) {
            var that = this;
            iSkip = iSkip || 0;
            aAccum = aAccum || [];
            var iTop = 5000;

            return new Promise(function (resolve) {
                if (!oModel) {
                    resolve(aAccum);
                    return;
                }
                oModel.read(sEntity, {
                    filters: aFilters || [],
                    urlParameters: { "$skip": iSkip, "$top": iTop },
                    success: function (oData) {
                        var aResults = oData.results || [];
                        aAccum = aAccum.concat(aResults);

                        if (aResults.length === iTop) {
                            resolve(that._fetchAllPages(oModel, sEntity, aFilters, iSkip + iTop, aAccum));
                        } else {
                            resolve(aAccum);
                        }
                    },
                    error: function (oErr) {
                        console.warn("-> [PAGINATION ERROR] Failed fetching batch page at skip " + iSkip + " for " + sEntity, oErr);
                        resolve(aAccum);
                    }
                });
            });
        },

        /* ================= VALUE HELPS & EXPORT ================= */
        onOrderTypeValueHelp: function (oEvent) {
            console.log("-> [VALUE HELP] Opening Order Type Value Help.");
            this._valueHelpInput = oEvent.getSource();
            if (!this._orderTypeDialog) {
                Fragment.load({
                    name: "bando.view.ProductionReport.fragments.OrderTypeValueHelp",
                    controller: this
                }).then(function (oDialog) {
                    this._orderTypeDialog = oDialog;
                    this.getView().addDependent(oDialog);
                    var oModel = new JSONModel({
                        orderTypes: [
                            { key: "ZMI1", description: "MIXING" },
                            { key: "ZCLI1", description: "CALENDERING" },
                            { key: "ZJO1", description: "JOINTING" },
                            { key: "ZFG1", description: "FG BELT" },
                            { key: "ZGM1", description: "GEAR PROCESS" },
                            { key: "ZKT1", description: "KIT PROCESS" },
                            { key: "ZMO1", description: "MOULDING" },
                            { key: "ZWR1", description: "WEIGHT ROLLER" }
                        ]
                    });
                    oDialog.setModel(oModel);
                    oDialog.open();
                }.bind(this));
            } else {
                this._orderTypeDialog.open();
            }
        },

        onOrderTypeConfirm: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                var sKey = oSelectedItem.getBindingContext().getProperty("key");
                console.log("-> [VALUE HELP] Selected Order Type:", sKey);
                if (this._valueHelpInput) {
                    this._valueHelpInput.setValue(sKey);
                }
            }
            if (this._orderTypeDialog) {
                this._orderTypeDialog.close();
                this._orderTypeDialog.destroy();
                this._orderTypeDialog = null;
            }
        },

        onOrderTypeCancel: function () {
            console.log("-> [VALUE HELP] Cancelled Order Type selection.");
            if (this._orderTypeDialog) {
                this._orderTypeDialog.close();
                this._orderTypeDialog.destroy();
                this._orderTypeDialog = null;
            }
        },

        onOrderTypeSearch: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            var oFilter = new Filter("description", FilterOperator.Contains, sValue);
            this._orderTypeDialog.getBinding("items").filter([oFilter]);
        },

        onStorageLocationValueHelp: function (oEvent) {
            console.log("-> [VALUE HELP] Opening Storage Location Value Help.");
            sap.ui.core.BusyIndicator.show();
            this._storLocInput = oEvent.getSource();
            if (!this._oStorageLocationDialog) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "bando.view.ProductionReport.fragments.StorageLocationValueHelp",
                    controller: this
                }).then(function (oDialog) {
                    this._oStorageLocationDialog = oDialog;
                    this.getView().addDependent(oDialog);
                    this._loadStorageLocationData();
                }.bind(this));
            } else {
                this._loadStorageLocationData();
            }
        },

        _loadStorageLocationData: function () {
            var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
            if (!oModel) {
                sap.ui.core.BusyIndicator.hide();
                return;
            }
            var oFilter = new Filter({ path: "StorageLocation", operator: FilterOperator.StartsWith, value1: "12" });
            oModel.read("/ZC_STORAGE_LOC_F4", {
                filters: [oFilter],
                urlParameters: { "$orderby": "StorageLocation", "$top": "5000" },
                success: function (oData) {
                    const aStorageLocs = oData.results
                        .map(item => (item.StorageLocation || "").trim())
                        .filter(s => /[A-Za-z]/.test(s))
                        .map(s => ({ StorageLocation: s }));

                    const oJSON = new JSONModel({ StorageLocs: aStorageLocs });
                    this._oStorageLocationDialog.setModel(oJSON, "VHModel");
                    this._oStorageLocationDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                }.bind(this)
            });
        },

        onStorageLocationSelected: function (oEvent) {
            const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
            if (oSelectedItem) {
                const sStorageLoc = oSelectedItem.getBindingContext("VHModel").getObject().StorageLocation;
                console.log("-> [VALUE HELP] Selected Storage Location:", sStorageLoc);
                const oInput = this._storLocInput || this.byId("idStorLoc");
                if (oInput) {
                    oInput.setValue(sStorageLoc);
                }
            }
            this.onStorageLocationVHClose();
        },

        onStorageLocationSearch: function (oEvent) {
            const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
            const oBinding = this.byId("idStorageLocationTable").getBinding("items");
            if (sValue) {
                oBinding.filter([new Filter("StorageLocation", FilterOperator.Contains, sValue.toUpperCase())]);
            } else {
                oBinding.filter([]);
            }
        },

        onStorageLocationVHClose: function () {
            if (this._oStorageLocationDialog) {
                this._oStorageLocationDialog.close();
                this.byId("idStorageLocationTable").removeSelections();
            }
        },

        onProdOrderHelp: function (oEvent) {
            console.log("-> [VALUE HELP] Opening Production Order Value Help.");
            sap.ui.core.BusyIndicator.show();
            this._Prodorder = oEvent.getSource();
            if (!this._oProdOrderDialog) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "bando.view.ProductionReport.fragments.ProdOrder",
                    controller: this
                }).then(function (oDialog) {
                    this._oProdOrderDialog = oDialog;
                    this.getView().addDependent(oDialog);
                    this._loadProdOrderData();
                }.bind(this));
            } else {
                this._loadProdOrderData();
            }
        },

        _loadProdOrderData: function () {
            var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
            oModel.read("/ZC_PROD_ORDER_F4", {
                urlParameters: { "$orderby": "Productionorder", "$top": "5000" },
                success: function (oData) {
                    const aProdorders = oData.results.map(item => ({ Productionorder: (item.Productionorder || "").trim() }));
                    this._oProdOrderDialog.setModel(new JSONModel({ Prodorders: aProdorders }), "VHModelProd");
                    this._oProdOrderDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                }.bind(this)
            });
        },

        onProdOrderSelected: function (oEvent) {
            const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
            if (oSelectedItem) {
                const sLoc = oSelectedItem.getBindingContext("VHModelProd").getObject().Productionorder;
                console.log("-> [VALUE HELP] Selected Production Order:", sLoc);
                const oInput = this._Prodorder || this.byId("idProductionOrder");
                if (oInput) oInput.setValue(sLoc);
            }
            this.onProdOrderVHClose();
        },

        onProductionOrderSearch: function (oEvent) {
            const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
            const oBinding = this.byId("idProdOrderTable").getBinding("items");
            if (sValue) {
                oBinding.filter([new Filter("Productionorder", FilterOperator.Contains, sValue.toUpperCase())]);
            } else {
                oBinding.filter([]);
            }
        },

        onProdOrderVHClose: function () {
            if (this._oProdOrderDialog) {
                this._oProdOrderDialog.close();
                this.byId("idProdOrderTable").removeSelections();
            }
        },

        onMatCodHelp: function (oEvent) {
            console.log("-> [VALUE HELP] Opening Material Code Value Help.");
            sap.ui.core.BusyIndicator.show();
            this._MaterialCodeInput = oEvent.getSource();
            if (!this._oMatCodeDialog) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "bando.view.ProductionReport.fragments.MatcodValueHelp",
                    controller: this
                }).then(function (oDialog) {
                    this._oMatCodeDialog = oDialog;
                    this.getView().addDependent(oDialog);
                    this._loadMatCodeData();
                }.bind(this));
            } else {
                this._loadMatCodeData();
            }
        },

        _loadMatCodeData: function () {
            var oModel = this.getOwnerComponent().getModel("ZSB_PROD_ORDER_REPORT_F4");
            oModel.read("/ZC_MATERIAL_NO_F4", {
                urlParameters: { "$filter": "startswith(Material,'WIN') or startswith(Material,'2IN')", "$orderby": "Material", "$top": "5000" },
                success: function (oData) {
                    const aMaterials = oData.results.map(item => ({ Material: (item.Material || "").trim() }));
                    this._oMatCodeDialog.setModel(new JSONModel({ Materials: aMaterials }), "VHModelMat");
                    this._oMatCodeDialog.open();
                    sap.ui.core.BusyIndicator.hide();
                }.bind(this)
            });
        },

        onMatCodeSelected: function (oEvent) {
            const oSelectedItem = oEvent.getSource().getSelectedItems()[0];
            if (oSelectedItem) {
                const sMat = oSelectedItem.getBindingContext("VHModelMat").getObject().Material;
                console.log("-> [VALUE HELP] Selected Material Code:", sMat);
                const oInput = this._MaterialCodeInput || this.byId("idMaterialCode");
                if (oInput) oInput.setValue(sMat);
            }
            this.onMatCodeVHClose();
        },

        onMatCodeSearch: function (oEvent) {
            const sValue = oEvent.getParameter("newValue") || oEvent.getParameter("query");
            const oBinding = this.byId("idMatCodeTable").getBinding("items");
            if (sValue) {
                oBinding.filter([new Filter("Material", FilterOperator.Contains, sValue.toUpperCase())]);
            } else {
                oBinding.filter([]);
            }
        },

        onMatCodeVHClose: function () {
            if (this._oMatCodeDialog) {
                this._oMatCodeDialog.close();
                this.byId("idMatCodeTable").removeSelections();
            }
        },

        /* ================= EXPORT TO EXCEL ================= */
        onDownload: function () {
            console.log("-> [EXPORT] Starting Excel spreadsheet generation.");
            var oView = this.getView();
            var oTable = oView.byId("idResultTable");
            var aData = oView.getModel("TabModel").getProperty("/Samples") || [];

            if (!aData.length) {
                console.warn("-> [EXPORT WARNING] No data available to export.");
                MessageToast.show("No data to export");
                return;
            }

            var oUserMap = oView.getModel("UserMap");
            var aExportData = aData.map(function (row) {
                var oCopy = Object.assign({}, row);
                if (row.bomexplosiondate) {
                    oCopy.bomexplosiondate = this.formatDate(row.bomexplosiondate);
                }
                if (row.manufacturingdate) {
                    oCopy.manufacturingdate = this.formatDate(row.manufacturingdate);
                }
                if (row.productionordstartdate) {
                    oCopy.productionordstartdate = this.formatDate(row.productionordstartdate);
                }
                if (row.CREATIONDATE) {
                    oCopy.CREATIONDATE = this.formatDate(row.CREATIONDATE);
                }
                if (row.mfgorderitemactualdeliverydate) {
                    oCopy.mfgorderitemactualdeliverydate = this.formatDate(row.mfgorderitemactualdeliverydate);
                }
                if (row.createdby) {
                    var sName = oUserMap.getProperty("/" + row.createdby);
                    oCopy.createdby = sName ? sName : row.createdby;
                }
                if (row.MFGORDERPLANNEDTOTALQTY) {
                    oCopy.MFGORDERPLANNEDTOTALQTY = Number(row.MFGORDERPLANNEDTOTALQTY).toFixed(3);
                }
                if (row.MFGORDERCONFIRMEDSCRAPQTY) {
                    oCopy.MFGORDERCONFIRMEDSCRAPQTY = Number(row.MFGORDERCONFIRMEDSCRAPQTY).toFixed(3);
                }
                if (row.mfgorderplannedtotalqty) {
                    oCopy.mfgorderplannedtotalqty = Number(row.mfgorderplannedtotalqty).toFixed(3);
                }
                if (row.actualdeliveredquantity) {
                    oCopy.actualdeliveredquantity = Number(row.actualdeliveredquantity).toFixed(3);
                }
                return oCopy;
            }.bind(this));

            var aColumns = [];
            oTable.getColumns().forEach(function (oColumn) {
                var oLabel = oColumn.getLabel();
                var sLabel = oLabel ? oLabel.getText() : "";
                var oTemplate = oColumn.getTemplate();
                var sBindingPath = "";

                if (oTemplate && oTemplate.getBindingInfo("text")) {
                    sBindingPath = oTemplate.getBindingInfo("text").parts[0].path;
                }
                if (sBindingPath) {
                    aColumns.push({ label: sLabel, property: sBindingPath, type: "string" });
                }
            });

            var oSettings = {
                workbook: { columns: aColumns },
                dataSource: aExportData,
                fileName: "Production_Report.xlsx"
            };

            var oSheet = new Spreadsheet(oSettings);
            oView.setBusy(true);
            oSheet.build().finally(function () {
                console.log("-> [EXPORT COMPLETE] Spreadsheet successfully built.");
                oSheet.destroy();
                oView.setBusy(false);
            });
        },

        onExit: function () {
            console.log("-> [EXIT] Destroying dialog instances.");
            if (this._oStorageLocationDialog) this._oStorageLocationDialog.destroy();
            if (this._oProdOrderDialog) this._oProdOrderDialog.destroy();
            if (this._oMatCodeDialog) this._oMatCodeDialog.destroy();
        }
    });
});