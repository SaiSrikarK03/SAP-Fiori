sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator",
    "sap/ui/export/Spreadsheet"
], function (Controller, MessageToast, JSONModel, Filter, FilterOperator, MessageBox, BusyIndicator,Spreadsheet) {
    "use strict";

    return Controller.extend("bando.controller.Dashboard.ProductionOrdersDashboard", {

        onInit: function () {
            // Initially empty – will be filled after pressing Go
            var oEmptyModel = new JSONModel({ Processes: [] });
            this.getView().setModel(oEmptyModel, "Dashboard");
        },

        // ----------------------------------------------------------------------
        // Mapping from MultiComboBox key to OData model name, entity set, and display name
        // Add/adapt for all processes present in the MultiComboBox
        // ----------------------------------------------------------------------
        _processMap: {
            "MIXING": {
                modelName: "ZSB_MIXING_PLAN1",
                entitySet: "/ZC_MIXING_PLAN1",
                displayName: "Mixing"
            },
            "CALENDER": {
                modelName: "ZSB_CALEN_PLAN",
                entitySet: "/ZC_CALEN_PLAN",
                displayName: "Calender"
            },
            "JOINTING": {
                modelName: "ZSB_JOINT_PLAN",
                entitySet: "/ZC_JOINT_PLAN",
                displayName: "Jointing"
            },
            "FG": {
                modelName: "ZSB_FG_PROCESS_PLAN",
                entitySet: "/ZC_FG_PROCESS_PLAN",
                displayName: "FG"
            },
            "FG_MOULDING": {
                modelName: "ZSB_MOULDING_FG_PLAN",
                entitySet: "/ZC_MOULDING_FG_PLAN",
                displayName: "FG Moulding"
            },
            "SFG_MOULDING": {
                modelName: "ZSB_MOULD_PLAN",
                entitySet: "/ZC_MOULD_PLAN",
                displayName: "SFG Moulding"
            },
            "WEIGHT_ROLLER": {
                modelName: "ZSB_WEIGHTROLLER_PLAN",
                entitySet: "/ZC_WEIGTHROLLER_PLAN",
                displayName: "Weight roller"
            },
            "GEAR_PROCESS": {
                modelName: "ZSB_GEAR_PLAN",
                entitySet: "/ZC_GEAR_PLAN",
                displayName: "Gear Process"
            },
            "KIT_PROCESS": {
                modelName: "ZSB_KIT_PLAN",
                entitySet: "/ZC_KIT_PLAN",
                displayName: "Kit Process"
            }
        },

        // ----------------------------------------------------------------------
        // Helper: fetch all pages from an OData entity (pagination)
        // ----------------------------------------------------------------------
        _fetchAllPages: function (oModel, sEntitySet, aFilters, iPageSize) {
            iPageSize = iPageSize || 1000;
            var deferred = $.Deferred();
            var allResults = [];
            var iSkip = 0;

            function fetchPage() {
                oModel.read(sEntitySet, {
                    filters: aFilters,
                    urlParameters: {
                        "$top": iPageSize,
                        "$skip": iSkip
                    },
                    success: function (oData) {
                        var aPage = oData.results || [];
                        allResults = allResults.concat(aPage);
                        if (aPage.length < iPageSize) {
                            deferred.resolve(allResults);
                        } else {
                            iSkip += iPageSize;
                            fetchPage();
                        }
                    },
                    error: function (oError) {
                        deferred.reject(oError);
                    }
                });
            }

            fetchPage();
            return deferred.promise();
        },

        // ----------------------------------------------------------------------
        // Helper: fetch TECO statuses for a list of order numbers (chunked OR)
        // ----------------------------------------------------------------------
        _fetchTecoForOrders: function (oModel, aOrderNumbers, iChunkSize) {
            iChunkSize = iChunkSize || 500;
            var deferred = $.Deferred();
            var allTecoOrders = [];
            var aChunks = [];

            for (var i = 0; i < aOrderNumbers.length; i += iChunkSize) {
                aChunks.push(aOrderNumbers.slice(i, i + iChunkSize));
            }

            if (aChunks.length === 0) {
                deferred.resolve(new Set());
                return deferred.promise();
            }

            function processChunk(chunk) {
                var aOrderFilters = chunk.map(function (order) {
                    return new Filter("ManufacturingOrder", FilterOperator.EQ, order);
                });
                var oOrFilter = new Filter({ filters: aOrderFilters, and: false });

                var aCombinedFilters = [
                    oOrFilter,
                    new Filter("StatusCode", FilterOperator.EQ, "I0045"),
                    new Filter("StatusIsActive", FilterOperator.EQ, true)
                ];

                var oDeferred = $.Deferred();
                oModel.read("/ZC_ORDER_CREATION1", {
                    filters: aCombinedFilters,
                    urlParameters: { "$top": chunk.length * 2 },
                    success: function (oData) {
                        var aResults = oData.results || [];
                        var aTecoOrders = aResults.map(function (item) { return item.ManufacturingOrder; });
                        oDeferred.resolve(aTecoOrders);
                    },
                    error: function (oError) {
                        oDeferred.reject(oError);
                    }
                });
                return oDeferred.promise();
            }

            function processSequentially(index) {
                if (index >= aChunks.length) {
                    deferred.resolve(new Set(allTecoOrders));
                    return;
                }
                processChunk(aChunks[index])
                    .then(function (aTecoOrders) {
                        allTecoOrders.push.apply(allTecoOrders, aTecoOrders);
                        processSequentially(index + 1);
                    })
                    .catch(function (oError) {
                        deferred.reject(oError);
                    });
            }

            processSequentially(0);
            return deferred.promise();
        },

        // ----------------------------------------------------------------------
        // Handler for the "Go" button
        // ----------------------------------------------------------------------
        onGoDashboard: function () {
            var oView = this.getView();

            // 1. Get selected processes from MultiComboBox
            var oProcessMCB = oView.byId("idProcess");
            var aSelectedKeys = oProcessMCB.getSelectedKeys();
            if (!aSelectedKeys || aSelectedKeys.length === 0) {
                MessageBox.warning("Please select at least one process.");
                return;
            }

            // 2. Get date range
            var oDateRange = oView.byId("idDateRange");
            var oStartDate = oDateRange.getDateValue();
            var oEndDate = oDateRange.getSecondDateValue();
            if (!oStartDate) {
                MessageBox.warning("Please select a start date.");
                oDateRange.setValueState("Error");
                oDateRange.setValueStateText("Start date is mandatory.");
                return;
            }
            oDateRange.setValueState("None");

            // Build date filter (if both dates exist, use BT; else use GE for start only)
            var aDateFilters = [];
            var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            var sStart = oDateFormat.format(oStartDate);
            if (oEndDate) {
                var sEnd = oDateFormat.format(oEndDate);
                aDateFilters.push(new Filter({
                    path: "productionordstartdate",
                    operator: FilterOperator.BT,
                    value1: sStart,
                    value2: sEnd
                }));
            } else {
                aDateFilters.push(new Filter("productionordstartdate", FilterOperator.GE, sStart));
            }

            // 3. Prepare to fetch data for each selected process
            var oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // model for TECO status
            var oDashboardModel = oView.getModel("Dashboard");

            BusyIndicator.show(0);

            var aProcessPromises = [];
            var aAllOrderNumbers = []; // to collect all production orders across all processes

            // For each selected process, fetch its rows
            aSelectedKeys.forEach(function (sKey) {
                var oProcessInfo = this._processMap[sKey];
                if (!oProcessInfo) {
                    MessageBox.error("Unknown process key: " + sKey);
                    return;
                }

                var oModel = oView.getModel(oProcessInfo.modelName);
                if (!oModel) {
                    MessageBox.error("Model not found for process: " + sKey);
                    return;
                }

                // Fetch rows with date filter
                var oPromise = this._fetchAllPages(oModel, oProcessInfo.entitySet, aDateFilters, 1000)
                    .then(function (aRows) {
                        // Store rows for later counting
                        return {
                            processKey: sKey,
                            displayName: oProcessInfo.displayName,
                            rows: aRows,
                            // Collect order numbers
                            orderNumbers: aRows.map(function (row) { return row.productionorderno; })
                                .filter(function (order) { return order && order !== "0" && !/^0+$/.test(order); })
                        };
                    }.bind(this));

                aProcessPromises.push(oPromise);
            }.bind(this));

            // Wait for all process fetches to complete
            Promise.all(aProcessPromises)
                .then(function (aProcessData) {
                    // Gather all unique order numbers from all processes
                    aAllOrderNumbers = [];
                    aProcessData.forEach(function (data) {
                        aAllOrderNumbers.push.apply(aAllOrderNumbers, data.orderNumbers);
                    });
                    var aUniqueOrders = [...new Set(aAllOrderNumbers)];

                    // 4. Fetch TECO statuses for all unique orders
                    return this._fetchTecoForOrders(oOrderCreationModel, aUniqueOrders, 500)
                        .then(function (tecoSet) {
                            // 5. Build the result array for the dashboard
                            var aDashboardProcesses = aProcessData.map(function (data) {
                                var rows = data.rows;
                                var total = rows.length;
                                var released = rows.filter(function (row) {
                                    return row.releasestatus === "RELEASED";
                                }).length;
                                var confirmed = rows.filter(function (row) {
                                    var doc = row.gicnfmaterialdocnumber;
                                    return doc && doc.trim() !== "" && doc !== "0";
                                }).length;
                                var goodsReceipt = rows.filter(function (row) {
                                    var doc = row.grmaterialdocnumber;
                                    return doc && doc.trim() !== "" && doc !== "0";
                                }).length;

                                // TECO count: count unique order numbers that are in tecoSet
                                var tecoCount = 0;
                                var orderSet = new Set(data.orderNumbers);
                                for (var order of orderSet) {
                                    if (tecoSet.has(order)) {
                                        tecoCount++;
                                    }
                                }

                                return {
                                    ProcessName: data.displayName,
                                    ProcessKey: data.processKey,
                                    TotalOrders: total,
                                    ReleasedOrders: released,
                                    ConfirmedOrders: confirmed,
                                    GoodsReceiptOrders: goodsReceipt,
                                    TecoOrders: tecoCount
                                };
                            });

                            // 6. Update the Dashboard model
                            oDashboardModel.setProperty("/Processes", aDashboardProcesses);

                            BusyIndicator.hide();
                            MessageToast.show("Dashboard updated for " + aDashboardProcesses.length + " process(es).");
                        }.bind(this));
                }.bind(this))
                .catch(function (oError) {
                    BusyIndicator.hide();
                    console.error("Error loading dashboard data:", oError);
                    MessageBox.error("An error occurred while fetching data. Please try again.");
                    // Reset model to empty
                    oDashboardModel.setProperty("/Processes", []);
                }.bind(this));
        },









        onExportExcel: function (oEvent) {
    var oButton = oEvent.getSource();
    var oContext = oButton.getBindingContext("Dashboard");
    if (!oContext) {
        sap.m.MessageBox.error("No process context found.");
        return;
    }
    var oProcessData = oContext.getObject();
    var sProcessKey = oProcessData.ProcessKey;
    if (!sProcessKey) {
        sap.m.MessageBox.error("Process key not found.");
        return;
    }

    var oView = this.getView();
    var oDateRange = oView.byId("idDateRange");
    var oStartDate = oDateRange.getDateValue();
    var oEndDate = oDateRange.getSecondDateValue();
    if (!oStartDate) {
        sap.m.MessageBox.warning("Please select a start date.");
        return;
    }

    // Build date filters (same logic as onGoDashboard)
    var aDateFilters = [];
    var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
    var sStart = oDateFormat.format(oStartDate);
    if (oEndDate) {
        var sEnd = oDateFormat.format(oEndDate);
        aDateFilters.push(new Filter({
            path: "productionordstartdate",
            operator: FilterOperator.BT,
            value1: sStart,
            value2: sEnd
        }));
    } else {
        aDateFilters.push(new Filter("productionordstartdate", FilterOperator.GE, sStart));
    }

    var oProcessInfo = this._processMap[sProcessKey];
    if (!oProcessInfo) {
        sap.m.MessageBox.error("Process info not found for key: " + sProcessKey);
        return;
    }
    var oModel = oView.getModel(oProcessInfo.modelName);
    if (!oModel) {
        sap.m.MessageBox.error("Model not found for process: " + sProcessKey);
        return;
    }

    sap.ui.core.BusyIndicator.show(0);

    // Fetch rows for the process
    this._fetchAllPages(oModel, oProcessInfo.entitySet, aDateFilters, 1000)
        .then(function (aRows) {
            // Collect unique order numbers
            var aOrderNumbers = aRows.map(function (row) { return row.productionorderno; })
                .filter(function (order) { return order && order !== "0" && !/^0+$/.test(order); });
            var aUniqueOrders = [...new Set(aOrderNumbers)];

            // Fetch TECO statuses
            var oTecoModel = oView.getModel("ZSB_PRODUCT_ORD1");
            return this._fetchTecoForOrders(oTecoModel, aUniqueOrders, 500)
                .then(function (tecoSet) {
                    // Daily aggregation
                    var oDailyCounts = {};
                    aRows.forEach(function (row) {
                        var sDate = row.productionordstartdate;
                        // Normalize to "yyyy-MM-dd"
                        if (typeof sDate === 'string' && sDate.indexOf('T') > -1) {
                            sDate = sDate.split('T')[0];
                        } else if (sDate instanceof Date) {
                            sDate = oDateFormat.format(sDate);
                        }
                        if (!oDailyCounts[sDate]) {
                            oDailyCounts[sDate] = {
                                total: 0, released: 0, unreleased: 0,
                                confirmed: 0, unconfirmed: 0,
                                goodsReceipt: 0, goodsReceiptNotCompleted: 0,
                                teco: 0, unTeco: 0
                            };
                        }
                        var day = oDailyCounts[sDate];
                        day.total++;

                        // Released
                        if (row.releasestatus === "RELEASED") {
                            day.released++;
                        } else {
                            day.unreleased++;
                        }

                        // Confirmed
                        var giDoc = row.gicnfmaterialdocnumber;
                        if (giDoc && giDoc.trim() !== "" && giDoc !== "0") {
                            day.confirmed++;
                        } else {
                            day.unconfirmed++;
                        }

                        // Goods Receipt
                        var grDoc = row.grmaterialdocnumber;
                        if (grDoc && grDoc.trim() !== "" && grDoc !== "0") {
                            day.goodsReceipt++;
                        } else {
                            day.goodsReceiptNotCompleted++;
                        }

                        // TECO
                        var order = row.productionorderno;
                        if (order && tecoSet.has(order)) {
                            day.teco++;
                        } else {
                            day.unTeco++;
                        }
                    });

                    // Build export data sorted by date
                    var aSortedDates = Object.keys(oDailyCounts).sort();
                    var aExportData = aSortedDates.map(function (dateStr) {
                        var day = oDailyCounts[dateStr];
                        var oDate = new Date(dateStr);
                        var sFormatted = this._formatDateForExport(oDate);
                        return {
                            releasedDate: sFormatted,
                            releasedCount: day.released,
                            unreleasedDate: sFormatted,
                            unreleasedCount: day.unreleased,
                            confirmedDate: sFormatted,
                            confirmedCount: day.confirmed,
                            unconfirmedDate: sFormatted,
                            unconfirmedCount: day.unconfirmed,
                            goodsReceiptDate: sFormatted,
                            goodsReceiptCount: day.goodsReceipt,
                            goodsReceiptNotCompletedDate: sFormatted,
                            goodsReceiptNotCompletedCount: day.goodsReceiptNotCompleted,
                            tecoDate: sFormatted,
                            tecoCount: day.teco,
                            unTecoDate: sFormatted,
                            unTecoCount: day.unTeco,
                            totalDate: sFormatted,
                            totalCount: day.total
                        };
                    }.bind(this));

                    // Define columns for export
                    var aColumns = [
                        { label: "Released Order Date", property: "releasedDate" },
                        { label: "Total Released Orders", property: "releasedCount" },
                        { label: "Unreleased Order Date", property: "unreleasedDate" },
                        { label: "Total Unreleased Orders", property: "unreleasedCount" },
                        { label: "Confirmed Order Date", property: "confirmedDate" },
                        { label: "Total Confirmed Orders", property: "confirmedCount" },
                        { label: "Unconfirmed Order Date", property: "unconfirmedDate" },
                        { label: "Total Unconfirmed Orders", property: "unconfirmedCount" },
                        { label: "Goods Receipt Order Date", property: "goodsReceiptDate" },
                        { label: "Total Goods Receipt Orders", property: "goodsReceiptCount" },
                        { label: "Goods Receipt Not Completed Order Date", property: "goodsReceiptNotCompletedDate" },
                        { label: "Total Goods Receipt Not Completed Orders", property: "goodsReceiptNotCompletedCount" },
                        { label: "TECO Order Date", property: "tecoDate" },
                        { label: "Total TECO Orders", property: "tecoCount" },
                        { label: "Un-TECO Order Date", property: "unTecoDate" },
                        { label: "Total Un-TECO Orders", property: "unTecoCount" },
                        { label: "Total Order Date", property: "totalDate" },
                        { label: "Total Orders", property: "totalCount" }
                    ];

                    var oSpreadsheet = new sap.ui.export.Spreadsheet({
                        workbook: {
                            columns: aColumns,
                            context: {
                                sheetName: oProcessInfo.displayName + " Dashboard"
                            }
                        },
                        dataSource: aExportData,
                        fileName: oProcessInfo.displayName + "_Dashboard_Export.xlsx"
                    });

                    oSpreadsheet.build()
                        .then(function () {
                            sap.m.MessageToast.show("Export completed.");
                        })
                        .catch(function (oError) {
                            sap.m.MessageBox.error("Export failed: " + oError.message);
                        })
                        .finally(function () {
                            sap.ui.core.BusyIndicator.hide();
                        });
                }.bind(this));
        }.bind(this))
        .catch(function (oError) {
            sap.ui.core.BusyIndicator.hide();
            console.error("Error fetching data for export:", oError);
            sap.m.MessageBox.error("An error occurred while fetching data. Please try again.");
        });
},

// Helper to format date as "dd-MMM-yyyy" (e.g., "01-Aug-2026")
_formatDateForExport: function (oDate) {
    if (!oDate) return "";
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var day = String(oDate.getDate()).padStart(2, '0');
    var month = monthNames[oDate.getMonth()];
    var year = oDate.getFullYear();
    return day + "-" + month + "-" + year;
},

    });
});