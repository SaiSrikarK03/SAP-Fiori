sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel",
        "sap/ui/model/odata/v2/ODataModel",
        "sap/m/MessageToast",
        "sap/m/MessageBox",
        "sap/ui/model/Filter",
        "sap/ui/model/FilterOperator",
        "sap/ui/core/IconPool",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/ui/export/Spreadsheet",
        "sap/ui/export/library",
        "sap/m/PDFViewer",
        "bando/util/importfile/importexcelfile",
        "bando/util/pdf-lib/pdf-lib.min",
        "sap/ui/core/Fragment",

    ],
    function (BaseController,
        JSONModel,
        ODataModel,
        MessageToast,
        MessageBox,
        Filter,
        FilterOperator,
        IconPool,
        Component,
        UIComponent,
        Router,
        Spreadsheet,
        exportLibrary,

        PDFViewer,
        importexcelfile,
        PDFLibjs,
        Fragment) {
        "use strict";

    return BaseController.extend("bando.controller.injection_moulding.KitProcess.KitProcessPlanReport.KitProcessPlanReport", {

        onInit: function () {
                // Table model
                this.getView().setModel(
                    new JSONModel({ ItemData: [] }),
                    "TabModel"
                );

                // Mixing Plan OData model
                this.getView().setModel(
                    new ODataModel("/sap/opu/odata/sap/ZSB_KIT_PLAN/"),
                    "ZSB_KIT_PLAN"
                );
            },

            /* ================= FORMATTERS ================= */
            formatDate: function (vDate) {
                if (!vDate) {
                    return "";
                }
                var oDate = vDate instanceof Date ? vDate : new Date(vDate);
                if (isNaN(oDate.getTime())) {
                    return "";
                }
                return sap.ui.core.format.DateFormat
                    .getDateInstance({ pattern: "dd/MM/yyyy" })
                    .format(oDate);
            },

            GoStockReqTableOpen: function () {
                var view = this.getView();
                var oModel = view.getModel("ZSB_KIT_PLAN");
                var tabModel = view.getModel("TabModel");

                var aFilters = [];

                
                /* ===== DATE RANGE FILTER (OPTIONAL) ===== */
                var oDateRange = view.byId("MIX_KitProcess");
                var dFrom = oDateRange.getDateValue();
                var dTo = oDateRange.getSecondDateValue();

                if (dFrom && dTo) {
                    var sFromDate =
                        dFrom.getFullYear() + "-" +
                        String(dFrom.getMonth() + 1).padStart(2, "0") + "-" +
                        String(dFrom.getDate()).padStart(2, "0");

                    var sToDate =
                        dTo.getFullYear() + "-" +
                        String(dTo.getMonth() + 1).padStart(2, "0") + "-" +
                        String(dTo.getDate()).padStart(2, "0");

                    aFilters.push(
                        new sap.ui.model.Filter(
                            "productionordstartdate",
                            sap.ui.model.FilterOperator.BT,
                            sFromDate,
                            sToDate
                        )
                    );
                }

                /* ===== PRODUCTION ORDER FILTER (FROM FRAGMENT TOKENS) ===== */
                var aTokens = view.byId("idmaterialdocumentMPR_KitProcess").getTokens();

                if (aTokens && aTokens.length) {
                    var aProdFilters = aTokens.map(function (oToken) {
                        return new sap.ui.model.Filter(
                            "productionorderno",
                            sap.ui.model.FilterOperator.EQ,
                            oToken.getKey() || oToken.getText()
                        );
                    });

                    aFilters.push(
                        new sap.ui.model.Filter({
                            filters: aProdFilters,
                            and: false   // OR condition
                        })
                    );
                }

                /* ===== MATERIAL FILTER ===== */
                var sMaterial = view.byId("idMaterial_MIX_KitProcess").getValue();
                if (sMaterial) {
                    aFilters.push(
                        new sap.ui.model.Filter(
                            "materialcode",
                            sap.ui.model.FilterOperator.EQ,
                            sMaterial
                        )
                    );
                }

                /* ===== BIPL LOT NO FILTER ===== */
                var sBiplLot = view.byId("idMaterial_MIX_bipllotnoKitProcess").getValue();
                if (sBiplLot) {
                    aFilters.push(
                        new Filter(
                            "bipllotno",
                            FilterOperator.EQ,
                            sBiplLot
                        )
                    );
                }

                /* ===== SHIFT FILTER ===== */
                var sShift = view.byId("idMaterial_MIX_shiftKitProcess").getValue();
                if (sShift) {
                    aFilters.push(
                        new Filter(
                            "shift",
                            FilterOperator.EQ,
                            sShift
                        )
                    );
                }

                /* ===== DESCRIPTION FILTER ===== */
                var sDescription = view.byId("idMaterial_MIX_description_KitProcess").getValue();
                if (sDescription) {
                    aFilters.push(
                        new Filter(
                            "description",
                            FilterOperator.EQ,
                            sDescription
                        )
                    );
                }

                /* ===== MACHINE NUMBER FILTER ===== */
                var sMachine = view.byId("idMaterial_MIX_machinenumberKitprocess").getValue();
                if (sMachine) {
                    aFilters.push(
                        new Filter(
                            "machinenumber",
                            FilterOperator.EQ,
                            sMachine
                        )
                    );
                }

                view.setBusy(true);

                /* ===== ODATA READ ===== */
                oModel.read("/ZC_KIT_PLAN", {
                    filters: aFilters,
                    urlParameters: {
                        "$top": 10000,
                        "$orderby": "productionorderno asc" 
                    },
                    success: function (oData) {
                        tabModel.setProperty("/ItemData", oData.results || []);
                        view.setBusy(false);

                        if (!oData.results || !oData.results.length) {
                            sap.m.MessageToast.show("No records found");
                        }
                    },
                    error: function (oError) {
                        console.error("Error fetching Mixing Plan data", oError);
                        sap.m.MessageToast.show("Error fetching data");
                        view.setBusy(false);
                    }
                });
            },

            _removeLeadingZeros: function(sVal) {
                if (!sVal) return "";
                return sVal.replace(/^0+/, "");
            },

            onDownload: function () {
                var oView = this.getView();
                var aData = oView.getModel("TabModel").getProperty("/ItemData") || [];

                if (!aData.length) {
                    sap.m.MessageToast.show("No data to export");
                    return;
                }

                // Prepare export data matching your table columns exactly
                var aExportData = aData.map(function (o) {
                    return {
                        Date: o.productionordstartdate ? 
                            sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd/MM/yyyy" }).format(new Date(o.productionordstartdate)) 
                            : "",
                        ProductionOrder: o.productionorderno || "",
                        Material: o.materialcode || "",
                        BIPLLotNo: o.bipllotno || "",
                        Shift: o.shift || "",
                        Description: o.description || "",
                        Machine: o.machinenumber || "",
                        Plant: o.plant || "",
                        LotBatchNo: o.lotbatchno || "",
                        ProductionOrderQty: o.productionorderqty != null ? parseFloat(o.productionorderqty).toFixed(4) : "0.0000",
                        StorageLoc: o.storagelocation || ""
                    };
                });

                // Define columns exactly matching your table headers
                var EdmType = exportLibrary.EdmType;
                var aCols = [
                    { label: "Date", property: "Date", type: EdmType.String },
                    { label: "Production Order", property: "ProductionOrder", type: EdmType.String },
                    { label: "Material", property: "Material", type: EdmType.String },
                    { label: "BIPL Lot No.", property: "BIPLLotNo", type: EdmType.String },
                    { label: "Shift", property: "Shift", type: EdmType.String },
                    { label: "Description", property: "Description", type: EdmType.String },
                    { label: "Machine", property: "Machine", type: EdmType.String },
                    { label: "Plant", property: "Plant", type: EdmType.String },
                    { label: "Lot Batch No", property: "LotBatchNo", type: EdmType.String },
                    { label: "Production Order Qty", property: "ProductionOrderQty", type: EdmType.Decimal, scale: 4 },
                    { label: "Storage Loc", property: "StorageLoc", type: EdmType.String }
                ];

                // Create the Spreadsheet
                var oSettings = {
                    workbook: { columns: aCols },
                    dataSource: aExportData,
                    fileName: "KitProcessPlanReport.xlsx"
                };

                var oSheet = new sap.ui.export.Spreadsheet(oSettings);
                oSheet.build()
                    .finally(function () {
                        oSheet.destroy();
                    });
            },

            onValueHelpRequest: function (oEvent) {

            this._oMultiInput = oEvent.getSource();

            // var Date = this.getView().byId("Dates_").getValue();

            var Date = "";

            // console.log(Date)
            if (Date || Date.length == 0) {
                sap.ui.core.BusyIndicator.show();

                //   var oFilters1 = new sap.ui.model.Filter("Createdat", sap.ui.model.FilterOperator.EQ, Date);
                // Retrieve the model from the view
                var oModel = this.getView().getModel("ZSB_KIT_PLAN");

                // Check if the model is valid
                if (!oModel) {
                    console.error("OData model is not properly initialized.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                //   var oFilters = [oFilters1];
                var that = this;
                var aAllItems = []; // Array to hold all retrieved items

                // Function to fetch data recursively
                function fetchData(skipCount) {
                    // var that = this;
                    // var oModel = that.getView().getModel();
                    // that.getView().setModel(oModel);
                    oModel.read("/ZC_KIT_PLAN", {
                        //   filters: oFilters,
                        urlParameters: {
                            $top: 5000,  // Request a chunk of 5000 records
                            $skip: skipCount  // Start from the skipCount position
                        },
                        success: function (oData) {
                            var aItems = oData.results;
                            aAllItems = aAllItems.concat(aItems); // Concatenate current chunk to the array

                            // Check if there are more records to fetch
                            if (oData.results.length >= 5000) {
                                // If there are more records, fetch next chunk
                                fetchData(skipCount + 5000);
                            } else {
                                // If no more records, all data is fetched
                                finishFetching();
                            }
                        },
                        error: function (oError) {
                            console.error("Error reading data: ", oError);
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });
                }

                function finishFetching() {


                    // Once all data is fetched, proceed to display it
                    that.oJSONModel = new sap.ui.model.json.JSONModel({
                        Datas: aAllItems
                    });
                    that.getView().setModel(that.oJSONModel, "oJSONModel");
                    console.log("that.oJSONModel:", that.oJSONModel)

                    // Load the value help dialog fragment
                    that._oBasicSearchField = new sap.m.SearchField();
                    that.loadFragment({
                        name: "bando.view.injection_moulding.KitProcess.KitProcessPlanReport.fragment.KitProcessPlanFrag",
                    }).then(function (oDialog) {
                        var oFilterBar = oDialog.getFilterBar();

                        var oColumnProductCode, oColumnPostingDate, oColumnCompanyCode;
                        that._oVHD = oDialog;
                        that.getView().addDependent(oDialog);

                        // Set key fields for filtering in the Define Conditions Tab
                        oDialog.setRangeKeyFields([{
                            label: "Production No.",
                            key: "productionorderno",
                            type: "string",
                            typeInstance: new sap.ui.model.type.String({}, {
                                maxLength: 10
                            })
                        }]);

                        // Set Basic Search for FilterBar
                        oFilterBar.setFilterBarExpanded(false);
                        oFilterBar.setBasicSearch(that._oBasicSearchField);

                        // Trigger filter bar search when the basic search is fired
                        that._oBasicSearchField.attachSearch(function () {
                            oFilterBar.search();
                        });

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(that.oJSONModel);

                            // Bind rows/items based on table type (sap.ui.table.Table or sap.m.Table)
                            if (oTable.bindRows) {
                                // Desktop/Table scenario (sap.ui.table.Table)
                                oTable.bindAggregation("rows", {
                                    path: "oJSONModel>/Datas",
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                // Define columns for sap.ui.table.Table
                                oColumnProductCode = new sap.ui.table.Column({
                                    label: new sap.m.Label({ text: "Production No." }),
                                    template: new sap.m.Text({ wrapping: false, text: "{oJSONModel>productionorderno}" })
                                });
                                oColumnProductCode.data({
                                    fieldName: "productionorder"
                                });

                                oTable.addColumn(oColumnProductCode);


                            } else if (oTable.bindItems) {
                                // Mobile scenario (sap.m.Table)
                                oTable.bindAggregation("items", {
                                    path: "oJSONModel>/Datas",
                                    template: new sap.m.ColumnListItem({
                                        cells: [
                                            new sap.m.Text({ text: "{oJSONModel>productionorderno}" }),

                                        ]
                                    }),
                                    events: {
                                        dataReceived: function () {
                                            oDialog.update();
                                        }
                                    }
                                });

                                // Define columns for sap.m.Table (if necessary)
                                oTable.addColumn(new sap.m.Column({
                                    header: new sap.m.Label({ text: "Production No." })
                                }));

                            }

                            oDialog.update();
                            sap.ui.core.BusyIndicator.hide();
                        });

                        oDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    });
                }

                // Start fetching data from the beginning
                fetchData(0);
            } else {
                //   sap.m.MessageBox.error("Please check Company Code / Fiscal Year");
                sap.ui.core.BusyIndicator.hide();
            }
        },

        onValueHelpOkPress: function(oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            console.log("aTokens:", aTokens);

            if (!this._oMultiInput) {
                console.error("MultiInput not defined!");
                return;
            }

            if (aTokens.length <= 10) {
                this._oMultiInput.setTokens(aTokens); // now safe
                this._oVHD.close();
            } else {
                sap.m.MessageBox.error("Please select max 15 items only!");
            }
        },

        onValueHelpCancelPress: function () {
            this._oVHD.close();
        },

        onValueHelpAfterClose: function () {
            this._oVHD.destroy();
        },

        onFilterBarSearch: function (oEvent) {
            var sSearchQuery = this._oBasicSearchField.getValue(),
                aSelectionSet = oEvent.getParameter("selectionSet");

            var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
                if (oControl.getValue()) {
                    aResult.push(new sap.ui.model.Filter({
                        path: oControl.getName(),
                        operator: FilterOperator.Contains,
                        value1: oControl.getValue()
                    }));
                }

                return aResult;
            }, []);

            aFilters.push(new sap.ui.model.Filter({
                filters: [
                    new sap.ui.model.Filter({ path: "productionorderno", operator: sap.ui.model.FilterOperator.EQ, value1: sSearchQuery })

                ],
                and: false
            }));

            this._filterTable(new sap.ui.model.Filter({
                filters: aFilters,
                and: true
            }));
        },

        _filterTable: function (oFilter) {
            var oVHD = this._oVHD;

            oVHD.getTableAsync().then(function (oTable) {
                if (oTable.bindRows) {
                    oTable.getBinding("rows").filter(oFilter);
                }
                if (oTable.bindItems) {
                    oTable.getBinding("items").filter(oFilter);
                }

                // This method must be called after binding update of the table.
                oVHD.update();
            });
        },

        // Connect to the OData service and fetch suggestions
        OnSuggest_User: function(oEvent) {
            // Store the source MultiInput
            this._oMultiInput = oEvent.getSource();

            var sTerm = oEvent.getParameter("suggestValue");

            this._connectToODataProductSearchService(sTerm)
                .then(function(aSuggestions) {
                    // Clear previous suggestions
                    this.destroySuggestionItems();

                    // Add new suggestions to the input field
                    for (var i = 0; i < aSuggestions.length; i++) {
                        this.addSuggestionItem(new sap.ui.core.Item({
                            text: aSuggestions[i]
                        }));
                    }
                }.bind(oEvent.getSource())); // bind the input
        },

        
        _connectToODataProductSearchService: function (sTerm) {
            var oModel = this.getView().getModel('ZSB_KIT_PLAN'); // OData Model
            var aFilters = [
                new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sTerm) // Search based on Name
            ];

            return new Promise(function (fnResolve, fnReject) {
                // Perform OData read request
                oModel.read("/ZC_KIT_PLAN", {  // Replace "/ProductSet" with your OData entity set
                    filters: aFilters,
                    urlParameters: {
                        "$top": 50
                    },
                    success: function (oData) {
                        var aResults = oData.results.map(function (mProduct) {
                            return mProduct.productionorderno;  // Assuming Name is the field you're interested in
                        });

                        // Resolve with the list of suggestions
                        fnResolve(aResults);
                    },
                    error: function (oError) {
                        console.error("Error fetching suggestions from OData service:", oError);
                        fnReject(oError);
                    }
                });
            });
        },

        ondocumentsuggestselected: function(oEvent) {
            sap.ui.core.BusyIndicator.show();

            var oSelectedItem = oEvent.getParameter("selectedItem");

            if (oSelectedItem) {
                var sSelectedText = oSelectedItem.getText();

                if (!this._oMultiInput) {
                    console.error("MultiInput not defined!");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // Set value into the stored MultiInput
                this._oMultiInput.setValue(sSelectedText);
            }

            sap.ui.core.BusyIndicator.hide();
        },

        });
    }
);