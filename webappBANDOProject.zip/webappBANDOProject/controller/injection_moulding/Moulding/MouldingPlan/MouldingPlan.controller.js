sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/IconPool",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Component",
    "sap/ui/core/UIComponent",
    "sap/m/routing/Router",
    "sap/ui/export/Spreadsheet",
    "bando/util/importfile/importexcelfile",
    "sap/m/PDFViewer",
    "bando/util/jspdf/html2canvasmin",
    "bando/util/jspdf/jspdfmin",
    "bando/util/qrcode/qrcode.min"

  ],
  function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, Spreadsheet, importexcelfile, PDFLibjs, pdfjsLib, pdf, QRCode) {
    "use strict";

    return BaseController.extend("bando.controller.injection_moulding.Moulding.MouldingPlan.MouldingPlan", {
      onInit: function () {
        this._fetchPostedData(); // Initial load


        var TabModel = new sap.ui.model.json.JSONModel({
          Samples: [

          ]

        });
        this.getView().setModel(TabModel, "TabModel");


        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }

        });

        this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");


        var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
        oRouter.getRoute("MouldingPlan").attachMatched(this._onRouteMatched, this); // Re-fetch on return
      },

      _onRouteMatched: function () {
        this._fetchPostedData(); // Always refresh from backend on route match
      },


      // _fetchPostedData: function () {
      //   var oView = this.getView();

      //   var Tab_SelectAll = new sap.ui.model.json.JSONModel({
      //     Samples: {
      //       selectall: false
      //     }
      //   });
      //   oView.setModel(Tab_SelectAll, "Tab_SelectAll");

      //   // Safely get the backend model
      //   var oModel = this.getOwnerComponent().getModel("ZSB_MOULD_PLAN");
      //   if (!oModel) {
      //     sap.m.MessageBox.error("Model 'ZSB_MOULD_PLAN' not found.");
      //     return;
      //   }

      //   // Show busy indicator during loading
      //   oView.setBusy(true);

      //   var prodordFilter = new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '');

      //   // Call the read function
      //   oModel.read("/ZC_MOULD_PLAN", {
      //     filters: [prodordFilter],

      //     success: function (oData) {
      //       // Create a new JSON model and set the data
      //       var oJSONModel = new sap.ui.model.json.JSONModel();
      //       oJSONModel.setData({
      //         Samples: oData.results
      //       });

      //       // Attach to view with name 'TabModel'
      //       oView.setModel(oJSONModel, "TabModel");

      //       // ✅ Call ComboBox loader after data is set
      //       this._loadMachineComboBox();

      //       oView.setBusy(false);
      //       oModel.refresh();
      //     }.bind(this), // ✅ BIND the controller context here

      //     error: function (oError) {
      //       oView.setBusy(false);
      //       sap.m.MessageBox.error("Failed to retrieve Mixing Plan data.");
      //       console.error("OData read error:", oError);
      //     }
      //   });
      // },


      _fetchPostedData: function () {
        var oView = this.getView();

        var Tab_SelectAll = new sap.ui.model.json.JSONModel({
          Samples: {
            selectall: false
          }
        });
        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

        // Safely get the backend model
        var oModel = this.getOwnerComponent().getModel("ZSB_MOULD_PLAN");
        if (!oModel) {
          sap.m.MessageBox.error("Model 'ZSB_MOULD_PLAN' not found.");
          return;
        }

        // Show busy indicator during loading
        oView.setBusy(true);

        var prodordFilter = new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '');

        // Call the read function with increased limit
        oModel.read("/ZC_MOULD_PLAN", {
          filters: [prodordFilter],
          urlParameters: {
            "$top": 10000  // Increased from default to 10,000 records
          },
          success: function (oData) {
            // Create a new JSON model and set the data
            var oJSONModel = new sap.ui.model.json.JSONModel();
            oJSONModel.setData({
              Samples: oData.results
            });

            // Attach to view with name 'TabModel'
            oView.setModel(oJSONModel, "TabModel");

            // ✅ Call ComboBox loader after data is set
            this._loadMachineComboBox();

            oView.setBusy(false);
            oModel.refresh();

            // Optional: Log how many records were loaded
            console.log("Loaded " + (oData.results ? oData.results.length : 0) + " records");
          }.bind(this), // ✅ BIND the controller context here

          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Failed to retrieve Moulding Plan data.");
            console.error("OData read error:", oError);
          }
        });
      },

      _loadMachineComboBox: function () {
        var oView = this.getView();
        var oTabModel = oView.getModel("TabModel");
        var aSamples = oTabModel.getProperty("/Samples") || [];

        // Get unique machine numbers
        var aUniqueMachineNumbers = [...new Set(aSamples.map(item => item.machinenumber))];

        // Convert to ComboBox item format
        var aComboBoxItems = aUniqueMachineNumbers.map(function (sMachineNumber) {
          return {
            key: sMachineNumber,
            text: sMachineNumber
          };
        });

        // Create JSON model for ComboBox
        var oMachineModel = new sap.ui.model.json.JSONModel({
          MachineNumbers: aComboBoxItems
        });

        // Set the model to the view
        oView.setModel(oMachineModel, "MachineModel");

        // Clear selection in ComboBox (optional)
        var oComboBox = oView.byId("inputMachineNumberFilter");
        if (oComboBox) {
          oComboBox.setSelectedKey("");
        }
      },


      onSelectAll: function (oEvent) {
        const bSelected = oEvent.getParameter("selected");
        const oTableModel = this.getView().getModel("TabModel");
        const aRows = oTableModel.getProperty("/Samples") || [];

        aRows.forEach(row => {
          row.__selected = bSelected;
        });

        oTableModel.setProperty("/Samples", aRows);
      },



      onAddRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        // Create a blank row (add fields as required)
        var oNewRow = {
          sap_uuid: "",
          plant: "1200",
          bipllotno: "",
          shift: "",
          materialcode: "",
          description: "",
          compoundcode: "",
          storagelocation: "",
          machinenumber: "",
          productionorderqty: "",
          productionordstartdate: "",
          // uom: "",
          // balanceQty: "",
          lotbatchno: "",
          manufacturingdate: null,
          expirydate: null,
          batchweight: "",
          operator: "",
          inspector: "",
          savedstatus: "",
          productionorderno: "",
          statusOfProdOrd: "",
          __selected: false
        };

        aData.push(oNewRow);
        oModel.setProperty("/Samples", aData);
      },



      onRemoveRow: function () {
        var oModel = this.getView().getModel("TabModel");
        var aData = oModel.getProperty("/Samples") || [];

        var aRowsToKeep = [];
        var bAnyDeleted = false;
        var bAnyBlocked = false;

        aData.forEach(function (row) {
          if (row.__selected) {
            if (!row.sap_uuid || row.sap_uuid.trim() === "") {
              // Deletable row — skip adding to keep list
              bAnyDeleted = true;
            } else {
              // Selected but not deletable — keep it
              aRowsToKeep.push(row);
              bAnyBlocked = true;
            }
          } else {
            // Not selected — keep it
            aRowsToKeep.push(row);
          }
        });

        oModel.setProperty("/Samples", aRowsToKeep);

        // Show appropriate message
        if (bAnyDeleted && bAnyBlocked) {
          sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
        } else if (bAnyBlocked && !bAnyDeleted) {
          sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
        } else if (bAnyDeleted) {
          sap.m.MessageBox.success("Selected rows removed successfully.");
        } else {
          sap.m.MessageBox.information("No rows were selected for deletion.");
        }
      },


      numericComparator: function (a, b) {
                // Convert to integer; use 0 if conversion fails (e.g., empty or non-numeric)
                var numA = parseInt(a, 10) || 0;
                var numB = parseInt(b, 10) || 0;

                // Return negative if a < b, zero if equal, positive if a > b (ascending order)
                return numA - numB;
            },


      // onNumericLiveChange: function (oEvent) {
      //     var sValue = oEvent.getParameter("value");

      //     // Remove any non-numeric characters (except decimal if needed)
      //     var sCleanedValue = sValue.replace(/[^\d]/g, ""); // only digits allowed

      //     // Optional: allow decimals
      //     // var sCleanedValue = sValue.replace(/[^0-9.]/g, "");

      //     if (sValue !== sCleanedValue) {
      //         oEvent.getSource().setValue(sCleanedValue);
      //     }
      // },
      onNumericLiveChange: function (oEvent) {
        var sValue = oEvent.getParameter("value");

        // Allow digits, commas, and periods
        var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

        // Optional (if you want to normalize double dots or commas)
        // Limit to only one dot and one comma max
        var hasDot = false;
        var hasComma = false;
        sCleanedValue = sCleanedValue
          .split("")
          .filter(char => {
            if (char === "." && !hasDot) {
              hasDot = true;
              return true;
            } else if (char === "," && !hasComma) {
              hasComma = true;
              return true;
            } else if (/\d/.test(char)) {
              return true;
            }
            return false;
          })
          .join("");

        // Set the cleaned value back if changed
        if (sValue !== sCleanedValue) {
          oEvent.getSource().setValue(sCleanedValue);
        }
      },













      onBeforeRendering: function () {
        var oUserInfo = sap.ushell.Container.getService("UserInfo");
        this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
      },


      onFilterProdStart: function () {
        const oView = this.getView();
        const oDatePicker = oView.byId("dpFilterProdStart");
        const oModel = oView.getModel("ZSB_MOULD_PLAN"); // ODataModel
        const oTabModel = oView.getModel("TabModel");      // Local JSONModel for table binding

        // Get selected date
        const oDate = oDatePicker.getDateValue();

        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, '') // Only empty production order
        ];

        if (oDate) {
          // Format date to yyyy-MM-dd
          const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          const sSelectedDate = oDateFormat.format(oDate);

          // Add date filter
          aFilters.push(new sap.ui.model.Filter("productionordstartdate", sap.ui.model.FilterOperator.EQ, sSelectedDate));
        }

        sap.ui.core.BusyIndicator.show(0);

        // Perform OData read with combined filters
        oModel.read("/ZC_MOULD_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []); // No results
              sap.m.MessageToast.show("No records found for selected criteria");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend");
          }
        });
      },
      onFilterMachineNumber: function () {
        const oView = this.getView();
        const oComboBox = oView.byId("inputMachineNumberFilter");
        const sSelectedMachine = oComboBox.getSelectedKey();

        const oModel = oView.getModel("ZSB_MOULD_PLAN"); // Your ODataModel
        const oTabModel = oView.getModel("TabModel");      // Your table model

        // Validate selection
        if (!sSelectedMachine) {
          // Reload full dataset
          this._fetchPostedData();
          return;
        }


        // Build filters
        const aFilters = [
          new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, ''), // Only empty prod orders
          new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, sSelectedMachine)
        ];

        // Show loading indicator
        sap.ui.core.BusyIndicator.show(0);

        // Perform filtered read
        oModel.read("/ZC_MOULD_PLAN", {
          filters: aFilters,
          success: function (oData) {
            sap.ui.core.BusyIndicator.hide();

            if (oData.results && oData.results.length > 0) {
              oTabModel.setProperty("/Samples", oData.results);
            } else {
              oTabModel.setProperty("/Samples", []);
              sap.m.MessageToast.show("No records found for selected Machine Number");
            }
          },
          error: function () {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error("Failed to fetch data from backend.");
          }
        });
      },


      // onProductionDateChange: function(oEvent) {
      //     const oDatePicker = oEvent.getSource();
      //     const oSelectedDate = oDatePicker.getDateValue();
      //     const sCurrentPath = oDatePicker.getBindingContext("TabModel").getPath();
      //     const oTabModel = this.getView().getModel("TabModel");

      //     // Get current date (without time part for comparison)
      //     const oToday = new Date();
      //     oToday.setHours(0, 0, 0, 0);

      //     // Create copy of selected date without time part
      //     const oSelectedDateNoTime = oSelectedDate ? new Date(oSelectedDate) : null;
      //     if (oSelectedDateNoTime) {
      //         oSelectedDateNoTime.setHours(0, 0, 0, 0);
      //     }

      //     // If date is cleared, allow it
      //     if (!oSelectedDate) {
      //         // Clear the value in the model
      //         oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //         return;
      //     }

      //     // Check if selected date is in the past
      //     if (oSelectedDateNoTime < oToday) {
      //         // Show error message
      //         sap.m.MessageBox.error("Cannot select a past date. Please select today's date or a future date.");

      //         // Get the current value from the model
      //         const sCurrentValue = oTabModel.getProperty(sCurrentPath + "/productionordstartdate");

      //         if (sCurrentValue) {
      //             // Parse the current model value back to a Date object and set it in the DatePicker
      //             const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
      //                 pattern: "yyyy-MM-dd"
      //             });
      //             const oCurrentDate = oDateFormat.parse(sCurrentValue);
      //             oDatePicker.setDateValue(oCurrentDate);
      //         } else {
      //             // If there's no current value, clear the DatePicker
      //             oDatePicker.setValue("");
      //         }
      //     }
      //     // If date is today or in the future, do nothing - the binding will automatically update the model
      //     // The two-way binding of the DatePicker will handle updating the model
      // },



      // _getTabRowsArray: function (oTabModel) {
      //   const oData = oTabModel.getProperty("/");
      //   if (Array.isArray(oData)) {
      //     return { array: oData, basePath: "/" };
      //   }
      //   if (oData && Array.isArray(oData.results)) {
      //     return { array: oData.results, basePath: "/results" };
      //   }
      //   // fallback: find first array property in root object
      //   if (oData && typeof oData === "object") {
      //     for (const k of Object.keys(oData)) {
      //       if (Array.isArray(oData[k])) {
      //         return { array: oData[k], basePath: `/${k}` };
      //       }
      //     }
      //   }
      //   // Nothing found -> return empty array and root path
      //   return { array: [], basePath: "/" };
      // },


      // _formatToModelDateString: function (vDateOrString) {
      //   if (!vDateOrString) {
      //     return "";
      //   }
      //   // If it's already a string in yyyy-MM-dd, quick return
      //   if (typeof vDateOrString === "string") {
      //     // naive check for yyyy-MM-dd
      //     if (/^\d{4}-\d{2}-\d{2}$/.test(vDateOrString)) {
      //       return vDateOrString;
      //     }
      //     // try parsing common formats
      //     const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
      //     const oParsed = oParse.parse(vDateOrString);
      //     if (oParsed) {
      //       const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       return oFmt.format(oParsed);
      //     }
      //     // fallback: try Date constructor
      //     const d = new Date(vDateOrString);
      //     if (!isNaN(d.getTime())) {
      //       const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       return oFmt.format(d);
      //     }
      //     return "";
      //   }
      //   // If Date object
      //   if (vDateOrString instanceof Date && !isNaN(vDateOrString.getTime())) {
      //     const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //     return oFmt.format(vDateOrString);
      //   }
      //   return "";
      // },


      // _isDuplicateCombination: function (oTabModel, sDateString, sBiplValue, sCurrentPath) {
      //   sDateString = sDateString || "";
      //   sBiplValue = (sBiplValue || "").toString().trim();

      //   // find rows array
      //   const oRowsInfo = this._getTabRowsArray(oTabModel);
      //   const aRows = oRowsInfo.array;

      //   // If no rows, can't be duplicate
      //   if (!aRows || aRows.length === 0) {
      //     return false;
      //   }

      //   // Normalize currentPath to compare (remove trailing index part)
      //   // sCurrentPath might be like "/results/3" or "/3" or "/items/5"
      //   const sCurrentRowIndexPath = sCurrentPath; // compare exact path to exclude same row
      //   // Walk rows and compare each's date + bipl. But model entries shape may differ:
      //   for (let i = 0; i < aRows.length; i++) {
      //     const oRow = aRows[i];
      //     // build candidate date and bipl from row
      //     const sRowDate = this._formatToModelDateString(oRow.productionordstartdate);
      //     const sRowBipl = (oRow.bipllotno || "").toString().trim();

      //     // We need to determine the binding path for this array item to skip the same row.
      //     // Candidate row path = basePath + "/" + i
      //     const sCandidatePath = `${oRowsInfo.basePath}/${i}`;

      //     // Skip the current row itself
      //     if (sCandidatePath === sCurrentRowIndexPath) {
      //       continue;
      //     }

      //     if (sRowDate === sDateString && sRowBipl === sBiplValue && sDateString !== "" && sBiplValue !== "") {
      //       return true;
      //     }
      //   }
      //   return false;
      // },



      // onProductionDateChange: function (oEvent) {
      //   const oDatePicker = oEvent.getSource();
      //   const oSelectedDate = oDatePicker.getDateValue();
      //   const oContext = oDatePicker.getBindingContext("TabModel");
      //   const sCurrentPath = oContext ? oContext.getPath() : null;
      //   const oTabModel = this.getView().getModel("TabModel");

      //   // Get current date (without time part for comparison)
      //   const oToday = new Date();
      //   oToday.setHours(0, 0, 0, 0);

      //   // Create copy of selected date without time part
      //   const oSelectedDateNoTime = oSelectedDate ? new Date(oSelectedDate) : null;
      //   if (oSelectedDateNoTime) {
      //     oSelectedDateNoTime.setHours(0, 0, 0, 0);
      //   }

      //   // If date is cleared, allow it and clear model value
      //   if (!oSelectedDate) {
      //     if (sCurrentPath) {
      //       oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //     }
      //     return;
      //   }

      //   // Check if selected date is in the past
      //   if (oSelectedDateNoTime < oToday) {
      //     sap.m.MessageBox.error("Cannot select a past date. Please select today's date or a future date.");
      //     // restore current model value (if any)
      //     const sCurrentValue = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
      //     if (sCurrentValue) {
      //       const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //       const oCurrentDate = oDateFormat.parse(sCurrentValue);
      //       oDatePicker.setDateValue(oCurrentDate);
      //     } else {
      //       oDatePicker.setValue("");
      //     }
      //     return;
      //   }

      //   // Format selected date to model string (yyyy-MM-dd)
      //   const oFmtModel = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
      //   const sSelectedDateStr = this._formatToModelDateString(oSelectedDate);

      //   // Read current bipl value from model for this row (may be empty if user hasn't typed yet)
      //   const sCurrentBipl = sCurrentPath ? (oTabModel.getProperty(sCurrentPath + "/bipllotno") || "").toString().trim() : "";

      //   // Check for duplicate combination (exclude current row)
      //   if (sCurrentPath && this._isDuplicateCombination(oTabModel, sSelectedDateStr, sCurrentBipl, sCurrentPath)) {
      //     // Duplicate found — clear the fields user just added in this row
      //     sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
      //     // Clear model fields for this row (both date and bipl)
      //     oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //     oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //     // Also clear the DatePicker UI (binding update should handle it, but do explicitly)
      //     oDatePicker.setValue("");
      //     return;
      //   }

      //   // No duplicate -> update model explicitly to normalized format (if your binding doesn't already)
      //   if (sCurrentPath) {
      //     // oTabModel.setProperty(sCurrentPath + "/productionordstartdate", sSelectedDateStr);
      //     oTabModel.setProperty(sCurrentPath + "/productionordstartdate", oSelectedDate);

      //   }
      //   // Two-way binding will keep UI in sync
      // },


      // onBiplChange: function (oEvent) {
      //   const oInput = oEvent.getSource();
      //   let sBiplVal = (oInput.getValue() || "").toString().trim();
      //   const oContext = oInput.getBindingContext("TabModel");
      //   const sCurrentPath = oContext ? oContext.getPath() : null;
      //   const oTabModel = this.getView().getModel("TabModel");

      //   // If user cleared value, update model and return
      //   if (!sBiplVal) {
      //     if (sCurrentPath) {
      //       oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //     }
      //     return;
      //   }

      //   // Optionally normalize bipl (uppercase) if needed
      //   sBiplVal = sBiplVal.toUpperCase();
      //   oInput.setValue(sBiplVal);

      //   // Get the date value in this row (may be Date, or yyyy-MM-dd string, or empty)
      //   const vDate = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
      //   const sDateStr = this._formatToModelDateString(vDate);

      //   // If either field missing, can't be duplicate — just set model
      //   if (!sDateStr) {
      //     if (sCurrentPath) {
      //       oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
      //     }
      //     return;
      //   }

      //   // Now check duplicate combination
      //   if (sCurrentPath && this._isDuplicateCombination(oTabModel, sDateStr, sBiplVal, sCurrentPath)) {
      //     sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
      //     // Clear model fields for this row
      //     oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
      //     oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
      //     // Clear UI input value (binding usually handles it)
      //     oInput.setValue("");
      //     // If there is a DatePicker in the same row, its binding will pick up the cleared model value.
      //     return;
      //   }

      //   // No duplicate -> persist bipllotno in model
      //   if (sCurrentPath) {
      //     oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
      //   }
      // },









      _getTabRowsArray: function (oTabModel) {
        const oData = oTabModel.getProperty("/");
        if (Array.isArray(oData)) {
          return { array: oData, basePath: "/" };
        }
        if (oData && Array.isArray(oData.results)) {
          return { array: oData.results, basePath: "/results" };
        }
        // fallback: find first array property in root object
        if (oData && typeof oData === "object") {
          for (const k of Object.keys(oData)) {
            if (Array.isArray(oData[k])) {
              return { array: oData[k], basePath: `/${k}` };
            }
          }
        }
        // Nothing found -> return empty array and root path
        return { array: [], basePath: "/" };
      },

      _formatToModelDateString: function (vDateOrString) {
        if (!vDateOrString) {
          return "";
        }
        // If it's already a string in yyyy-MM-dd, quick return
        if (typeof vDateOrString === "string") {
          // naive check for yyyy-MM-dd
          if (/^\d{4}-\d{2}-\d{2}$/.test(vDateOrString)) {
            return vDateOrString;
          }
          // try parsing common formats
          const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
          const oParsed = oParse.parse(vDateOrString);
          if (oParsed) {
            const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            return oFmt.format(oParsed);
          }
          // fallback: try Date constructor
          const d = new Date(vDateOrString);
          if (!isNaN(d.getTime())) {
            const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            return oFmt.format(d);
          }
          return "";
        }
        // If Date object
        if (vDateOrString instanceof Date && !isNaN(vDateOrString.getTime())) {
          const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
          return oFmt.format(vDateOrString);
        }
        return "";
      },

      // UPDATED: Method to fetch saved records from database with date filter
      _fetchSavedRecords: function (sDateString) {
        return new Promise((resolve, reject) => {
          // Check if we have a date string to filter by
          if (!sDateString || sDateString.trim() === "") {
            resolve([]);
            return;
          }

          // Use the same model as your save operation
          const oModel = this.getView().getModel("ZSB_MOULD_PLAN");
          if (!oModel) {
            console.error("ZSB_MOULD_PLAN model not found");
            resolve([]);
            return;
          }

          // Create filter for the specific date
          const oFilter = new sap.ui.model.Filter("productionordstartdate",
            sap.ui.model.FilterOperator.EQ,
            sDateString
          );

          oModel.read("/ZC_MOULD_PLAN", {
            filters: [oFilter],
            urlParameters: {
              "$select": "productionordstartdate,bipllotno"
            },
            success: (oData) => {
              const aRecords = oData.results || [];
              // Format dates to match yyyy-MM-dd format
              const aFormattedRecords = aRecords.map(record => {
                // Convert the OData date format to string
                let formattedDate = "";
                if (record.productionordstartdate) {
                  // Handle OData date format (could be string or object)
                  if (typeof record.productionordstartdate === 'string') {
                    formattedDate = record.productionordstartdate;
                  } else if (record.productionordstartdate.__edmType === "Edm.DateTime") {
                    // Handle OData DateTime format
                    const dateStr = record.productionordstartdate;
                    if (dateStr) {
                      formattedDate = this._formatToModelDateString(new Date(dateStr));
                    }
                  }
                }

                return {
                  productionordstartdate: formattedDate,
                  bipllotno: (record.bipllotno || "").toString().trim()
                };
              });
              resolve(aFormattedRecords);
            },
            error: (oError) => {
              console.error("Error fetching saved records:", oError);
              // Don't reject, just return empty array to allow user to continue
              resolve([]);
            }
          });
        });
      },

      _isDuplicateCombination: async function (oTabModel, sDateString, sBiplValue, sCurrentPath) {
        sDateString = sDateString || "";
        sBiplValue = (sBiplValue || "").toString().trim();

        // If either field is empty, can't be duplicate
        if (!sDateString || !sBiplValue) {
          return false;
        }

        // Check 1: Current table model (as before)
        const oRowsInfo = this._getTabRowsArray(oTabModel);
        const aRows = oRowsInfo.array;

        // Normalize currentPath to compare (remove trailing index part)
        const sCurrentRowIndexPath = sCurrentPath; // compare exact path to exclude same row

        // Check in current table model
        for (let i = 0; i < aRows.length; i++) {
          const oRow = aRows[i];
          // build candidate date and bipl from row
          const sRowDate = this._formatToModelDateString(oRow.productionordstartdate);
          const sRowBipl = (oRow.bipllotno || "").toString().trim();

          // We need to determine the binding path for this array item to skip the same row.
          // Candidate row path = basePath + "/" + i
          const sCandidatePath = `${oRowsInfo.basePath}/${i}`;

          // Skip the current row itself
          if (sCandidatePath === sCurrentRowIndexPath) {
            continue;
          }

          if (sRowDate === sDateString && sRowBipl === sBiplValue) {
            return true;
          }
        }

        // Check 2: Saved records in database (filtered by date for efficiency)
        try {
          const aSavedRecords = await this._fetchSavedRecords(sDateString);

          // Check against saved records
          for (const oSavedRecord of aSavedRecords) {
            if (oSavedRecord.bipllotno === sBiplValue) {
              return true;
            }
          }
        } catch (error) {
          // If there's an error fetching saved records, log it but continue
          console.error("Error checking saved records for duplicates:", error);
          // Return false to not block user input due to network/backend issues
        }

        return false;
      },

      // UPDATED: onProductionDateChange with async duplicate check
      onProductionDateChange: async function (oEvent) {
        const oDatePicker = oEvent.getSource();
        const oSelectedDate = oDatePicker.getDateValue();
        const oContext = oDatePicker.getBindingContext("TabModel");
        const sCurrentPath = oContext ? oContext.getPath() : null;
        const oTabModel = this.getView().getModel("TabModel");

        // Get current date (without time part for comparison)
        const oToday = new Date();
        oToday.setHours(0, 0, 0, 0);

        // Create copy of selected date without time part
        const oSelectedDateNoTime = oSelectedDate ? new Date(oSelectedDate) : null;
        if (oSelectedDateNoTime) {
          oSelectedDateNoTime.setHours(0, 0, 0, 0);
        }

        // If date is cleared, allow it and clear model value
        if (!oSelectedDate) {
          if (sCurrentPath) {
            oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
          }
          return;
        }

        // Check if selected date is in the past
        if (oSelectedDateNoTime < oToday) {
          sap.m.MessageBox.error("Cannot select a past date. Please select today's date or a future date.");
          // restore current model value (if any)
          const sCurrentValue = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
          if (sCurrentValue) {
            const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            const oCurrentDate = oDateFormat.parse(sCurrentValue);
            oDatePicker.setDateValue(oCurrentDate);
          } else {
            oDatePicker.setValue("");
          }
          return;
        }

        // Format selected date to model string (yyyy-MM-dd)
        const sSelectedDateStr = this._formatToModelDateString(oSelectedDate);

        // Read current bipl value from model for this row (may be empty if user hasn't typed yet)
        const sCurrentBipl = sCurrentPath ? (oTabModel.getProperty(sCurrentPath + "/bipllotno") || "").toString().trim() : "";

        // Check for duplicate combination (exclude current row) - now async
        const bIsDuplicate = await this._isDuplicateCombination(oTabModel, sSelectedDateStr, sCurrentBipl, sCurrentPath);

        if (bIsDuplicate) {
          // Duplicate found — clear the fields user just added in this row
          sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
          // Clear model fields for this row (both date and bipl)
          oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
          oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
          // Also clear the DatePicker UI (binding update should handle it, but do explicitly)
          oDatePicker.setValue("");
          return;
        }

        // No duplicate -> update model explicitly to normalized format (if your binding doesn't already)
        if (sCurrentPath) {
          oTabModel.setProperty(sCurrentPath + "/productionordstartdate", oSelectedDate);
        }
        // Two-way binding will keep UI in sync
      },

      // UPDATED: onBiplChange with async duplicate check
      onBiplChange: async function (oEvent) {
        const oInput = oEvent.getSource();
        let sBiplVal = (oInput.getValue() || "").toString().trim();
        const oContext = oInput.getBindingContext("TabModel");
        const sCurrentPath = oContext ? oContext.getPath() : null;
        const oTabModel = this.getView().getModel("TabModel");

        // If user cleared value, update model and return
        if (!sBiplVal) {
          if (sCurrentPath) {
            oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
          }
          return;
        }

        // Optionally normalize bipl (uppercase) if needed
        sBiplVal = sBiplVal.toUpperCase();
        oInput.setValue(sBiplVal);

        // Get the date value in this row (may be Date, or yyyy-MM-dd string, or empty)
        const vDate = sCurrentPath ? oTabModel.getProperty(sCurrentPath + "/productionordstartdate") : null;
        const sDateStr = this._formatToModelDateString(vDate);

        // If either field missing, can't be duplicate — just set model
        if (!sDateStr) {
          if (sCurrentPath) {
            oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
          }
          return;
        }

        // Now check duplicate combination - now async
        const bIsDuplicate = await this._isDuplicateCombination(oTabModel, sDateStr, sBiplVal, sCurrentPath);

        if (bIsDuplicate) {
          sap.m.MessageBox.error("This Production Start Date and Bipl Lot No combination already exists in the table. The values you entered have been cleared.");
          // Clear model fields for this row
          oTabModel.setProperty(sCurrentPath + "/productionordstartdate", "");
          oTabModel.setProperty(sCurrentPath + "/bipllotno", "");
          // Clear UI input value (binding usually handles it)
          oInput.setValue("");
          // If there is a DatePicker in the same row, its binding will pick up the cleared model value.
          return;
        }

        // No duplicate -> persist bipllotno in model
        if (sCurrentPath) {
          oTabModel.setProperty(sCurrentPath + "/bipllotno", sBiplVal);
        }
      },













      // onImportExl: function () {
      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       // const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });


      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("mouldingplantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));
      //       // const mapped = jsonData.map(row => {
      //       //     const obj = {};
      //       //     headers.forEach((hdr, idx) => {
      //       //         const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //       //         if (field) {
      //       //             const rawValue = row[Object.keys(row)[idx]];
      //       //             obj[field] = rawValue;
      //       //         }
      //       //     });
      //       //     return obj;
      //       // });
      //       const mapped = jsonData.map(row => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // 🔁 Convert Excel serial number to JS Date
      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               const utcValue = utcDays * 86400; // seconds
      //               rawValue = new Date(utcValue * 1000); // convert to ms
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });


      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1"); //ZSB_MATERIALMASTER
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // ✅ 1. Validate Material Codes & Fetch Product Names
      //       const aUniqueMaterials = [...new Set(aSelectedRows.map(r => r.materialcode))];
      //       const aMaterialFilters = new sap.ui.model.Filter({
      //         filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
      //         and: false
      //       });

      //       const oMaterialDataMap = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters: [aMaterialFilters],
      //           success: function (oData) {
      //             const map = {};
      //             oData.results.forEach(entry => {
      //               map[entry.Product] = entry.ProductName;
      //             });
      //             resolve(map);
      //           },
      //           error: reject
      //         });
      //       });

      //       const aValidMaterials = Object.keys(oMaterialDataMap);
      //       const aInvalidMaterials = aUniqueMaterials.filter(mat => !aValidMaterials.includes(mat));
      //       const aInvalidMaterialMessages = aSelectedRows
      //         .map((row, idx) => {
      //           if (aInvalidMaterials.includes(row.materialcode)) {
      //             return `Row ${idx + 1}: Material code "${row.materialcode}" is invalid.`;
      //           }
      //           return null;
      //         })
      //         .filter(Boolean);

      //       if (aInvalidMaterialMessages.length > 0) {
      //         aErrors.push("Invalid Material Code(s):\n\n" + aInvalidMaterialMessages.join("\n"));
      //       }

      //       // ✅ Overwrite Excel descriptions with ProductName
      //       // aSelectedRows.forEach(row => {
      //       //     if (oMaterialDataMap[row.materialcode]) {
      //       //         row.description = oMaterialDataMap[row.materialcode]; // Overwrite
      //       //     }
      //       // });

      //       //2nd best whothpitut date
      //       aSelectedRows.forEach(row => {
      //         const fullProductName = oMaterialDataMap[row.materialcode];
      //         if (fullProductName) {
      //           row.description = fullProductName;

      //           // ✅ Extract before '(' for compoundcode
      //           const parts = fullProductName.split("(");
      //           const productNameOnly = parts[0]?.trim() || fullProductName;
      //           row.compoundcode = productNameOnly;
      //         }
      //       });





      //       // ✅ 2. Validate Machine Combinations
      //       const comboFilters = new sap.ui.model.Filter({
      //         filters: aSelectedRows.map(row =>
      //           new sap.ui.model.Filter({
      //             filters: [
      //               new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //               new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //               new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //             ],
      //             and: true
      //           })
      //         ),
      //         and: false
      //       });

      //       const aValidCombos = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //           filters: [comboFilters],
      //           success: function (oData) {
      //             const keys = oData.results.map(
      //               r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //             );
      //             resolve(keys);
      //           },
      //           error: reject
      //         });
      //       });

      //       const aInvalidRowsCombo = aSelectedRows
      //         .map((row, idx) => {
      //           const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //           if (!aValidCombos.includes(key)) {
      //             return `Row ${idx + 1}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}"`;
      //           }
      //           return null;
      //         })
      //         .filter(Boolean);

      //       if (aInvalidRowsCombo.length > 0) {
      //         aErrors.push("Invalid Production Version Assignments:\n\n" + aInvalidRowsCombo.join("\n"));
      //       }

      //       // ❌ If any errors exist, show them
      //       if (aErrors.length > 0) {
      //         sap.m.MessageBox.error(aErrors.join("\n\n"));
      //         return;
      //       }

      //       // ✅ All validations passed — import data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(mapped);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");
      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }

      //   // Trigger file selection
      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },











      //final export code 



      // onImportExl: function () {
      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       // const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "" });
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });


      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("mouldingplantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));
      //       // const mapped = jsonData.map(row => {
      //       //     const obj = {};
      //       //     headers.forEach((hdr, idx) => {
      //       //         const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //       //         if (field) {
      //       //             const rawValue = row[Object.keys(row)[idx]];
      //       //             obj[field] = rawValue;
      //       //         }
      //       //     });
      //       //     return obj;
      //       // });
      //       const mapped = jsonData.map(row => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // 🔁 Convert Excel serial number to JS Date
      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               const utcValue = utcDays * 86400; // seconds
      //               rawValue = new Date(utcValue * 1000); // convert to ms
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });


      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }


      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //     const oQtyModel = oView.getModel("ZSB_PROD_QTY"); // 🆕 Production Qty model
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // 🧠 STEP 1: Gather all unique material codes and descriptions
      //       const aUniqueMaterials = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.materialcode || "").trim())
      //           .filter(Boolean)
      //       )];

      //       const aUniqueDescriptions = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.description || "").trim())
      //           .filter(Boolean)
      //       )];

      //       if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
      //         sap.m.MessageBox.error("No material data found in the Excel file.");
      //         return;
      //       }

      //       // 🧠 STEP 2: Build filters for both code and description
      //       const filters = [];
      //       if (aUniqueMaterials.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
      //           and: false
      //         }));
      //       }
      //       if (aUniqueDescriptions.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
      //           and: false
      //         }));
      //       }

      //       // 🧠 STEP 3: Fetch material master data
      //       const oMaterialResults = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters,
      //           success: data => resolve(data.results || []),
      //           error: reject
      //         });
      //       });

      //       // Build lookup maps
      //       const codeToName = {};
      //       const nameToCode = {};
      //       oMaterialResults.forEach(entry => {
      //         const code = String(entry.Product).trim();
      //         const name = String(entry.ProductName).trim();
      //         codeToName[code] = name;
      //         nameToCode[name] = code;
      //       });

      //       // 🧠 STEP 4: Validate & enrich each row
      //       aSelectedRows.forEach((row, idx) => {
      //         const code = String(row.materialcode || "").trim();
      //         const desc = String(row.description || "").trim();

      //         if (!code && !desc) {
      //           aErrors.push(`Row ${idx + 1}: Material code and description both missing.`);
      //           return;
      //         }

      //         if (code && !desc) {
      //           if (codeToName[code]) {
      //             row.description = codeToName[code];
      //           } else {
      //             aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
      //           }
      //         } else if (!code && desc) {
      //           if (nameToCode[desc]) {
      //             row.materialcode = nameToCode[desc];
      //           } else {
      //             aErrors.push(`Row ${idx + 1}: Description "${desc}" not found in material master.`);
      //           }
      //         } else if (code && desc) {
      //           const validDesc = codeToName[code];
      //           if (!validDesc) {
      //             aErrors.push(`Row ${idx + 1}: Invalid material code "${code}".`);
      //           } else if (validDesc !== desc) {
      //             aErrors.push(
      //               `Row ${idx + 1}: Description "${desc}" does not match material "${code}" (expected "${validDesc}").`
      //             );
      //           }
      //         }

      //         const finalDesc = String(row.description || "").trim();
      //         if (finalDesc) {
      //           const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //           row.compoundcode = base;
      //         }
      //       });

      //       // 🧠 STEP 5: Validate Machine Combinations
      //       const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //       if (rowsWithMachine.length > 0) {
      //         const comboFilters = new sap.ui.model.Filter({
      //           filters: rowsWithMachine.map(row =>
      //             new sap.ui.model.Filter({
      //               filters: [
      //                 new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //                 new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //                 new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //               ],
      //               and: true
      //             })
      //           ),
      //           and: false
      //         });

      //         const validCombos = await new Promise((resolve, reject) => {
      //           oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //             filters: [comboFilters],
      //             success: data => resolve(
      //               (data.results || []).map(
      //                 r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //               )
      //             ),
      //             error: reject
      //           });
      //         });

      //         const invalidCombos = rowsWithMachine
      //           .map((row, idx) => {
      //             const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //             if (!validCombos.includes(key)) {
      //               const trueIdx = aSelectedRows.indexOf(row);
      //               return `Row ${trueIdx + 1}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
      //             }
      //             return null;
      //           })
      //           .filter(Boolean);

      //         if (invalidCombos.length > 0) {
      //           aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
      //         }
      //       }

      //       // 🧠 STEP 6: Fetch Production Quantity for each unique material individually and set 0.000 if not found

      //       // Prepare unique valid materials for production qty fetching
      //       const aUniqueValidMaterials = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.materialcode || "").trim())
      //           .filter(Boolean)
      //       )];
      //       const aProdQtyPromises = aUniqueValidMaterials.map(mat =>
      //         new Promise((resolve, reject) => {
      //           oQtyModel.read("/ZC_PROD_QTY", {
      //             filters: [new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, mat)],
      //             success: function (oData) {
      //               resolve({
      //                 material: mat,
      //                 qty: oData.results?.[0]?.Qty || "0.000",
      //                 baseunit: oData.results?.[0]?.BaseUnit || ""
      //               });
      //             },
      //             error: function (err) {
      //               console.error("Production order qty fetch failed for", mat, err);
      //               resolve({ material: mat, qty: "0.000", baseunit: "" });
      //             }
      //           });
      //         })
      //       );

      //       const aProdQtyResults = await Promise.all(aProdQtyPromises);

      //       const qtyMap = {};
      //       aProdQtyResults.forEach(entry => {
      //         qtyMap[entry.material] = {
      //           Qty: entry.qty,
      //           BaseUnit: entry.baseunit
      //         };
      //       });

      //       // Assign qty and base unit to each row
      //       aSelectedRows.forEach(row => {
      //         const mat = String(row.materialcode || "").trim();
      //         if (mat && qtyMap[mat]) {
      //           row.productionorderqty = qtyMap[mat].Qty;
      //           row.baseunit = qtyMap[mat].BaseUnit;
      //         } else {
      //           // If material not found in qtyMap, set productionorderqty to 0.000 anyway
      //           row.productionorderqty = "0.000";
      //           row.baseunit = "";
      //         }
      //       });


      //       // 🚫 STEP 7: Show all accumulated errors together
      //       if (aErrors.length > 0) {
      //         sap.m.MessageBox.error(aErrors.join("\n\n"));
      //         return;
      //       }

      //       // ✅ STEP 8: Import Validated & Enriched Data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(aSelectedRows);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");

      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }





      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },


      // // onExportExl: function () {
      // //   const oModel = this.getView().getModel("TabModel");
      // //   const aData = oModel.getProperty("/Samples");

      // //   const aColumns = [
      // //     { label: "Plant", property: "plant" },
      // //     { label: "Bipl lot no", property: "bipllotno" },
      // //     { label: "Shift", property: "shift" },
      // //     { label: "Material Code", property: "materialcode" },
      // //     { label: "Description", property: "description" },
      // //     { label: "Machine Number", property: "machinenumber" },
      // //     { label: "Production Order Qty", property: "productionorderqty" },
      // //     { label: "productionordstartdate", property: "productionordstartdate" },
      // //     { label: "Lot/Batch-No", property: "lotbatchno" },
      // //     { label: "Production Order No", property: "productionorderno" },
      // //     // { label: "Compound Code", property: "compoundcode" },
      // //     { label: "Storage Location", property: "storagelocation" },
      // //     // { label: "Manufacturing Date", property: "manufacturingdate" },
      // //     // { label: "Expiry Date", property: "expirydate" },
      // //     // { label: "Batch Weight", property: "batchweight" },
      // //     // { label: "operator", property: "operator" },
      // //     // { label: "inspector", property: "inspector" },
      // //   ];

      // //   // If no data, still export empty row just to include headers
      // //   const aSafeData = Array.isArray(aData) && aData.length > 0 ? aData : [{}];

      // //   const oSpreadsheet = new sap.ui.export.Spreadsheet({
      // //     workbook: {
      // //       columns: aColumns,
      // //       context: {
      // //         sheetName: "Moulding Plan"
      // //       }
      // //     },
      // //     dataSource: aSafeData,
      // //     fileName: "Moulding_Plan_Export.xlsx"
      // //   });

      // //   oSpreadsheet.build().then(() => {
      // //     sap.m.MessageToast.show("Export completed.");
      // //   }).catch(function (oError) {
      // //     sap.m.MessageBox.error("Export failed: " + oError.message);
      // //   });
      // // },



      // onExportExl: function () {
      //   const oModel = this.getView().getModel("TabModel");
      //   const aData = oModel.getProperty("/Samples") || [];

      //   // 🔹 Format function for dd-MM-yyyy
      //   const fnFormatDate = (date) => {
      //     if (!date) return "";
      //     const oDate = new Date(date);
      //     const day = String(oDate.getDate()).padStart(2, '0');
      //     const month = String(oDate.getMonth() + 1).padStart(2, '0');
      //     const year = oDate.getFullYear();
      //     return `${day}-${month}-${year}`;
      //   };

      //   // 🔹 Clone + format dates before export
      //   const aExportData = aData.length > 0
      //     ? aData.map(item => ({
      //       ...item,
      //       productionordstartdate: fnFormatDate(item.productionordstartdate),
      //       manufacturingdate: fnFormatDate(item.manufacturingdate),
      //       expirydate: fnFormatDate(item.expirydate)
      //     }))
      //     : [{}]; // pass a dummy row to avoid the "unknown number of rows" warning

      //   // 🔹 Define columns
      //   const aColumns = [
      //     { label: "Plant", property: "plant" },
      //     { label: "Bipl lot no", property: "bipllotno" },
      //     { label: "Shift", property: "shift" },
      //     { label: "Material Code", property: "materialcode" },
      //     { label: "Description", property: "description" },
      //     { label: "Machine Number", property: "machinenumber" },
      //     { label: "Production Order Qty", property: "productionorderqty" },
      //     { label: "Production Ord Start Date", property: "productionordstartdate" },
      //     { label: "Lot/Batch-No", property: "lotbatchno" },
      //     { label: "Production Order No", property: "productionorderno" },
      //     { label: "Storage Location", property: "storagelocation" },
      //   ];

      //   // 🔹 Create spreadsheet
      //   const oSpreadsheet = new sap.ui.export.Spreadsheet({
      //     workbook: {
      //       columns: aColumns,
      //       context: { sheetName: "Moulding Plan" }
      //     },
      //     dataSource: aExportData,
      //     fileName: "Moulding_Plan_Export.xlsx"
      //   });

      //   oSpreadsheet.build()
      //     .then(() => {
      //       sap.m.MessageToast.show("Export completed.");
      //     })
      //     .catch((oError) => {
      //       sap.m.MessageBox.error("Export failed: " + oError.message);
      //     });
      // },





      // onImportExl: function () {

      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("mouldingplantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h =>
      //         h.trim().toLowerCase().replace(/\s+/g, "")
      //       );

      //       const allErrors = [];
      //       const mapped = jsonData.map((row, rowIndex) => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               rawValue = new Date(utcDays * 86400 * 1000);
      //             } else if (field.toLowerCase().includes("date") && typeof rawValue === "string") {
      //               const parts = rawValue.split("-");
      //               if (parts.length === 3) {
      //                 const [dd, mm, yyyy] = parts.map(p => parseInt(p, 10));
      //                 if (!isNaN(dd) && !isNaN(mm) && !isNaN(yyyy)) {
      //                   rawValue = new Date(yyyy, mm - 1, dd);
      //                 }
      //               }
      //             } else if (field === "shift") {
      //               if (!rawValue) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                 return;
      //               }
      //               const value = String(rawValue).trim().toUpperCase();
      //               if (!["A", "B", "C"].includes(value) || value.length !== 1) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}"`);
      //                 return;
      //               }
      //               rawValue = value;
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });

      //       if (allErrors.length > 0) {
      //         sap.m.MessageBox.error("Excel Import Errors:\n\n" + allErrors.join("\n"));
      //         return;
      //       }

      //       validateAndImport(mapped);
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       const aUniqueMaterials = [...new Set(
      //         aSelectedRows.map(r => String(r.materialcode || "").trim()).filter(Boolean)
      //       )];

      //       const aUniqueDescriptions = [...new Set(
      //         aSelectedRows.map(r => String(r.description || "").trim()).filter(Boolean)
      //       )];

      //       const filters = [];
      //       if (aUniqueMaterials.length) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueMaterials.map(mat =>
      //             new sap.ui.model.Filter("Product", "EQ", mat)),
      //           and: false
      //         }));
      //       }
      //       if (aUniqueDescriptions.length) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueDescriptions.map(desc =>
      //             new sap.ui.model.Filter("ProductName", "EQ", desc)),
      //           and: false
      //         }));
      //       }

      //       const oMaterialResults = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters,
      //           success: data => resolve(data.results || []),
      //           error: reject
      //         });
      //       });

      //       const codeMap = {};
      //       const nameMap = {};

      //       oMaterialResults.forEach(entry => {
      //         const code = String(entry.Product).trim();
      //         const name = String(entry.ProductName).trim();
      //         const extGrp = String(entry.ExternalProductGroup || "").trim();
      //         codeMap[code] = { Product: code, ProductName: name, ExternalProductGroup: extGrp };
      //         nameMap[name] = { Product: code, ProductName: name, ExternalProductGroup: extGrp };
      //       });

      //       aSelectedRows.forEach((row, idx) => {
      //         const rowNumber = idx + 2;
      //         if (!row.plant) row.plant = "1200";

      //         const material = codeMap[row.materialcode];
      //         if (!material || material.ExternalProductGroup !== "MOULDING") {
      //           aErrors.push(`Row ${rowNumber}: Invalid or non-MOULDING material.`);
      //         }

      //         if (!row.shift) {
      //           aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //         }

      //         if (row.description) {
      //           row.compoundcode = row.description.split("(")[0].trim();
      //         }
      //       });

      //       if (aErrors.length) {
      //         sap.m.MessageBox.error("Validation Errors:\n\n" + aErrors.join("\n"));
      //         return;
      //       }

      //       // ✅ FINAL STEP: Import data as-is (no production qty fetching)
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       oModel.setProperty("/Samples", existingData.concat(aSelectedRows));

      //       sap.m.MessageToast.show("Data imported successfully.");

      //     } catch (err) {
      //       console.error(err);
      //       sap.m.MessageBox.error("Validation failed.");
      //     }
      //   }

      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", e => {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },










      // onImportExl: function () {

      //   const that = this;

      //   function ensureXLSX(cb) {
      //     if (window.XLSX) return cb();

      //     const script = document.createElement("script");
      //     script.src = importexcelfile;
      //     script.onload = cb;
      //     script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
      //     document.head.appendChild(script);
      //   }

      //   function doImport(file) {
      //     const reader = new FileReader();
      //     reader.onload = function (e) {
      //       const data = e.target.result;
      //       const workbook = XLSX.read(data, { type: "binary" });
      //       const sheet = workbook.Sheets[workbook.SheetNames[0]];
      //       const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

      //       if (!jsonData.length) {
      //         sap.m.MessageToast.show("No data found in the Excel sheet.");
      //         return;
      //       }

      //       const table = that.byId("mouldingplantabl");
      //       const columns = table.getColumns();
      //       const fieldNames = columns.map(col => {
      //         const template = col.getTemplate();
      //         const bindInfo =
      //           template.getBindingInfo("value") ||
      //           template.getBindingInfo("text") ||
      //           template.getBindingInfo("selected") ||
      //           template.getBindingInfo("selectedKey");
      //         return bindInfo?.parts?.[0]?.path || null;
      //       }).filter(Boolean);

      //       const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

      //       // 🚨 Collect all errors during mapping
      //       const allErrors = [];
      //       const mapped = jsonData.map((row, rowIndex) => {
      //         const obj = {};
      //         headers.forEach((hdr, idx) => {
      //           const field = fieldNames.find(f => f.toLowerCase() === hdr);
      //           if (field) {
      //             let rawValue = row[Object.keys(row)[idx]];

      //             // 🔹 Handle Excel numeric serial date
      //             if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
      //               const utcDays = Math.floor(rawValue - 25569);
      //               const utcValue = utcDays * 86400; // seconds
      //               rawValue = new Date(utcValue * 1000); // convert to JS Date
      //             }

      //             // 🔹 Handle Excel text date in dd-MM-yyyy format
      //             else if (field.toLowerCase().includes("date") && typeof rawValue === "string") {
      //               const parts = rawValue.split("-");
      //               if (parts.length === 3) {
      //                 const [dd, mm, yyyy] = parts.map(p => parseInt(p, 10));
      //                 if (!isNaN(dd) && !isNaN(mm) && !isNaN(yyyy)) {
      //                   rawValue = new Date(yyyy, mm - 1, dd);
      //                 }
      //               }
      //             }
      //             // 🔹 Handle shift field - only 1 character & only A, B, or C
      //             else if (field === "shift") {
      //               // If shift is missing
      //               if (rawValue === null || rawValue === undefined || rawValue === "") {
      //                 allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               let value = String(rawValue).trim().toUpperCase();

      //               // If more than one character → invalid
      //               if (value.length !== 1) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               // Only allow A, B, C
      //               if (!["A", "B", "C"].includes(value)) {
      //                 allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
      //                 rawValue = ""; // Keep as empty for now
      //                 return; // Don't process further for this field
      //               }

      //               rawValue = value; // Assign cleaned value
      //             }

      //             obj[field] = rawValue;
      //           }
      //         });
      //         return obj;
      //       });

      //       // 🚨 Check if we have any errors during mapping
      //       if (allErrors.length > 0) {
      //         // Show all mapping errors at once
      //         const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       validateAndImport(mapped);
      //     };

      //     reader.onerror = function () {
      //       sap.m.MessageToast.show("Error reading Excel file.");
      //     };

      //     reader.readAsBinaryString(file);
      //   }

      //   async function validateAndImport(mapped) {
      //     const oView = that.getView();
      //     const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
      //     const aSelectedRows = mapped;

      //     try {
      //       const aErrors = [];

      //       // 🧠 STEP 1: Gather all unique material codes and descriptions
      //       const aUniqueMaterials = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.materialcode || "").trim())
      //           .filter(Boolean)
      //       )];

      //       const aUniqueDescriptions = [...new Set(
      //         aSelectedRows
      //           .map(r => String(r.description || "").trim())
      //           .filter(Boolean)
      //       )];

      //       if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
      //         sap.m.MessageBox.error("No material data found in the Excel file.");
      //         return;
      //       }

      //       // 🧠 STEP 2: Build filters for both code and description
      //       const filters = [];
      //       if (aUniqueMaterials.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
      //           and: false
      //         }));
      //       }
      //       if (aUniqueDescriptions.length > 0) {
      //         filters.push(new sap.ui.model.Filter({
      //           filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
      //           and: false
      //         }));
      //       }

      //       // 🧠 STEP 3: Fetch material master data
      //       const oMaterialResults = await new Promise((resolve, reject) => {
      //         oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
      //           filters,
      //           success: data => resolve(data.results || []),
      //           error: reject
      //         });
      //       });

      //       // 🆕 Build lookup maps with ExternalProductGroup information
      //       const codeMap = {}; // Key: Product
      //       const nameMap = {}; // Key: ProductName

      //       oMaterialResults.forEach(entry => {
      //         const code = String(entry.Product).trim();
      //         const name = String(entry.ProductName).trim();
      //         const extProdGroup = String(entry.ExternalProductGroup || "").trim();

      //         codeMap[code] = {
      //           Product: code,
      //           ProductName: name,
      //           ExternalProductGroup: extProdGroup
      //         };

      //         nameMap[name] = {
      //           Product: code,
      //           ProductName: name,
      //           ExternalProductGroup: extProdGroup
      //         };
      //       });

      //       // 🧠 STEP 4: Validate & enrich each row
      //       aSelectedRows.forEach((row, idx) => {
      //         const code = String(row.materialcode || "").trim();
      //         const desc = String(row.description || "").trim();
      //         const rowNumber = idx + 2; // Excel row numbers (header is row 1)

      //         // 🆕 Set default plant to 1200 if not entered by user
      //         if (!row.plant || String(row.plant || "").trim() === "") {
      //           row.plant = "1200";
      //         }

      //         if (!code && !desc) {
      //           aErrors.push(`Row ${rowNumber}: Material code and description both missing.`);
      //           return;
      //         }

      //         if (code && !desc) {
      //           // Only code provided
      //           const material = codeMap[code];
      //           if (material) {
      //             // 🆕 Check if it's a MOULDING material
      //             if (material.ExternalProductGroup !== "MOULDING") {
      //               aErrors.push(`Row ${rowNumber}: Material "${code}" is not a MOULDING material.`);
      //             } else {
      //               row.description = material.ProductName;
      //             }
      //           } else {
      //             aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
      //           }
      //         } else if (!code && desc) {
      //           // Only description provided
      //           const material = nameMap[desc];
      //           if (material) {
      //             // 🆕 Check if it's a MOULDING material
      //             if (material.ExternalProductGroup !== "MOULDING") {
      //               aErrors.push(`Row ${rowNumber}: Material "${desc}" is not a MOULDING material.`);
      //             } else {
      //               row.materialcode = material.Product;
      //             }
      //           } else {
      //             aErrors.push(`Row ${rowNumber}: Description "${desc}" not found in material master.`);
      //           }
      //         } else if (code && desc) {
      //           // Both code and description provided
      //           const material = codeMap[code];
      //           if (!material) {
      //             aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
      //           } else if (material.ProductName !== desc) {
      //             aErrors.push(
      //               `Row ${rowNumber}: Description "${desc}" does not match material "${code}" (expected "${material.ProductName}").`
      //             );
      //           } else if (material.ExternalProductGroup !== "MOULDING") {
      //             // 🆕 Check if it's a MOULDING material
      //             aErrors.push(`Row ${rowNumber}: Material "${code}" ("${desc}") is not a MOULDING material.`);
      //           }
      //         }

      //         // 🚨 Validate shift field again during validation phase
      //         if (row.shift) {
      //           const shiftValue = String(row.shift).trim().toUpperCase();
      //           if (!["A", "B", "C"].includes(shiftValue)) {
      //             aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: A, B, C`);
      //           } else if (shiftValue.length !== 1) {
      //             aErrors.push(`Row ${rowNumber}: Shift value must be exactly 1 character.`);
      //           }
      //         } else {
      //           aErrors.push(`Row ${rowNumber}: Shift is missing.`);
      //         }

      //         const finalDesc = String(row.description || "").trim();
      //         if (finalDesc) {
      //           const base = finalDesc.split("(")[0]?.trim() || finalDesc;
      //           row.compoundcode = base;
      //         }

      //         // 🆕 Set default values if productionorderqty or baseunit are missing
      //         if (!row.productionorderqty || String(row.productionorderqty || "").trim() === "") {
      //           row.productionorderqty = "0.000";
      //         }
      //         if (!row.baseunit || String(row.baseunit || "").trim() === "") {
      //           row.baseunit = "";
      //         }
      //       });

      //       // 🧠 STEP 5: Validate Machine Combinations
      //       const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

      //       if (rowsWithMachine.length > 0) {
      //         const comboFilters = new sap.ui.model.Filter({
      //           filters: rowsWithMachine.map(row =>
      //             new sap.ui.model.Filter({
      //               filters: [
      //                 new sap.ui.model.Filter("Plant", "EQ", row.plant),
      //                 new sap.ui.model.Filter("Material", "EQ", row.materialcode),
      //                 new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
      //               ],
      //               and: true
      //             })
      //           ),
      //           and: false
      //         });

      //         const validCombos = await new Promise((resolve, reject) => {
      //           oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
      //             filters: [comboFilters],
      //             success: data => resolve(
      //               (data.results || []).map(
      //                 r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
      //               )
      //             ),
      //             error: reject
      //           });
      //         });

      //         const invalidCombos = rowsWithMachine
      //           .map((row, idx) => {
      //             const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
      //             if (!validCombos.includes(key)) {
      //               const trueIdx = aSelectedRows.indexOf(row);
      //               return `Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
      //             }
      //             return null;
      //           })
      //           .filter(Boolean);

      //         if (invalidCombos.length > 0) {
      //           aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
      //         }
      //       }

      //       // 🚫 STEP 6: Show all accumulated errors together
      //       if (aErrors.length > 0) {
      //         const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
      //         sap.m.MessageBox.error(errorMessage);
      //         return;
      //       }

      //       // ✅ STEP 7: Import Validated & Enriched Data
      //       const oModel = oView.getModel("TabModel");
      //       const existingData = oModel.getProperty("/Samples") || [];
      //       const updatedData = existingData.concat(aSelectedRows);
      //       oModel.setProperty("/Samples", updatedData);

      //       sap.m.MessageToast.show("Data imported and validated successfully.");

      //     } catch (error) {
      //       console.error("Validation error:", error);
      //       sap.m.MessageBox.error("Validation failed. Please try again.");
      //     }
      //   }

      //   const fileInput = document.createElement("input");
      //   fileInput.type = "file";
      //   fileInput.accept = ".xlsx,.xls";
      //   fileInput.style.display = "none";

      //   fileInput.addEventListener("change", function (e) {
      //     const file = e.target.files[0];
      //     if (!file) return;
      //     ensureXLSX(() => doImport(file));
      //     document.body.removeChild(fileInput);
      //   });

      //   document.body.appendChild(fileInput);
      //   fileInput.click();
      // },





      onImportExl: function () {
        const that = this;

        function ensureXLSX(cb) {
          if (window.XLSX) return cb();

          const script = document.createElement("script");
          script.src = importexcelfile;
          script.onload = cb;
          script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
          document.head.appendChild(script);
        }

        function doImport(file) {
          const reader = new FileReader();
          reader.onload = function (e) {
            const data = e.target.result;
            const workbook = XLSX.read(data, { type: "binary" });
            const sheet = workbook.Sheets[workbook.SheetNames[0]];
            const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

            if (!jsonData.length) {
              sap.m.MessageToast.show("No data found in the Excel sheet.");
              return;
            }

            const table = that.byId("mouldingplantabl");
            const columns = table.getColumns();
            const fieldNames = columns.map(col => {
              const template = col.getTemplate();
              const bindInfo =
                template.getBindingInfo("value") ||
                template.getBindingInfo("text") ||
                template.getBindingInfo("selected") ||
                template.getBindingInfo("selectedKey");
              return bindInfo?.parts?.[0]?.path || null;
            }).filter(Boolean);

            const headers = Object.keys(jsonData[0]).map(h => h.trim().toLowerCase().replace(/\s+/g, ""));

            // 🚨 Collect all errors during mapping
            const allErrors = [];
            const mapped = jsonData.map((row, rowIndex) => {
              const obj = {};
              headers.forEach((hdr, idx) => {
                const field = fieldNames.find(f => f.toLowerCase() === hdr);
                if (field) {
                  let rawValue = row[Object.keys(row)[idx]];

                  // 🔹 Handle Excel numeric serial date for productionordstartdate
                  if (field === "productionordstartdate") {
                    // Excel already gives Date object when cellDates:true
                    if (rawValue instanceof Date && !isNaN(rawValue.getTime())) {
                      rawValue = rawValue;
                    }
                    // Excel numeric date
                    else if (typeof rawValue === "number") {
                      rawValue = new Date(Math.round((rawValue - 25569) * 86400 * 1000));
                    }
                    // Excel text date
                    else if (typeof rawValue === "string" && rawValue) {
                      const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
                      const oParsed = oParse.parse(rawValue);
                      rawValue = oParsed || null;
                    }
                  }
                  // 🔹 Handle other date fields
                  else if (field.toLowerCase().includes("date") && typeof rawValue === "number") {
                    const utcDays = Math.floor(rawValue - 25569);
                    const utcValue = utcDays * 86400; // seconds
                    rawValue = new Date(utcValue * 1000); // convert to JS Date
                  }
                  // 🔹 Handle Excel text date in dd-MM-yyyy format for other date fields
                  else if (field.toLowerCase().includes("date") && typeof rawValue === "string") {
                    const parts = rawValue.split("-");
                    if (parts.length === 3) {
                      const [dd, mm, yyyy] = parts.map(p => parseInt(p, 10));
                      if (!isNaN(dd) && !isNaN(mm) && !isNaN(yyyy)) {
                        rawValue = new Date(yyyy, mm - 1, dd);
                      }
                    }
                  }
                  // 🔹 Handle shift field - only 1 character & only A, B, or C
                  else if (field === "shift") {
                    // If shift is missing
                    if (rawValue === null || rawValue === undefined || rawValue === "") {
                      allErrors.push(`Row ${rowIndex + 2}: Shift is missing`);
                      rawValue = ""; // Keep as empty for now
                      return; // Don't process further for this field
                    }

                    let value = String(rawValue).trim().toUpperCase();

                    // If more than one character → invalid
                    if (value.length !== 1) {
                      allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
                      rawValue = ""; // Keep as empty for now
                      return; // Don't process further for this field
                    }

                    // Only allow A, B, C
                    if (!["A", "B", "C"].includes(value)) {
                      allErrors.push(`Row ${rowIndex + 2}: Invalid Shift value "${value}". Allowed: A, B, C`);
                      rawValue = ""; // Keep as empty for now
                      return; // Don't process further for this field
                    }

                    rawValue = value; // Assign cleaned value
                  }

                  obj[field] = rawValue;
                }
              });
              return obj;
            });

            // 🚨 Check if we have any errors during mapping
            if (allErrors.length > 0) {
              // Show all mapping errors at once
              const errorMessage = "Excel Import Errors:\n\n" + allErrors.join("\n");
              sap.m.MessageBox.error(errorMessage);
              return;
            }

            validateAndImport(mapped);
          };

          reader.onerror = function () {
            sap.m.MessageToast.show("Error reading Excel file.");
          };

          reader.readAsBinaryString(file);
        }

        async function validateAndImport(mapped) {
          const oView = that.getView();
          const oMaterialMasterModel = oView.getModel("ZSB_MATERIALMASTER1");
          const aSelectedRows = mapped;

          try {
            const aErrors = [];

            // 🆕 STEP 1: Check for duplicate Production Start Date + Bipl Lot No combinations within Excel file itself
            const excelCombinationMap = new Map();
            aSelectedRows.forEach((row, idx) => {
              const rowNumber = idx + 2; // Excel row numbers (header is row 1)

              // Format the date from Excel
              let dateValue = row.productionordstartdate;
              let dateString = "";

              if (dateValue) {
                if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
                  const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                  dateString = oFmt.format(dateValue);
                } else if (typeof dateValue === "string") {
                  // Try to parse the string date
                  const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
                  const oParsed = oParse.parse(dateValue);
                  if (oParsed) {
                    const oFmt = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    dateString = oFmt.format(oParsed);
                  }
                }
              }

              const biplValue = (row.bipllotno || "").toString().trim();

              // Only check if both values are present
              if (dateString && biplValue) {
                const combinationKey = `${dateString}|${biplValue}`;

                if (excelCombinationMap.has(combinationKey)) {
                  const firstRow = excelCombinationMap.get(combinationKey);
                  aErrors.push(`Row ${rowNumber}: Duplicate combination of Production Start Date (${dateString}) and Bipl Lot No (${biplValue}). First occurrence at row ${firstRow}.`);
                } else {
                  excelCombinationMap.set(combinationKey, rowNumber);
                }
              }
            });

            // 🆕 STEP 2: Check for past dates in imported data
            const oToday = new Date();
            oToday.setHours(0, 0, 0, 0);

            aSelectedRows.forEach((row, idx) => {
              const rowNumber = idx + 2; // Excel row numbers
              let dateValue = row.productionordstartdate;

              if (dateValue) {
                let selectedDate = null;

                // Handle different date formats
                if (dateValue instanceof Date && !isNaN(dateValue.getTime())) {
                  selectedDate = new Date(dateValue);
                  selectedDate.setHours(0, 0, 0, 0);
                } else if (typeof dateValue === "string") {
                  // Try to parse the string date
                  const oParse = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "dd-MM-yyyy" });
                  const oParsed = oParse.parse(dateValue);
                  if (oParsed) {
                    selectedDate = new Date(oParsed);
                    selectedDate.setHours(0, 0, 0, 0);
                  }
                }

                // Check if date is in the past
                if (selectedDate && selectedDate < oToday) {
                  const formattedDate = that._formatToModelDateString(selectedDate);
                  aErrors.push(`Row ${rowNumber}: Cannot select a past date (${formattedDate}). Please select today's date or a future date.`);
                }
              }
            });

            // 🧠 STEP 3: Gather all unique material codes and descriptions
            const aUniqueMaterials = [...new Set(
              aSelectedRows
                .map(r => String(r.materialcode || "").trim())
                .filter(Boolean)
            )];

            const aUniqueDescriptions = [...new Set(
              aSelectedRows
                .map(r => String(r.description || "").trim())
                .filter(Boolean)
            )];

            if (aUniqueMaterials.length === 0 && aUniqueDescriptions.length === 0) {
              sap.m.MessageBox.error("No material data found in the Excel file.");
              return;
            }

            // 🧠 STEP 4: Build filters for both code and description
            const filters = [];
            if (aUniqueMaterials.length > 0) {
              filters.push(new sap.ui.model.Filter({
                filters: aUniqueMaterials.map(mat => new sap.ui.model.Filter("Product", "EQ", mat)),
                and: false
              }));
            }
            if (aUniqueDescriptions.length > 0) {
              filters.push(new sap.ui.model.Filter({
                filters: aUniqueDescriptions.map(desc => new sap.ui.model.Filter("ProductName", "EQ", desc)),
                and: false
              }));
            }

            // 🧠 STEP 5: Fetch material master data
            const oMaterialResults = await new Promise((resolve, reject) => {
              oMaterialMasterModel.read("/ZC_MATERIALMASTER1", {
                filters,
                success: data => resolve(data.results || []),
                error: reject
              });
            });

            // 🆕 Build lookup maps with ExternalProductGroup information
            const codeMap = {}; // Key: Product
            const nameMap = {}; // Key: ProductName

            oMaterialResults.forEach(entry => {
              const code = String(entry.Product).trim();
              const name = String(entry.ProductName).trim();
              const extProdGroup = String(entry.ExternalProductGroup || "").trim();

              codeMap[code] = {
                Product: code,
                ProductName: name,
                ExternalProductGroup: extProdGroup
              };

              nameMap[name] = {
                Product: code,
                ProductName: name,
                ExternalProductGroup: extProdGroup
              };
            });

            // 🧠 STEP 6: Validate & enrich each row
            aSelectedRows.forEach((row, idx) => {
              const code = String(row.materialcode || "").trim();
              const desc = String(row.description || "").trim();
              const rowNumber = idx + 2; // Excel row numbers (header is row 1)

              // 🆕 Set default plant to 1200 if not entered by user
              if (!row.plant || String(row.plant || "").trim() === "") {
                row.plant = "1200";
              }

              if (!code && !desc) {
                aErrors.push(`Row ${rowNumber}: Material code and description both missing.`);
                return;
              }

              if (code && !desc) {
                // Only code provided
                const material = codeMap[code];
                if (material) {
                  // 🆕 Check if it's a MOULDING material
                  if (material.ExternalProductGroup !== "MOULDING") {
                    aErrors.push(`Row ${rowNumber}: Material "${code}" is not a MOULDING material.`);
                  } else {
                    row.description = material.ProductName;
                  }
                } else {
                  aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
                }
              } else if (!code && desc) {
                // Only description provided
                const material = nameMap[desc];
                if (material) {
                  // 🆕 Check if it's a MOULDING material
                  if (material.ExternalProductGroup !== "MOULDING") {
                    aErrors.push(`Row ${rowNumber}: Material "${desc}" is not a MOULDING material.`);
                  } else {
                    row.materialcode = material.Product;
                  }
                } else {
                  aErrors.push(`Row ${rowNumber}: Description "${desc}" not found in material master.`);
                }
              } else if (code && desc) {
                // Both code and description provided
                const material = codeMap[code];
                if (!material) {
                  aErrors.push(`Row ${rowNumber}: Invalid material code "${code}".`);
                } else if (material.ProductName !== desc) {
                  aErrors.push(
                    `Row ${rowNumber}: Description "${desc}" does not match material "${code}" (expected "${material.ProductName}").`
                  );
                } else if (material.ExternalProductGroup !== "MOULDING") {
                  // 🆕 Check if it's a MOULDING material
                  aErrors.push(`Row ${rowNumber}: Material "${code}" ("${desc}") is not a MOULDING material.`);
                }
              }

              // 🚨 Validate shift field again during validation phase
              if (row.shift) {
                const shiftValue = String(row.shift).trim().toUpperCase();
                if (!["A", "B", "C"].includes(shiftValue)) {
                  aErrors.push(`Row ${rowNumber}: Invalid Shift value "${shiftValue}". Allowed: A, B, C`);
                } else if (shiftValue.length !== 1) {
                  aErrors.push(`Row ${rowNumber}: Shift value must be exactly 1 character.`);
                }
              } else {
                aErrors.push(`Row ${rowNumber}: Shift is missing.`);
              }

              const finalDesc = String(row.description || "").trim();
              if (finalDesc) {
                const base = finalDesc.split("(")[0]?.trim() || finalDesc;
                row.compoundcode = base;
              }

              // 🆕 Set default values if productionorderqty or baseunit are missing
              if (!row.productionorderqty || String(row.productionorderqty || "").trim() === "") {
                row.productionorderqty = "0.000";
              }
              if (!row.baseunit || String(row.baseunit || "").trim() === "") {
                row.baseunit = "";
              }
            });

            // 🧠 STEP 7: Validate Machine Combinations
            const rowsWithMachine = aSelectedRows.filter(r => String(r.machinenumber || "").trim());

            if (rowsWithMachine.length > 0) {
              const comboFilters = new sap.ui.model.Filter({
                filters: rowsWithMachine.map(row =>
                  new sap.ui.model.Filter({
                    filters: [
                      new sap.ui.model.Filter("Plant", "EQ", row.plant),
                      new sap.ui.model.Filter("Material", "EQ", row.materialcode),
                      new sap.ui.model.Filter("ProductionVersion", "EQ", row.machinenumber)
                    ],
                    and: true
                  })
                ),
                and: false
              });

              const validCombos = await new Promise((resolve, reject) => {
                oMaterialMasterModel.read("/ZC_PRODUCTIONVERSION1", {
                  filters: [comboFilters],
                  success: data => resolve(
                    (data.results || []).map(
                      r => `${r.Plant}_${r.Material}_${r.ProductionVersion}`
                    )
                  ),
                  error: reject
                });
              });

              const invalidCombos = rowsWithMachine
                .map((row, idx) => {
                  const key = `${row.plant}_${row.materialcode}_${row.machinenumber}`;
                  if (!validCombos.includes(key)) {
                    const trueIdx = aSelectedRows.indexOf(row);
                    return `Row ${trueIdx + 2}: Invalid machine "${row.machinenumber}" for material "${row.materialcode}" and plant "${row.plant}".`;
                  }
                  return null;
                })
                .filter(Boolean);

              if (invalidCombos.length > 0) {
                aErrors.push("Invalid Production Version Assignments:\n\n" + invalidCombos.join("\n"));
              }
            }

            // 🆕 STEP 8: Check for duplicate combinations with existing table data
            if (aErrors.length === 0) {
              const oTabModel = oView.getModel("TabModel");
              const oExistingRowsInfo = that._getTabRowsArray(oTabModel);
              const aExistingRows = oExistingRowsInfo.array;

              // Build a map of existing combinations
              const existingCombinationMap = new Map();
              aExistingRows.forEach((row, index) => {
                const dateString = that._formatToModelDateString(row.productionordstartdate);
                const biplValue = (row.bipllotno || "").toString().trim();

                if (dateString && biplValue) {
                  const combinationKey = `${dateString}|${biplValue}`;
                  existingCombinationMap.set(combinationKey, index + 1); // Store row index (1-based for user)
                }
              });

              // Check imported rows against existing data
              aSelectedRows.forEach((row, idx) => {
                const rowNumber = idx + 2; // Excel row numbers

                // Format the date
                let dateString = "";
                if (row.productionordstartdate) {
                  dateString = that._formatToModelDateString(row.productionordstartdate);
                }

                const biplValue = (row.bipllotno || "").toString().trim();

                // Only check if both values are present
                if (dateString && biplValue) {
                  const combinationKey = `${dateString}|${biplValue}`;

                  if (existingCombinationMap.has(combinationKey)) {
                    const existingRowIndex = existingCombinationMap.get(combinationKey);
                    aErrors.push(`Row ${rowNumber}: This combination of Production Start Date (${dateString}) and Bipl Lot No (${biplValue}) already exists in the table at row ${existingRowIndex}.`);
                  }
                }
              });
            }

            // 🆕 STEP 9: Check for duplicate combinations with saved records in database
            if (aErrors.length === 0) {
              // First, group rows by date to optimize database queries
              const dateGroups = new Map();

              aSelectedRows.forEach((row, idx) => {
                const dateString = that._formatToModelDateString(row.productionordstartdate);
                const biplValue = (row.bipllotno || "").toString().trim();

                if (dateString && biplValue) {
                  if (!dateGroups.has(dateString)) {
                    dateGroups.set(dateString, []);
                  }
                  dateGroups.get(dateString).push({
                    rowIndex: idx,
                    dateString: dateString,
                    biplValue: biplValue,
                    rowNumber: idx + 2
                  });
                }
              });

              // Check each date group against database
              for (const [dateString, rows] of dateGroups) {
                try {
                  const aSavedRecords = await that._fetchSavedRecords(dateString);

                  // Create a map of saved records for this date
                  const savedBiplMap = new Set();
                  aSavedRecords.forEach(record => {
                    if (record.bipllotno) {
                      savedBiplMap.add(record.bipllotno);
                    }
                  });

                  // Check each row in this date group
                  rows.forEach(rowData => {
                    if (savedBiplMap.has(rowData.biplValue)) {
                      aErrors.push(`Row ${rowData.rowNumber}: This combination of Production Start Date (${dateString}) and Bipl Lot No (${rowData.biplValue}) already exists in the saved records.`);
                    }
                  });
                } catch (error) {
                  console.error(`Error fetching saved records for date ${dateString}:`, error);
                  // Continue with import even if database check fails
                  // Don't add to errors to allow user to proceed
                }
              }
            }

            // 🚫 STEP 10: Show all accumulated errors together
            if (aErrors.length > 0) {
              const errorMessage = "Validation Errors:\n\n" + aErrors.join("\n");
              sap.m.MessageBox.error(errorMessage);
              return;
            }

            // ✅ STEP 11: Import Validated & Enriched Data
            const oModel = oView.getModel("TabModel");
            const existingData = oModel.getProperty("/Samples") || [];
            const updatedData = existingData.concat(aSelectedRows);
            oModel.setProperty("/Samples", updatedData);

            sap.m.MessageToast.show("Data imported and validated successfully.");

          } catch (error) {
            console.error("Validation error:", error);
            sap.m.MessageBox.error("Validation failed. Please try again.");
          }
        }

        const fileInput = document.createElement("input");
        fileInput.type = "file";
        fileInput.accept = ".xlsx,.xls";
        fileInput.style.display = "none";

        fileInput.addEventListener("change", function (e) {
          const file = e.target.files[0];
          if (!file) return;
          ensureXLSX(() => doImport(file));
          document.body.removeChild(fileInput);
        });

        document.body.appendChild(fileInput);
        fileInput.click();
      },





      onExportExl: function () {
        const oModel = this.getView().getModel("TabModel");
        const aData = oModel.getProperty("/Samples") || [];

        // 🔹 Sort the data in the same sequence as the table
        const aSortedData = aData.sort((a, b) => {
          // First sort by productionordstartdate (descending)
          const dateA = new Date(a.productionordstartdate);
          const dateB = new Date(b.productionordstartdate);

          if (dateA > dateB) return -1;
          if (dateA < dateB) return 1;

          // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
        });

        // 🔹 Format function for dd-MM-yyyy
        const fnFormatDate = (date) => {
          if (!date) return "";
          const oDate = new Date(date);
          const day = String(oDate.getDate()).padStart(2, '0');
          const month = String(oDate.getMonth() + 1).padStart(2, '0');
          const year = oDate.getFullYear();
          return `${day}-${month}-${year}`;
        };

        // 🔹 Clone + format dates before export
        const aExportData = aSortedData.length > 0
          ? aSortedData.map(item => ({
            ...item,
            productionordstartdate: fnFormatDate(item.productionordstartdate),
            manufacturingdate: fnFormatDate(item.manufacturingdate),
            expirydate: fnFormatDate(item.expirydate)
          }))
          : [{}]; // pass a dummy row to avoid the "unknown number of rows" warning

        // 🔹 Define columns
        const aColumns = [
          { label: "Plant", property: "plant" },
          { label: "Bipl lot no", property: "bipllotno" },
          { label: "Shift", property: "shift" },
          { label: "Material Code", property: "materialcode" },
          { label: "Description", property: "description" },
          { label: "Machine Number", property: "machinenumber" },
          { label: "Production Order Qty", property: "productionorderqty" },
          { label: "Production Ord Start Date", property: "productionordstartdate" },
          { label: "Lot/Batch-No", property: "lotbatchno" },
          { label: "Production Order No", property: "productionorderno" },
          { label: "Storage Location", property: "storagelocation" },
        ];

        // 🔹 Create spreadsheet
        const oSpreadsheet = new sap.ui.export.Spreadsheet({
          workbook: {
            columns: aColumns,
            context: { sheetName: "Moulding SFG Plan" }
          },
          dataSource: aExportData,
          fileName: "MouldingSFG_Plan_Export.xlsx"
        });

        oSpreadsheet.build()
          .then(() => {
            sap.m.MessageToast.show("Export completed.");
          })
          .catch((oError) => {
            sap.m.MessageBox.error("Export failed: " + oError.message);
          });
      },

      // { label: "UOM", property: "uom" },
      //         { label: "Balance Qty", property: "balanceQty" },



      //         { label: "Saved Status", property: "savedstatus" },

      //         { label: "Status of Production Order", property: "statusOfProdOrd" }














      onFetchMixingPlanData: function (plannedOrderNo) {
        var that = this;

        if (plannedOrderNo !== null) {
          var oModel = this.getView().getModel("TabModel");
          var aData = oModel.getProperty("/Samples");
          console.log("processOrderNo not found");
          return new Promise(function (resolve, reject) {
            try {
              // ✅ Show busy indicator
              // sap.ui.core.BusyIndicator.show(0);

              var oFilter = new sap.ui.model.Filter("plannedorderno", sap.ui.model.FilterOperator.EQ, plannedOrderNo);
              var oModel2 = that.getView().getModel("ZSB_MOULD_PLAN");

              oModel2.read("/ZC_MOULD_PLAN", {
                filters: [oFilter],
                success: function (oData) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  var aItems = oData.results;
                  console.log("aItems:", aItems);

                  var oTarget = aData.find(function (item) {
                    return item.processOrderNo === plannedOrderNo;
                  });

                  if (oTarget) {
                    if (aItems.length > 0) {
                      oTarget.machinenumber = aItems[0].machinenumber || null;
                      oTarget.productionOrderQty = aItems[0].productionorderqty || null;
                      oTarget.balanceQty = aItems[0].balanceqty || null;
                      oTarget.LotBatchNo = aItems[0].lotbatchno || null;
                      oTarget.ManufacturingDate = aItems[0].manufacturingdate || null;
                      oTarget.ExpiryDate = aItems[0].expirydate || null;
                      oTarget.batchweight = aItems[0].batchweight || null;
                      oTarget.Operator = aItems[0].operator || null;
                      oTarget.Inspector = aItems[0].inspector || null;
                      oTarget.savedstatus = aItems[0].status || null;
                    } else {
                      oTarget.machinenumber = null;
                      oTarget.productionOrderQty = null;
                      oTarget.balanceQty = null;
                      oTarget.LotBatchNo = null;
                      oTarget.ManufacturingDate = null;
                      oTarget.ExpiryDate = null;
                      oTarget.batchweight = null;
                      oTarget.Operator = null;
                      oTarget.Inspector = null;
                      oTarget.savedstatus = null;
                    }

                    oModel.refresh();
                  } else {
                    console.log("processOrderNo not found");
                  }

                  resolve(aItems.length > 0 ? (aItems[0].machinenumber || null) : null);
                },
                error: function (oError) {
                  // ✅ Hide busy indicator
                  sap.ui.core.BusyIndicator.hide();

                  console.error("Error reading data: ", oError);
                  reject(oError);
                }
              });
            } catch (e) {
              // ✅ Hide busy indicator in case of unexpected error
              sap.ui.core.BusyIndicator.hide();

              console.error("Unexpected error: ", e);
              reject(e);
            }
          });
        }
      },



      generateUUID: function () {
        return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
          const r = Math.random() * 16 | 0,
            v = c === 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
      },


      onSavePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_MOULD_PLAN");

        const aData = oView.getModel("TabModel").getProperty("/Samples");


        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
          return;
        }

        // save scene
        const alreadySavedRows = aSelectedRows.filter(row =>
          row.sap_uuid !== null &&
          row.sap_uuid !== undefined &&
          row.sap_uuid !== ""
        );

        if (alreadySavedRows.length > 0) {
          const savedIndexes = alreadySavedRows.map(row => aData.indexOf(row) + 1);
          sap.m.MessageBox.error(
            "Cannot save. The following selected row(s) are already saved:\n\n" +
            savedIndexes.join(", ")
          );
          return;
        }




        // ✅ Separate validation for Production Order Qty
        const invalidQtyRows = aSelectedRows.filter(row =>
          row.productionorderno !== null &&
          row.productionorderno !== undefined &&
          Number(row.productionorderno) !== 0
        );

        if (invalidQtyRows.length > 0) {
          const invalidIndexes = invalidQtyRows.map(row => aData.indexOf(row) + 1);
          sap.m.MessageBox.error(
            "Cannot save. The following selected row(s) already have a Production Order Quantity (not 0 or empty):\n\n" +
            invalidIndexes.join(", ")
          );
          return;
        }




        // ✅ Validate mandatory fields
        const aInvalidRows = [];

        aSelectedRows.forEach((row, index) => {
          const missingFields = [];

          // if (!row.plant) missingFields.push("Plant");
          if (!row.machinenumber) missingFields.push("Machine Number");
          if (!row.bipllotno) missingFields.push("bipllotno");
          if (!row.shift) missingFields.push("shift");
          // if (!row.lotbatchno) missingFields.push("lot batchno");
          if (!row.materialcode) missingFields.push("Material Code");
          // if (!row.productionorderqty) missingFields.push("Production Order Qty");
          if (!row.productionordstartdate) missingFields.push("Production order start Date");
          // if (!row.storagelocation) missingFields.push("storage location");

          if (missingFields.length > 0) {
            const rowIndex = aData.indexOf(row) + 1; // Get actual row number from full dataset
            aInvalidRows.push(`Row ${rowIndex} is missing: ${missingFields.join(", ")}`);
          }
        });

        if (aInvalidRows.length > 0) {
          sap.m.MessageBox.error(
            "The following selected row(s) have missing mandatory fields:\n\n" + aInvalidRows.join("\n")
          );
          return;
        }



        sap.ui.core.BusyIndicator.show(0);

        const aPromises = aSelectedRows.map(row => {

          const oPayload = {
            sap_uuid: this.generateUUID(),
            plant: "1200",
            // bipllotno: row.bipllotno,
            bipllotno: String(row.bipllotno) || "0",
            shift: row.shift,
            materialcode: row.materialcode,
            description: row.description,
            compoundcode: row.compoundcode,
            machinenumber: row.machinenumber,
            productionorderqty: String(row.productionorderqty) || "0",
            productionordstartdate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
            storagelocation: row.storagelocation,
            lotbatchno: row.lotbatchno,
            manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            batchweight: row.batchweight || "0",
            operator: row.operator,
            inspector: row.inspector,
            productionorderno: null,
            status: "GT",
            screenname: "MOULDING",
            screencode: "MP01",
            createdat: new Date(),
            createdby: this.sUserId
          };

          return new Promise((resolve, reject) => {
            oModel.create("/ZC_MOULD_PLAN", oPayload, {
              success: resolve,
              error: reject
            });
          });
        });
        var that = this;

        Promise.allSettled(aPromises).then(async results => {
          sap.ui.core.BusyIndicator.hide();

          const aFailed = results.filter(r => r.status === "rejected");
          if (aFailed.length > 0) {
            sap.m.MessageBox.error(`${aFailed.length} row(s) failed to post.`);
          } else {
            // let oMixingPostDatas = await that.ToFetchMixingPlanData();
            that._fetchPostedData();
            // debugger
            sap.m.MessageBox.success("All selected rows posted successfully.", {
              onClose: () => {
                oModel.refresh(true); // Reloads all bindings
              }
            });

          }
        });
      },




      onDeletePress: function () {
        const oView = this.getView();
        const oModel = oView.getModel("ZSB_MOULD_PLAN");
        const oTabModel = oView.getModel("TabModel");
        const aData = oTabModel.getProperty("/Samples");

        if (!aData || !Array.isArray(aData)) {
          sap.m.MessageBox.error("No data available.");
          return;
        }

        const aSelectedRows = aData.filter(row => row.__selected);

        if (aSelectedRows.length === 0) {
          sap.m.MessageBox.warning("Please select at least one row to delete.");
          return;
        }

        if (aSelectedRows.some(row => !row.sap_uuid)) {
          sap.m.MessageBox.warning("Row not saved to delete.");
          return;
        }

        if (aSelectedRows.some(row => row.productionorderno && row.productionorderno !== "0")) {
          sap.m.MessageBox.error("Cannot delete rows that already have a Production order No.");
          return;
        }

        sap.m.MessageBox.confirm(
          `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
          {
            title: "Confirm Deletion",
            actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
            onClose: function (oAction) {
              if (oAction !== sap.m.MessageBox.Action.OK) return;

              sap.ui.core.BusyIndicator.show(0);

              const aDeletePromises = aSelectedRows.map(row => {
                return new Promise((resolve, reject) => {
                  if (!row.sap_uuid) {
                    reject("Missing sap_uuid for deletion.");
                    return;
                  }

                  const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${row.sap_uuid}')`;

                  oModel.remove(sKeyPath, {
                    success: resolve,
                    error: reject
                  });
                });
              });

              Promise.allSettled(aDeletePromises).then(results => {
                sap.ui.core.BusyIndicator.hide();

                const aFailed = results.filter(r => r.status === "rejected");
                const aSuccess = results.filter(r => r.status === "fulfilled");

                // Remove deleted rows from TabModel local data
                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                oTabModel.setProperty("/Samples", aRemainingData);

                if (aSuccess.length > 0) {
                  sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                }

                if (aFailed.length > 0) {
                  sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                  console.error("Deletion errors:", aFailed);
                }
              });
            }
          }
        );
      },











      // Fragment for material - product

      onMaterialFragmentOpen: function (oEvent) {
        // console.log("hi")
        sap.ui.core.BusyIndicator.show();  // Show busy indicator when starting
        this.EventRowCollNo = oEvent.getSource().getParent();

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty("/Samples");

        const input = oEvent.getSource(); // the Input field
        const context = input.getBindingContext("TabModel");

        if (context) {
          const rowPath = context.getPath();
          const rowData = context.getObject();

          // var mod01 = this.getView().getModel("TabModel");
          // var ItemTableModel = mod01.getProperty(rowPath)
          // const rowData = ItemTableModel;

          this.oEventModelRowDatas = rowData;
          this.oEventModelRowPath = rowPath;

          if (rowData.plant === "") {
            sap.m.MessageBox.information("Please enter the plant...")
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          var that = this;

          var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);
          var ExternalProductGroup = new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "MOULDING");
          // var productGroupFilter09 = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "09");
          // var productGroupFilter35 = new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "35");


          this._oBasicSearchField = new sap.m.SearchField();

          this.loadFragment({
            name: "bando.view.CommonFragments.PlanScreens.materialmaster"
          }).then(function (oDialog) {
            // bando.view.CommonFragments.PlanScreens.
            var oFilterBar = oDialog.getFilterBar(),
              oColumnProductCode, oColumnProductName, oColumnPlant;

            this._oVHD_Product = oDialog;
            this.getView().addDependent(oDialog);

            // Set key fields for filtering in the Define Conditions Tab
            oDialog.setRangeKeyFields([{
              label: "Product",
              key: "Product",
              type: "string",
              typeInstance: new sap.ui.model.type.String({}, {
                maxLength: 10
              })
            }]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchField.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.getTableAsync().then(function (oTable) {
              // Get the model for the products and bind it to the table
              oTable.setModel(this.oProductsModel);

              // Apply plant filter to the data binding

              // For Desktop and tablet, the default table is sap.ui.table.Table
              if (oTable.bindRows) {
                // Bind rows to the ODataModel with a filter for plant
                // ZSB_MATERIALMASTER
                oTable.bindAggregation("rows", {
                  path: "ZSB_MATERIALMASTER1>/ZC_MATERIALMASTER1",
                  filters: [plantFilter, ExternalProductGroup], // Apply the plant filter here
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });
                //ZSB_MATERIALMASTER

                // Define columns for the table
                oColumnProductCode = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Product" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Product}" })
                });
                oColumnProductCode.data({
                  fieldName: "Product"
                });

                oColumnProductName = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "ProductName" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>ProductName}" })
                });
                oColumnProductName.data({
                  fieldName: "ProductName"
                });

                oColumnPlant = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Plant" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Plant}" })
                });
                oColumnPlant.data({
                  fieldName: "Plant"
                });

                oTable.addColumn(oColumnProductCode);
                oTable.addColumn(oColumnProductName);
                oTable.addColumn(oColumnPlant);
              }
              //ZSB_MATERIALMASTER

              // For Mobile, the default table is sap.m.Table
              if (oTable.bindItems) {
                // Bind items to the ODataModel with a filter for plant
                oTable.bindAggregation("items", {
                  path: "ZSB_MATERIALMASTER1>/ZC_MATERIALMASTER1",
                  filters: [plantFilter], // Apply the plant filter here
                  template: new sap.m.ColumnListItem({
                    cells: [
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Product}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductName}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Plant}" }),
                    ]
                  }),
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Add columns for mobile/table view
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Product" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "ProductName" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
              }

              // Open the dialog
              oDialog.open();
              sap.ui.core.BusyIndicator.hide(); // Hide the busy indicator after dialog opens
            }.bind(this));
          }.bind(this));
        }
      },



      onValueHelpOkPress_Product: async function (oEvent) {
        sap.ui.core.BusyIndicator.show();

        var aTokens = oEvent.getParameter("tokens");
        let KeyVal = aTokens[0].getKey();   // Product Code
        let TextVal = aTokens[0].getText();

        let parts = TextVal.split("(");
        let ProductCode = KeyVal;
        let ProductName = parts[0].trim();

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(this.oEventModelRowPath);

        // Fill basic material details
        ItemTableModel.materialcode = ProductCode;
        ItemTableModel.description = ProductName;

        var oODataModel = this.getView().getModel("ZSB_MATERIALMASTER1"); // check alias in manifest
        var oProdQty = this.getView().getModel("ZSB_PROD_QTY"); // check alias in manifest

        // 🔥 Fetch BatchWeight
        // oODataModel.read("/ZC_BATCHWEIGHT", {
        //     filters: [
        //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode)
        //     ],
        //     success: function (oData) {
        //         if (oData.results && oData.results.length > 0) {
        //             let batchWeight = oData.results[0].Batchweight;
        //             ItemTableModel.batchweight = batchWeight;
        //         } else {
        //             ItemTableModel.batchweight = "";
        //         }
        //         mod01.refresh();
        //     },
        //     error: function (oError) {
        //         console.error("Batch weight fetch failed", oError);
        //         ItemTableModel.batchweight = "";
        //         mod01.refresh();
        //     }
        // });
        // 🔥 Fetch BatchWeight with additional filters
        oODataModel.read("/ZC_BATCHWEIGHT", {
          filters: [
            new sap.ui.model.Filter({
              filters: [
                new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode),
                new sap.ui.model.Filter("ClassType", sap.ui.model.FilterOperator.EQ, "001"),
                new sap.ui.model.Filter("CharcInternalID", sap.ui.model.FilterOperator.EQ, "0000000833")
              ],
              and: true
            })
          ],
          success: function (oData) {
            if (oData.results && oData.results.length > 0) {
              let batchWeight = oData.results[0].Batchweight;
              ItemTableModel.batchweight = batchWeight;
            } else {
              ItemTableModel.batchweight = "";
            }
            mod01.refresh();
          },
          error: function (oError) {
            console.error("Batch weight fetch failed", oError);
            ItemTableModel.batchweight = "";
            mod01.refresh();
          }
        });


        // 🔥 Fetch CompoundCode
        oODataModel.read("/ZC_COMPOUNDCODE", {
          filters: [
            new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, ProductCode)
          ],
          success: function (oData) {
            if (oData.results && oData.results.length > 0) {
              let compoundCode = oData.results[0].CompoundCode;
              ItemTableModel.compoundcode = compoundCode;
            } else {
              ItemTableModel.compoundcode = "";
            }
            mod01.refresh();
          },
          error: function (oError) {
            console.error("Compound code fetch failed", oError);
            ItemTableModel.compoundcode = "";
            mod01.refresh();
          }
        });
        // oProdQty.read("/ZC_PROD_QTY", {
        //     filters: [
        //         new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, ProductCode)
        //     ],
        //     success: function (oData) {
        //         if (oData.results && oData.results.length > 0) {
        //             let prodQty = oData.results[0].Qty;
        //             let baseUnit = oData.results[0].BaseUnit;

        //             // ✅ Set the production order quantity and base unit in the row
        //             ItemTableModel.productionorderqty = prodQty;
        //             ItemTableModel.baseunit = baseUnit || ""; // optional, if you want to show it elsewhere

        //             mod01.refresh();
        //         } else {
        //             // If no record found, clear the value
        //             ItemTableModel.productionorderqty = "";
        //             mod01.refresh();
        //         }
        //     },
        //     error: function (oError) {
        //         console.error("Production order qty fetch failed", oError);
        //         ItemTableModel.productionorderqty = "";
        //         mod01.refresh();
        //     }
        // });


        // ✅ close/destroy dialog (decide on one strategy)
        this._oVHD_Product.destroy();
        sap.ui.core.BusyIndicator.hide();
      },



      onFilterBarSearch_Product: function (oEvent) {
        console.log(oEvent);
        var sSearchQuery = this._oBasicSearchField.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet");

        // Construct filters for search and selection set values
        var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(new sap.ui.model.Filter({
              path: oControl.getName(),
              operator: sap.ui.model.FilterOperator.Contains,
              value1: oControl.getValue()
            }));
          }
          return aResult;
        }, []);

        aFilters.push(new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter({ path: "Product", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "ProductName", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            // new sap.ui.model.Filter({ path: "StandardPrice", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
          ],
          and: false
        }));

        this._filterTable_Product(new sap.ui.model.Filter({
          filters: aFilters,
          and: true
        }));
      },

      _filterTable_Product: function (oFilter) {
        var oVHD = this._oVHD_Product;

        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }

          // Update the dialog after filtering
          oVHD.update();
        });
      },

      onValueHelpCancelPress_Product: function () {
        this._oVHD_Product.close(); // Close the value help dialog without making any changes
      },




      //suggest  section for material -product

      onSuggestMaterial: function (oEvent) {
        const sTerm = oEvent.getParameter("suggestValue");
        const oInput = oEvent.getSource();
        const oModel = this.getView().getModel("ZSB_MATERIALMASTER1"); //ZSB_MATERIALMASTER

        if (!sTerm) return;

        // Get context and row info
        const context = oInput.getBindingContext("TabModel");
        let aFilters = [];
        let rowPath, rowData, tabModel;

        if (context) {
          rowPath = context.getPath();
          rowData = context.getObject();
          tabModel = context.getModel();

          if (!rowData.plant) {
            sap.m.MessageBox.information("Please enter the plant...");
            return;
          }

          aFilters.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant));
          aFilters.push(new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "MOULDING"));
          // aFilters.push(new sap.ui.model.Filter("ProductGroup", sap.ui.model.FilterOperator.EQ, "09"));

        }

        // Search term filter
        const oSearchFilter = new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sTerm),

          ],
          and: false
        });

        aFilters.push(oSearchFilter);

        // Fetch suggestions from OData
        oModel.read("/ZC_MATERIALMASTER1", {
          filters: aFilters,
          success: function (oData) {
            oInput.destroySuggestionItems();

            oData.results.forEach(item => {
              const oItem = new sap.ui.core.Item({
                text: `${item.Product} (${item.ProductName})`,
                key: item.Product
              });
              oItem.data("ProductName", item.ProductName); // attach extra data
              oInput.addSuggestionItem(oItem);
            });

            // Attach suggestionItemSelected only once
            if (!oInput._hasSuggestionSelectHandler) {
              oInput.attachSuggestionItemSelected(function (oEvt) {
                const selectedItem = oEvt.getParameter("selectedItem");
                if (!selectedItem || !context) return;

                const sSelectedKey = selectedItem.getKey();
                const sSelectedText = selectedItem.getText();
                const productName = selectedItem.data("ProductName") || sSelectedText;

                // Set values in model
                tabModel.setProperty(rowPath + "/materialcode", sSelectedKey);
                tabModel.setProperty(rowPath + "/description", productName);
                tabModel.setProperty(rowPath + "/compoundcode", productName);
                tabModel.refresh();
              });
              oInput._hasSuggestionSelectHandler = true; // prevent double attachment
            }
          },
          error: function () {
            console.error("Failed to fetch suggestions");
          }
        });
      },




      // End Fragment for material - product


      // Start Fragment for Productionversion

      onProductVersionFrag: function (oEvent) {
        sap.ui.core.BusyIndicator.show();  // Show busy indicator when starting
        this.EventRowCollNo = oEvent.getSource().getParent();

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty("/Samples");

        const input = oEvent.getSource(); // the Input field
        const context = input.getBindingContext("TabModel");

        if (context) {
          const rowPath = context.getPath();
          const rowData = context.getObject();

          // var mod01 = this.getView().getModel("TabModel");
          // var ItemTableModel = mod01.getProperty(rowPath)
          // const rowData = ItemTableModel;

          this.oEventModelRowDatas = rowData;
          this.oEventModelRowPath = rowPath;

          if (rowData.plant === "") {
            sap.m.MessageBox.information("Please enter the plant...")
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          if (rowData.materialcode === "") {
            sap.m.MessageBox.information("Please enter the Material...")
            sap.ui.core.BusyIndicator.hide();
            return;
          }

          var that = this;

          var MaterialFilter = new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, rowData.materialcode);
          var plantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant);

          this._oBasicSearchField = new sap.m.SearchField();

          this.loadFragment({
            name: "bando.view.CommonFragments.PlanScreens.productionversion"
          }).then(function (oDialog) {
            var oFilterBar = oDialog.getFilterBar(),
              oColumnProduct, oColumnProductionVersion, oColumnPlant;

            this._ProdVer = oDialog;
            this.getView().addDependent(oDialog);

            // Set key fields for filtering in the Define Conditions Tab
            oDialog.setRangeKeyFields([{
              label: "Product",
              key: "Product",
              type: "string",
              typeInstance: new sap.ui.model.type.String({}, {
                maxLength: 10
              })
            }]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchField);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchField.attachSearch(function () {
              oFilterBar.search();
            });

            oDialog.getTableAsync().then(function (oTable) {
              // Get the model for the products and bind it to the table
              oTable.setModel(this.oProductsModel);

              // Apply plant filter to the data binding

              // For Desktop and tablet, the default table is sap.ui.table.Table
              //ZSB_MATERIALMASTER
              if (oTable.bindRows) {
                // Bind rows to the ODataModel with a filter for plant
                oTable.bindAggregation("rows", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter, MaterialFilter], // Apply the plant filter here
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Define columns for the table
                //ZSB_MATERIALMASTER
                oColumnProductionVersion = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "ProductionVersion" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>ProductionVersion}" })
                });
                oColumnProductionVersion.data({
                  fieldName: "ProductionVersion"
                });

                oColumnProduct = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Material" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Material}" })
                });
                oColumnProduct.data({
                  fieldName: "Material"
                });

                oColumnPlant = new sap.ui.table.Column({
                  label: new sap.m.Label({ text: "Plant" }),
                  template: new sap.m.Text({ wrapping: false, text: "{ZSB_MATERIALMASTER1>Plant}" })
                });
                oColumnPlant.data({
                  fieldName: "Plant"
                });

                oTable.addColumn(oColumnProductionVersion);
                oTable.addColumn(oColumnProduct);
                oTable.addColumn(oColumnPlant);
              }

              // For Mobile, the default table is sap.m.Table
              //ZSB_MATERIALMASTER
              if (oTable.bindItems) {
                // Bind items to the ODataModel with a filter for plant
                oTable.bindAggregation("items", {
                  path: "ZSB_MATERIALMASTER1>/ZC_PRODUCTIONVERSION1",
                  filters: [plantFilter], // Apply the plant filter here
                  template: new sap.m.ColumnListItem({
                    cells: [
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>ProductionVersion}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Material}" }),
                      new sap.m.Label({ text: "{ZSB_MATERIALMASTER1>Plant}" }),
                    ]
                  }),
                  events: {
                    dataReceived: function () {
                      oDialog.update();
                    }
                  }
                });

                // Add columns for mobile/table view
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "ProductionVersion" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Material" }) }));
                oTable.addColumn(new sap.m.Column({ header: new sap.m.Label({ text: "Plant" }) }));
              }

              // Open the dialog
              oDialog.open();
              sap.ui.core.BusyIndicator.hide(); // Hide the busy indicator after dialog opens
            }.bind(this));
          }.bind(this));
        }
      },

      onValueHelpOkPress_ProdVer: async function (oEvent) {
        sap.ui.core.BusyIndicator.show();
        // this.oEventModelRowDatas = rowData;
        // this.oEventModelRowPath = rowPath;

        console.log("this.oEventModelDatas", this.oEventModelRowDatas)
        console.log("this.oEventModelRowPath", this.oEventModelRowPath)

        var aTokens = oEvent.getParameter("tokens");
        let KeyVal = aTokens[0].getKey(); // Get the key of the selected token
        let TextVal = aTokens[0].getText();

        let parts = TextVal.split("(")

        let ProductCode = KeyVal;
        let ProductName = parts[0];

        var mod01 = this.getView().getModel("TabModel");
        var ItemTableModel = mod01.getProperty(this.oEventModelRowPath)
        ItemTableModel.machinenumber = ProductCode
        mod01.refresh()

        // context.getModel().setProperty(`${rowPath}/dipscurrent`, getdipcurr);

        this._ProdVer.destroy(); // Destroy the value help dialog
        sap.ui.core.BusyIndicator.hide();
      },

      onValueHelpCancelPress_ProdVer: function () {
        this._ProdVer.close(); // Close the value help dialog without making any changes
      },

      onFilterBarSearch_ProdVer: function (oEvent) {
        console.log(oEvent);
        var sSearchQuery = this._oBasicSearchField.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet");

        // Construct filters for search and selection set values
        var aFilters = aSelectionSet && aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(new sap.ui.model.Filter({
              path: oControl.getName(),
              operator: sap.ui.model.FilterOperator.Contains,
              value1: oControl.getValue()
            }));
          }
          return aResult;
        }, []);

        aFilters.push(new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter({ path: "ProductionVersion", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Material", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            new sap.ui.model.Filter({ path: "Plant", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
            // new sap.ui.model.Filter({ path: "StandardPrice", operator: sap.ui.model.FilterOperator.Contains, value1: sSearchQuery }),
          ],
          and: false
        }));

        this._filterTable_ProdVer(new sap.ui.model.Filter({
          filters: aFilters,
          and: true
        }));
      },

      _filterTable_ProdVer: function (oFilter) {
        var oVHD = this._ProdVer;

        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }

          // Update the dialog after filtering
          oVHD.update();
        });
      },



      //suggest  section for  product[MACHINENUMBER]


      onSuggestMachineNumber: function (oEvent) {
        const sTerm = oEvent.getParameter("suggestValue");
        const oInput = oEvent.getSource();
        const oModel = this.getView().getModel("ZSB_MATERIALMASTER1");//ZSB_MATERIALMASTER

        if (!sTerm) return;

        const context = oInput.getBindingContext("TabModel");
        let aFilters = [];

        let rowPath, rowData, tabModel;

        if (context) {
          rowPath = context.getPath();
          rowData = context.getObject();
          tabModel = context.getModel();

          if (!rowData.plant) {
            sap.m.MessageBox.information("Please enter the plant...");
            return;
          }

          if (!rowData.materialcode) {
            sap.m.MessageBox.information("Please enter the material...");
            return;
          }

          aFilters.push(new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, rowData.plant));
          aFilters.push(new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, rowData.materialcode));

        }

        // Search based on ProductionVersion (machine number), Material, or Plant
        const oSearchFilter = new sap.ui.model.Filter({
          filters: [
            new sap.ui.model.Filter("ProductionVersion", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sTerm),
            new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sTerm)
          ],
          and: false
        });

        aFilters.push(oSearchFilter);

        oModel.read("/ZC_PRODUCTIONVERSION1", {
          filters: aFilters,
          success: function (oData) {
            oInput.destroySuggestionItems();

            oData.results.forEach(item => {
              const oItem = new sap.ui.core.Item({
                key: item.ProductionVersion,
                text: `${item.ProductionVersion} (${item.Material}) - ${item.Plant}`
              });
              oItem.data("Material", item.Material);
              oItem.data("Plant", item.Plant);
              oInput.addSuggestionItem(oItem);
            });

            // Attach handler once
            if (!oInput._hasSuggestionSelectHandler_Machine) {
              oInput.attachSuggestionItemSelected(function (oEvt) {
                const selectedItem = oEvt.getParameter("selectedItem");
                if (!selectedItem || !context) return;

                const machineNum = selectedItem.getKey();

                tabModel.setProperty(rowPath + "/machinenumber", machineNum);
                tabModel.refresh();
              });
              oInput._hasSuggestionSelectHandler_Machine = true;
            }
          },
          error: function () {
            console.error("Failed to fetch machine number suggestions.");
          }
        });
      },


      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oMixingModel = oView.getModel("ZSB_MOULD_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Selected row not saved.");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }



      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZMO1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: row.productionorderqty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;

      //       if (!sProdOrder) {
      //         sap.m.MessageToast.show(`No production order returned for row ${i + 1}. Skipping.`);
      //         continue;
      //       }

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) {
      //         sap.m.MessageToast.show(`No batch number for Production Order ${sProdOrder}. Skipping.`);
      //         continue;
      //       }

      //       // Update backend
      //       const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       };

      //       await new Promise((resolve, reject) => {
      //         oMixingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       // Save to apply to TabModel later
      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //       sap.m.MessageToast.show(`Error processing row ${i + 1}.`);
      //     }
      //   }

      //   // Update TabModel in one go
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       aData[idx].productionorderno = updated.productionorderno;
      //       aData[idx].lotbatchno = updated.lotbatchno;
      //       aData[idx].storagelocation = updated.storagelocation;
      //     }
      //   });

      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");
      // },



      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oBeltFGModel = oView.getModel("ZSB_MOULD_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Save the selected row first");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }


      //   const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
      //               // First sort by productionordstartdate (descending)
      //               const dateA = a.productionordstartdate;
      //               const dateB = b.productionordstartdate;

      //               if (dateA && dateB) {
      //                   if (dateA > dateB) return -1;
      //                   if (dateA < dateB) return 1;
      //               }

      //               // Then sort by bipllotno (ascending)
      //               const lotA = a.bipllotno || "";
      //               const lotB = b.bipllotno || "";

      //               if (lotA < lotB) return -1;
      //               if (lotA > lotB) return 1;

      //               return 0;
      //           });
      //           // aSortedSelectedRows


      //   // const oSelectedRow = aRowsWithUUID[0];
      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSortedSelectedRows.length; i++) {
      //     const row = aSortedSelectedRows[i];

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZMO1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: row.productionorderqty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;
      //       if (!sProdOrder) continue;

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) continue;

      //       const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc
      //       };

      //       await new Promise((resolve, reject) => {
      //         oBeltFGModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc,
      //         productionordstartdate: row.productionordstartdate,
      //         plant: row.plant,
      //         materialcode: row.materialcode
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //     }
      //   }

      //   // 🔄 Update TabModel
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       Object.assign(aData[idx], updated);
      //     }
      //   });
      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");

      //   // ✅ Now Generate QR PDF
      //   // this._generateQRPdf(aUpdatedRows);
      // },



      onApiPostButton: async function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        // const oSewingModel = oView.getModel("ZSB_CALEN_PLAN");
        const oBeltFGModel = oView.getModel("ZSB_MOULD_PLAN");
        const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");
        const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");

        const aData = oTabModel.getProperty("/Samples");
        const aSelectedRows = aData.filter(row => row.__selected);

        // --- 🚫 BLOCKER VALIDATION (cannot proceed)
        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        // Check for saved rows (sap_uuid)
        const aRowsWithoutUUID = aSelectedRows.filter(row => !row.sap_uuid);
        if (aRowsWithoutUUID.length > 0) {
          const sRowNumbers = aRowsWithoutUUID
            .map((row, index) => `Row ${index + 1}`)
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed for the following rows:\n\n${sRowNumbers}: Please save the row first`
          );
          return;
        }

        // Check for existing production orders
        const aRowsWithProdOrder = aSelectedRows.filter(row => {
          const val = row.productionorderno;
          return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
        });

        if (aRowsWithProdOrder.length > 0) {
          const sProdOrders = aRowsWithProdOrder
            .map(row => row.productionorderno || "(No Production Order)")
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed due to the following issues:\n\nProduction Order(s) ${sProdOrders}: Already have valid Production Order Number assigned`
          );
          return;
        }

        // --- 🧪 VALIDATION (field completeness)
        let aValidationErrors = [];

        aSelectedRows.forEach((row, index) => {
          let missingFields = [];

          if (!row.materialcode || row.materialcode.trim() === "") {
            missingFields.push("Material Code");
          }
          if (!row.plant || row.plant.trim() === "") {
            missingFields.push("Plant");
          }
          if (!row.productionorderqty || row.productionorderqty <= 0) {
            missingFields.push("Production Order Quantity");
          }
          if (!row.productionordstartdate) {
            missingFields.push("Production Order Start Date");
          }
          if (!row.machinenumber || row.machinenumber.trim() === "") {
            missingFields.push("Machine Number");
          }

          if (missingFields.length > 0) {
            // const sRowId = `Row ${index + 1} (UUID: ${row.sap_uuid})`;
            const sRowId = `Row ${index + 1}`;

            aValidationErrors.push(`${sRowId}: ${missingFields.join(", ")}`);
          }
        });

        if (aValidationErrors.length > 0) {
          sap.m.MessageBox.error(
            "Missing required fields:\n\n" + aValidationErrors.join("\n")
          );
          return;
        }

        // --- ✅ PROCESSING (all validations passed)
        sap.ui.core.BusyIndicator.show(0);

        // Sort selected rows
        const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
          // First sort by productionordstartdate (descending)
          const dateA = a.productionordstartdate;
          const dateB = b.productionordstartdate;

          if (dateA && dateB) {
            if (dateA > dateB) return -1;
            if (dateA < dateB) return 1;
          }

          // Then sort by bipllotno (ascending)
          const lotA = a.bipllotno || "";
          const lotB = b.bipllotno || "";

          if (lotA < lotB) return -1;
          if (lotA > lotB) return 1;

          return 0;
        });

        // Arrays to collect results
        const aSuccessResults = [];
        const aErrorResults = [];

        for (let i = 0; i < aSortedSelectedRows.length; i++) {
          const row = aSortedSelectedRows[i];
          // const sRowId = `Row ${i + 1} (UUID: ${row.sap_uuid})`;
          const sRowId = `Row ${i + 1}`;

          const oPayload = {
            Material: row.materialcode,
            ProductionPlant: row.plant,
            ManufacturingOrderType: "ZMO1",
            ProductionVersion: row.machinenumber,
            TotalQuantity: row.productionorderqty,
            MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
            BasicSchedulingType: "1"
          };

          try {
            // 1. CREATE Operation - Production Order
            // const oPostData = await new Promise((resolve, reject) => {
            //   oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
            //     success: function (odata) {
            //       console.log("CREATE Success - Production Order:", odata);

            //       // Check if production order was created successfully
            //       if (!odata.Productionorder) {
            //         let errorMessage = "No production order returned";
            //         if (odata.errorresponse) {
            //           try {
            //             const errorObj = JSON.parse(odata.errorresponse);
            //             errorMessage = errorObj.error?.message?.value || errorObj.error?.message || odata.errorresponse;
            //           } catch (e) {
            //             errorMessage = odata.errorresponse;
            //           }
            //         }
            //         reject(new Error(errorMessage));
            //       } else {
            //         resolve(odata);
            //       }
            //     },
            //     error: reject
            //   });
            // });

            const oPostData = await new Promise((resolve, reject) => {
              oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
                success: function (odata) {
                  console.log("CREATE Success - Production Order:", odata);

                  // Check if production order was actually created
                  if (odata.Productionorder && odata.Productionorder !== "") {
                    // Success: order created
                    resolve(odata);
                  } else {
                    // Business error: extract message from Errorresponse
                    let errorMessage = "No production order returned";
                    if (odata.Errorresponse) {  // note capital 'E'
                      try {
                        const errorObj = JSON.parse(odata.Errorresponse);
                        // Navigate to the most descriptive message
                        errorMessage = errorObj.error?.message?.value ||
                          errorObj.error?.message ||
                          odata.Errorresponse;
                      } catch (e) {
                        // If parsing fails, keep the raw string
                        errorMessage = odata.Errorresponse;
                      }
                    }
                    reject(new Error(errorMessage));
                  }
                },
                error: function (err) {
                  // Handle HTTP/network errors (e.g., 400, 500)
                  reject(err);
                }
              });
            });

            const sProdOrder = oPostData.Productionorder;
            const sStorageLoc = oPostData.StorageLocation;

            // 2. READ Operation - Batch Creation
            const oBatchData = await new Promise((resolve, reject) => {
              oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
                success: function (odata) {
                  console.log("READ Success - Batch Creation:", odata);
                  if (!odata.Batch) {
                    reject(new Error("No batch number returned"));
                  } else {
                    resolve(odata);
                  }
                },
                error: reject
              });
            });

            const sBatchNo = oBatchData.Batch;

            const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${row.sap_uuid}')`;
            const oUpdatePayload = {
              productionorderno: sProdOrder,
              lotbatchno: sBatchNo,
              storagelocation: sStorageLoc
            };

            // 3. UPDATE Operation - MouldingSFG Plan
            await new Promise((resolve, reject) => {
              oBeltFGModel.update(sKeyPath, oUpdatePayload, {
                merge: true,
                success: function (odata) {
                  console.log("UPDATE Success - Moulding SFG Plan:", odata);
                  resolve(odata);
                },
                error: reject
              });
            });

            // Add to success list WITH sap_uuid for proper matching
            aSuccessResults.push({
              rowId: sRowId,
              sap_uuid: row.sap_uuid, // Store the UUID for matching
              productionOrder: sProdOrder,
              batchNo: sBatchNo,
              storageLocation: sStorageLoc,
              materialCode: row.materialcode
            });

          } catch (oError) {
            console.error(`❌ API Post Failed for ${sRowId}:`, oError);

            // Extract error message
            let sErrorMessage = oError.message || "Unknown error";

            // For OData errors
            if (oError.responseText) {
              try {
                const oErrorResponse = JSON.parse(oError.responseText);
                if (oErrorResponse.error && oErrorResponse.error.message) {
                  sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                }
              } catch (e) {
                sErrorMessage = oError.responseText;
              }
            }

            // Add to error list WITH sap_uuid
            aErrorResults.push({
              rowId: sRowId,
              sap_uuid: row.sap_uuid, // Store the UUID for reference
              error: sErrorMessage
            });
          }
        }

        // CORRECTED: Update the model with processed rows using sap_uuid
        aSuccessResults.forEach(result => {
          // Find the row in aData by sap_uuid
          const idx = aData.findIndex(row => row.sap_uuid === result.sap_uuid);
          if (idx !== -1) {
            Object.assign(aData[idx], {
              productionorderno: result.productionOrder,
              lotbatchno: result.batchNo,
              storagelocation: result.storageLocation
            });
            console.log(`✅ Updated row with UUID: ${result.sap_uuid}`, {
              productionOrder: result.productionOrder,
              batchNo: result.batchNo,
              storageLocation: result.storageLocation
            });
          } else {
            console.error(`❌ Could not find row with UUID: ${result.sap_uuid}`);
          }
        });

        oTabModel.setProperty("/Samples", aData);
        oTabModel.refresh();
        sap.ui.core.BusyIndicator.hide();

        // Show summary message
        this.showPostSummary(aSuccessResults, aErrorResults);
      },

      showPostSummary: function (aSuccessResults, aErrorResults) {
        const sTotal = aSuccessResults.length + aErrorResults.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `API Post process completed for ${sTotal} row(s).\n\n`;
        let bHasSuccess = aSuccessResults.length > 0;
        let bHasFailed = aErrorResults.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
          aSuccessResults.forEach(result => {
            sMessage += `   - ${result.rowId}`;
            if (result.productionOrder) {
              sMessage += ` (Prod. Order: ${result.productionOrder}`;
              if (result.batchNo) {
                sMessage += `, Batch: ${result.batchNo}`;
              }
              if (result.storageLocation) {
                sMessage += `, Storage: ${result.storageLocation}`;
              }
              sMessage += `)`;
            }
            sMessage += `\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
          aErrorResults.forEach(result => {
            sMessage += `   - ${result.rowId}: ${result.error}\n`;
          });
        }

        // Always show MessageBox for all cases
        setTimeout(() => {
          if (bHasFailed) {
            // Show detailed error dialog with summary
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.ERROR,
                title: "API Post Process Summary",
                actions: [sap.m.MessageBox.Action.OK],
                details: aErrorResults.map(f =>
                  `${f.rowId}\nError: ${f.error}`
                ).join('\n\n')
              }
            );
          } else {
            // Show success dialog
            sap.m.MessageBox.show(
              sMessage,
              {
                icon: sap.m.MessageBox.Icon.SUCCESS,
                title: "API Post Process Summary",
                actions: [sap.m.MessageBox.Action.OK]
              }
            );
          }
        }, 100);
      },


      generateProdOrderNo: function () {
        const oView = this.getView();
        const oODataModel = oView.getModel("ZSB_PROD_HD_ITM_MSFG");

        return new Promise((resolve, reject) => {
          // First, read the SINGLE row from ZC_PROD_ORD_TEMP_MSFG
          oODataModel.read("/ZC_PROD_ORD_TEMP_MSFG", {
            success: function (oData) {
              let nextProdOrderNo = 1; // Default to 1 if no record exists

              if (oData.results && oData.results.length > 0) {
                // Get the first (and should be only) record
                const currentProdOrderNo = oData.results[0].Productionorders;
                console.log("Current production order number found:", currentProdOrderNo);

                // Convert to number and increment
                if (currentProdOrderNo && !isNaN(currentProdOrderNo)) {
                  nextProdOrderNo = parseInt(currentProdOrderNo) + 1;
                } else if (typeof currentProdOrderNo === 'string') {
                  const numericPart = currentProdOrderNo.replace(/\D/g, '');
                  if (numericPart) {
                    nextProdOrderNo = parseInt(numericPart) + 1;
                  }
                }
              } else {
                console.log("No existing production order number found, starting from 1");
              }

              // Format as 12-digit padded number (based on your EntityType definition)
              const paddedProdOrderNo = nextProdOrderNo.toString().padStart(12, '0');
              console.log("Next production order number:", paddedProdOrderNo);

              resolve(paddedProdOrderNo);
            },
            error: function (err) {
              console.error("Failed to read existing production order number:", err);
              reject("Failed to generate production order number");
            }
          });
        });
      },

      initializeProdOrderNumber: function () {
        const oView = this.getView();
        const oODataModel = oView.getModel("ZSB_PROD_HD_ITM_MSFG");

        return new Promise((resolve, reject) => {
          // First check if record exists
          oODataModel.read("/ZC_PROD_ORD_TEMP_MSFG", {
            success: function (oData) {
              if (oData.results && oData.results.length === 0) {
                // No record exists, create initial record
                const oPayload = {
                  Productionorders: "000000000000" // Start from 0 so first save becomes 1
                };

                oODataModel.create("/ZC_PROD_ORD_TEMP_MSFG", oPayload, {
                  success: function () {
                    console.log("Initialized production order number table with 000000000000");
                    resolve();
                  },
                  error: function (oError) {
                    console.error("Failed to initialize production order number:", oError);
                    reject(oError);
                  }
                });
              } else {
                console.log("Production order number table already initialized");
                resolve();
              }
            },
            error: function (err) {
              console.error("Failed to check production order number table:", err);
              reject(err);
            }
          });
        });
      },

      onApiPostButtonbatch: async function () {
        const oView = this.getView();
        const oTabModel = oView.getModel("TabModel");
        const oTableSaveModel = oView.getModel("ZSB_MOULD_PLAN");
        const oProdHeadItemModel = oView.getModel("ZSB_PROD_HD_ITM_MSFG");

        const aData = oTabModel.getProperty("/Samples");
        const aSelectedRows = aData.filter(row => row.__selected);

        // --- 🚫 BLOCKER VALIDATION (cannot proceed)
        if (aSelectedRows.length === 0) {
          sap.m.MessageToast.show("Please select at least one row.");
          return;
        }

        // Check for saved rows (sap_uuid)
        const aRowsWithoutUUID = aSelectedRows.filter(row => !row.sap_uuid);
        if (aRowsWithoutUUID.length > 0) {
          const sRowNumbers = aRowsWithoutUUID
            .map((row, index) => `Row ${index + 1}`)
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed for the following rows:\n\n${sRowNumbers}: Please save the row first`
          );
          return;
        }

        // Check for existing production orders
        const aRowsWithProdOrder = aSelectedRows.filter(row => {
          const val = row.productionorderno;
          return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
        });

        if (aRowsWithProdOrder.length > 0) {
          const sProdOrders = aRowsWithProdOrder
            .map(row => row.productionorderno || "(No Production Order)")
            .join(", ");
          sap.m.MessageBox.warning(
            `Cannot proceed due to the following issues:\n\nProduction Order(s) ${sProdOrders}: Already have valid Production Order Number assigned`
          );
          return;
        }

        // --- 🧪 VALIDATION (field completeness)
        let aValidationErrors = [];

        aSelectedRows.forEach((row, index) => {
          let missingFields = [];

          if (!row.materialcode || row.materialcode.trim() === "") {
            missingFields.push("Material Code");
          }
          if (!row.plant || row.plant.trim() === "") {
            missingFields.push("Plant");
          }
          if (!row.productionorderqty || row.productionorderqty <= 0) {
            missingFields.push("Production Order Quantity");
          }
          if (!row.productionordstartdate) {
            missingFields.push("Production Order Start Date");
          }
          if (!row.machinenumber || row.machinenumber.trim() === "") {
            missingFields.push("Machine Number");
          }

          if (missingFields.length > 0) {
            const sRowId = `Row ${index + 1}`;
            aValidationErrors.push(`${sRowId}: ${missingFields.join(", ")}`);
          }
        });

        if (aValidationErrors.length > 0) {
          sap.m.MessageBox.error(
            "Missing required fields:\n\n" + aValidationErrors.join("\n")
          );
          return;
        }

        // --- ✅ PROCESSING (all validations passed)
        sap.ui.core.BusyIndicator.show(0);

        // Sort selected rows
        const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
          const dateA = a.productionordstartdate;
          const dateB = b.productionordstartdate;

          if (dateA && dateB) {
            if (dateA > dateB) return -1;
            if (dateA < dateB) return 1;
          }

          const lotA = parseInt(a.bipllotno, 10) || 0;
          const lotB = parseInt(b.bipllotno, 10) || 0;
          return lotA - lotB;
        });

        // Arrays to collect results
        const aSuccessResults = [];
        const aErrorResults = [];
        let ProductionOrderNumber = null;
        let currentRecords = null;

        try {
          // ✅ First, read the current record from ZC_PROD_ORD_TEMP_MSFG
          currentRecords = await new Promise((resolve, reject) => {
            oProdHeadItemModel.read("/ZC_PROD_ORD_TEMP_MSFG", {
              success: function (oData) {
                resolve(oData.results || []);
              },
              error: function (err) {
                console.error("Failed to read current production order number:", err);
                reject(err);
              }
            });
          });

          // ✅ Generate the NEXT production order number
          ProductionOrderNumber = await this.generateProdOrderNo();
          console.log("Using production order number:", ProductionOrderNumber);

          // Prepare payload for ZSB_PROD_HD_ITM_MSFG
          const oPayload = {
            productionorders: ProductionOrderNumber,
            toitem: aSortedSelectedRows.map((row, index) => ({
              id: row.sap_uuid,
              Material: row.materialcode,
              Productionplant: row.plant,
              Manufacturingordertype: "ZMO1",
              Productionversion: row.machinenumber,
              Totalquantity: row.productionorderqty,
              Uom: row.uom,
              Mfgorderplannedstartdate: row.productionordstartdate ?
                new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
              Basicschedulingtype: "1",
            }))
          };

          console.log("Payload for ZSB_PROD_HD_ITM_MSFG:", JSON.stringify(oPayload, null, 2));

          // 1. Create Production Orders using ZSB_PROD_HD_ITM_MSFG service
          const oResponse = await new Promise((resolve, reject) => {
            oProdHeadItemModel.create("/header", oPayload, {
              success: function (odata) {
                console.log("Production Order Creation Success:", odata);
                resolve(odata);
              },
              error: function (oError) {
                console.error("Production Order Creation Error:", oError);
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                  try {
                    const oErrorResponse = JSON.parse(oError.responseText);
                    if (oErrorResponse.error && oErrorResponse.error.message) {
                      sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                    }
                  } catch (e) {
                    sErrorMessage = oError.responseText;
                  }
                }
                reject(new Error(sErrorMessage));
              }
            });
          });

          // ✅ Update the ZC_PROD_ORD_TEMP_MSFG table with the new production order number
          if (currentRecords.length > 0) {
            const currentRecord = currentRecords[0];
            const sPath = `/ZC_PROD_ORD_TEMP_MSFG('${currentRecord.Productionorders}')`;

            await new Promise((resolve, reject) => {
              oProdHeadItemModel.remove(sPath, {
                success: function () {
                  console.log("Deleted old production order number:", currentRecord.Productionorders);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to delete old production order number:", oError);
                  reject(oError);
                }
              });
            });

            const oCreatePayload = { Productionorders: ProductionOrderNumber };
            await new Promise((resolve, reject) => {
              oProdHeadItemModel.create("/ZC_PROD_ORD_TEMP_MSFG", oCreatePayload, {
                success: function () {
                  console.log("Successfully created new production order number:", ProductionOrderNumber);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to create new production order number:", oError);
                  reject(oError);
                }
              });
            });
          } else {
            const oCreatePayload = { Productionorders: ProductionOrderNumber };
            await new Promise((resolve, reject) => {
              oProdHeadItemModel.create("/ZC_PROD_ORD_TEMP_MSFG", oCreatePayload, {
                success: function () {
                  console.log("Successfully created production order number:", ProductionOrderNumber);
                  resolve();
                },
                error: function (oError) {
                  console.error("Failed to create production order number:", oError);
                  reject(oError);
                }
              });
            });
          }

          // Check response structure
          if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            throw new Error("Invalid response format: missing toitem results");
          }

          // Process each item response
          for (let i = 0; i < oResponse.toitem.results.length; i++) {
            const itemResponse = oResponse.toitem.results[i];
            const originalIndex = i;
            const originalRow = aSortedSelectedRows[originalIndex];
            const sRowId = `Row ${originalIndex + 1}`;
            const sBiplLotNo = originalRow.bipllotno || "(no bipl lot)";

            try {
              // Check for backend error first
              if (itemResponse.Errorresponse && itemResponse.Errorresponse.trim() !== "") {
                throw new Error(itemResponse.Errorresponse);
              }

              const sProdOrder = itemResponse.productionorder;
              const sStorageLoc = itemResponse.Storagelocation || "";

              if (!sProdOrder) {
                throw new Error("No production order returned in item response");
              }

              console.log(`Processing item ${i + 1}: Production Order = ${sProdOrder}, Storage Location = ${sStorageLoc}`);

              // 2. READ Operation - Batch Creation
              const batchKey = `00${sProdOrder}`;
              console.log(`Calling batch creation for key: ${batchKey}`);

              const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");
              const oBatchData = await new Promise((resolve, reject) => {
                oBatchModel.read(`/ZC_BATCH_CREATE('${batchKey}')`, {
                  success: function (odata) {
                    console.log("READ Success - Batch Creation:", odata);
                    if (!odata.Batch) {
                      reject(new Error("No batch number returned"));
                    } else {
                      resolve(odata);
                    }
                  },
                  error: function (oError) {
                    console.error("Batch creation failed:", oError);
                    reject(oError);
                  }
                });
              });

              const sBatchNo = oBatchData.Batch;
              console.log(`Generated batch number: ${sBatchNo} for production order: ${sProdOrder}`);

              // 3. UPDATE Operation - Mixing Plan
              const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${originalRow.sap_uuid}')`;
              const oUpdatePayload = {
                productionorderno: sProdOrder,
                lotbatchno: sBatchNo,
                storagelocation: sStorageLoc
              };

              console.log(`Updating mixing plan with key: ${sKeyPath}`, oUpdatePayload);

              await new Promise((resolve, reject) => {
                oTableSaveModel.update(sKeyPath, oUpdatePayload, {
                  merge: true,
                  success: function (odata) {
                    console.log("UPDATE Success - Mixing Plan:", odata);
                    resolve(odata);
                  },
                  error: function (oError) {
                    console.error("Mixing plan update failed:", oError);
                    reject(oError);
                  }
                });
              });

              // Add to success list
              aSuccessResults.push({
                rowId: sRowId,
                bipllotno: sBiplLotNo,
                sap_uuid: originalRow.sap_uuid,
                productionOrder: sProdOrder,
                batchNo: sBatchNo,
                storageLocation: sStorageLoc,
                materialCode: originalRow.materialcode
              });

            } catch (oError) {
              console.error(`❌ Processing Failed for ${sRowId} (Bipl: ${sBiplLotNo}):`, oError);

              let sErrorMessage = oError.message || "Unknown error";
              if (oError.responseText) {
                try {
                  const oErrorResponse = JSON.parse(oError.responseText);
                  if (oErrorResponse.error && oErrorResponse.error.message) {
                    sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                  }
                } catch (e) {
                  sErrorMessage = oError.responseText;
                }
              }

              aErrorResults.push({
                rowId: sRowId,
                bipllotno: sBiplLotNo,
                sap_uuid: originalRow.sap_uuid,
                error: sErrorMessage
              });
            }
          }

          // ✅ Update the local TabModel with successful rows
          aSuccessResults.forEach(result => {
            const idx = aData.findIndex(row => row.sap_uuid === result.sap_uuid);
            if (idx !== -1) {
              Object.assign(aData[idx], {
                productionorderno: result.productionOrder,
                lotbatchno: result.batchNo,
                storagelocation: result.storageLocation
              });
              console.log(`✅ Updated row with UUID: ${result.sap_uuid}`, {
                productionOrder: result.productionOrder,
                batchNo: result.batchNo,
                storageLocation: result.storageLocation
              });
            } else {
              console.error(`❌ Could not find row with UUID: ${result.sap_uuid}`);
            }
          });

          // Clear selection
          aSelectedRows.forEach(row => {
            row.__selected = false;
          });

          oTabModel.setProperty("/Samples", aData);
          oTabModel.refresh();

        } catch (oError) {
          console.error("❌ Production order creation failed:", oError);

          let sErrorMessage = oError.message || "Unknown error";
          if (oError.responseText) {
            try {
              const oErrorResponse = JSON.parse(oError.responseText);
              if (oErrorResponse.error && oErrorResponse.error.message) {
                sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
              }
            } catch (e) {
              sErrorMessage = oError.responseText;
            }
          }

          sap.m.MessageBox.error(`Production order creation failed: ${sErrorMessage}`);
          sap.ui.core.BusyIndicator.hide();
          return;
        }

        sap.ui.core.BusyIndicator.hide();

        // Show summary using the dedicated function
        this.showPostSummaryBatch(aSuccessResults, aErrorResults);
      },

      showPostSummaryBatch: function (aSuccessResults, aErrorResults) {
        const sTotal = aSuccessResults.length + aErrorResults.length;

        if (sTotal === 0) {
          return;
        }

        let sMessage = `API Post process completed for ${sTotal} row(s).\n\n`;
        let bHasSuccess = aSuccessResults.length > 0;
        let bHasFailed = aErrorResults.length > 0;

        if (bHasSuccess) {
          sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
          aSuccessResults.forEach(result => {
            sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno})`;
            if (result.productionOrder) {
              sMessage += ` → Prod. Order: ${result.productionOrder}`;
              if (result.batchNo) {
                sMessage += `, Batch: ${result.batchNo}`;
              }
              if (result.storageLocation) {
                sMessage += `, Storage: ${result.storageLocation}`;
              }
            }
            sMessage += `\n`;
          });
          sMessage += "\n";
        }

        if (bHasFailed) {
          sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
          aErrorResults.forEach(result => {
            sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}): ${result.error}\n`;
          });
        }

        // Show appropriate dialog
        setTimeout(() => {
          if (bHasFailed && !bHasSuccess) {
            // All failed
            sap.m.MessageBox.error(sMessage, {
              title: "API Post Process Failed"
            });
          } else if (bHasFailed && bHasSuccess) {
            // Partial success
            sap.m.MessageBox.warning(sMessage, {
              title: "API Post Process Partial Success",
              details: aErrorResults.map(f =>
                `${f.rowId} (Bipl: ${f.bipllotno})\nError: ${f.error}`
              ).join('\n\n')
            });
          } else {
            // All success
            sap.m.MessageBox.success(sMessage, {
              title: "API Post Process Successful"
            });
          }
        }, 100);
      },




      // onApiPostButton: async function () {
      //   const oView = this.getView();
      //   const oTabModel = oView.getModel("TabModel");
      //   const oMixingModel = oView.getModel("ZSB_MOULD_PLAN");
      //   const oPostModel = oView.getModel("ZSB_PRODUCT_ORD1");
      //   const oBatchModel = oView.getModel("ZSB_BATCH_CREATION");
      //   const oQtyModel = oView.getModel("ZSB_PROD_QTY");  // new model for quantity fetching

      //   const aData = oTabModel.getProperty("/Samples");
      //   const aSelectedRows = aData.filter(row => row.__selected);

      //   if (!aSelectedRows.length) {
      //     sap.m.MessageBox.warning("Please select at least one row.");
      //     return;
      //   }

      //   const aRowsWithUUID = aSelectedRows.filter(row => row.sap_uuid);

      //   if (!aRowsWithUUID.length) {
      //     sap.m.MessageBox.warning("Save the selected row first");
      //     return;
      //   }

      //   const aRowsWithProdOrder = aSelectedRows.filter(row => {
      //     const val = row.productionorderno;
      //     return val !== null && val !== undefined && val !== "" && val !== 0 && val !== "0";
      //   });

      //   if (aRowsWithProdOrder.length > 0) {
      //     sap.m.MessageBox.warning(
      //       "Some of the selected rows already have a valid Production Order Number assigned. Please deselect those rows before proceeding."
      //     );
      //     return;
      //   }

      //   sap.ui.core.BusyIndicator.show(0);

      //   const aUpdatedRows = [];

      //   for (let i = 0; i < aSelectedRows.length; i++) {
      //     const row = aSelectedRows[i];

      //     // Fetch production order qty from ZC_PROD_QTY entity using material code
      //     let productionOrderQty = row.productionorderqty;  // fallback if fetch fails

      //     try {
      //       // Assuming materialcode is the key or filter param here
      //       const qtyResult = await new Promise((resolve, reject) => {
      //         oQtyModel.read(`/ZC_PROD_QTY('${row.materialcode}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });
      //       if (qtyResult && qtyResult.Qty !== undefined) {
      //         productionOrderQty = qtyResult.Qty; // map Qty field to productionorderqty
      //       }
      //     } catch (qtyErr) {
      //       console.warn(`Could not fetch production order qty for material ${row.materialcode}`, qtyErr);
      //       // continue with original qty or zero if you want
      //     }

      //     const oPayload = {
      //       Material: row.materialcode,
      //       ProductionPlant: row.plant,
      //       ManufacturingOrderType: "ZMO1",
      //       ProductionVersion: row.machinenumber,
      //       TotalQuantity: productionOrderQty,
      //       MfgOrderPlannedStartDate: row.productionordstartdate ? new Date(row.productionordstartdate.toLocaleDateString('en-CA')) : null,
      //       BasicSchedulingType: "1"
      //     };

      //     try {
      //       const oPostData = await new Promise((resolve, reject) => {
      //         oPostModel.create("/ZC_PRODUCT_ORD1", oPayload, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sProdOrder = oPostData.Productionorder;
      //       const sStorageLoc = oPostData.StorageLocation;
      //       if (!sProdOrder) continue;

      //       const oBatchData = await new Promise((resolve, reject) => {
      //         oBatchModel.read(`/ZC_BATCH_CREATE('${'00' + sProdOrder}')`, {
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       const sBatchNo = oBatchData.Batch;
      //       if (!sBatchNo) continue;

      //       const sKeyPath = `/ZC_MOULD_PLAN(sap_uuid='${row.sap_uuid}')`;
      //       const oUpdatePayload = {
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc,
      //         productionorderqty: productionOrderQty  // update qty also in your model
      //       };

      //       await new Promise((resolve, reject) => {
      //         oMixingModel.update(sKeyPath, oUpdatePayload, {
      //           merge: true,
      //           success: resolve,
      //           error: reject
      //         });
      //       });

      //       aUpdatedRows.push({
      //         sap_uuid: row.sap_uuid,
      //         productionorderno: sProdOrder,
      //         lotbatchno: sBatchNo,
      //         storagelocation: sStorageLoc,
      //         productionordstartdate: row.productionordstartdate,
      //         plant: row.plant,
      //         materialcode: row.materialcode,
      //         productionorderqty: productionOrderQty
      //       });

      //     } catch (err) {
      //       console.error("Error processing row", row, err);
      //     }
      //   }

      //   // 🔄 Update TabModel with productionorderqty too
      //   aUpdatedRows.forEach(updated => {
      //     const idx = aData.findIndex(row => row.sap_uuid === updated.sap_uuid);
      //     if (idx !== -1) {
      //       Object.assign(aData[idx], updated);
      //     }
      //   });
      //   oTabModel.setProperty("/Samples", aData);
      //   oTabModel.refresh();

      //   sap.ui.core.BusyIndicator.hide();
      //   sap.m.MessageToast.show("All selected rows processed.");
      // },


    });
  }
);


