sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",
        "bando/util/jspdf/html2canvasmin",
        "bando/util/jspdf/jspdfmin",
        "bando/util/importfile/importexcelfile",
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, PDFLibjs, pdfjsLib, pdf, importexcelfile) {
        "use strict";

        return BaseController.extend("bando.controller.injection_moulding.WeightRoller.WeightRollerActual.WeightRollerActual", {
            onInit: function () {
                // console.log("hi")


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");

                this._selectedProductionOrders = [];
                this._selectedMaterials = [];



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("WeightRollerActual").attachMatched(this._onRouteMatched, this);

            },

            // _onRouteMatched: function () {
            //     // Clear filters
            //     // this.byId("idDateRange").setDateValue(null);
            //     // this.byId("idDateRange").setSecondDateValue(null);
            //     // this.byId("idPlant").setValue("");
            //     // this.byId("idMaterial").setValue("");
            //     // this.byId("idProductGroup").setValue("");

            //     // Optionally: clear or re-fetch table data
            //     this.getView().getModel("TabModel").setProperty("/Samples", []);
            //     this.HeaderModel = new sap.ui.model.json.JSONModel({

            //         HeaderData: {
            //             idDateRange: "",
            //             idPlant: "",
            //             idMaterial: "",
            //             // idProductGroup: "",
            //             idProductionorderno: "",

            //         }
            //     })

            //     this.getView().setModel(this.HeaderModel, "HeaderModel");
            // },



            _onRouteMatched: function () {
                // Clear table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);

                // Reset header model (if needed)
                this.HeaderModel = new sap.ui.model.json.JSONModel({
                    HeaderData: {
                        idDateRange: "",
                        idPlant: "",
                        idMaterial: "",
                        idProductionorderno: "",
                    }
                });
                this.getView().setModel(this.HeaderModel, "HeaderModel");

                // 🔥 CLEAR INPUT FIELDS BY ID (this is what fixes your issue)
                this.byId("idDateRange").setDateValue(null);
                this.byId("idDateRange").setSecondDateValue(null);

                this.byId("idPlant").setValue("");

                // this.byId("idMaterial").setValue("");
                var oMaterialInput = this.byId("idMaterial");
                oMaterialInput.setValue("");  // Clear the value
                oMaterialInput.removeAllTokens();  // Clear all tokens

                // this.byId("idProductionorderno").setValue("");
                var oPOInput = this.byId("idProductionorderno");
                oPOInput.setValue("");  // Clear the value
                oPOInput.removeAllTokens();  // Clear all tokens
            },



            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },


            numericComparator: function (a, b) {
                // Convert to integer; use 0 if conversion fails (e.g., empty or non-numeric)
                var numA = parseInt(a, 10) || 0;
                var numB = parseInt(b, 10) || 0;

                // Return negative if a < b, zero if equal, positive if a > b (ascending order)
                return numA - numB;
            },


            // GoWeightRollerActualfilter: function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oMaterial = oView.byId("idMaterial").getValue().trim();
            //     // const oProductGroup = oView.byId("idProductGroup").getValue().trim();
            //     const oProductionOrder = oView.byId("idProductionorderno").getValue().trim();

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required

            //     // && !oProductGroup
            //     if (
            //         !oStartDate && !oEndDate &&
            //         !oPlant && !oMaterial && !oProductionOrder
            //     ) {
            //         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];

            //     // Date Range filter (optional)
            //     // if (oStartDate && oEndDate) {
            //     //     const oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
            //     //         pattern: "yyyy-MM-ddTHH:mm:ss"
            //     //     });

            //     //     const sStartDate = oDateFormat.format(new Date(oStartDate.setHours(0, 0, 0, 0)));
            //     //     const sEndDate = oDateFormat.format(new Date(oEndDate.setHours(23, 59, 59, 999)));

            //     //     aFilters.push(new sap.ui.model.Filter({
            //     //         path: "productionordstartdate",
            //     //         operator: sap.ui.model.FilterOperator.BT,
            //     //         value1: sStartDate,
            //     //         value2: sEndDate
            //     //     }));
            //     // }

            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

            //         const sStartDate = oDateFormat.format(oStartDate); // 'yyyy-MM-dd'
            //         const sEndDate = oDateFormat.format(oEndDate);     // 'yyyy-MM-dd'

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }


            //     // Add filters only if values are entered
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }
            //     if (oMaterial) {
            //         aFilters.push(new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, oMaterial));
            //     }
            //     // if (oProductGroup) {
            //     //     aFilters.push(new sap.ui.model.Filter("productgroup", sap.ui.model.FilterOperator.EQ, oProductGroup));
            //     // }
            //     if (oProductionOrder) {
            //         aFilters.push(new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, oProductionOrder));
            //     }

            //     const oDynamicPage = this.byId("idWeightRollerActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();

            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             oTabModel.setProperty("/Samples", aFiltered);
            //             oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //             var Tab_SelectAll = new sap.ui.model.json.JSONModel({
            //                 Samples: {
            //                     selectall: false
            //                 }
            //             });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //         },
            //         error: function () {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");

            //             var Tab_SelectAll = new sap.ui.model.json.JSONModel({
            //                 Samples: {
            //                     selectall: false
            //                 }
            //             });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //         }
            //     });
            // },


            // GoWeightRollerActualfilter: function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();


            //     // const oMaterial = oView.byId("idMaterial").getValue().trim();
            //     const oMaterialInput = oView.byId("idMaterial");
            //     const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
            //     const aMaterials = aMaterialTokens.map(t => t.getKey());


            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     if (!oStartDate && !oEndDate && !oPlant && !aMaterials && aProductionOrders.length === 0) {
            //         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant and Material filters
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }
            //     // if (oMaterial) {
            //     //     aFilters.push(new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, oMaterial));
            //     // }
            //     // CHANGED: Material filter (multiple materials handled as OR) - same as production orders
            //     if (aMaterials.length > 0) {
            //         const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
            //         const oMaterialCombinedFilter = new sap.ui.model.Filter({
            //             filters: aMaterialFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oMaterialCombinedFilter);
            //     }
            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idWeightRollerActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();

            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             oTabModel.setProperty("/Samples", aFiltered);
            //             oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //         },
            //         error: function () {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            //         }
            //     });
            // },



            // GoWeightRollerActualfilter: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oShiftComboBox = oView.byId("idshift");
            //     const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

            //     const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

            //     // const oMaterial = oView.byId("idMaterial").getValue().trim();
            //     const oMaterialInput = oView.byId("idMaterial");
            //     const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
            //     const aMaterials = aMaterialTokens.map(t => t.getKey());

            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     if (!oStartDate && !oEndDate && !oPlant && !aMaterials && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
            //         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant filter
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }

            //     // Shift filter (if a shift is selected)
            //     if (sSelectedShift) {
            //         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
            //     }

            //     // BIPL LOT No filter - Added this section
            //     if (sBiplLotNo) {
            //         aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
            //     }

            //     // Material filter (multiple materials handled as OR)
            //     if (aMaterials.length > 0) {
            //         const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
            //         const oMaterialCombinedFilter = new sap.ui.model.Filter({
            //             filters: aMaterialFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oMaterialCombinedFilter);
            //     }

            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idWeightRollerActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Call the read function with increased limit
            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         filters: aFilters,
            //         urlParameters: {
            //             "$top": 10000  // Increased from default to 10,000 records
            //         },
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();

            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             oTabModel.setProperty("/Samples", aFiltered);
            //             oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Optional: Log how many records were loaded
            //             console.log("Loaded " + (aFiltered ? aFiltered.length : 0) + " records after filtering");

            //             // Call the callback if provided
            //             if (callback && typeof callback === 'function') {
            //                 callback(aFiltered);
            //             }

            //         }.bind(this),

            //         error: function (oError) {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Call callback with empty array on error
            //             if (callback && typeof callback === 'function') {
            //                 callback([]);
            //             }
            //         }
            //     });
            // },


// used till 15-07-202
            // GoWeightRollerActual: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oShiftComboBox = oView.byId("idshift");
            //     const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

            //     const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

            //     // const oMaterial = oView.byId("idMaterial").getValue().trim();
            //     const oMaterialInput = oView.byId("idMaterial");
            //     const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
            //     const aMaterials = aMaterialTokens.map(t => t.getKey());

            //     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     // if (!oStartDate && !oEndDate && !oPlant && !aMaterials && !oMachineNumber && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
            //     //     sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //     //     return;
            //     // }
            //     if (!oStartDate) {
            //         sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
            //         oDateRange.setValueState("Error");
            //         oDateRange.setValueStateText("Please select Production Order Start Date.");
            //         return;
            //     } else {
            //         oDateRange.setValueState("None");
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant filter
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }

            //     // Machine Number filter
            //     if (oMachineNumber) {
            //         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
            //     }

            //     // Shift filter (if a shift is selected)
            //     if (sSelectedShift) {
            //         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
            //     }

            //     // BIPL LOT No filter - Added this section
            //     if (sBiplLotNo) {
            //         aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
            //     }

            //     // Material filter (multiple materials handled as OR)
            //     if (aMaterials.length > 0) {
            //         const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
            //         const oMaterialCombinedFilter = new sap.ui.model.Filter({
            //             filters: aMaterialFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oMaterialCombinedFilter);
            //     }

            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idWeightRollerActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Call the read function with increased limit
            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         filters: aFilters,
            //         urlParameters: {
            //             "$top": 10000,
            //         },
            //         success: function (oData) {
            //             // Debug point 1 - we're in the first success callback
            //             // debugger;
            //             console.log("First OData call successful, processing results...");

            //             // First filter: Remove rows with invalid production order numbers
            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             // Log all production orders that were loaded
            //             const allProductionOrders = aFiltered.map(row => row.productionorderno);
            //             console.log("All loaded production orders:", {
            //                 allloadedprodorders: [...new Set(allProductionOrders)],
            //                 totalRows: aFiltered.length,
            //                 uniqueOrders: [...new Set(allProductionOrders)].length
            //             });

            //             // If no rows after initial filtering, show empty table
            //             if (aFiltered.length === 0) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 oTabModel.setProperty("/Samples", []);
            //                 oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                 if (callback && typeof callback === 'function') {
            //                     callback([]);
            //                 }
            //                 return;
            //             }

            //             // Get all unique production order numbers
            //             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

            //             const aOrderFilters = aUniqueOrders.map(order =>
            //                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            //             );
            //             const oOrderOrFilter = new sap.ui.model.Filter({
            //                 filters: aOrderFilters,
            //                 and: false // OR logic
            //             });

            //             // Combine with AND conditions for I0045 and active status
            //             const aFinalFilters = [
            //                 oOrderOrFilter,
            //                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
            //                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            //             ];

            //             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
            //             console.log("Unique orders being checked:", {
            //                 uniqueOrders: aUniqueOrders,
            //                 count: aUniqueOrders.length
            //             });

            //             // Make the second OData call – now returns only orders with active I0045
            //             oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //                 filters: aFinalFilters,
            //                 urlParameters: {
            //                     "$top": 10000  // still safe – only active I0045 records are returned
            //                 },
            //                 success: function (oStatusData) {
            //                     // The result contains only orders that have active I0045 status
            //                     const ordersWithActiveI0045 = new Set(
            //                         oStatusData.results.map(item => item.ManufacturingOrder)
            //                     );

            //                     console.log("Orders with active I0045 (to be excluded):", {
            //                         statusfilteredout: Array.from(ordersWithActiveI0045),
            //                         count: ordersWithActiveI0045.size
            //                     });

            //                     // Filter out rows belonging to those orders
            //                     const aFilteredByStatus = aFiltered.filter(row =>
            //                         !ordersWithActiveI0045.has(row.productionorderno)
            //                     );

            //                     // Log final results
            //                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
            //                     console.log("Final production orders after filtering:", {
            //                         remainingprodorders: [...new Set(finalProductionOrders)],
            //                         totalRemainingRows: aFilteredByStatus.length,
            //                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
            //                     });

            //                     // Summary log
            //                     console.log("=== SUMMARY ===");
            //                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
            //                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
            //                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

            //                     sap.ui.core.BusyIndicator.hide();

            //                     oTabModel.setProperty("/Samples", aFilteredByStatus);
            //                     oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
            //                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFilteredByStatus);
            //                     }
            //                 },
            //                 error: function (oError) {
            //                     // Debug point 3 - second OData call error
            //                     // debugger;
            //                     sap.ui.core.BusyIndicator.hide();
            //                     console.error("Error checking order status:", oError);

            //                     // If there's an error checking status, show all rows (don't filter)
            //                     oTabModel.setProperty("/Samples", aFiltered);
            //                     oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFiltered);
            //                     }
            //                 }
            //             });
            //         },
            //         error: function (oError) {
            //             // Debug point 4 - first OData call error
            //             // debugger;
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Call callback with empty array on error
            //             if (callback && typeof callback === 'function') {
            //                 callback([]);
            //             }
            //         }
            //     });
            // },
            // GoWeightRollerActualfilter: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
            //     const oTabModel = oView.getModel("TabModel");     // Local model
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

            //     // Get filter inputs
            //     const oDateRange = oView.byId("idDateRange");
            //     const oPlant = oView.byId("idPlant").getValue().trim();
            //     const oShiftComboBox = oView.byId("idshift");
            //     const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

            //     const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

            //     // const oMaterial = oView.byId("idMaterial").getValue().trim();
            //     const oMaterialInput = oView.byId("idMaterial");
            //     const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
            //     const aMaterials = aMaterialTokens.map(t => t.getKey());

            //     const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

            //     const oMI = oView.byId("idProductionorderno");
            //     const aTokens = oMI.getTokens(); // array of sap.m.Token
            //     const aProductionOrders = aTokens.map(t => t.getKey());

            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     // At least one filter is required
            //     if (!oStartDate && !oEndDate && !oPlant && !aMaterials && !oMachineNumber && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
            //         sap.m.MessageBox.warning("Please enter at least one filter criteria.");
            //         return;
            //     }

            //     const aFilters = [];

            //     // Date range filter
            //     if (oStartDate && oEndDate) {
            //         const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
            //         const sStartDate = oDateFormat.format(oStartDate);
            //         const sEndDate = oDateFormat.format(oEndDate);

            //         aFilters.push(new sap.ui.model.Filter({
            //             path: "productionordstartdate",
            //             operator: sap.ui.model.FilterOperator.BT,
            //             value1: sStartDate,
            //             value2: sEndDate
            //         }));
            //     }

            //     // Plant filter
            //     if (oPlant) {
            //         aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
            //     }

            //     // Machine Number filter
            //     if (oMachineNumber) {
            //         aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
            //     }

            //     // Shift filter (if a shift is selected)
            //     if (sSelectedShift) {
            //         aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
            //     }

            //     // BIPL LOT No filter - Added this section
            //     if (sBiplLotNo) {
            //         aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
            //     }

            //     // Material filter (multiple materials handled as OR)
            //     if (aMaterials.length > 0) {
            //         const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
            //         const oMaterialCombinedFilter = new sap.ui.model.Filter({
            //             filters: aMaterialFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oMaterialCombinedFilter);
            //     }

            //     // Production order filter (multiple POs handled as OR)
            //     if (aProductionOrders.length > 0) {
            //         const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
            //         const oPOCombinedFilter = new sap.ui.model.Filter({
            //             filters: aPOFilters,
            //             and: false // OR logic
            //         });
            //         aFilters.push(oPOCombinedFilter);
            //     }

            //     const oDynamicPage = this.byId("idWeightRollerActualDynamic");
            //     if (oDynamicPage) {
            //         oDynamicPage.setShowFooter(true);
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Call the read function with increased limit
            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         filters: aFilters,
            //         urlParameters: {
            //             "$top": 10000,
            //         },
            //         success: function (oData) {
            //             // Debug point 1 - we're in the first success callback
            //             // debugger;
            //             console.log("First OData call successful, processing results...");

            //             // First filter: Remove rows with invalid production order numbers
            //             const aFiltered = oData.results.filter(row => {
            //                 const prodOrder = row.productionorderno;
            //                 return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
            //             });

            //             // Log all production orders that were loaded
            //             const allProductionOrders = aFiltered.map(row => row.productionorderno);
            //             console.log("All loaded production orders:", {
            //                 allloadedprodorders: [...new Set(allProductionOrders)],
            //                 totalRows: aFiltered.length,
            //                 uniqueOrders: [...new Set(allProductionOrders)].length
            //             });

            //             // If no rows after initial filtering, show empty table
            //             if (aFiltered.length === 0) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 oTabModel.setProperty("/Samples", []);
            //                 oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                 const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                 oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                 if (callback && typeof callback === 'function') {
            //                     callback([]);
            //                 }
            //                 return;
            //             }

            //             // Get all unique production order numbers
            //             const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

            //             const aOrderFilters = aUniqueOrders.map(order =>
            //                 new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
            //             );
            //             const oOrderOrFilter = new sap.ui.model.Filter({
            //                 filters: aOrderFilters,
            //                 and: false // OR logic
            //             });

            //             // Combine with AND conditions for I0045 and active status
            //             const aFinalFilters = [
            //                 oOrderOrFilter,
            //                 new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
            //                 new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
            //             ];

            //             console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
            //             console.log("Unique orders being checked:", {
            //                 uniqueOrders: aUniqueOrders,
            //                 count: aUniqueOrders.length
            //             });

            //             // Make the second OData call – now returns only orders with active I0045
            //             oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //                 filters: aFinalFilters,
            //                 urlParameters: {
            //                     "$top": 10000  // still safe – only active I0045 records are returned
            //                 },
            //                 success: function (oStatusData) {
            //                     // The result contains only orders that have active I0045 status
            //                     const ordersWithActiveI0045 = new Set(
            //                         oStatusData.results.map(item => item.ManufacturingOrder)
            //                     );

            //                     console.log("Orders with active I0045 (to be excluded):", {
            //                         statusfilteredout: Array.from(ordersWithActiveI0045),
            //                         count: ordersWithActiveI0045.size
            //                     });

            //                     // Filter out rows belonging to those orders
            //                     const aFilteredByStatus = aFiltered.filter(row =>
            //                         !ordersWithActiveI0045.has(row.productionorderno)
            //                     );

            //                     // Log final results
            //                     const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
            //                     console.log("Final production orders after filtering:", {
            //                         remainingprodorders: [...new Set(finalProductionOrders)],
            //                         totalRemainingRows: aFilteredByStatus.length,
            //                         uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
            //                     });

            //                     // Summary log
            //                     console.log("=== SUMMARY ===");
            //                     console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
            //                     console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
            //                     console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

            //                     sap.ui.core.BusyIndicator.hide();

            //                     oTabModel.setProperty("/Samples", aFilteredByStatus);
            //                     oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
            //                         (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFilteredByStatus);
            //                     }
            //                 },
            //                 error: function (oError) {
            //                     // Debug point 3 - second OData call error
            //                     // debugger;
            //                     sap.ui.core.BusyIndicator.hide();
            //                     console.error("Error checking order status:", oError);

            //                     // If there's an error checking status, show all rows (don't filter)
            //                     oTabModel.setProperty("/Samples", aFiltered);
            //                     oView.byId("idWeighrollerActualtablescreen").setVisible(true);

            //                     const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //                     oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //                     console.log("Error checking status. Showing all " + aFiltered.length + " records");

            //                     if (callback && typeof callback === 'function') {
            //                         callback(aFiltered);
            //                     }
            //                 }
            //             });
            //         },
            //         error: function (oError) {
            //             // Debug point 4 - first OData call error
            //             // debugger;
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);

            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");

            //             // Call callback with empty array on error
            //             if (callback && typeof callback === 'function') {
            //                 callback([]);
            //             }
            //         }
            //     });
            // },



            GoWeightRollerActual: function (callback) {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
                const oTabModel = oView.getModel("TabModel");     // Local model
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

                // Get filter inputs
                const oDateRange = oView.byId("idDateRange");
                const oPlant = oView.byId("idPlant").getValue().trim();
                const oShiftComboBox = oView.byId("idshift");
                const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

                const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

                const oMaterialInput = oView.byId("idMaterial");
                const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
                const aMaterials = aMaterialTokens.map(t => t.getKey());

                const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

                const oMI = oView.byId("idProductionorderno");
                const aTokens = oMI.getTokens(); // array of sap.m.Token
                const aProductionOrders = aTokens.map(t => t.getKey());

                const oStartDate = oDateRange.getDateValue();
                const oEndDate = oDateRange.getSecondDateValue();

                // Validate date
                if (!oStartDate) {
                    sap.m.MessageBox.warning("Production Order Start Date is mandatory.");
                    oDateRange.setValueState("Error");
                    oDateRange.setValueStateText("Please select Production Order Start Date.");
                    return;
                } else {
                    oDateRange.setValueState("None");
                }

                const aFilters = [];

                // Date range filter
                if (oStartDate && oEndDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    const sStartDate = oDateFormat.format(oStartDate);
                    const sEndDate = oDateFormat.format(oEndDate);

                    aFilters.push(new sap.ui.model.Filter({
                        path: "productionordstartdate",
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: sStartDate,
                        value2: sEndDate
                    }));
                }

                // Plant filter
                if (oPlant) {
                    aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
                }

                // Machine Number filter
                if (oMachineNumber) {
                    aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
                }

                // Shift filter (if a shift is selected)
                if (sSelectedShift) {
                    aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
                }

                // BIPL LOT No filter
                if (sBiplLotNo) {
                    aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
                }

                // Material filter (multiple materials handled as OR)
                if (aMaterials.length > 0) {
                    const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
                    const oMaterialCombinedFilter = new sap.ui.model.Filter({
                        filters: aMaterialFilters,
                        and: false // OR logic
                    });
                    aFilters.push(oMaterialCombinedFilter);
                }

                // Production order filter (multiple POs handled as OR)
                if (aProductionOrders.length > 0) {
                    const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
                    const oPOCombinedFilter = new sap.ui.model.Filter({
                        filters: aPOFilters,
                        and: false // OR logic
                    });
                    aFilters.push(oPOCombinedFilter);
                }

                const oDynamicPage = this.byId("idWeightRollerActualDynamic");
                if (oDynamicPage) {
                    oDynamicPage.setShowFooter(true);
                }

                sap.ui.core.BusyIndicator.show(0);

                // ------------------------------
                // PAGINATION HELPER (fetch all pages)
                // ------------------------------
                function fetchAllPages(model, entitySet, filters, pageSize) {
                    return new Promise(function (resolve, reject) {
                        let allResults = [];
                        let skip = 0;
                        let totalCount = null;

                        function readPage() {
                            model.read(entitySet, {
                                filters: filters,
                                urlParameters: {
                                    "$top": pageSize,
                                    "$skip": skip,
                                    "$inlinecount": "allpages"   // optional but useful
                                },
                                success: function (oData) {
                                    const results = oData.results || [];
                                    allResults = allResults.concat(results);

                                    // Determine if we have more data
                                    let hasMore = false;
                                    if (oData.__count !== undefined) {
                                        totalCount = parseInt(oData.__count, 10);
                                        hasMore = (skip + pageSize) < totalCount;
                                    } else {
                                        // Fallback: if this page has exactly 'pageSize' rows, assume there is more
                                        hasMore = (results.length === pageSize);
                                    }

                                    if (hasMore) {
                                        skip += pageSize;
                                        readPage(); // fetch next page
                                    } else {
                                        resolve(allResults);
                                    }
                                },
                                error: function (oError) {
                                    reject(oError);
                                }
                            });
                        }

                        readPage();
                    });
                }

                // Use the helper to fetch all rows with pagination (page size = 1000)
                fetchAllPages(oModel, "/ZC_WEIGTHROLLER_PLAN", aFilters, 1000)
                    .then(function (allRows) {
                        console.log("Total rows fetched (all pages):", allRows.length);

                        // First filter: Remove rows with invalid production order numbers
                        const aFiltered = allRows.filter(row => {
                            const prodOrder = row.productionorderno;
                            return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
                        });

                        // Log all production orders that were loaded
                        const allProductionOrders = aFiltered.map(row => row.productionorderno);
                        console.log("All loaded production orders:", {
                            allloadedprodorders: [...new Set(allProductionOrders)],
                            totalRows: aFiltered.length,
                            uniqueOrders: [...new Set(allProductionOrders)].length
                        });

                        // If no rows after initial filtering, show empty table
                        if (aFiltered.length === 0) {
                            sap.ui.core.BusyIndicator.hide();
                            oTabModel.setProperty("/Samples", []);
                            oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                            oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                            if (callback && typeof callback === 'function') {
                                callback([]);
                            }
                            return;
                        }

                        // Get all unique production order numbers
                        const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

                        // ----- OPTIMIZED STATUS CHECK (with pagination) -----
                        // Build an OR filter for all unique orders
                        const aOrderFilters = aUniqueOrders.map(order =>
                            new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
                        );
                        const oOrderOrFilter = new sap.ui.model.Filter({
                            filters: aOrderFilters,
                            and: false // OR logic
                        });

                        // Combine with AND conditions for I0045 and active status
                        const aFinalFilters = [
                            oOrderOrFilter,
                            new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                            new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
                        ];

                        console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
                        console.log("Unique orders being checked:", {
                            uniqueOrders: aUniqueOrders,
                            count: aUniqueOrders.length
                        });

                        // Use pagination for the status check as well
                        fetchAllPages(oOrderCreationModel, "/ZC_ORDER_CREATION1", aFinalFilters, 1000)
                            .then(function (statusRows) {
                                // The result contains only orders that have active I0045 status
                                const ordersWithActiveI0045 = new Set(
                                    statusRows.map(item => item.ManufacturingOrder)
                                );

                                console.log("Orders with active I0045 (to be excluded):", {
                                    statusfilteredout: Array.from(ordersWithActiveI0045),
                                    count: ordersWithActiveI0045.size
                                });

                                // Filter out rows belonging to those orders
                                const aFilteredByStatus = aFiltered.filter(row =>
                                    !ordersWithActiveI0045.has(row.productionorderno)
                                );

                                // Log final results
                                const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
                                console.log("Final production orders after filtering:", {
                                    remainingprodorders: [...new Set(finalProductionOrders)],
                                    totalRemainingRows: aFilteredByStatus.length,
                                    uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
                                });

                                // Summary log
                                console.log("=== SUMMARY ===");
                                console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
                                console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
                                console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

                                sap.ui.core.BusyIndicator.hide();

                                oTabModel.setProperty("/Samples", aFilteredByStatus);
                                oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                                oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                                console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
                                    (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

                                if (callback && typeof callback === 'function') {
                                    callback(aFilteredByStatus);
                                }
                            })
                            .catch(function (oError) {
                                // Error in status check
                                sap.ui.core.BusyIndicator.hide();
                                console.error("Error checking order status:", oError);

                                // If there's an error checking status, show all rows (don't filter)
                                oTabModel.setProperty("/Samples", aFiltered);
                                oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                                oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                                console.log("Error checking status. Showing all " + aFiltered.length + " records");

                                if (callback && typeof callback === 'function') {
                                    callback(aFiltered);
                                }
                            });
                    })
                    .catch(function (oError) {
                        // Error in the first OData call (fetching weight roller plan)
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");
                        console.error("OData read error (pagination):", oError);

                        const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                        if (callback && typeof callback === 'function') {
                            callback([]);
                        }
                    });
            },

            GoWeightRollerActualfilter: function (callback) {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // OData model
                const oTabModel = oView.getModel("TabModel");     // Local model
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Model for status check

                // Get filter inputs
                const oDateRange = oView.byId("idDateRange");
                const oPlant = oView.byId("idPlant").getValue().trim();
                const oShiftComboBox = oView.byId("idshift");
                const sSelectedShift = oShiftComboBox.getSelectedKey(); // Get selected shift (A, B, or C)

                const sBiplLotNo = oView.byId("idBiplLotNo").getValue().trim();

                const oMaterialInput = oView.byId("idMaterial");
                const aMaterialTokens = oMaterialInput.getTokens(); // array of sap.m.Token
                const aMaterials = aMaterialTokens.map(t => t.getKey());

                const oMachineNumber = oView.byId("idMachineNumber").getValue().trim();

                const oMI = oView.byId("idProductionorderno");
                const aTokens = oMI.getTokens(); // array of sap.m.Token
                const aProductionOrders = aTokens.map(t => t.getKey());

                const oStartDate = oDateRange.getDateValue();
                const oEndDate = oDateRange.getSecondDateValue();

                // At least one filter is required
                if (!oStartDate && !oEndDate && !oPlant && !aMaterials && !oMachineNumber && aProductionOrders.length === 0 && !sSelectedShift && !sBiplLotNo) {
                    sap.m.MessageBox.warning("Please enter at least one filter criteria.");
                    return;
                }

                const aFilters = [];

                // Date range filter
                if (oStartDate && oEndDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    const sStartDate = oDateFormat.format(oStartDate);
                    const sEndDate = oDateFormat.format(oEndDate);

                    aFilters.push(new sap.ui.model.Filter({
                        path: "productionordstartdate",
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: sStartDate,
                        value2: sEndDate
                    }));
                }

                // Plant filter
                if (oPlant) {
                    aFilters.push(new sap.ui.model.Filter("plant", sap.ui.model.FilterOperator.EQ, oPlant));
                }

                // Machine Number filter
                if (oMachineNumber) {
                    aFilters.push(new sap.ui.model.Filter("machinenumber", sap.ui.model.FilterOperator.EQ, oMachineNumber));
                }

                // Shift filter (if a shift is selected)
                if (sSelectedShift) {
                    aFilters.push(new sap.ui.model.Filter("shift", sap.ui.model.FilterOperator.EQ, sSelectedShift));
                }

                // BIPL LOT No filter
                if (sBiplLotNo) {
                    aFilters.push(new sap.ui.model.Filter("bipllotno", sap.ui.model.FilterOperator.EQ, sBiplLotNo));
                }

                // Material filter (multiple materials handled as OR)
                if (aMaterials.length > 0) {
                    const aMaterialFilters = aMaterials.map(material => new sap.ui.model.Filter("materialcode", sap.ui.model.FilterOperator.EQ, material));
                    const oMaterialCombinedFilter = new sap.ui.model.Filter({
                        filters: aMaterialFilters,
                        and: false // OR logic
                    });
                    aFilters.push(oMaterialCombinedFilter);
                }

                // Production order filter (multiple POs handled as OR)
                if (aProductionOrders.length > 0) {
                    const aPOFilters = aProductionOrders.map(po => new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.EQ, po));
                    const oPOCombinedFilter = new sap.ui.model.Filter({
                        filters: aPOFilters,
                        and: false // OR logic
                    });
                    aFilters.push(oPOCombinedFilter);
                }

                const oDynamicPage = this.byId("idWeightRollerActualDynamic");
                if (oDynamicPage) {
                    oDynamicPage.setShowFooter(true);
                }

                sap.ui.core.BusyIndicator.show(0);

                // ------------------------------
                // PAGINATION HELPER (fetch all pages)
                // ------------------------------
                function fetchAllPages(model, entitySet, filters, pageSize) {
                    return new Promise(function (resolve, reject) {
                        let allResults = [];
                        let skip = 0;
                        let totalCount = null;

                        function readPage() {
                            model.read(entitySet, {
                                filters: filters,
                                urlParameters: {
                                    "$top": pageSize,
                                    "$skip": skip,
                                    "$inlinecount": "allpages"   // optional but useful
                                },
                                success: function (oData) {
                                    const results = oData.results || [];
                                    allResults = allResults.concat(results);

                                    // Determine if we have more data
                                    let hasMore = false;
                                    if (oData.__count !== undefined) {
                                        totalCount = parseInt(oData.__count, 10);
                                        hasMore = (skip + pageSize) < totalCount;
                                    } else {
                                        // Fallback: if this page has exactly 'pageSize' rows, assume there is more
                                        hasMore = (results.length === pageSize);
                                    }

                                    if (hasMore) {
                                        skip += pageSize;
                                        readPage(); // fetch next page
                                    } else {
                                        resolve(allResults);
                                    }
                                },
                                error: function (oError) {
                                    reject(oError);
                                }
                            });
                        }

                        readPage();
                    });
                }

                // Use the helper to fetch all rows with pagination (page size = 1000)
                fetchAllPages(oModel, "/ZC_WEIGTHROLLER_PLAN", aFilters, 1000)
                    .then(function (allRows) {
                        console.log("Total rows fetched (all pages):", allRows.length);

                        // First filter: Remove rows with invalid production order numbers
                        const aFiltered = allRows.filter(row => {
                            const prodOrder = row.productionorderno;
                            return prodOrder && prodOrder !== "0" && !/^0+$/.test(prodOrder);
                        });

                        // Log all production orders that were loaded
                        const allProductionOrders = aFiltered.map(row => row.productionorderno);
                        console.log("All loaded production orders:", {
                            allloadedprodorders: [...new Set(allProductionOrders)],
                            totalRows: aFiltered.length,
                            uniqueOrders: [...new Set(allProductionOrders)].length
                        });

                        // If no rows after initial filtering, show empty table
                        if (aFiltered.length === 0) {
                            sap.ui.core.BusyIndicator.hide();
                            oTabModel.setProperty("/Samples", []);
                            oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                            const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                            oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                            if (callback && typeof callback === 'function') {
                                callback([]);
                            }
                            return;
                        }

                        // Get all unique production order numbers
                        const aUniqueOrders = [...new Set(aFiltered.map(row => row.productionorderno))];

                        // ----- OPTIMIZED STATUS CHECK (with pagination) -----
                        // Build an OR filter for all unique orders
                        const aOrderFilters = aUniqueOrders.map(order =>
                            new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, order)
                        );
                        const oOrderOrFilter = new sap.ui.model.Filter({
                            filters: aOrderFilters,
                            and: false // OR logic
                        });

                        // Combine with AND conditions for I0045 and active status
                        const aFinalFilters = [
                            oOrderOrFilter,
                            new sap.ui.model.Filter("StatusCode", sap.ui.model.FilterOperator.EQ, "I0045"),
                            new sap.ui.model.Filter("StatusIsActive", sap.ui.model.FilterOperator.EQ, true)
                        ];

                        console.log("Checking TECO status for " + aUniqueOrders.length + " unique orders...");
                        console.log("Unique orders being checked:", {
                            uniqueOrders: aUniqueOrders,
                            count: aUniqueOrders.length
                        });

                        // Use pagination for the status check as well
                        fetchAllPages(oOrderCreationModel, "/ZC_ORDER_CREATION1", aFinalFilters, 1000)
                            .then(function (statusRows) {
                                // The result contains only orders that have active I0045 status
                                const ordersWithActiveI0045 = new Set(
                                    statusRows.map(item => item.ManufacturingOrder)
                                );

                                console.log("Orders with active I0045 (to be excluded):", {
                                    statusfilteredout: Array.from(ordersWithActiveI0045),
                                    count: ordersWithActiveI0045.size
                                });

                                // Filter out rows belonging to those orders
                                const aFilteredByStatus = aFiltered.filter(row =>
                                    !ordersWithActiveI0045.has(row.productionorderno)
                                );

                                // Log final results
                                const finalProductionOrders = aFilteredByStatus.map(row => row.productionorderno);
                                console.log("Final production orders after filtering:", {
                                    remainingprodorders: [...new Set(finalProductionOrders)],
                                    totalRemainingRows: aFilteredByStatus.length,
                                    uniqueRemainingOrders: [...new Set(finalProductionOrders)].length
                                });

                                // Summary log
                                console.log("=== SUMMARY ===");
                                console.log("Initial loaded orders:", allProductionOrders.length + " rows, " + [...new Set(allProductionOrders)].length + " unique orders");
                                console.log("Filtered out orders with active I0045:", ordersWithActiveI0045.size + " orders");
                                console.log("Final orders after filtering:", aFilteredByStatus.length + " rows, " + [...new Set(finalProductionOrders)].length + " unique orders");

                                sap.ui.core.BusyIndicator.hide();

                                oTabModel.setProperty("/Samples", aFilteredByStatus);
                                oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                                oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                                console.log("Loaded " + aFilteredByStatus.length + " records after filtering out " +
                                    (aFiltered.length - aFilteredByStatus.length) + " rows with active I0045 status");

                                if (callback && typeof callback === 'function') {
                                    callback(aFilteredByStatus);
                                }
                            })
                            .catch(function (oError) {
                                // Error in status check
                                sap.ui.core.BusyIndicator.hide();
                                console.error("Error checking order status:", oError);

                                // If there's an error checking status, show all rows (don't filter)
                                oTabModel.setProperty("/Samples", aFiltered);
                                oView.byId("idWeighrollerActualtablescreen").setVisible(true);

                                const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                                oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                                console.log("Error checking status. Showing all " + aFiltered.length + " records");

                                if (callback && typeof callback === 'function') {
                                    callback(aFiltered);
                                }
                            });
                    })
                    .catch(function (oError) {
                        // Error in the first OData call (fetching weight roller plan)
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");
                        console.error("OData read error (pagination):", oError);

                        const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                        if (callback && typeof callback === 'function') {
                            callback([]);
                        }
                    });
            },
            applyAllFilters: function () {
                const oView = this.getView();
                const oReleaseCombo = oView.byId("comboReleaseStatusFilter");
                const oGICombo = oView.byId("comboGIStatusFilter");
                const oGRCombo = oView.byId("comboGRStatusFilter");
                const oConfirmedQtyCombo = oView.byId("comboConfirmedQtyFilter");

                const sRelease = oReleaseCombo.getSelectedKey();
                const sGI = oGICombo.getSelectedKey();
                const sGR = oGRCombo.getSelectedKey();
                const sConfirmedQty = oConfirmedQtyCombo.getSelectedKey();

                // If all filters are "All", just reload full data without extra filtering
                if ((!sRelease || sRelease === "") &&
                    (!sGI || sGI === "") &&
                    (!sGR || sGR === "") &&
                    (!sConfirmedQty || sConfirmedQty === "")) {
                    this.GoMixingActualfilter();
                    return;
                }

                // Show loading indicator
                sap.ui.core.BusyIndicator.show(0);

                // Fetch fresh data (respects main search filters) and then apply status filters
                this.GoWeightRollerActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Apply all three filters in one pass (AND condition)
                    const aFilteredData = fetchedData.filter(item => {
                        // ----- Release Status filter -----
                        let releaseOk = true;
                        if (sRelease && sRelease !== "") {
                            if (sRelease === "RELEASED") {
                                releaseOk = item.releasestatus === "RELEASED";
                            } else { // UNRELEASED
                                releaseOk = !item.releasestatus ||
                                    item.releasestatus.trim() === "" ||
                                    item.releasestatus === " ";
                            }
                        }

                        // ----- GI Status filter -----
                        let giOk = true;
                        if (sGI && sGI !== "") {
                            const giVal = item.gicnfmaterialdocnumber;
                            if (sGI === "COMPLETED") {
                                giOk = giVal && giVal.trim() !== "" && giVal !== "0";
                            } else { // NOT_COMPLETED
                                giOk = !giVal || giVal.trim() === "" || giVal === "0";
                            }
                        }

                        // ----- GR Status filter -----
                        let grOk = true;
                        if (sGR && sGR !== "") {
                            const grVal = item.grmaterialdocnumber;
                            if (sGR === "COMPLETED") {
                                grOk = grVal && grVal.trim() !== "" && grVal !== "0";
                            } else { // NOT_COMPLETED
                                grOk = !grVal || grVal.trim() === "" || grVal === "0";
                            }
                        }

                        // ----- Confirmed Quantity filter -----
                        let confirmedQtyOk = true;
                        if (sConfirmedQty && sConfirmedQty !== "") {
                            const qty = item.confirmedqty; // comes as string
                            const isFilled = qty && qty.trim() !== "" &&
                                !isNaN(parseFloat(qty)) &&
                                parseFloat(qty) !== 0;

                            if (sConfirmedQty === "FILLED") {
                                confirmedQtyOk = isFilled;
                            } else { // NOT_FILLED
                                confirmedQtyOk = !isFilled;
                            }
                        }

                        // All must be true
                        return releaseOk && giOk && grOk && confirmedQtyOk;
                    });

                    // Update the table model
                    const oTabModel = oView.getModel("TabModel");
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Optional: show summary
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} records`);
                });
            },

            onFilterConfirmedQty: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboConfirmedQtyFilter");
                const sSelectedFilter = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected, reload the full data
                if (!sSelectedFilter || sSelectedFilter === "") {
                    this.GoWeightRollerActualfilter();
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                // Fetch data (via your existing GoWeightRollerActualfilter) and apply client‑side filter
                this.GoWeightRollerActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter logic for "FILLED" vs "NOT_FILLED"
                    const aFilteredData = fetchedData.filter(item => {
                        const qty = item.confirmedqty; // value comes as string
                        const isFilled = (qty && qty.trim() !== "" &&
                            !isNaN(parseFloat(qty)) &&
                            parseFloat(qty) !== 0);

                        return sSelectedFilter === "FILLED" ? isFilled : !isFilled;
                    });

                    // Update the model with filtered data
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show result summary
                    const sFilterText = sSelectedFilter === "FILLED" ? "Filled" : "Not Filled";
                    sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} ${sFilterText} records`);
                });
            },


            onFilterReleaseStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboReleaseStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoWeightRollerActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoWeightRollerActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected status
                    const aFilteredData = fetchedData.filter(item => {
                        if (sSelectedStatus === "RELEASED") {
                            // For released: status must be exactly "RELEASED"
                            return item.releasestatus === "RELEASED";
                        } else {
                            // For unreleased: status is empty, null, undefined, or just whitespace
                            return !item.releasestatus ||
                                item.releasestatus.trim() === "" ||
                                item.releasestatus === " ";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "RELEASED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} released records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} unreleased records`);
                    }
                });
            },

            onFilterGIStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGIStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoWeightRollerActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoWeightRollerActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GI status
                    const aFilteredData = fetchedData.filter(item => {
                        const giCnfValue = item.gicnfmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return giCnfValue &&
                                giCnfValue.trim() !== "" &&
                                giCnfValue !== "0" &&
                                giCnfValue !== null &&
                                giCnfValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !giCnfValue ||
                                giCnfValue.trim() === "" ||
                                giCnfValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GI records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GI records`);
                    }
                });
            },

            onFilterGRStatus: function () {
                const oView = this.getView();
                const oComboBox = oView.byId("comboGRStatusFilter");
                const sSelectedStatus = oComboBox.getSelectedKey();
                const oTabModel = oView.getModel("TabModel");

                // If "All" is selected or no status, just reload data
                if (!sSelectedStatus || sSelectedStatus === "") {
                    this.GoWeightRollerActualfilter();
                    return;
                }

                // Show loading
                sap.ui.core.BusyIndicator.show(0);

                // Fetch data with callback for filtering
                this.GoWeightRollerActualfilter(function (fetchedData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!fetchedData || fetchedData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Filter data based on selected GR status
                    const aFilteredData = fetchedData.filter(item => {
                        const grValue = item.grmaterialdocnumber;

                        if (sSelectedStatus === "COMPLETED") {
                            // For completed: value exists, is not empty/null/undefined, and is not "0"
                            return grValue &&
                                grValue.trim() !== "" &&
                                grValue !== "0" &&
                                grValue !== null &&
                                grValue !== undefined;
                        } else {
                            // For not completed: value is empty, null, undefined, "0", or just whitespace
                            return !grValue ||
                                grValue.trim() === "" ||
                                grValue === "0";
                        }
                    });

                    // Update the model
                    oTabModel.setProperty("/Samples", aFilteredData);

                    // Show message
                    if (sSelectedStatus === "COMPLETED") {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} completed GR records`);
                    } else {
                        sap.m.MessageToast.show(`Filtered to ${aFilteredData.length} not completed GR records`);
                    }
                });
            },




            // ontypeconfirmedqty: function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const sNewValue = oInput.getValue();

            //     // Get the binding context and row data
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oRowData = oContext.getObject();

            //     const iConfirmedQty = parseFloat(sNewValue);
            //     const iProductionOrderQty = parseFloat(oRowData.productionorderqty);

            //     // Validate inputs
            //     // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
            //     //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
            //     //     oInput.setValue(""); // Clear the input
            //     //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
            //     //     oContext.getModel().refresh(); // Reflect change in UI
            //     //     return;
            //     // }

            //     if (iConfirmedQty > iProductionOrderQty) {
            //         sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
            //         oInput.setValue("");
            //         // oRowData.balanceqty = oRowData.productionorderqty || 0;
            //         oContext.getModel().refresh();
            //         return;
            //     }

            //     // Set Confirmed QTY explicitly if needed
            //     oRowData.confirmedqty = iConfirmedQty;

            //     // Calculate and update Balance QTY
            //     const iBalanceQty = iProductionOrderQty - iConfirmedQty;
            //     // oRowData.balanceqty = iBalanceQty;
            //     oRowData.scrapqty = Number(iBalanceQty.toFixed(3));

            //     // Refresh the model to update UI
            //     oContext.getModel().refresh();
            // },




            // ontypeconfirmedqty: function (oEvent) {
            //     const oInput = oEvent.getSource();
            //     const sNewValue = oInput.getValue();

            //     // Get the binding context and row data
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const oRowData = oContext.getObject();

            //     // Handle empty or invalid input - replace with 0
            //     let iConfirmedQty = parseFloat(sNewValue);
            //     if (isNaN(iConfirmedQty)) {
            //         iConfirmedQty = 0;
            //     }

            //     const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;

            //     // Validate inputs
            //     // if (isNaN(iConfirmedQty) || iConfirmedQty <= 0) {
            //     //     sap.m.MessageBox.warning("Please enter a valid number greater than 0 for Confirmed QTY.");
            //     //     oInput.setValue(""); // Clear the input
            //     //     oRowData.balanceqty = oRowData.productionorderqty || 0; // Reset balance
            //     //     oContext.getModel().refresh(); // Reflect change in UI
            //     //     return;
            //     // }

            //     if (iConfirmedQty > iProductionOrderQty) {
            //         sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
            //         oInput.setValue("");
            //         // oRowData.balanceqty = oRowData.productionorderqty || 0;
            //         oContext.getModel().refresh();
            //         return;
            //     }

            //     // Set Confirmed QTY explicitly if needed
            //     oRowData.confirmedqty = iConfirmedQty;

            //     // Calculate and update Balance QTY
            //     const iBalanceQty = iProductionOrderQty - iConfirmedQty;
            //     // oRowData.balanceqty = iBalanceQty;
            //     oRowData.scrapqty = isNaN(iBalanceQty) ? 0.000 : Number(iBalanceQty.toFixed(3));

            //     // Refresh the model to update UI
            //     oContext.getModel().refresh();
            // },

            ontypeconfirmedqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                let iConfirmedQty = parseFloat(sNewValue);
                if (isNaN(iConfirmedQty)) {
                    iConfirmedQty = 0;
                }

                const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;
                const iCurrentScrapQty = parseFloat(oRowData.scrapqty) || 0;   // existing scrap

                // 1. Check against production order qty
                if (iConfirmedQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY must be less than or equal to Production Order QTY.");
                    oInput.setValue("");
                    oContext.getModel().refresh();
                    return;
                }

                // 2. Check sum with existing scrap
                if (iConfirmedQty + iCurrentScrapQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY + Scrap QTY exceeds Production Order QTY.");
                    oInput.setValue("");
                    oContext.getModel().refresh();
                    return;
                }

                // 3. Valid – update confirmed qty
                oRowData.confirmedqty = iConfirmedQty;

                // 4. (Optional) Update balance qty
                const iBalanceQty = iProductionOrderQty - iConfirmedQty - iCurrentScrapQty;
                oRowData.balanceqty = iBalanceQty;   // uncomment this line if you have the field

                oContext.getModel().refresh();
            },

            ontypescrapqty: function (oEvent) {
                const oInput = oEvent.getSource();
                const sNewValue = oInput.getValue();

                // Get row context
                const oContext = oInput.getBindingContext("TabModel");
                const oRowData = oContext.getObject();

                const iScrapQty = parseFloat(sNewValue);
                const iConfirmedQty = parseFloat(oRowData.confirmedqty) || 0;
                const iProductionOrderQty = parseFloat(oRowData.productionorderqty) || 0;

                // Validate scrap qty value
                if (isNaN(iScrapQty) || iScrapQty < 0) {
                    sap.m.MessageBox.error("Scrap QTY must be a valid positive number.");
                    oInput.setValue("");
                    return;
                }

                // Check if scrap qty exceeds production order qty
                if (iScrapQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Scrap QTY cannot exceed Production Order QTY.");
                    oInput.setValue("");
                    return;
                }

                // NEW: Check if Confirmed + Scrap exceeds Production Order Qty
                if (iConfirmedQty + iScrapQty > iProductionOrderQty) {
                    sap.m.MessageBox.error("Confirmed QTY + Scrap QTY exceeds Production Order QTY.");
                    oInput.setValue("");
                    return;
                }

                // Update the model
                oContext.getModel().setProperty(oContext.getPath() + "/scrapqty", iScrapQty);
            },



            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },



            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oODataModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);
            //             const workbook = XLSX.read(data, { type: "array" });
            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aNotFound = [];

            //             sap.ui.core.BusyIndicator.show(0);

            //             const aUpdatePromises = jsonData.map((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 const matchedRow = aSamples.find(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (!matchedRow || !matchedRow.sap_uuid) {
            //                     aNotFound.push(prodOrder);
            //                     return null;
            //                 }

            //                 const parseDecimal = (val) => {
            //                     const parsed = parseFloat(val);
            //                     return isNaN(parsed) ? "0.000" : parsed.toFixed(3);
            //                 };

            //                 const oPayload = {
            //                     confirmedqty: parseDecimal(importRow["Confirmed Qty"]),
            //                     compoundcode: parseDecimal(importRow["compoundcode"]),
            //                     // defectqty: parseDecimal(importRow["Defect Qty"]),
            //                     balanceqty: parseDecimal(importRow["Balance Qty"]),
            //                     manufacturingdate: importRow["Manufacturing Date"] ? new Date(importRow["Manufacturing Date"]) : null,
            //                     // batchweight: String(importRow["Batch Weight"] || ""),
            //                     // operator: String(importRow["Operator"] || ""),
            //                     // inspector: String(importRow["Inspector"] || "")
            //                 };



            //                 // ✅ Update model row for UI (safe now)
            //                 matchedRow.confirmedqty = oPayload.confirmedqty;
            //                 matchedRow.compoundcode = oPayload.compoundcode;
            //                 // matchedRow.defectqty = oPayload.defectqty;
            //                 matchedRow.balanceqty = oPayload.balanceqty;
            //                 matchedRow.manufacturingdate = oPayload.manufacturingdate;
            //                 // matchedRow.batchweight = oPayload.batchweight;
            //                 // matchedRow.operator = oPayload.operator;
            //                 // matchedRow.inspector = oPayload.inspector;

            //                 // 🔑 Construct OData entity key
            //                 const sKey = oODataModel.createKey("/ZC_WEIGTHROLLER_PLAN", {
            //                     sap_uuid: matchedRow.sap_uuid
            //                 });

            //                 // 🔁 Return update promise
            //                 return new Promise((resolve, reject) => {
            //                     oODataModel.update(sKey, oPayload, {
            //                         success: resolve,
            //                         error: reject
            //                     });
            //                 });
            //             }).filter(Boolean); // remove any nulls (not found rows)

            //             Promise.allSettled(aUpdatePromises).then(results => {
            //                 sap.ui.core.BusyIndicator.hide();

            //                 const aFailed = results.filter(r => r.status === "rejected");
            //                 let msg = `${results.length - aFailed.length} rows updated successfully.`;
            //                 if (aFailed.length > 0) msg += `\n${aFailed.length} rows failed to update.`;
            //                 if (aNotFound.length > 0) {
            //                     msg += `\n\nThe following Production Orders were not found or missing sap_uuid:\n${aNotFound.join(", ")}`;
            //                 }

            //                 sap.m.MessageBox.information(msg);
            //                 oTabModel.refresh(true);
            //             });
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";
            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };
            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            // onExportExl: function () {
            //     const oModel = this.getView().getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // Filter selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     // Use selected rows if available, else use all rows
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     const aColumns = [
            //         { label: "Plant", property: "plant" },
            //         { label: "Production Order No", property: "productionorderno" },
            //         { label: "bipllotno", property: "bipllotno" },
            //         { label: "shift", property: "shift" },
            //         { label: "Material Code", property: "materialcode" },
            //         { label: "Description", property: "description" },
            //         { label: "Machine Number", property: "machinenumber" },
            //         { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         { label: "Production Order Qty", property: "productionorderqty" },
            //         { label: "Lot/Batch-No", property: "lotbatchno" },
            //         { label: "Storage Location", property: "storagelocation" },
            //         { label: "compoundcode", property: "compoundcode" },
            //         { label: "Confirmed Qty", property: "confirmedqty" },
            //         { label: "Scrap Qty", property: "scrapqty" },

            //         // { label: "Defect Qty", property: "defectQty" },
            //         // { label: "Balance Qty", property: "balanceQty" },
            //         // { label: "UOM", property: "uom" },
            //         { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         // { label: "Batch Weight", property: "batchweight" },
            //         // { label: "Operator", property: "operator" },
            //         // { label: "Inspector", property: "inspector" },
            //         { label: "Released Status", property: "releasestatus" },
            //         { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
            //         { label: "Confirmation Count", property: "gicnfconfirmationcount" },
            //         { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
            //         { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
            //         { label: "GR Material Doc Year", property: "grmaterialdocyear" },
            //         { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
            //         // { label: "Status of Production Order", property: "statusOfProdOrd" }
            //     ];

            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: {
            //                 sheetName: "WeightRoller Plan"
            //             }
            //         },
            //         dataSource: aExportData,
            //         fileName: "WeightRoller_Plan_Export.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed.");
            //         })
            //         .catch(function (oError) {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },




            onExportExl: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, else use all rows
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno (ascending)
                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                // Format both date fields to match table display (dd-MM-yyyy)
                // const aFormattedData = aExportData.map(item => {
                //     const formattedItem = Object.assign({}, item);

                //     // Helper function to format date to dd-MM-yyyy
                //     const formatDate = (dateValue) => {
                //         if (!dateValue) return "";

                //         const date = new Date(dateValue);

                //         // Handle timezone correction - get local date
                //         const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                //         // Format as dd-MM-yyyy
                //         const day = String(localDate.getDate()).padStart(2, '0');
                //         const month = String(localDate.getMonth() + 1).padStart(2, '0');
                //         const year = localDate.getFullYear();

                //         return `${day}-${month}-${year}`;
                //     };

                //     // Format production order start date
                //     if (formattedItem.productionordstartdate) {
                //         formattedItem.productionordstartdate = formatDate(formattedItem.productionordstartdate);
                //     }

                //     // Format manufacturing date
                //     if (formattedItem.manufacturingdate) {
                //         formattedItem.manufacturingdate = formatDate(formattedItem.manufacturingdate);
                //     }

                //     return formattedItem;
                // });
                // const aFormattedData = aExportData.map(item => {
                //     const formattedItem = Object.assign({}, item);

                //     if (formattedItem.manufacturingdate) {
                //         // Convert to local date string in dd-MM-yyyy format (like in table)
                //         const date = new Date(formattedItem.manufacturingdate);

                //         // Handle timezone correction - get local date
                //         const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                //         // Format as dd-MM-yyyy
                //         const day = String(localDate.getDate()).padStart(2, '0');
                //         const month = String(localDate.getMonth() + 1).padStart(2, '0');
                //         const year = localDate.getFullYear();

                //         formattedItem.manufacturingdate = `${day}-${month}-${year}`;
                //         formattedItem.productionordstartdate = `${day}-${month}-${year}`;
                //     }

                //     return formattedItem;
                // });
                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    // Manufacturing Date
                    if (formattedItem.manufacturingdate) {
                        const date = new Date(formattedItem.manufacturingdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    // Production Order Start Date
                    if (formattedItem.productionordstartdate) {
                        const date = new Date(formattedItem.productionordstartdate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.productionordstartdate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    if (formattedItem.PostingDate) {
                        const date = new Date(formattedItem.PostingDate);

                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${year}-${month}-${day}`; // match inputFormat
                    }

                    return formattedItem;
                });


                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "bipllotno", property: "bipllotno" },
                    { label: "shift", property: "shift" },
                    { label: "Material Code", property: "materialcode" },
                    { label: "Description", property: "description" },
                    { label: "Machine Number", property: "machinenumber" },
                    { label: "Production order start Date", property: "productionordstartdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Production Order Qty", property: "productionorderqty" },
                    { label: "Lot/Batch-No", property: "lotbatchno" },
                    { label: "Storage Location", property: "storagelocation" },
                    // { label: "compoundcode", property: "compoundcode" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },
                    { label: "Reject Codes", property: "RejectCodes" },
                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },

                    // { label: "Defect Qty", property: "defectQty" },
                    // { label: "Balance Qty", property: "balanceQty" },
                    // { label: "UOM", property: "uom" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Expiry Date", property: "expirydate", type: "date", inputFormat: "yyyy-MM-dd" },
                    // { label: "Batch Weight", property: "batchweight" },
                    // { label: "Operator", property: "operator" },
                    // { label: "Inspector", property: "inspector" },
                    { label: "Released Status", property: "releasestatus" },
                    { label: "Confirmation Group", property: "gicnfconfirmationgroup" },
                    { label: "Confirmation Count", property: "gicnfconfirmationcount" },
                    { label: "GI/CNF Mat Doc Year", property: "gicnfmaterialdocyear" },
                    { label: "GI/CNF Material Doc Number", property: "gicnfmaterialdocnumber" },
                    { label: "GR Material Doc Year", property: "grmaterialdocyear" },
                    { label: "GR Material Doc Number", property: "grmaterialdocnumber" },
                    // { label: "Status of Production Order", property: "statusOfProdOrd" }
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "WeightRoller Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "WeightRoller_Actual_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },





            // onExporttoImport: function () {
            //     const oModel = this.getView().getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // 🔍 Check for selected rows
            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     const aColumns = [
            //         { label: "Plant", property: "plant" },
            //         { label: "Production Order No", property: "productionorderno" },
            //         // { label: "bipllotno", property: "bipllotno" },
            //         // { label: "shift", property: "shift" },
            //         { label: "Confirmed Qty", property: "confirmedqty" },
            //         // { label: "compoundcode", property: "compoundcode" },
            //         // { label: "Defect Qty", property: "defectQty" },
            //         // { label: "Scrap Qty", property: "balanceqty" },
            //         { label: "Scrap Qty", property: "scrapqty" },
            //         { label: "Reject Codes", property: "RejectCodes" },
            //         { label: "Manufacturing Date", property: "manufacturingdate", type: "date", inputFormat: "yyyy-MM-dd" },
            //         // { label: "Manufacturing Date", property: "manufacturingdate", type: "string" },
            //         // { label: "Batch Weight", property: "batchweight" },
            //         // { label: "Operator", property: "operator" },
            //         // { label: "Inspector", property: "inspector" },
            //     ];

            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: {
            //                 sheetName: "Mixing Actual"
            //             }
            //         },
            //         dataSource: aExportData,
            //         fileName: "MixingActualExporttoImport.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed.");
            //         })
            //         .catch(function (oError) {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },



            onExporttoImport: function () {
                const oModel = this.getView().getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // 🔍 Check for selected rows
                const aSelectedRows = aData.filter(row => row.__selected);
                let aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // 🔹 Sort the data in the same sequence as the table
                // First by productionordstartdate (ascending), then by bipllotno (ascending)
                aExportData = aExportData.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno (ascending)
                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                // Format manufacturing date to match table display (dd-MM-yyyy)
                const aFormattedData = aExportData.map(item => {
                    const formattedItem = Object.assign({}, item);

                    if (formattedItem.manufacturingdate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.manufacturingdate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.manufacturingdate = `${day}-${month}-${year}`;
                    }

                    if (formattedItem.PostingDate) {
                        // Convert to local date string in dd-MM-yyyy format (like in table)
                        const date = new Date(formattedItem.PostingDate);

                        // Handle timezone correction - get local date
                        const localDate = new Date(date.getTime() - (date.getTimezoneOffset() * 60000));

                        // Format as dd-MM-yyyy
                        const day = String(localDate.getDate()).padStart(2, '0');
                        const month = String(localDate.getMonth() + 1).padStart(2, '0');
                        const year = localDate.getFullYear();

                        formattedItem.PostingDate = `${day}-${month}-${year}`;
                    }

                    return formattedItem;
                });

                const aColumns = [
                    { label: "Plant", property: "plant" },
                    { label: "Production Order No", property: "productionorderno" },
                    { label: "Prduction order qty", property: "productionorderqty" },
                    { label: "Confirmed Qty", property: "confirmedqty" },
                    { label: "Scrap Qty", property: "scrapqty" },
                    { label: "Reject Codes", property: "RejectCodes" },
                    { label: "Posting Date", property: "PostingDate", type: "date", inputFormat: "yyyy-MM-dd" },
                    { label: "Manufacturing Date", property: "manufacturingdate", type: "string" },
                ];

                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: {
                            sheetName: "WeightRoller Actual"
                        }
                    },
                    dataSource: aFormattedData,
                    fileName: "WeightRollerActualExporttoImport.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed.");
                    })
                    .catch(function (oError) {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },

            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             // ADDED: dateNF option for better date handling
            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy" // Added this option
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // ADDED: Timezone-safe date parsing function (same as working code)
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes (preserving original logic)
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     updatedRow.RejectCodes = rejectCodes;
            //                 }

            //                 // FIXED: Parse manufacturing date using the proper function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         // FIXED: Store Date object instead of formatted string
            //                         updatedRow.manufacturingdate = manufacturingDate;

            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available - FIXED: Store Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },




            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             // ADDED: dateNF option for better date handling
            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false,
            //                 dateNF: "dd-mm-yyyy" // Specify expected date format
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: "",
            //                 dateNF: "dd-mm-yyyy" // Added this option
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // ADDED: Timezone-safe date parsing function (same as working code)
            //             function parseExcelDate(rawValue) {
            //                 if (!rawValue && rawValue !== 0) {
            //                     return null;
            //                 }

            //                 // CASE 1: Already a Date object (shouldn't happen with raw:true)
            //                 if (rawValue instanceof Date) {
            //                     // Create local date from the date object
            //                     const d = new Date(rawValue);
            //                     return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
            //                 }

            //                 // CASE 2: Excel serial number (most common case from Excel)
            //                 if (typeof rawValue === 'number') {
            //                     // Excel incorrectly treats 1900 as a leap year, so we need to adjust
            //                     // Use local date calculation to avoid timezone issues
            //                     const excelEpoch = new Date(1899, 11, 30);
            //                     const days = Math.floor(rawValue);
            //                     const ms = Math.round((rawValue - days) * 86400000);

            //                     // Calculate in local time
            //                     const date = new Date(excelEpoch);
            //                     date.setDate(date.getDate() + days);
            //                     date.setTime(date.getTime() + ms);

            //                     // Create a new date with just year/month/day (no time)
            //                     const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     return !isNaN(localDate.getTime()) ? localDate : null;
            //                 }

            //                 // CASE 3: String value
            //                 if (typeof rawValue === 'string') {
            //                     const trimmed = rawValue.trim();
            //                     if (!trimmed) return null;

            //                     // Try dd-mm-yyyy format first (most common)
            //                     if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
            //                         const year = parseInt(parts[2], 10);

            //                         // Validate date components
            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             // Verify the date is valid (e.g., not Feb 31)
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try yyyy-mm-dd format
            //                     if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
            //                         const parts = trimmed.split("-");
            //                         const year = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const day = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try dd/mm/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const day = parseInt(parts[0], 10);
            //                         const month = parseInt(parts[1], 10) - 1;
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try mm/dd/yyyy format
            //                     if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
            //                         const parts = trimmed.split("/");
            //                         const month = parseInt(parts[0], 10) - 1;
            //                         const day = parseInt(parts[1], 10);
            //                         const year = parseInt(parts[2], 10);

            //                         if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
            //                             const date = new Date(year, month, day);
            //                             if (date.getFullYear() === year &&
            //                                 date.getMonth() === month &&
            //                                 date.getDate() === day) {
            //                                 return date;
            //                             }
            //                         }
            //                     }

            //                     // Try parsing as local date (for other formats)
            //                     // Parse the string in local timezone
            //                     const parsed = new Date(trimmed);
            //                     if (!isNaN(parsed.getTime())) {
            //                         // Extract just the date part to avoid timezone issues
            //                         return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            //                     }
            //                 }

            //                 // If we get here, try one more approach
            //                 try {
            //                     // Force local date parsing
            //                     const date = new Date(rawValue);
            //                     if (!isNaN(date.getTime())) {
            //                         return new Date(date.getFullYear(), date.getMonth(), date.getDate());
            //                     }
            //                 } catch (e) {
            //                     console.warn("Could not parse date:", rawValue, e);
            //                 }

            //                 return null;
            //             }

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes (preserving original logic)
            //                 // const rejectCodes = importRow["Reject Codes"];
            //                 // if (rejectCodes !== undefined && rejectCodes !== null) {
            //                 //     updatedRow.RejectCodes = rejectCodes;
            //                 // }
            //                 // *** ADDED: VALIDATION FOR REJECT CODES LENGTH (MAX 60 CHARACTERS) ***
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     const rejectCodesStr = rejectCodes.toString().trim();

            //                     // Check if reject codes exceed 60 characters
            //                     if (rejectCodesStr.length > 60) {
            //                         aInvalidRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
            //                         });
            //                         return; // Skip this row entirely
            //                     }

            //                     // Only update if not empty string after trim
            //                     if (rejectCodesStr !== "") {
            //                         updatedRow.RejectCodes = rejectCodesStr;
            //                     }
            //                 }

            //                 // FIXED: Parse manufacturing date using the proper function
            //                 const rawDateValue = importRow["Manufacturing Date"];
            //                 const manufacturingDate = parseExcelDate(rawDateValue);
            //                 const hasManufacturingDate = manufacturingDate !== null;

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         // FIXED: Store Date object instead of formatted string
            //                         updatedRow.manufacturingdate = manufacturingDate;

            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields WITHOUT calculations
            //                     // (Confirmed Qty and Scrap Qty imported as-is)

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyStr !== null;
            //                     const userHasScrapQty = scrapQtyStr !== null;

            //                     // Get original values as fallback
            //                     let finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                     let finalScrapQty = matchedRow.scrapqty || "0.000";

            //                     // Import Confirmed Qty if provided
            //                     if (userHasConfirmedQty) {
            //                         finalConfirmedQty = confirmedQtyStr;
            //                     }

            //                     // Import Scrap Qty if provided
            //                     if (userHasScrapQty) {
            //                         finalScrapQty = scrapQtyStr;
            //                     }

            //                     // Get production order quantity for validation
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Validate that values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         // Keep validation for confirmed qty exceeding production order qty
            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with imported values
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available - FIXED: Store Date object
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = manufacturingDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add invalid rows information (removed adjustment information)
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            onImportExl: function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oSelectedModel = oView.getModel("Tab_SelectAll");

                function ensureXLSX(cb) {
                    if (window.XLSX) {
                        return cb();
                    }

                    const script = document.createElement("script");
                    script.src = importexcelfile;
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        const data = new Uint8Array(e.target.result);

                        // ADDED: dateNF option for better date handling
                        const workbook = XLSX.read(data, {
                            type: "array",
                            raw: true,
                            cellDates: false,
                            dateNF: "dd-mm-yyyy" // Specify expected date format
                        });

                        const sheetName = workbook.SheetNames[0];
                        const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
                            raw: true,
                            defval: "",
                            dateNF: "dd-mm-yyyy" // Added this option
                        });

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        const aSamples = oTabModel.getProperty("/Samples") || [];
                        const aNotFound = [];
                        const aValidationErrors = []; // For all validation errors (scrap/reject code issues, confirmed qty > prod order qty)
                        const aBlockedRows = []; // For rows that cannot be imported due to business rules

                        // ADDED: Timezone-safe date parsing function (same as working code)
                        function parseExcelDate(rawValue) {
                            if (!rawValue && rawValue !== 0) {
                                return null;
                            }

                            // CASE 1: Already a Date object (shouldn't happen with raw:true)
                            if (rawValue instanceof Date) {
                                // Create local date from the date object
                                const d = new Date(rawValue);
                                return !isNaN(d.getTime()) ? new Date(d.getFullYear(), d.getMonth(), d.getDate()) : null;
                            }

                            // CASE 2: Excel serial number (most common case from Excel)
                            if (typeof rawValue === 'number') {
                                // Excel incorrectly treats 1900 as a leap year, so we need to adjust
                                // Use local date calculation to avoid timezone issues
                                const excelEpoch = new Date(1899, 11, 30);
                                const days = Math.floor(rawValue);
                                const ms = Math.round((rawValue - days) * 86400000);

                                // Calculate in local time
                                const date = new Date(excelEpoch);
                                date.setDate(date.getDate() + days);
                                date.setTime(date.getTime() + ms);

                                // Create a new date with just year/month/day (no time)
                                const localDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                return !isNaN(localDate.getTime()) ? localDate : null;
                            }

                            // CASE 3: String value
                            if (typeof rawValue === 'string') {
                                const trimmed = rawValue.trim();
                                if (!trimmed) return null;

                                // Try dd-mm-yyyy format first (most common)
                                if (/^(\d{1,2})-(\d{1,2})-(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1; // Months are 0-indexed
                                    const year = parseInt(parts[2], 10);

                                    // Validate date components
                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        // Verify the date is valid (e.g., not Feb 31)
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try yyyy-mm-dd format
                                if (/^(\d{4})-(\d{1,2})-(\d{1,2})$/.test(trimmed)) {
                                    const parts = trimmed.split("-");
                                    const year = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const day = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try dd/mm/yyyy format
                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const day = parseInt(parts[0], 10);
                                    const month = parseInt(parts[1], 10) - 1;
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try mm/dd/yyyy format
                                if (/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.test(trimmed)) {
                                    const parts = trimmed.split("/");
                                    const month = parseInt(parts[0], 10) - 1;
                                    const day = parseInt(parts[1], 10);
                                    const year = parseInt(parts[2], 10);

                                    if (month >= 0 && month <= 11 && day >= 1 && day <= 31) {
                                        const date = new Date(year, month, day);
                                        if (date.getFullYear() === year &&
                                            date.getMonth() === month &&
                                            date.getDate() === day) {
                                            return date;
                                        }
                                    }
                                }

                                // Try parsing as local date (for other formats)
                                // Parse the string in local timezone
                                const parsed = new Date(trimmed);
                                if (!isNaN(parsed.getTime())) {
                                    // Extract just the date part to avoid timezone issues
                                    return new Date(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
                                }
                            }

                            // If we get here, try one more approach
                            try {
                                // Force local date parsing
                                const date = new Date(rawValue);
                                if (!isNaN(date.getTime())) {
                                    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
                                }
                            } catch (e) {
                                console.warn("Could not parse date:", rawValue, e);
                            }

                            return null;
                        }

                        // Parse decimal values with better handling
                        const parseDecimal = (val) => {
                            if (val === undefined || val === null || val === "") return null;
                            // Remove any non-numeric characters except decimal point and minus
                            const cleaned = String(val).replace(/[^\d.-]/g, '');
                            const parsed = parseFloat(cleaned);
                            return isNaN(parsed) ? null : parsed.toFixed(3);
                        };

                        // Store temporary data for potential import
                        const aTempSamples = JSON.parse(JSON.stringify(aSamples)); // Deep copy for validation
                        const aRowsToProcess = [];

                        // First pass - collect all validation errors and prepare data
                        let hasValidationErrors = false;

                        jsonData.forEach((importRow, rowIndex) => {
                            const plant = importRow["Plant"];
                            const prodOrder = importRow["Production Order No"];

                            // Find matching row by Plant and Production Order No
                            const matchedRowIndex = aSamples.findIndex(item =>
                                item.plant === plant && item.productionorderno === prodOrder
                            );

                            if (matchedRowIndex === -1) {
                                aNotFound.push(`${plant}/${prodOrder}`);
                                hasValidationErrors = true;
                                return;
                            }

                            const matchedRow = aSamples[matchedRowIndex];
                            const tempRow = aTempSamples[matchedRowIndex];

                            // Check what user is trying to import
                            const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
                                importRow["Confirmed Qty"] !== null &&
                                importRow["Confirmed Qty"].toString().trim() !== "";
                            const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
                                importRow["Scrap Qty"] !== null &&
                                importRow["Scrap Qty"].toString().trim() !== "";
                            const rawDateValue = importRow["Manufacturing Date"];
                            const manufacturingDate = parseExcelDate(rawDateValue);
                            const hasManufacturingDate = manufacturingDate !== null;

                            const rawPostingDate = importRow["Posting Date"];
                            const postingDate = parseExcelDate(rawPostingDate);
                            const hasPostingDate = postingDate !== null;

                            // Check if there are business rule violations first
                            if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
                                // Rule: Cannot import any of the 3 fields if GR Material Doc number exists
                                if (hasConfirmedQty || hasScrapQty || hasManufacturingDate || hasPostingDate) {
                                    aBlockedRows.push({
                                        prodOrder: prodOrder,
                                        plant: plant,
                                        reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
                                    });
                                    hasValidationErrors = true;
                                }
                            }
                            else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
                                // Rule: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
                                if (hasConfirmedQty || hasScrapQty || hasPostingDate) {
                                    aBlockedRows.push({
                                        prodOrder: prodOrder,
                                        plant: plant,
                                        reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
                                    });
                                    hasValidationErrors = true;
                                }
                                else if (hasManufacturingDate) {
                                    // Only manufacturing date can be imported - store for later
                                    tempRow.manufacturingdate = manufacturingDate;
                                    tempRow.__selected = true;
                                    aRowsToProcess.push({
                                        rowIndex: matchedRowIndex,
                                        row: tempRow,
                                        message: `${prodOrder} (Manufacturing Date only)`
                                    });
                                }
                            }
                            else {
                                // Check scrap/reject code validation rules
                                const rejectCodes = importRow["Reject Codes"];
                                const rejectCodesStr = rejectCodes !== undefined && rejectCodes !== null ?
                                    rejectCodes.toString().trim() : "";

                                // Parse scrap quantity
                                const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);
                                const userHasScrapQty = scrapQtyStr !== null;

                                // Check if scrap quantity is "entered" (not null/undefined/empty/0/0.00/0.000)
                                let scrapQtyEntered = false;
                                if (userHasScrapQty) {
                                    const scrapQtyNum = parseFloat(scrapQtyStr);
                                    // Check if scrap quantity is not zero (0, 0.00, 0.000 all count as zero)
                                    scrapQtyEntered = !isNaN(scrapQtyNum) && scrapQtyNum !== 0;
                                }

                                // Check if reject code is entered
                                const rejectCodeEntered = rejectCodesStr !== "";

                                // Apply scrap/reject code validation rules
                                if (!scrapQtyEntered && rejectCodeEntered) {
                                    // Rule: Reject code entered but scrap quantity not entered
                                    aValidationErrors.push({
                                        prodOrder: prodOrder,
                                        reason: `Reject Code provided but Scrap Qty is not entered (must be zero or empty). Cannot import.`
                                    });
                                    hasValidationErrors = true;
                                }

                                if (scrapQtyEntered && !rejectCodeEntered) {
                                    // Rule: Scrap quantity entered but reject code not entered
                                    aValidationErrors.push({
                                        prodOrder: prodOrder,
                                        reason: `Scrap Qty entered but Reject Code is not filled. Please enter Reject Code.`
                                    });
                                    hasValidationErrors = true;
                                }

                                // Check reject code length if both are entered
                                if (scrapQtyEntered && rejectCodeEntered && rejectCodesStr.length > 60) {
                                    aValidationErrors.push({
                                        prodOrder: prodOrder,
                                        reason: `Reject Codes exceeds maximum length of 60 characters (${rejectCodesStr.length} characters entered)`
                                    });
                                    hasValidationErrors = true;
                                }

                                // Check confirmed quantity validation
                                if (hasConfirmedQty) {
                                    const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                                    if (confirmedQtyStr !== null) {
                                        const confirmedNum = parseFloat(confirmedQtyStr);
                                        const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

                                        if (confirmedNum < 0) {
                                            aValidationErrors.push({
                                                prodOrder: prodOrder,
                                                reason: `Confirmed Qty cannot be negative: ${confirmedQtyStr}`
                                            });
                                            hasValidationErrors = true;
                                        }

                                        // Do NOT allow confirmed qty to exceed production order qty
                                        if (confirmedNum > productionOrderQty) {
                                            aValidationErrors.push({
                                                prodOrder: prodOrder,
                                                reason: `Confirmed Qty (${confirmedQtyStr}) cannot exceed Production Order Qty (${productionOrderQty})`
                                            });
                                            hasValidationErrors = true;
                                        }
                                    }
                                }

                                // Check scrap quantity for negative values
                                if (userHasScrapQty) {
                                    const scrapNum = parseFloat(scrapQtyStr);
                                    if (scrapNum < 0) {
                                        aValidationErrors.push({
                                            prodOrder: prodOrder,
                                            reason: `Scrap Qty cannot be negative: ${scrapQtyStr}`
                                        });
                                        hasValidationErrors = true;
                                    }
                                }

                                // ---------- Sum validation: Confirmed + Scrap ≤ Production ----------
                                // Determine final values that would be imported (use existing if not provided)
                                let effectiveConfirmed = parseFloat(matchedRow.confirmedqty) || 0;
                                let effectiveScrap = parseFloat(matchedRow.scrapqty) || 0;

                                // If Confirmed Qty is provided in import, use that
                                if (hasConfirmedQty) {
                                    const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                                    if (confirmedQtyStr !== null) {
                                        effectiveConfirmed = parseFloat(confirmedQtyStr);
                                    }
                                }

                                // If Scrap Qty is provided and valid (non‑zero + reject code), use that
                                if (userHasScrapQty && scrapQtyEntered && rejectCodeEntered) {
                                    effectiveScrap = parseFloat(scrapQtyStr);
                                }

                                const prodQty = parseFloat(matchedRow.productionorderqty) || 0;
                                if (effectiveConfirmed + effectiveScrap > prodQty) {
                                    aValidationErrors.push({
                                        prodOrder: prodOrder,
                                        reason: `Confirmed Qty (${effectiveConfirmed}) + Scrap Qty (${effectiveScrap}) exceeds Production Order Qty (${prodQty})`
                                    });
                                    hasValidationErrors = true;
                                }
                                // ----------------------------------------------------------------



                                // If no validation errors for this row, prepare it for import
                                if (!hasValidationErrors) {
                                    // Parse values from import
                                    const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
                                    const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

                                    // Determine if user provided values
                                    const userHasConfirmedQty = confirmedQtyStr !== null;
                                    const userHasScrapQty = scrapQtyStr !== null;

                                    // Get original values as fallback
                                    let finalConfirmedQty = matchedRow.confirmedqty || "0.000";
                                    let finalScrapQty = matchedRow.scrapqty || "0.000";

                                    // Import Confirmed Qty if provided
                                    if (userHasConfirmedQty) {
                                        finalConfirmedQty = confirmedQtyStr;
                                    }

                                    // Import Scrap Qty if provided (validation already passed)
                                    if (userHasScrapQty && scrapQtyEntered && rejectCodeEntered) {
                                        finalScrapQty = scrapQtyStr;
                                    }

                                    // Update the temporary row
                                    tempRow.confirmedqty = finalConfirmedQty;
                                    tempRow.scrapqty = finalScrapQty;

                                    // Update reject codes if scrap quantity was entered (validation already passed)
                                    if (scrapQtyEntered && rejectCodeEntered) {
                                        tempRow.RejectCodes = rejectCodesStr;
                                    }

                                    // Add manufacturing date if available
                                    if (hasManufacturingDate) {
                                        tempRow.manufacturingdate = manufacturingDate;
                                    }

                                    // ** MISSING: Add posting date if available **
                                    // if (hasPostingDate) {
                                    //     tempRow.postingdate = postingDate;   // or tempRow.postingDate depending on your model field name
                                    // }
                                    if (hasPostingDate) {
                                        tempRow.PostingDate = postingDate;   // ✅ matches model property name
                                    }



                                    tempRow.__selected = true;

                                    aRowsToProcess.push({
                                        rowIndex: matchedRowIndex,
                                        row: tempRow,
                                        message: prodOrder
                                    });
                                }
                            }
                        });

                        // If there are any validation errors, stop the import completely
                        if (hasValidationErrors || aValidationErrors.length > 0 || aBlockedRows.length > 0) {
                            let message = "Import failed due to validation errors:\n\n";

                            if (aValidationErrors.length > 0) {
                                message += `Validation errors: ${aValidationErrors.length} row(s)\n`;
                                aValidationErrors.forEach(err => {
                                    message += `- ${err.prodOrder}: ${err.reason}\n`;
                                });
                                message += "\n";
                            }

                            if (aBlockedRows.length > 0) {
                                message += `Business rule violations: ${aBlockedRows.length} row(s)\n`;
                                aBlockedRows.forEach(blocked => {
                                    message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
                                });
                                message += "\n";
                            }

                            if (aNotFound.length > 0) {
                                message += `Not found in table: ${aNotFound.length} row(s)\n`;
                                message += aNotFound.join(", ");
                            }

                            message += "\nNo data was imported. Please fix the errors and try again.";

                            sap.m.MessageBox.show(message, {
                                title: "Import Failed",
                                icon: sap.m.MessageBox.Icon.ERROR,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                            return;
                        }

                        // If no validation errors, proceed with the import
                        if (aRowsToProcess.length > 0) {
                            // Apply all updates to the actual samples array
                            aRowsToProcess.forEach(item => {
                                aSamples[item.rowIndex] = item.row;
                            });

                            // Update the model
                            oTabModel.setProperty("/Samples", aSamples);

                            // Optionally update the select all checkbox
                            const allSelected = aSamples.every(row => row.__selected);
                            oSelectedModel.setProperty("/Samples/selectall", allSelected);

                            // Refresh the table
                            oTabModel.refresh(true);

                            // Build success message
                            let message = `Successfully updated ${aRowsToProcess.length} row(s).\n`;
                            message += `Updated Production Orders:\n`;
                            aRowsToProcess.forEach(item => {
                                message += `  • ${item.message}\n`;
                            });
                            message += "\nCheckboxes have been selected for updated rows.\n";

                            sap.m.MessageBox.show(message, {
                                title: "Import Successful",
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                actions: [sap.m.MessageBox.Action.OK],
                                contentWidth: "600px"
                            });
                        } else {
                            // This should not happen if we passed validation, but handle it anyway
                            sap.m.MessageBox.show("No data was imported.", {
                                title: "Import Results",
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                actions: [sap.m.MessageBox.Action.OK]
                            });
                        }
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };

                    reader.readAsArrayBuffer(file);
                }

                // Create file input element
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";

                fileInput.onchange = function (e) {
                    const file = e.target.files[0];
                    if (!file) return;

                    // Check file extension
                    const fileName = file.name.toLowerCase();
                    if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
                        sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
                        document.body.removeChild(fileInput);
                        return;
                    }

                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                };

                document.body.appendChild(fileInput);
                fileInput.click();
            },



            // onImportExl: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oSelectedModel = oView.getModel("Tab_SelectAll");

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) {
            //             return cb();
            //         }

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = new Uint8Array(e.target.result);

            //             const workbook = XLSX.read(data, {
            //                 type: "array",
            //                 raw: true,
            //                 cellDates: false
            //             });

            //             const sheetName = workbook.SheetNames[0];
            //             const jsonData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName], {
            //                 raw: true,
            //                 defval: ""
            //             });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const aSamples = oTabModel.getProperty("/Samples") || [];
            //             const aUpdatedRows = [];
            //             const aNotFound = [];
            //             const aAdjustedRows = [];
            //             const aInvalidRows = [];
            //             const aBlockedRows = []; // For rows that cannot be imported due to business rules
            //             let hasAnyUpdate = false;

            //             // Process each row individually
            //             jsonData.forEach((importRow) => {
            //                 const plant = importRow["Plant"];
            //                 const prodOrder = importRow["Production Order No"];

            //                 // Find matching row by Plant and Production Order No
            //                 const matchedRowIndex = aSamples.findIndex(item =>
            //                     item.plant === plant && item.productionorderno === prodOrder
            //                 );

            //                 if (matchedRowIndex === -1) {
            //                     aNotFound.push(`${plant}/${prodOrder}`);
            //                     return; // Skip to next row
            //                 }

            //                 const matchedRow = aSamples[matchedRowIndex];

            //                 // Create updated row starting with original values
            //                 const updatedRow = { ...matchedRow };

            //                 // Handle Reject Codes
            //                 const rejectCodes = importRow["Reject Codes"];
            //                 if (rejectCodes !== undefined && rejectCodes !== null) {
            //                     updatedRow.RejectCodes = rejectCodes;
            //                 }

            //                 // Parse manufacturing date (common for all cases)
            //                 let formattedDate = null;
            //                 const rawDateValue = importRow["Manufacturing Date"];

            //                 if (rawDateValue) {
            //                     if (typeof rawDateValue === "number") {
            //                         // Excel serial date
            //                         const excelEpoch = new Date(1899, 11, 30);
            //                         const manufacturingDate = new Date(excelEpoch.getTime() + rawDateValue * 86400000);
            //                         if (!isNaN(manufacturingDate.getTime())) {
            //                             formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                         }
            //                     } else if (typeof rawDateValue === "string") {
            //                         // Try to parse as yyyy-MM-dd (from export format)
            //                         if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(rawDateValue)) {
            //                             const [year, month, day] = rawDateValue.split("-").map(Number);
            //                             const manufacturingDate = new Date(year, month - 1, day);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                         // Try to parse as dd-MM-yyyy (UI format)
            //                         else if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(rawDateValue)) {
            //                             const [day, month, year] = rawDateValue.split("-").map(Number);
            //                             const manufacturingDate = new Date(year, month - 1, day);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                         // Try general date parsing
            //                         else {
            //                             const manufacturingDate = new Date(rawDateValue);
            //                             if (!isNaN(manufacturingDate.getTime())) {
            //                                 formattedDate = manufacturingDate.toISOString().split('T')[0];
            //                             }
            //                         }
            //                     }
            //                 }

            //                 // Check what user is trying to import
            //                 const hasConfirmedQty = importRow["Confirmed Qty"] !== undefined &&
            //                     importRow["Confirmed Qty"] !== null &&
            //                     importRow["Confirmed Qty"].toString().trim() !== "";
            //                 const hasScrapQty = importRow["Scrap Qty"] !== undefined &&
            //                     importRow["Scrap Qty"] !== null &&
            //                     importRow["Scrap Qty"].toString().trim() !== "";
            //                 const hasManufacturingDate = formattedDate !== null;

            //                 // Now handle import based on business rules
            //                 if (matchedRow.grmaterialdocnumber && matchedRow.grmaterialdocnumber.trim() !== "") {
            //                     // Rule 3: Cannot import any of the 3 fields if GR Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty || hasManufacturingDate) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GR Material Doc number already exists (Goods Receipt already completed) - cannot import Confirmed Qty, Scrap Qty, or Manufacturing Date"
            //                         });
            //                         return; // Skip this row, don't import anything
            //                     }
            //                     // If user is not trying to import any of these fields, nothing happens
            //                 }
            //                 else if (matchedRow.gicnfmaterialdocnumber && matchedRow.gicnfmaterialdocnumber.trim() !== "") {
            //                     // Rule 1 & 2: Only Manufacturing Date can be imported if GI/CNF Material Doc number exists
            //                     if (hasConfirmedQty || hasScrapQty) {
            //                         aBlockedRows.push({
            //                             prodOrder: prodOrder,
            //                             plant: plant,
            //                             reason: "GI/CNF Material Doc number already exists (Goods Issue already completed) - cannot import Confirmed Qty or Scrap Qty"
            //                         });
            //                         // But we can still import Manufacturing Date if user provided it
            //                     }

            //                     // Only import Manufacturing Date for these rows
            //                     if (hasManufacturingDate) {
            //                         updatedRow.manufacturingdate = formattedDate;
            //                         // Keep existing confirmedqty and scrapqty values
            //                         updatedRow.confirmedqty = matchedRow.confirmedqty || "0.000";
            //                         updatedRow.scrapqty = matchedRow.scrapqty || "0.000";

            //                         updatedRow.__selected = true;
            //                         aSamples[matchedRowIndex] = updatedRow;
            //                         aUpdatedRows.push(`${prodOrder} (Manufacturing Date only)`);
            //                         hasAnyUpdate = true;
            //                     }
            //                 }
            //                 else {
            //                     // No restrictions - import all fields with calculations

            //                     // Parse decimal values with better handling
            //                     const parseDecimal = (val) => {
            //                         if (val === undefined || val === null || val === "") return null;
            //                         // Remove any non-numeric characters except decimal point and minus
            //                         const cleaned = String(val).replace(/[^\d.-]/g, '');
            //                         const parsed = parseFloat(cleaned);
            //                         return isNaN(parsed) ? null : parsed.toFixed(3);
            //                     };

            //                     // Get original production order quantity
            //                     const productionOrderQty = parseFloat(matchedRow.productionorderqty) || 0;

            //                     // Parse values from import
            //                     const confirmedQtyStr = parseDecimal(importRow["Confirmed Qty"]);
            //                     const scrapQtyStr = parseDecimal(importRow["Scrap Qty"]);

            //                     // Convert to numbers for calculation
            //                     const confirmedQtyNum = confirmedQtyStr ? parseFloat(confirmedQtyStr) : null;
            //                     const scrapQtyNum = scrapQtyStr ? parseFloat(scrapQtyStr) : null;

            //                     // Logic for Confirmed Qty and Scrap Qty calculation
            //                     let finalConfirmedQty = confirmedQtyStr;
            //                     let finalScrapQty = scrapQtyStr;

            //                     // Determine if user provided values
            //                     const userHasConfirmedQty = confirmedQtyNum !== null;
            //                     const userHasScrapQty = scrapQtyNum !== null;

            //                     if (userHasConfirmedQty && userHasScrapQty) {
            //                         // User provided both values - check if they are correct
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         const difference = Math.abs(scrapQtyNum - calculatedScrap);

            //                         if (difference > 0.001) { // Tolerance for floating point comparison
            //                             // Values don't match - adjust scrapqty based on calculation
            //                             finalScrapQty = calculatedScrap.toFixed(3);
            //                             aAdjustedRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty adjusted from ${scrapQtyNum} to ${finalScrapQty} based on calculation (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                             });
            //                         }
            //                     } else if (userHasConfirmedQty && !userHasScrapQty) {
            //                         // User only provided confirmedqty - calculate scrapqty
            //                         const calculatedScrap = productionOrderQty - confirmedQtyNum;
            //                         finalScrapQty = calculatedScrap.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Scrap Qty calculated as ${finalScrapQty} (Production Order Qty: ${productionOrderQty} - Confirmed Qty: ${confirmedQtyNum})`
            //                         });
            //                     } else if (!userHasConfirmedQty && userHasScrapQty) {
            //                         // User only provided scrapqty - calculate confirmedqty
            //                         const calculatedConfirmed = productionOrderQty - scrapQtyNum;
            //                         finalConfirmedQty = calculatedConfirmed.toFixed(3);
            //                         aAdjustedRows.push({
            //                             prodOrder: prodOrder,
            //                             reason: `Confirmed Qty calculated as ${finalConfirmedQty} (Production Order Qty: ${productionOrderQty} - Scrap Qty: ${scrapQtyNum})`
            //                         });
            //                     } else {
            //                         // User provided neither - keep existing values
            //                         finalConfirmedQty = matchedRow.confirmedqty || "0.000";
            //                         finalScrapQty = matchedRow.scrapqty || "0.000";
            //                     }

            //                     // Validate that calculated values make sense
            //                     if (finalConfirmedQty) {
            //                         const confirmedNum = parseFloat(finalConfirmedQty);
            //                         if (confirmedNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty cannot be negative: ${finalConfirmedQty}`
            //                             });
            //                             finalConfirmedQty = "0.000";
            //                         }

            //                         if (confirmedNum > productionOrderQty) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Confirmed Qty (${finalConfirmedQty}) cannot exceed Production Order Qty (${productionOrderQty})`
            //                             });
            //                             finalConfirmedQty = productionOrderQty.toFixed(3);
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     if (finalScrapQty) {
            //                         const scrapNum = parseFloat(finalScrapQty);
            //                         if (scrapNum < 0) {
            //                             aInvalidRows.push({
            //                                 prodOrder: prodOrder,
            //                                 reason: `Scrap Qty cannot be negative: ${finalScrapQty}`
            //                             });
            //                             finalScrapQty = "0.000";
            //                         }
            //                     }

            //                     // Update the row with all fields
            //                     updatedRow.confirmedqty = finalConfirmedQty;
            //                     updatedRow.scrapqty = finalScrapQty;

            //                     // Add manufacturing date if available
            //                     if (formattedDate) {
            //                         updatedRow.manufacturingdate = formattedDate;
            //                     }

            //                     updatedRow.__selected = true;
            //                     aSamples[matchedRowIndex] = updatedRow;
            //                     aUpdatedRows.push(prodOrder);
            //                     hasAnyUpdate = true;
            //                 }
            //             });

            //             if (hasAnyUpdate) {
            //                 // Update the model
            //                 oTabModel.setProperty("/Samples", aSamples);

            //                 // Optionally update the select all checkbox
            //                 const allSelected = aSamples.every(row => row.__selected);
            //                 oSelectedModel.setProperty("/Samples/selectall", allSelected);

            //                 // Refresh the table
            //                 oTabModel.refresh(true);
            //             }

            //             // Build result message
            //             let message = "";

            //             if (aUpdatedRows.length > 0 || aBlockedRows.length > 0) {
            //                 if (aUpdatedRows.length > 0) {
            //                     message += `Successfully updated ${aUpdatedRows.length} row(s).\n`;
            //                     message += `Updated Production Orders:\n`;
            //                     aUpdatedRows.forEach(row => {
            //                         message += `  • ${row}\n`;
            //                     });
            //                     message += "\nCheckboxes have been selected for updated rows.\n\n";

            //                     // Add adjustment information
            //                     if (aAdjustedRows.length > 0) {
            //                         message += `Automatic calculations performed: ${aAdjustedRows.length} row(s)\n`;
            //                         aAdjustedRows.forEach(adj => {
            //                             message += `- ${adj.prodOrder}: ${adj.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }

            //                     // Add invalid rows information
            //                     if (aInvalidRows.length > 0) {
            //                         message += `Validation adjustments: ${aInvalidRows.length} row(s)\n`;
            //                         aInvalidRows.forEach(inv => {
            //                             message += `- ${inv.prodOrder}: ${inv.reason}\n`;
            //                         });
            //                         message += "\n";
            //                     }
            //                 }

            //                 // Add blocked rows information
            //                 if (aBlockedRows.length > 0) {
            //                     message += `Rows skipped due to business rules: ${aBlockedRows.length} row(s)\n`;
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `- ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                     message += "\n";
            //                 }

            //                 // Add not found information
            //                 if (aNotFound.length > 0) {
            //                     message += `Not found in table: ${aNotFound.length} row(s)\n`;
            //                     message += aNotFound.join(", ");
            //                 }

            //                 const icon = aBlockedRows.length > 0 ? sap.m.MessageBox.Icon.WARNING : sap.m.MessageBox.Icon.INFORMATION;
            //                 const title = aBlockedRows.length > 0 ? "Partial Import Results" : "Import Results";

            //                 sap.m.MessageBox.show(message, {
            //                     title: title,
            //                     icon: icon,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             } else {
            //                 if (aNotFound.length > 0) {
            //                     message = `No matching rows found for:\n${aNotFound.join("\n")}`;
            //                 } else if (aBlockedRows.length > 0) {
            //                     message = "No data was imported due to business rule violations:\n\n";
            //                     aBlockedRows.forEach(blocked => {
            //                         message += `• ${blocked.prodOrder} (Plant: ${blocked.plant}): ${blocked.reason}\n`;
            //                     });
            //                 } else {
            //                     message = "No data was imported.";
            //                 }

            //                 sap.m.MessageBox.show(message, {
            //                     title: "Import Results",
            //                     icon: sap.m.MessageBox.Icon.WARNING,
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     contentWidth: "600px"
            //                 });
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsArrayBuffer(file);
            //     }

            //     // Create file input element
            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.onchange = function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;

            //         // Check file extension
            //         const fileName = file.name.toLowerCase();
            //         if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
            //             sap.m.MessageBox.error("Please select an Excel file (.xlsx or .xls)");
            //             document.body.removeChild(fileInput);
            //             return;
            //         }

            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     };

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },






            // ------------------------------------------------------------------------------------------------------------------------------------------
            // For Goods issue Confirmation - Start
            // ------------------------------------------------------------------------------------------------------------------------------------------


            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // Confirmation OData //ZSB_TB_FT_PRODCONF

            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }


            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");

            //     if (aWithGI.length > 0) {
            //         // Extract production order numbers from those rows
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);

            //         // Create message string
            //         const sMessage =
            //             "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") +
            //             "\n\nPlease unselect them before proceeding.";

            //         sap.m.MessageBox.warning(sMessage);
            //         return;
            //     }


            //     // Check if all selected rows are released
            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
            //         return;
            //     }


            //     // const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     // if (aWithGI.length > 0) {
            //     //     sap.m.MessageBox.warning("Goods Issue already exists for one or more selected rows. Cannot proceed.");
            //     //     return;
            //     // }



            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const val = row.confirmedqty;
            //         return val === "" || val === null || val === undefined || isNaN(val) || parseFloat(val) <= 0;
            //     });

            //     if (aMissingQty.length > 0) {
            //         sap.m.MessageBox.error("Please enter a valid Confirmed QTY (greater than 0) for all selected rows.");
            //         return;
            //     }

            //     // const aMissingQty = aSelectedRows.filter(row => !row.confirmedqty);

            //     // if (aMissingQty.length > 0) {
            //     //     sap.m.MessageBox.error("Please enter Confirmed QTY for all selected rows.");
            //     //     return;
            //     // }




            //     sap.ui.core.BusyIndicator.show(0);

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const oRow = aSelectedRows[i];

            //         try {
            //             // Apply filters
            //             const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //             const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //             await new Promise((resolve, reject) => {
            //                 oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                     filters: [oFilter1, oFilter2],
            //                     success: async function (OData) {
            //                         if (OData.results.length === 0) {
            //                             sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
            //                             return resolve();
            //                         }

            //                         const oData = OData.results[0];

            //                         // Calculate work quantities
            //                         const calcQty = (qty, total, ref) => (qty * total) / ref;
            //                         const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oData.OperationReferenceQuantity);

            //                         // Call Confirm Issue API
            //                         let ManufacturingOrderOperation = oData.ManufacturingOrderOperation;
            //                         let GR_NO = await that.ToConfirmIssueAPIPost(
            //                             ManufacturingOrderOperation,
            //                             opconfirmedworkquantity1,
            //                             opconfirmedworkquantity2,
            //                             opconfirmedworkquantity3,
            //                             opconfirmedworkquantity4,
            //                             opconfirmedworkquantity5,
            //                             opconfirmedworkquantity6,
            //                             oRow // <-- pass the row
            //                         );

            //                         const matDoc = GR_NO[0].materialdocument;
            //                         oRow.gicnfmaterialdocnumber = GR_NO[0].materialdocument;
            //                         oRow.gicnfmaterialdocyear = GR_NO[0].matdocyear;
            //                         oRow.gicnfconfirmationgroup = GR_NO[0].confirmationgroup;
            //                         oRow.gicnfconfirmationcount = GR_NO[0].confirmationcount;

            //                         oTabModel.refresh();

            //                         if (!matDoc) {
            //                             let ErrorMessage = "Some error occurred while posting.";
            //                             try {
            //                                 const kk = JSON.parse(GR_NO[0].errorresponse);
            //                                 ErrorMessage = kk.error.message.value;
            //                             } catch (e) {
            //                                 // ignore
            //                             }
            //                             sap.m.MessageBox.error(ErrorMessage);
            //                         } else {
            //                             await that.ToUpdateIntTab(oRow, matDoc, GR_NO[0]);
            //                             sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
            //                             that.FinalStatus = new sap.ui.model.json.JSONModel({
            //                                 MSGSTRIP: {
            //                                     visible: true,
            //                                     text: "Material Document No - Goods Issue : " + matDoc,
            //                                     type: 'Success'
            //                                 }
            //                             });
            //                             oView.setModel(that.FinalStatus, "FinalStatus");
            //                         }

            //                         resolve();
            //                     },
            //                     error: function (error) {
            //                         console.log(error);
            //                         sap.ui.core.BusyIndicator.hide();
            //                         reject(error);
            //                     }
            //                 });
            //             });

            //         } catch (e) {
            //             console.error("Error in confirmation:", e);
            //         }
            //     }

            //     sap.ui.core.BusyIndicator.hide();
            // },


            // ToConfirmIssueAPIPost: function (ManufacturingOrderOperation, opconfirmedworkquantity1, opconfirmedworkquantity2, opconfirmedworkquantity3, opconfirmedworkquantity4, opconfirmedworkquantity5, opconfirmedworkquantity6) {

            //     return new Promise(async (resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();



            //         const oView = this.getView();
            //         const oTabModel = oView.getModel("TabModel");

            //         const aRows = oTabModel.getProperty("/Samples");
            //         const iSelectedIndex = aRows.findIndex(row => row.__selected);

            //         if (iSelectedIndex === -1) {
            //             sap.m.MessageToast.show("Please select a row.");
            //             return;
            //         }

            //         const oSelectedRow = aRows[iSelectedIndex];



            //         var that = this;
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.information("Do you want to post this data.", {
            //             actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //             emphasizedAction: sap.m.MessageBox.Action.YES,
            //             onClose: async function (sAction) {
            //                 if (sAction === "YES") {

            //                     sap.ui.core.BusyIndicator.show();

            //                     // ************** Start For Header *********************
            //                     const postIDTableLevel = new Promise((resolve, reject) => {

            //                         var oEntry = {
            //                             orderid: oSelectedRow.productionorderno,
            //                             orderoperation: ManufacturingOrderOperation,
            //                             ordersuboperation: "0000",
            //                             // "ConfirmationUnit"  : "KG",
            //                             //  "ConfirmationUnitISOCode" : "PCE",
            //                             confirmationyieldquantity: String(oSelectedRow.confirmedqty),
            //                             //  "ConfirmationScrapQuantity" : "0",
            //                             //  "OpWorkQuantityUnit1" : "HR",
            //                             //  "WorkQuantityUnit1ISOCode"  : "HR",
            //                             opconfirmedworkquantity1: String(opconfirmedworkquantity1),
            //                             opconfirmedworkquantity2: String(opconfirmedworkquantity2),
            //                             opconfirmedworkquantity3: String(opconfirmedworkquantity3),
            //                             opconfirmedworkquantity4: String(opconfirmedworkquantity4),
            //                             opconfirmedworkquantity5: String(opconfirmedworkquantity5),
            //                             opconfirmedworkquantity6: String(opconfirmedworkquantity6),
            //                             // uom:"",
            //                             materialdocument: "",
            //                             matdocyear: "",
            //                             sequence: "0000",
            //                             // "response" : ""
            //                             confirmationgroup: "",
            //                             confirmationcount: "",
            //                             finalconfirmationtype: "X",
            //                             scrapqty: parseFloat(oSelectedRow.balanceqty).toFixed(3)

            //                         };
            //                         console.log("oEntryoEntry:", oEntry);

            //                         that.getView().setModel();

            //                         var oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");//ZSB_TB_FT_PRODCONF

            //                         oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
            //                             success: function (oData, oResponse) {

            //                                 console.log(oData);
            //                                 console.log(oData.response);

            //                                 console.log(oData)
            //                                 // oModelGet.refresh(true);
            //                                 sap.ui.core.BusyIndicator.hide();
            //                                 resolve(oData);
            //                             },

            //                             error: function (error) {
            //                                 console.log("error");
            //                                 sap.ui.core.BusyIndicator.hide();
            //                                 sap.m.MessageBox.error("Process Failed...")
            //                                 reject(error)
            //                             }
            //                         });

            //                     });
            //                     // / ************** End For Header *********************

            //                     let OutPutData = await Promise.all([postIDTableLevel]);

            //                     // ************************************************************

            //                     resolve(OutPutData);

            //                 } else {
            //                     sap.m.MessageToast.show("Cancelled");
            //                     sap.ui.core.BusyIndicator.hide();
            //                 }
            //             }
            //         });
            //     });
            // },

            // ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

            //     return new Promise((resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();
            //         var that = this;
            //         var oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");
            //         // oModelGet.setHeaders({
            //         //     "X-Requested-With": "X",
            //         //     "Content-Type": "application/json"
            //         // });

            //         var oEntry = {
            //             confirmedqty: String(HeaderModel.confirmedqty),
            //             // confirmedqty: String(HeaderModel.confirmedqty),
            //             balanceqty: String(HeaderModel.balanceqty), // ✅ Added balanceqty
            //             gicnfmaterialdocnumber: resp.materialdocument,
            //             gicnfmaterialdocyear: resp.matdocyear,
            //             gicnfconfirmationgroup: resp.confirmationgroup,
            //             gicnfconfirmationcount: resp.confirmationcount,


            //         };

            //         oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            //             success: function (oData, oResponse) {
            //                 console.log("Goods Issue No Updated Successfully...")
            //                 resolve(oData);
            //             },

            //             error: function (error) {
            //                 console.log("error");
            //                 sap.ui.core.BusyIndicator.hide();
            //                 sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
            //                 reject(error)
            //             }
            //         });

            //     });
            // },


            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     if (aWithGI.length > 0) {
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
            //         const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";
            //         sap.m.MessageBox.warning(sMessage);
            //         return;
            //     }

            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         sap.m.MessageBox.error("Some selected rows are not released. Please release them first.");
            //         return;
            //     }


            //     const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");

            //     if (aNotUpdated.length > 0) {
            //         // Extract Production Orders that are not updated
            //         const aNotUpdatedProdOrders = aNotUpdated.map(row => row.productionorderno).filter(Boolean);

            //         const sMessage = "The following Production Orders are not updated:\n\n" +
            //             aNotUpdatedProdOrders.join(", ") + "\n\nPlease ensure these rows are updated before proceeding.";

            //         sap.m.MessageBox.error(sMessage);
            //         return;
            //     }

            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const confirmedVal = row.confirmedqty;
            //         const balanceVal = row.scrapqty;

            //         // Function to check zero or empty values for qty fields
            //         const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;

            //         // Check if confirmedqty invalid (null, empty, NaN, or negative)
            //         const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;

            //         // Check if BOTH confirmedqty and scrapqty are zero/null (or equivalent)
            //         const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);

            //         // Return true if either:
            //         // 1) confirmedqty is invalid (negative, missing, NaN)
            //         // OR
            //         // 2) both confirmedqty and scrapqty are zero/null
            //         return confirmedInvalid || bothZeroOrNull;
            //     });

            //     if (aMissingQty.length > 0) {
            //         sap.m.MessageBox.error("Please enter a valid Confirmed QTY (0 or greater) for all selected rows. If the value is empty, please add 0.");
            //         return;
            //     }
            //     // NEW VALIDATION: Check if sum of confirmedqty + balanceqty equals productionorderqty
            //     const aQtyMismatch = aSelectedRows.filter(row => {
            //         const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
            //         const iBalanceQty = parseFloat(row.scrapqty) || 0;
            //         const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;

            //         const iTotalQty = iConfirmedQty + iBalanceQty;

            //         // Use tolerance for floating point comparison
            //         const dTolerance = 0.0001;
            //         return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
            //     });

            //     if (aQtyMismatch.length > 0) {
            //         const aProdOrders = aQtyMismatch.map(row => row.productionorderno).filter(Boolean);
            //         const sMessage = `The sum of Confirmed QTY and Scrap QTY must equal Production Order QTY for the following Production Orders:\n\n${aProdOrders.join(", ")}\n\nPlease adjust the quantities before proceeding.`;
            //         sap.m.MessageBox.error(sMessage);
            //         return;
            //     }

            //     // ✅ Confirm before processing
            //     sap.m.MessageBox.confirm("Do you want to post the selected data?", {
            //         actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //         emphasizedAction: sap.m.MessageBox.Action.YES,
            //         onClose: async function (sAction) {
            //             if (sAction === sap.m.MessageBox.Action.YES) {
            //                 sap.ui.core.BusyIndicator.show(0);

            //                 let allSuccessful = true;

            //                 for (let i = 0; i < aSelectedRows.length; i++) {
            //                     const oRow = aSelectedRows[i];

            //                     try {
            //                         const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //                         const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //                         await new Promise((resolve, reject) => {
            //                             oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                                 filters: [oFilter1, oFilter2],
            //                                 success: async function (OData) {
            //                                     if (OData.results.length === 0) {
            //                                         sap.m.MessageBox.error(`YBP4 data not found for order ${oRow.productionorderno}`);
            //                                         allSuccessful = false;
            //                                         return resolve();
            //                                     }

            //                                     const oData = OData.results[0];
            //                                     // const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;
            //                                     const calcQty = (qty, total, scrap, ref) =>
            //                                         (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

            //                                     console.log("response:", oData)
            //                                     const opconfirmedworkquantity1 = calcQty(oData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
            //                                     const opconfirmedworkquantity2 = calcQty(oData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
            //                                     const opconfirmedworkquantity3 = calcQty(oData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
            //                                     const opconfirmedworkquantity4 = calcQty(oData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
            //                                     const opconfirmedworkquantity5 = calcQty(oData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);
            //                                     const opconfirmedworkquantity6 = calcQty(oData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oData.OperationReferenceQuantity);

            //                                     const ManufacturingOrderOperation = oData.ManufacturingOrderOperation;
            //             // debugger
            //                                     const postResult = await that.ToConfirmIssueAPIPost(
            //                                         ManufacturingOrderOperation,
            //                                         opconfirmedworkquantity1,
            //                                         opconfirmedworkquantity2,
            //                                         opconfirmedworkquantity3,
            //                                         opconfirmedworkquantity4,
            //                                         opconfirmedworkquantity5,
            //                                         opconfirmedworkquantity6,
            //                                         oRow
            //                                     );

            //                                     const matDoc = postResult.materialdocument;
            //                                     oRow.gicnfmaterialdocnumber = postResult.materialdocument;
            //                                     oRow.gicnfmaterialdocyear = postResult.matdocyear;
            //                                     oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
            //                                     oRow.gicnfconfirmationcount = postResult.confirmationcount;

            //                                     oTabModel.refresh();

            //                                     if (!matDoc) {
            //                                         let ErrorMessage = "Some error occurred while posting.";
            //                                         try {
            //                                             const kk = JSON.parse(postResult.errorresponse);
            //                                             ErrorMessage = kk.error.message.value;
            //                                         } catch (e) { }
            //                                         sap.m.MessageBox.error(ErrorMessage);
            //                                         allSuccessful = false;
            //                                     } else {
            //                                         await that.ToUpdateIntTab(oRow, matDoc, postResult);
            //                                         that.FinalStatus = new sap.ui.model.json.JSONModel({
            //                                             MSGSTRIP: {
            //                                                 visible: true,
            //                                                 text: "Material Document No - Goods Issue : " + matDoc,
            //                                                 type: 'Success'
            //                                             }
            //                                         });
            //                                         oView.setModel(that.FinalStatus, "FinalStatus");
            //                                     }

            //                                     resolve();
            //                                 },
            //                                 error: function (error) {
            //                                     console.log(error);
            //                                     sap.ui.core.BusyIndicator.hide();
            //                                     allSuccessful = false;
            //                                     reject(error);
            //                                 }
            //                             });
            //                         });

            //                     } catch (e) {
            //                         console.error("Error in confirmation:", e);
            //                         allSuccessful = false;
            //                     }
            //                 }

            //                 sap.ui.core.BusyIndicator.hide();

            //                 // ✅ Final message at the end
            //                 if (allSuccessful) {
            //                     sap.m.MessageBox.success("Process order confirmed and materials issued successfully.");
            //                 } else {
            //                     sap.m.MessageBox.warning("Process completed with some errors. Check details.");
            //                 }
            //             }
            //         }
            //     });
            // },


            // ToConfirmIssueAPIPost: function (
            //     ManufacturingOrderOperation,
            //     opconfirmedworkquantity1,
            //     opconfirmedworkquantity2,
            //     opconfirmedworkquantity3,
            //     opconfirmedworkquantity4,
            //     opconfirmedworkquantity5,
            //     opconfirmedworkquantity6,
            //     oSelectedRow
            // ) {
            //     return new Promise(async (resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();

            //         const that = this;
            //         const oEntry = {
            //             orderid: oSelectedRow.productionorderno,
            //             orderoperation: ManufacturingOrderOperation,
            //             ordersuboperation: "0000",
            //             confirmationyieldquantity: String(oSelectedRow.confirmedqty),
            //             opconfirmedworkquantity1: String(opconfirmedworkquantity1),
            //             opconfirmedworkquantity2: String(opconfirmedworkquantity2),
            //             opconfirmedworkquantity3: String(opconfirmedworkquantity3),
            //             opconfirmedworkquantity4: String(opconfirmedworkquantity4),
            //             opconfirmedworkquantity5: String(opconfirmedworkquantity5),
            //             opconfirmedworkquantity6: String(opconfirmedworkquantity6),
            //             materialdocument: "",
            //             matdocyear: "",
            //             sequence: "0000",
            //             confirmationgroup: "",
            //             confirmationcount: "",
            //             finalconfirmationtype: "X",
            //             scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3)
            //         };
            //         console.log("payload bring posrted: ", oEntry)

            //         const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1");

            //         oModelGet.create("/ZC_TB_FT_PRODCONF1", oEntry, {
            //             success: function (oData) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 resolve(oData); // ✅ Return the object directly
            //             },
            //             error: function (error) {
            //                 sap.ui.core.BusyIndicator.hide();
            //                 sap.m.MessageBox.error("Process Failed...");
            //                 reject(error);
            //             }
            //         });
            //     });
            // },



            // ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {

            //     return new Promise((resolve, reject) => {
            //         sap.ui.core.BusyIndicator.show();
            //         var that = this;
            //         var oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");
            //         // oModelGet.setHeaders({
            //         //     "X-Requested-With": "X",
            //         //     "Content-Type": "application/json"
            //         // });

            //         var oEntry = {
            //             confirmedqty: String(HeaderModel.confirmedqty),
            //             // confirmedqty: String(HeaderModel.confirmedqty),
            //             scrapqty: String(HeaderModel.scrapqty), // ✅ Added balanceqty
            //             gicnfmaterialdocnumber: resp.materialdocument,
            //             gicnfmaterialdocyear: resp.matdocyear,
            //             gicnfconfirmationgroup: resp.confirmationgroup,
            //             gicnfconfirmationcount: resp.confirmationcount,


            //         };

            //         oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
            //             success: function (oData, oResponse) {
            //                 console.log("Goods Issue No Updated Successfully...")
            //                 resolve(oData);
            //             },

            //             error: function (error) {
            //                 console.log("error");
            //                 sap.ui.core.BusyIndicator.hide();
            //                 sap.m.MessageToast.show("Goods Issue Doc No - Internal table update failed")
            //                 reject(error)
            //             }
            //         });

            //     });
            // },


            // OnAPIPost_Confirmation: async function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTabModel = oView.getModel("TabModel");
            //     const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     let aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     // Arrays to track results
            //     const aSuccessRows = [];
            //     const aFailedRows = [];
            //     const aSkippedRows = [];

            //     // Run validations first
            //     const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
            //     if (aWithGI.length > 0) {
            //         const aProdOrders = aWithGI.map(row => row.productionorderno).filter(Boolean);
            //         const sMessage = "Goods Issue already exists for the following Production Orders:\n\n" +
            //             aProdOrders.join(", ") + "\n\nPlease unselect them before proceeding.";

            //         // Track skipped rows
            //         aWithGI.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Goods Issue already exists"
            //             });
            //         });

            //         // Remove already GI rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));

            //         if (aSelectedRows.length === 0) {
            //             this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             return;
            //         }
            //     }

            //     const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
            //     if (aUnreleased.length > 0) {
            //         // Track unreleased rows
            //         aUnreleased.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Not released"
            //             });
            //         });

            //         // Remove unreleased rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
            //     }

            //     const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
            //     if (aNotUpdated.length > 0) {
            //         // Track not updated rows
            //         aNotUpdated.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Please enter the QTY & update the status"
            //             });
            //         });

            //         // Remove not updated rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
            //     }

            //     const aMissingQty = aSelectedRows.filter(row => {
            //         const confirmedVal = row.confirmedqty;
            //         const balanceVal = row.scrapqty;
            //         const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
            //         const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
            //         const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
            //         return confirmedInvalid || bothZeroOrNull;
            //     });

            //     if (aMissingQty.length > 0) {
            //         // Track missing quantity rows
            //         aMissingQty.forEach(row => {
            //             aSkippedRows.push({
            //                 productionOrder: row.productionorderno,
            //                 reason: "Invalid quantity values"
            //             });
            //         });

            //         // Remove missing quantity rows from processing
            //         aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
            //     }

            //     // const aQtyMismatch = aSelectedRows.filter(row => {
            //     //     const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
            //     //     const iBalanceQty = parseFloat(row.scrapqty) || 0;
            //     //     const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
            //     //     const iTotalQty = iConfirmedQty + iBalanceQty;
            //     //     const dTolerance = 0.0001;
            //     //     return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
            //     // });

            //     // if (aQtyMismatch.length > 0) {
            //     //     // Track quantity mismatch rows
            //     //     aQtyMismatch.forEach(row => {
            //     //         aSkippedRows.push({
            //     //             productionOrder: row.productionorderno,
            //     //             reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
            //     //         });
            //     //     });

            //     //     // Remove quantity mismatch rows from processing
            //     //     aSelectedRows = aSelectedRows.filter(row => !aQtyMismatch.includes(row));
            //     // }

            //     // Check if any rows remain to process
            //     if (aSelectedRows.length === 0) {
            //         // Show summary if all rows were skipped during validation
            //         this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //         return;
            //     }

            //     aSelectedRows.sort((a, b) => {
            //         // Sort by productionordstartdate (ascending)
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);

            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;

            //         // If dates are equal, sort by bipllotno numerically (ascending)
            //         const lotA = parseInt(a.bipllotno, 10) || 0;
            //         const lotB = parseInt(b.bipllotno, 10) || 0;

            //         // Return difference for numeric order
            //         return lotA - lotB;
            //     });

            //     // ✅ Confirm before processing
            //     sap.m.MessageBox.confirm("Do you want to post the selected data?", {
            //         actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
            //         emphasizedAction: sap.m.MessageBox.Action.YES,
            //         onClose: async function (sAction) {
            //             if (sAction === sap.m.MessageBox.Action.YES) {
            //                 // Show loading indicator ONCE at the beginning
            //                 sap.ui.core.BusyIndicator.show(0);

            //                 // Process each row individually
            //                 for (let i = 0; i < aSelectedRows.length; i++) {
            //                     const oRow = aSelectedRows[i];

            //                     try {
            //                         const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
            //                         const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

            //                         const oData = await new Promise((resolve, reject) => {
            //                             oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
            //                                 filters: [oFilter1, oFilter2],
            //                                 success: function (OData) {
            //                                     resolve(OData);
            //                                 },
            //                                 error: function (error) {
            //                                     reject(error);
            //                                 }
            //                             });
            //                         });

            //                         console.log("Response:", oData);

            //                         if (oData.results.length === 0) {
            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: `YBP4 data not found for order ${oRow.productionorderno}`
            //                             });
            //                             continue; // Skip to next row
            //                         }

            //                         // Activity - Confirmation qty + Scrap qty * Operation qty/base qty
            //                         const oResultData = oData.results[0];
            //                         // const calcQty = (qty, total, scrap, ref) => (qty * (total + scrap)) / ref;
            //                         // const calcQty = (qty, total, scrap, ref) =>
            //                         //     (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);


            //                         const calcQty = (qty, total, scrap, ref) => {
            //                             const result =
            //                                 (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);

            //                             // round to 3 decimals and return as NUMBER
            //                             return Number(result.toFixed(3));
            //                         };

            //                         const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
            //                         const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

            //                         const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

            //                         const postResult = await that.ToConfirmIssueAPIPost(
            //                             ManufacturingOrderOperation,
            //                             opconfirmedworkquantity1,
            //                             opconfirmedworkquantity2,
            //                             opconfirmedworkquantity3,
            //                             opconfirmedworkquantity4,
            //                             opconfirmedworkquantity5,
            //                             opconfirmedworkquantity6,
            //                             oRow
            //                         );

            //                         const matDoc = postResult.materialdocument;

            //                         if (!matDoc) {
            //                             let ErrorMessage = "Some error occurred while posting.";
            //                             try {
            //                                 const kk = JSON.parse(postResult.errorresponse);
            //                                 ErrorMessage = kk.error.message.value;
            //                             } catch (e) { }

            //                             aFailedRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 error: ErrorMessage
            //                             });
            //                         } else {
            //                             // Update row with material document
            //                             oRow.gicnfmaterialdocnumber = postResult.materialdocument;
            //                             oRow.gicnfmaterialdocyear = postResult.matdocyear;
            //                             oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
            //                             oRow.gicnfconfirmationcount = postResult.confirmationcount;

            //                             // Update internal table
            //                             await that.ToUpdateIntTab(oRow, matDoc, postResult);

            //                             aSuccessRows.push({
            //                                 productionOrder: oRow.productionorderno,
            //                                 materialDocument: matDoc
            //                             });
            //                         }

            //                     } catch (error) {
            //                         console.error("Error in confirmation for order:", oRow.productionorderno, error);
            //                         aFailedRows.push({
            //                             productionOrder: oRow.productionorderno,
            //                             error: error.message || "Unknown error"
            //                         });
            //                     }
            //                 }

            //                 // Refresh table once at the end
            //                 oTabModel.refresh();

            //                 // Hide loading indicator only after all processing is complete
            //                 sap.ui.core.BusyIndicator.hide();

            //                 // Show summary
            //                 that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
            //             }
            //         }
            //     });
            // },


            checkUserHasGoodsIssueRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },


            OnAPIPost_Confirmation: async function () {
                const that = this;
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- 1. Local GI check (already has material document in UI) ---
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                if (aWithGI.length > 0) {
                    aWithGI.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Goods Issue already exists (local)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aWithGI.includes(row));
                }

                // --- 2. Release status check ---
                const aUnreleased = aSelectedRows.filter(row => row.releasestatus !== "RELEASED");
                if (aUnreleased.length > 0) {
                    aUnreleased.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not released"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aUnreleased.includes(row));
                }

                // --- 3. Update status check (must be "GT") ---
                const aNotUpdated = aSelectedRows.filter(row => row.updatestatusgistatus !== "GT");
                if (aNotUpdated.length > 0) {
                    aNotUpdated.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Not updated (status not GT)"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aNotUpdated.includes(row));
                }

                // --- 4. Quantity validation ---
                const aMissingQty = aSelectedRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });

                if (aMissingQty.length > 0) {
                    aMissingQty.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Invalid quantity values"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingQty.includes(row));
                }

                // --- 5. Posting Date validation (mandatory) ---
                const aMissingPostingDate = aSelectedRows.filter(row => {
                    const postingDate = row.PostingDate;
                    // Check if null, undefined, empty string, or invalid Date object
                    if (!postingDate) return true;
                    // If it's a date object, check if valid
                    const dateObj = new Date(postingDate);
                    return isNaN(dateObj.getTime());
                });

                if (aMissingPostingDate.length > 0) {
                    aMissingPostingDate.forEach(row => {
                        aSkippedRows.push({
                            productionOrder: row.productionorderno,
                            reason: "Missing or invalid posting date"
                        });
                    });
                    aSelectedRows = aSelectedRows.filter(row => !aMissingPostingDate.includes(row));
                }

                // --- If no rows left after validations, show summary and return ---
                if (aSelectedRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- ADDED / MODIFIED: Fetch existing GI data from ZSB_MATDOC_FETCH ---
                const oFetchModel = oView.getModel("ZSB_MATDOC_FETCH");
                if (!oFetchModel) {
                    sap.m.MessageToast.show("Missing model for fetching existing goods issue data.");
                    return;
                }

                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];           // rows that need to be posted

                // ⏳ BUSY: Show busy indicator before async fetch
                sap.ui.core.BusyIndicator.show(0);

                // Fetch existing data for all remaining rows in parallel
                const fetchExistingPromises = aSelectedRows.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            row.productionorderno
                        );

                        const oSorter = new sap.ui.model.Sorter(
                            "MfgOrderConfirmation",
                            true   // descending = highest first
                        );

                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_MATDOC_FETCH", {
                                filters: [oFilter],
                                sorters: [oSorter],
                                top: 1,
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log("result fetched:", oData);

                        if (oData.results && oData.results.length > 0) {
                            // Already sorted by backend and limited to top 1,
                            // but keep explicit sort for safety
                            const sortedResults = [...oData.results].sort((a, b) =>
                                b.MfgOrderConfirmation - a.MfgOrderConfirmation
                            );
                            const highest = sortedResults[0];
                            console.log(`✅ Fetched for order ${row.productionorderno}: MfgOrderConfirmation = ${highest.MfgOrderConfirmation}, MaterialDocument = ${highest.MaterialDocument}`);
                            return { row, existing: highest };
                        } else {
                            // No existing data → treat as not existing
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GI for order ${row.productionorderno}:`, err);
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Populate arrays
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a material document in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;
                    const confirmationGroup = existing.MfgOrderConfirmationGroup;
                    const confirmationCount = existing.MfgOrderConfirmation;

                    // Update local row
                    row.gicnfmaterialdocnumber = matDoc;
                    row.gicnfmaterialdocyear = matDocYear;
                    row.gicnfconfirmationgroup = confirmationGroup;
                    row.gicnfconfirmationcount = confirmationCount;

                    // Update internal table (use the existing ToUpdateIntTab method)
                    try {
                        await that.ToUpdateIntTab(
                            row,
                            matDoc,
                            {
                                materialdocument: matDoc,
                                matdocyear: matDocYear,
                                confirmationgroup: confirmationGroup,
                                confirmationcount: confirmationCount
                            }
                        );
                        console.log(`✅ Updated internal table for existing order ${row.productionorderno}`);
                        aSuccessRows.push({
                            productionOrder: row.productionorderno,
                            materialDocument: matDoc,
                            materialDocumentYear: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update internal table for existing order ${row.productionorderno}:`, updateErr);
                        aFailedRows.push({
                            productionOrder: row.productionorderno,
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // ⏳ BUSY: Hide busy indicator before showing confirmation dialog
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // --- Sort rows to post ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods issue for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        // ⏳ BUSY: Show busy indicator again before posting
                        sap.ui.core.BusyIndicator.show(0);

                        // --- Process each row that needs to be posted ---
                        for (let i = 0; i < aRowsToPost.length; i++) {
                            const oRow = aRowsToPost[i];

                            try {
                                // Fetch YBP4 data (as in original)
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, oRow.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (oData.results.length === 0) {
                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: `YBP4 data not found for order ${oRow.productionorderno}`
                                    });
                                    continue;
                                }

                                const oResultData = oData.results[0];
                                const calcQty = (qty, total, scrap, ref) => {
                                    const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                                    return Number(result.toFixed(3));
                                };

                                const opconfirmedworkquantity1 = calcQty(oResultData.WorkCenterStandardWorkQty1, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity2 = calcQty(oResultData.WorkCenterStandardWorkQty2, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity3 = calcQty(oResultData.WorkCenterStandardWorkQty3, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity4 = calcQty(oResultData.WorkCenterStandardWorkQty4, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity5 = calcQty(oResultData.WorkCenterStandardWorkQty5, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);
                                const opconfirmedworkquantity6 = calcQty(oResultData.WorkCenterStandardWorkQty6, oRow.confirmedqty, oRow.scrapqty, oResultData.OperationReferenceQuantity);

                                const ManufacturingOrderOperation = oResultData.ManufacturingOrderOperation;

                                const postResult = await that.ToConfirmIssueAPIPost(
                                    ManufacturingOrderOperation,
                                    opconfirmedworkquantity1,
                                    opconfirmedworkquantity2,
                                    opconfirmedworkquantity3,
                                    opconfirmedworkquantity4,
                                    opconfirmedworkquantity5,
                                    opconfirmedworkquantity6,
                                    oRow
                                );

                                const matDoc = postResult.materialdocument;
                                if (!matDoc) {
                                    let ErrorMessage = "Some error occurred while posting.";
                                    try {
                                        const kk = JSON.parse(postResult.errorresponse);
                                        ErrorMessage = kk.error.message.value;
                                    } catch (e) { }

                                    aFailedRows.push({
                                        productionOrder: oRow.productionorderno,
                                        error: ErrorMessage
                                    });
                                } else {
                                    // Update row with material document
                                    oRow.gicnfmaterialdocnumber = postResult.materialdocument;
                                    oRow.gicnfmaterialdocyear = postResult.matdocyear;
                                    oRow.gicnfconfirmationgroup = postResult.confirmationgroup;
                                    oRow.gicnfconfirmationcount = postResult.confirmationcount;

                                    // Update internal table
                                    await that.ToUpdateIntTab(oRow, matDoc, postResult);

                                    aSuccessRows.push({
                                        productionOrder: oRow.productionorderno,
                                        materialDocument: matDoc
                                    });
                                }

                            } catch (error) {
                                console.error("Error in confirmation for order:", oRow.productionorderno, error);
                                aFailedRows.push({
                                    productionOrder: oRow.productionorderno,
                                    error: error.message || "Unknown error"
                                });
                            }
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        that.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    }
                });
            },

            // Show confirmation summary
            showConfirmationSummary: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },
            ToConfirmIssueAPIPost: function (
                ManufacturingOrderOperation,
                opconfirmedworkquantity1,
                opconfirmedworkquantity2,
                opconfirmedworkquantity3,
                opconfirmedworkquantity4,
                opconfirmedworkquantity5,
                opconfirmedworkquantity6,
                oSelectedRow
            ) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oEntry = {
                        orderid: oSelectedRow.productionorderno,
                        orderoperation: ManufacturingOrderOperation,
                        ordersuboperation: "0000",
                        confirmationyieldquantity: String(oSelectedRow.confirmedqty),
                        opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                        opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                        opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                        opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                        opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                        opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                        materialdocument: "",
                        matdocyear: "",
                        sequence: "0000",
                        confirmationgroup: "",
                        confirmationcount: "",
                        finalconfirmationtype: "X",
                        PostingDate: oSelectedRow.PostingDate ? new Date(oSelectedRow.PostingDate.toLocaleDateString('en-CA')) : null,
                        scrapqty: parseFloat(oSelectedRow.scrapqty).toFixed(3)
                    };

                    console.log("payload being posted: ", oEntry);

                    const oModelGet = that.getView().getModel("ZSB_TB_FT_PRODCONF1_WTRL");

                    oModelGet.create("/ZC_FT_PRODCONF1_WROLLER", oEntry, {
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (error) {
                            reject(error);
                        }
                    });
                });
            },

            ToUpdateIntTab: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");

                    var oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        RejectCodes: String(HeaderModel.RejectCodes),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                        PostingDate: HeaderModel.PostingDate ? new Date(HeaderModel.PostingDate.toLocaleDateString('en-CA')) : null,
                    };

                    oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData, oResponse) {
                            console.log("Goods Issue No Updated Successfully...");
                            resolve(oData);
                        },
                        error: function (error) {
                            console.log("Error updating internal table:", error);
                            reject(error);
                        }
                    });
                });
            },



            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqnoGI: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessageGoodsIssue: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Main Goods Issue function using header-item service (batch)
            // ============================================================
            onGoodsIssuePressBatch: async function () {
                const that = this;
                const oView = this.getView();
                const oGIModel = oView.getModel("ZSB_GICONF_HEAD_ITEM");   // new service
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                let aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Arrays for final summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aSkippedRows = [];

                // --- VALIDATIONS (same as original) ---
                // 1. Already has Goods Issue
                const aWithGI = aSelectedRows.filter(row => row.gicnfmaterialdocnumber && row.gicnfmaterialdocnumber.trim() !== "");
                aWithGI.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Issue already exists"
                    });
                });
                let aProcessRows = aSelectedRows.filter(row => !aWithGI.includes(row));

                // 2. Not released
                const aUnreleased = aProcessRows.filter(row => row.releasestatus !== "RELEASED");
                aUnreleased.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not released"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aUnreleased.includes(row));

                // 3. Update status not "GT"
                const aNotUpdated = aProcessRows.filter(row => row.updatestatusgistatus !== "GT");
                aNotUpdated.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Not updated (status not GT)"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aNotUpdated.includes(row));

                // 4. Missing quantity
                const aMissingQty = aProcessRows.filter(row => {
                    const confirmedVal = row.confirmedqty;
                    const balanceVal = row.scrapqty;
                    const isZeroOrNull = val => val === "" || val === null || val === undefined || parseFloat(val) === 0;
                    const confirmedInvalid = confirmedVal === "" || confirmedVal === null || confirmedVal === undefined || isNaN(confirmedVal) || parseFloat(confirmedVal) < 0;
                    const bothZeroOrNull = isZeroOrNull(confirmedVal) && isZeroOrNull(balanceVal);
                    return confirmedInvalid || bothZeroOrNull;
                });
                aMissingQty.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Invalid quantity values"
                    });
                });
                aProcessRows = aProcessRows.filter(row => !aMissingQty.includes(row));

                // 5. Quantity mismatch (confirmed + scrap ≠ production order qty)
                // const aQtyMismatch = aProcessRows.filter(row => {
                //     const iConfirmedQty = parseFloat(row.confirmedqty) || 0;
                //     const iBalanceQty = parseFloat(row.scrapqty) || 0;
                //     const iProductionOrderQty = parseFloat(row.productionorderqty) || 0;
                //     const iTotalQty = iConfirmedQty + iBalanceQty;
                //     const dTolerance = 0.0001;
                //     return Math.abs(iTotalQty - iProductionOrderQty) > dTolerance;
                // });
                // aQtyMismatch.forEach(row => {
                //     aSkippedRows.push({
                //         productionOrder: row.productionorderno,
                //         reason: "Quantity mismatch (confirmed + scrap ≠ production order)"
                //     });
                // });
                // aProcessRows = aProcessRows.filter(row => !aQtyMismatch.includes(row));

                // If no rows left to process, show summary and return
                if (aProcessRows.length === 0) {
                    this.showConfirmationSummary(aSuccessRows, aFailedRows, aSkippedRows);
                    return;
                }

                // Sort rows by start date and lot number
                aProcessRows.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // Confirm with user
                sap.m.MessageBox.confirm("Do you want to post the selected data?", {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) return;

                        sap.ui.core.BusyIndicator.show(0);

                        // --- FETCH YBP4 DATA FOR ALL PROCESS ROWS (parallel) ---
                        const oModel = oView.getModel("ZSB_TB_FT_PRODCONF1"); // model for reading YBP4 data
                        const fetchPromises = aProcessRows.map(async (row) => {
                            try {
                                const oFilter1 = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                                const oFilter2 = new sap.ui.model.Filter("OperationControlProfile", sap.ui.model.FilterOperator.EQ, "YBP4");

                                const oData = await new Promise((resolve, reject) => {
                                    oModel.read("/ZC_PRODUCTIONORDERCONFRMATION1", {
                                        filters: [oFilter1, oFilter2],
                                        success: resolve,
                                        error: reject
                                    });
                                });

                                if (!oData.results || oData.results.length === 0) {
                                    return { row, success: false, error: `YBP4 data not found for order ${row.productionorderno}` };
                                }

                                return { row, success: true, data: oData.results[0] };
                            } catch (err) {
                                return { row, success: false, error: err.message || "Error fetching YBP4 data" };
                            }
                        });

                        const fetchResults = await Promise.all(fetchPromises);

                        // Separate successful fetches from failed ones
                        const validFetchResults = fetchResults.filter(r => r.success);
                        const failedFetchResults = fetchResults.filter(r => !r.success);

                        // Add fetch failures to aFailedRows
                        failedFetchResults.forEach(f => {
                            aFailedRows.push({
                                productionOrder: f.row.productionorderno,
                                error: f.error
                            });
                        });

                        // If no valid rows after fetches, show summary
                        if (validFetchResults.length === 0) {
                            sap.ui.core.BusyIndicator.hide();
                            this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                            return;
                        }

                        // Build payload items array
                        const aItems = [];
                        const calcQty = (qty, total, scrap, ref) => {
                            const result = (Number(qty) * (Number(total) + Number(scrap))) / Number(ref);
                            return Number(result.toFixed(3));
                        };

                        validFetchResults.forEach(({ row, data }) => {
                            const opconfirmedworkquantity1 = calcQty(data.WorkCenterStandardWorkQty1, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity2 = calcQty(data.WorkCenterStandardWorkQty2, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity3 = calcQty(data.WorkCenterStandardWorkQty3, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity4 = calcQty(data.WorkCenterStandardWorkQty4, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity5 = calcQty(data.WorkCenterStandardWorkQty5, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);
                            const opconfirmedworkquantity6 = calcQty(data.WorkCenterStandardWorkQty6, row.confirmedqty, row.scrapqty, data.OperationReferenceQuantity);

                            aItems.push({
                                Id: row.sap_uuid,                                 // unique item identifier
                                Orderid: row.productionorderno,
                                Orderoperation: data.ManufacturingOrderOperation,
                                Ordersuboperation: "0000",
                                Confirmationyieldquantity: String(row.confirmedqty),
                                Opconfirmedworkquantity1: String(opconfirmedworkquantity1),
                                Opconfirmedworkquantity2: String(opconfirmedworkquantity2),
                                Opconfirmedworkquantity3: String(opconfirmedworkquantity3),
                                Opconfirmedworkquantity4: String(opconfirmedworkquantity4),
                                Opconfirmedworkquantity5: String(opconfirmedworkquantity5),
                                Opconfirmedworkquantity6: String(opconfirmedworkquantity6),
                                Scrapqty: parseFloat(row.scrapqty).toFixed(3),
                                Sequence: "0000",
                                Finalconfirmationtype: "X",
                                // Uom: optional, can be omitted or set from somewhere
                            });
                        });

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGI();

                        // Build final payload
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: { results: aItems }
                        };

                        console.log(`🚀 Posting Goods Issue with ${aItems.length} items in one payload`, oPayload);
                        // debugger

                        try {
                            // Create header with all items
                            const oResponse = await new Promise((resolve, reject) => {
                                oGIModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ Goods Issue batch created`, oResponse);

                            // Validate response structure
                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aProcessRows.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                // Check if backend returned an error for this item
                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aFailedRows.push({
                                        productionOrder: originalRow.productionorderno,
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                // Get material document details from item response
                                const matDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;
                                const confirmationGroup = itemResp.Confirmationgroup;
                                const confirmationCount = itemResp.Confirmationcount;

                                // Update local row
                                originalRow.gicnfmaterialdocnumber = matDoc;
                                originalRow.gicnfmaterialdocyear = matDocYear;
                                originalRow.gicnfconfirmationgroup = confirmationGroup;
                                originalRow.gicnfconfirmationcount = confirmationCount;

                                // Update WeightRoller plan table
                                try {
                                    await this.ToUpdateIntTabGoodsIssue(
                                        originalRow,
                                        matDoc,
                                        {
                                            materialdocument: matDoc,
                                            matdocyear: matDocYear,
                                            confirmationgroup: confirmationGroup,
                                            confirmationcount: confirmationCount
                                        }
                                    );
                                    console.log(`✅ Updated WeightRoller plan for row ${originalRow.sap_uuid}`);
                                } catch (updateErr) {
                                    console.error(`⚠️ WeightRoller plan update failed for row ${originalRow.sap_uuid}`, updateErr);
                                    // Still consider the GI successful; log warning but don't mark as failed
                                }

                                aSuccessRows.push({
                                    productionOrder: originalRow.productionorderno,
                                    materialDocument: matDoc
                                });
                            }

                            // Update FinalStatus with last successful material document (if any)
                            if (aSuccessRows.length > 0) {
                                const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                                this.FinalStatus = new sap.ui.model.json.JSONModel({
                                    MSGSTRIP: {
                                        visible: true,
                                        text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                        type: 'Success'
                                    }
                                });
                                this.getView().setModel(this.FinalStatus, "FinalStatus");
                            }

                        } catch (oError) {
                            // Entire request failed
                            console.error(`❌ Goods Issue batch failed:`, oError);
                            const sErrorMessage = this._extractErrorMessageGoodsIssue(oError);

                            // Mark all rows that were supposed to be processed as failed
                            aProcessRows.forEach(row => {
                                aFailedRows.push({
                                    productionOrder: row.productionorderno,
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Refresh table and hide busy indicator
                        oTabModel.setProperty("/Samples", aRows); // ensure selection cleared? Not cleared yet; we can clear later
                        oTabModel.refresh();
                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showConfirmationSummarybatch(aSuccessRows, aFailedRows, aSkippedRows);
                    }.bind(this) // bind to keep 'this' context
                });
            },

            // ============================================================
            // Update internal table (WeightRoller plan) with Goods Issue details
            // ============================================================
            ToUpdateIntTabGoodsIssue: function (HeaderModel, materialdocument, resp) {
                return new Promise((resolve, reject) => {
                    const that = this;
                    const oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");

                    const oEntry = {
                        confirmedqty: String(HeaderModel.confirmedqty),
                        scrapqty: String(HeaderModel.scrapqty),
                        RejectCodes: String(HeaderModel.RejectCodes),
                        gicnfmaterialdocnumber: resp.materialdocument,
                        gicnfmaterialdocyear: resp.matdocyear,
                        gicnfconfirmationgroup: resp.confirmationgroup,
                        gicnfconfirmationcount: resp.confirmationcount,
                    };

                    console.log(`📝 Updating WeightRoller plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            reject(error);
                        }
                    });
                });
            },

            // Show confirmation summary
            showConfirmationSummarybatch: function (aSuccessRows, aFailedRows, aSkippedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aSkippedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Confirmation process completed.\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasSkipped = aSkippedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully confirmed: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}`;
                        if (row.materialDocument) {
                            sMessage += ` (Material Doc: ${row.materialDocument})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";

                    // Update FinalStatus with last successful material document
                    if (aSuccessRows.length > 0) {
                        const lastSuccess = aSuccessRows[aSuccessRows.length - 1];
                        this.FinalStatus = new sap.ui.model.json.JSONModel({
                            MSGSTRIP: {
                                visible: true,
                                text: `Material Document No - Goods Issue : ${lastSuccess.materialDocument}`,
                                type: 'Success'
                            }
                        });
                        this.getView().setModel(this.FinalStatus, "FinalStatus");
                    }
                }

                if (bHasSkipped) {
                    sMessage += `⚠️ Skipped during validation: ${aSkippedRows.length}\n`;
                    aSkippedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.reason}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to confirm: ${aFailedRows.length}\n`;
                    aFailedRows.forEach(row => {
                        sMessage += `   - ${row.productionOrder}: ${row.error}\n`;
                    });
                }

                // Determine which type of message to show
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aFailedRows.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else if (bHasSkipped) {
                        // Show warning dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else if (bHasSuccess) {
                        // Show success dialog with summary (big section for all cases)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Confirmation Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },













            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Goods reciept start
            // ------------------------------------------------------------------------------------------------------------------------------------------




            // onGoodsReceiptPress: async function () {
            //     const oView = this.getView();
            //     // const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
            //     const oModel = oView.getModel("ZSB_BELTFG_GR");
            //     const oTabModel = oView.getModel("TabModel");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let errors = [];

            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }

            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }

            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness)
            //     let aValidationErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];

            //         // if (!row.batchweight) missingFields.push("Batch Weight");
            //         // if (!row.operator) missingFields.push("Operator");
            //         // if (!row.inspector) missingFields.push("Inspector");
            //         // if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }


            //     // --- ✅ PROCESSING (all validations passed)
            //     sap.ui.core.BusyIndicator.show(0);

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];

            //         const oPayload = {
            //             material: row.materialcode,
            //             plant: row.plant,
            //             storagelocation: row.storagelocation,
            //             goodsmovementtype: "101",
            //             manufacturingorder: row.productionorderno,
            //             // manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             goodsmovementrefdoctype: "F",
            //             quantityinentryunit: String(row.confirmedqty),
            //             postingdate: new Date(),
            //             goodsmovementcode: "02"
            //         };

            //         // try {
            //         //     const oData = await new Promise((resolve, reject) => {
            //         //         oModel.create("/ZC_BELTFG_GR", oPayload, {
            //         //             success: resolve,
            //         //             error: reject
            //         //         });
            //         //     });

            //         //     row.grmaterialdocnumber = oData.materialdocument;
            //         //     row.grmaterialdocyear = oData.matdocyear;
            //         //     // row.batchweight = String(row.confirmedqty);

            //         //     const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
            //         //     // row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

            //         //     await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

            //         // } catch (oError) {
            //         //     console.error(`❌ GR Failed for row ${i + 1}:`, oError);
            //         //     sap.m.MessageBox.error(`Goods Receipt failed for row ${i + 1}. See console for details.`);
            //         //     continue; // Optionally stop or continue
            //         // }
            //         try {
            //             const oData = await new Promise((resolve, reject) => {
            //                 oModel.create("/ZC_BELTFG_GR", oPayload, {
            //                     success: function (oResponse) {
            //                         console.log("✅ GR Success Response:", oResponse);
            //                         resolve(oResponse);
            //                     },
            //                     error: function (oError) {
            //                         console.error("❌ GR Error Response:", oError);
            //                         reject(oError);
            //                     }
            //                 });
            //             });

            //             // --- CHECK FOR ERROR FIELD EVEN IN SUCCESS ---
            //             if (oData.error && Object.keys(oData.error).length > 0) {
            //                 console.error(`❌ GR Backend Error for row ${i + 1}:`, oData.error);

            //                 sap.m.MessageBox.error(
            //                     `Goods Receipt backend error for row ${i + 1}:\n\n` +
            //                     (oData.error.errordetails?.map(e => e.message).join("\n") || JSON.stringify(oData.error, null, 2))
            //                 );
            //                 continue; // skip this row and move to next
            //             }

            //             // --- GR SUCCESS PROCESSING ---
            //             console.log("➡️ Processing GR Success for row", i + 1, oData);

            //             row.grmaterialdocnumber = oData.materialdocument;
            //             row.grmaterialdocyear = oData.matdocyear;

            //             const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);

            //             await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas?.[0]);

            //         } catch (oError) {
            //             console.error(`❌ GR Failed for row ${i + 1}:`, oError);

            //             sap.m.MessageBox.error(
            //                 `Goods Receipt failed for row ${i + 1}.\n\n` +
            //                 (oError?.responseText || JSON.stringify(oError, null, 2))
            //             );

            //             continue; // Continue with next row
            //         }

            //     }

            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();
            //     sap.m.MessageToast.show("Goods Receipt process completed.");
            // },


            // onGoodsReceiptPress: async function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_TB_FT_GR_HEAD1");
            //     const oTabModel = oView.getModel("TabModel");
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let errors = [];

            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }

            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }

            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness)
            //     let aValidationErrors = [];

            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];

            //         // if (!row.batchweight) missingFields.push("Batch Weight");
            //         // if (!row.operator) missingFields.push("Operator");
            //         // if (!row.inspector) missingFields.push("Inspector");
            //         if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- ✅ PROCESSING (all validations passed)
            //     sap.ui.core.BusyIndicator.show(0);

            //     // Arrays to collect results
            //     const aSuccessResults = [];
            //     const aErrorResults = [];

            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sProdOrder = row.productionorderno || `Row ${i + 1}`;

            //         const oPayload = {
            //             material: row.materialcode,
            //             plant: row.plant,
            //             storagelocation: row.storagelocation,
            //             goodsmovementtype: "101",
            //             manufacturingorder: row.productionorderno,
            //             manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             goodsmovementrefdoctype: "F",
            //             quantityinentryunit: String(row.confirmedqty),
            //             postingdate: new Date(),
            //             goodsmovementcode: "02"
            //         };

            //         try {
            //             const oData = await new Promise((resolve, reject) => {
            //                 oModel.create("/ZC_TB_FT_GR_HEAD1", oPayload, {
            //                     success: resolve,
            //                     error: reject
            //                 });
            //             });

            //             row.grmaterialdocnumber = oData.materialdocument;
            //             row.grmaterialdocyear = oData.matdocyear;

            //             const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
            //             row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

            //             await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

            //             // Add to success list
            //             aSuccessResults.push({
            //                 productionOrder: sProdOrder,
            //                 materialDocument: oData.materialdocument,
            //                 year: oData.matdocyear
            //             });

            //         } catch (oError) {
            //             console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

            //             // Extract error message
            //             let sErrorMessage = oError.message || "Unknown error";

            //             // For specific ShelfLifeExpirationDate error
            //             if (sErrorMessage.includes("ShelfLifeExpirationDate")) {
            //                 sErrorMessage = "Missing Shelf Life Expiration Date in material document";
            //             }

            //             // For OData errors
            //             if (oError.responseText) {
            //                 try {
            //                     const oErrorResponse = JSON.parse(oError.responseText);
            //                     if (oErrorResponse.error && oErrorResponse.error.message) {
            //                         sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
            //                     }
            //                 } catch (e) {
            //                     // If can't parse JSON, use response text
            //                     sErrorMessage = oError.responseText;
            //                 }
            //             }

            //             // Add to error list
            //             aErrorResults.push({
            //                 productionOrder: sProdOrder,
            //                 error: sErrorMessage
            //             });
            //         }
            //     }

            //     // Update the model with processed rows
            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();

            //     // Show summary message
            //     this.showGRSummary(aSuccessResults, aErrorResults);
            // },

            // showGRSummary: function (aSuccessResults, aErrorResults) {
            //     let sMessage = "Goods Receipt Process Summary\n\n";

            //     // Add successful results
            //     if (aSuccessResults.length > 0) {
            //         sMessage += `✅ SUCCESSFUL (${aSuccessResults.length}):\n`;
            //         aSuccessResults.forEach(result => {
            //             sMessage += `   • Production Order ${result.productionOrder}: Material Document ${result.materialDocument}/${result.year}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     // Add error results
            //     if (aErrorResults.length > 0) {
            //         sMessage += `❌ FAILED (${aErrorResults.length}):\n`;
            //         aErrorResults.forEach(result => {
            //             // Truncate long error messages
            //             let sErrorMsg = result.error;
            //             if (sErrorMsg.length > 100) {
            //                 sErrorMsg = sErrorMsg.substring(0, 100) + "...";
            //             }
            //             sMessage += `   • Production Order ${result.productionOrder}: ${sErrorMsg}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     // Add totals
            //     const iTotalProcessed = aSuccessResults.length + aErrorResults.length;
            //     sMessage += `Total Processed: ${iTotalProcessed}\n`;
            //     sMessage += `Successful: ${aSuccessResults.length}\n`;
            //     sMessage += `Failed: ${aErrorResults.length}`;

            //     // Create a detailed message for dialog
            //     let sDetailedMessage = "";
            //     if (aErrorResults.length > 0) {
            //         sDetailedMessage = "Detailed Errors:\n\n";
            //         aErrorResults.forEach(result => {
            //             sDetailedMessage += `Production Order ${result.productionOrder}:\n`;
            //             sDetailedMessage += `${result.error}\n\n`;
            //         });
            //     }

            //     if (aErrorResults.length === 0) {
            //         // All successful
            //         sap.m.MessageBox.success(sMessage, {
            //             title: "Process Complete"
            //         });
            //     } else if (aSuccessResults.length === 0) {
            //         // All failed
            //         sap.m.MessageBox.error(sMessage, {
            //             title: "Process Failed",
            //             details: sDetailedMessage,
            //             contentWidth: "600px"
            //         });
            //     } else {
            //         // Mixed results
            //         sap.m.MessageBox.warning(sMessage, {
            //             title: "Process Completed with Errors",
            //             details: sDetailedMessage,
            //             contentWidth: "600px"
            //         });
            //     }

            //     // Show toast message
            //     if (aSuccessResults.length > 0) {
            //         sap.m.MessageToast.show(`Goods Receipt completed for ${aSuccessResults.length} production order(s).`);
            //     }
            // },

            onGoodsReceiptPress: async function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_GR_NO_BATCH");
                if (oModel) {
                    console.log("Model found:", oModel);
                } else {
                    console.error("Model NOT found: ZSB_TB_FT_GR_HEAD1");
                }
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                let aBlockerErrors = [];

                aSelectedRows.forEach((row) => {
                    let errors = [];

                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }

                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists");
                    }

                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness)
                let aValidationErrors = [];

                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");

                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- ✅ PROCESSING (all validations passed)
                sap.ui.core.BusyIndicator.show(0);

                // Arrays to collect results
                const aSuccessResults = [];
                const aErrorResults = [];

                aSelectedRows.sort((a, b) => {
                    // Sort by productionordstartdate (ascending)
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);

                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;

                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                for (let i = 0; i < aSelectedRows.length; i++) {
                    const row = aSelectedRows[i];
                    const sProdOrder = row.productionorderno || `Row ${i + 1}`;

                    const oPayload = {
                        material: row.materialcode,
                        plant: row.plant,
                        storagelocation: row.storagelocation,
                        goodsmovementtype: "101",
                        manufacturingorder: row.productionorderno,
                        // manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementrefdoctype: "F",
                        quantityinentryunit: String(row.confirmedqty),
                        // postingdate: new Date(),
                        postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        goodsmovementcode: "02"
                    };
                    console.log("payload:", oPayload);

                    try {
                        const oData = await new Promise((resolve, reject) => {
                            oModel.create("/ZC_GR_NO_BATCH", oPayload, {
                                success: function (oData) {
                                    console.log("result:", oData);
                                    // Check if material document exists AND if errorresponse is present
                                    if (!oData.materialdocument && oData.errorresponse) {
                                        // This is an error returned in success response
                                        let errorMessage = "Unknown error";
                                        try {
                                            const errorObj = JSON.parse(oData.errorresponse);
                                            errorMessage = errorObj.error?.message?.value || errorObj.error?.message || oData.errorresponse;
                                        } catch (e) {
                                            errorMessage = oData.errorresponse;
                                        }
                                        reject(new Error(errorMessage));
                                    } else if (!oData.materialdocument) {
                                        // No material document and no error response
                                        reject(new Error("No material document returned"));
                                    } else {
                                        resolve(oData);
                                    }
                                },
                                error: reject
                            });
                        });

                        console.log("result:", oData);

                        // If we get here, we have a valid material document
                        row.grmaterialdocnumber = oData.materialdocument;
                        row.grmaterialdocyear = oData.matdocyear;

                        const MatDocItemDatas = await this.ToFetchExpiredateGRTab(row, oData.materialdocument, oData);
                        row.expirydate = MatDocItemDatas?.[0]?.ShelfLifeExpirationDate || null;

                        await this.ToUpdateGRTab(row, oData.materialdocument, oData, MatDocItemDatas[0]);

                        // Add to success list
                        aSuccessResults.push({
                            productionOrder: sProdOrder,
                            materialDocument: oData.materialdocument,
                            year: oData.matdocyear
                        });

                    } catch (oError) {
                        console.error(`❌ GR Failed for Production Order ${sProdOrder}:`, oError);

                        // Extract error message
                        let sErrorMessage = oError.message || "Unknown error";

                        // For OData errors
                        if (oError.responseText) {
                            try {
                                const oErrorResponse = JSON.parse(oError.responseText);
                                if (oErrorResponse.error && oErrorResponse.error.message) {
                                    sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                                }
                            } catch (e) {
                                sErrorMessage = oError.responseText;
                            }
                        }

                        // Add to error list
                        aErrorResults.push({
                            productionOrder: sProdOrder,
                            error: sErrorMessage
                        });
                    }
                }

                // Update the model with processed rows
                oTabModel.setProperty("/Samples", aRows);
                oTabModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showGRSummary(aSuccessResults, aErrorResults);
            },

            // Also update the showGRSummary to be consistent with our other summaries:
            showGRSummary: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                let bHasSuccess = aSuccessResults.length > 0;
                let bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}`;
                        if (result.materialDocument) {
                            sMessage += ` (Material Doc: ${result.materialDocument}/${result.year})`;
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - Production Order ${result.productionOrder}: ${result.error}\n`;
                    });
                }

                // Always show MessageBox for all cases (consistent with other summaries)
                setTimeout(() => {
                    if (bHasFailed) {
                        // Show detailed error dialog with summary
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.ERROR,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK],
                                details: aErrorResults.map(f =>
                                    `Production Order: ${f.productionOrder}\nError: ${f.error}`
                                ).join('\n\n')
                            }
                        );
                    } else {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Goods Receipt Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },


            ToUpdateGRTab: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        RejectCodes: String(HeaderModel.RejectCodes),
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // batchweight: HeaderModel.batchweight,
                        // operator: HeaderModel.operator,
                        // inspector: HeaderModel.inspector,
                        // batchweight: String(parseInt(HeaderModel.confirmedqty)),
                        // expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,

                    };

                    oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully.");
                            sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed");
                            sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            ToFetchExpiredateGRTab: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    // Safely get the backend model
                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    // var oFilterMatDocoItem = new sap.ui.model.Filter("MaterialDocumentItem", sap.ui.model.FilterOperator.EQ, "10");
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    // Call the read function
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {

                            resolve(oData.results)

                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve WeightRoller Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },








            generateUUIDreqnoGR: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },


            // ============================================================
            // UPDATED: Main Goods Receipt function using header-item service
            // ============================================================
            // onGoodsReceiptPressBatch: async function () {
            //     const oView = this.getView();
            //     const oGRModel = oView.getModel("ZSD_GR_NO_BATCH_HEAD_ITEM");         // new service
            //     const oTabModel = oView.getModel("TabModel");
            //     const oWeightrollerModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");     // for updates
            //     const aRows = oTabModel.getProperty("/Samples");
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row.");
            //         return;
            //     }

            //     let aBlockerErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let errors = [];
            //         if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
            //             errors.push("Missing Goods Issue Confirmation");
            //         }
            //         if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
            //             errors.push("Goods Receipt already exists");
            //         }
            //         if (!row.productionorderno || row.productionorderno.trim() === "") {
            //             errors.push("Missing Production Order");
            //         }
            //         if (errors.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
            //         }
            //     });

            //     if (aBlockerErrors.length > 0) {
            //         sap.m.MessageBox.warning(
            //             "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- 🧪 VALIDATION (field completeness) ---
            //     // let aValidationErrors = [];
            //     // aSelectedRows.forEach((row, index) => {
            //     //     let missingFields = [];
            //     //     if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //     //     if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //     //     if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //     //     if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //     //     if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //     //     if (missingFields.length > 0) {
            //     //         aValidationErrors.push(`Row ${index + 1}: ${missingFields.join(", ")}`);
            //     //     }
            //     // });

            //     // if (aValidationErrors.length > 0) {
            //     //     sap.m.MessageBox.error(
            //     //         "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //     //     );
            //     //     return;
            //     // }
            //     // --- 🧪 VALIDATION (field completeness) ---
            //     let aValidationErrors = [];
            //     aSelectedRows.forEach((row) => {
            //         let missingFields = [];
            //         if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
            //         if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
            //         if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
            //         if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
            //         if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
            //         if (missingFields.length > 0) {
            //             const sProdOrder = row.productionorderno || "(No Production Order)";
            //             aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
            //         }
            //     });

            //     if (aValidationErrors.length > 0) {
            //         sap.m.MessageBox.error(
            //             "Missing required fields:\n\n" + aValidationErrors.join("\n")
            //         );
            //         return;
            //     }

            //     // --- Sort selected rows (same logic as before) ---
            //     const aSortedSelectedRows = [...aSelectedRows].sort((a, b) => {
            //         const dateA = new Date(a.productionordstartdate);
            //         const dateB = new Date(b.productionordstartdate);
            //         if (dateA < dateB) return -1;
            //         if (dateA > dateB) return 1;
            //         const lotA = parseInt(a.bipllotno, 10) || 0;
            //         const lotB = parseInt(b.bipllotno, 10) || 0;
            //         return lotA - lotB;
            //     });

            //     sap.ui.core.BusyIndicator.show(0);

            //     const aSuccessResults = [];
            //     const aErrorResults = [];

            //     // Generate a unique request number (UUID style)
            //     const requestNo = this.generateUUIDreqnoGR();

            //     // Create ONE payload with ALL selected rows in toitem
            //     const oPayload = {
            //         Requestno: requestNo,
            //         toitem: {
            //             results: aSortedSelectedRows.map(row => ({
            // Id: row.sap_uuid,                                 // use sap_uuid as item identifier
            // Material: row.materialcode,
            // Plant: row.plant,
            // Storagelocation: row.storagelocation,
            // Goodsmovementtype: "101",
            // Goodsmovementcode: "02",
            // Quantityinentryunit: String(row.confirmedqty),
            // Manufacturingorder: row.productionorderno,
            // // Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            // Postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            // Goodsmovementrefdoctype: "F"
            //             }))
            //         }
            //     };

            //     console.log(`🚀 Creating GR with ${aSortedSelectedRows.length} items in one payload`, oPayload);
            //     try {
            //         // Create header with ALL items in one call
            //         const oResponse = await new Promise((resolve, reject) => {
            //             oGRModel.create("/header", oPayload, {
            //                 success: resolve,
            //                 error: reject
            //             });
            //         });

            //         console.log(`✅ GR created for all items`, oResponse);

            //         // Validate response structure
            //         if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
            //             throw new Error("Invalid response: missing toitem results");
            //         }

            //         // Process each item in the response
            //         for (let i = 0; i < oResponse.toitem.results.length; i++) {
            //             const itemResp = oResponse.toitem.results[i];
            //             const originalRow = aSortedSelectedRows.find(r => r.sap_uuid === itemResp.Id);

            //             if (!originalRow) {
            //                 console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
            //                 continue;
            //             }

            //             // Check if backend returned an error for this item
            //             if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
            //                 aErrorResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     error: itemResp.Errorresponse
            //                 });
            //                 continue;
            //             }

            //             // Get the material document details from the item response
            //             const materialDoc = itemResp.Materialdocument;
            //             const matDocYear = itemResp.Matdocyear;

            //             try {
            //                 // --- STEP 1: Fetch expiry date from material document item entity ---
            //                 const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear }
            //                 );

            //                 // Extract expiry date (use first item's ShelfLifeExpirationDate)
            //                 const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

            //                 // Update local row
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

            //                 // --- STEP 2: Update plan table with fetched expiry date ---
            //                 await this.ToUpdateGRTabBatch(
            //                     originalRow,
            //                     materialDoc,
            //                     { materialdocument: materialDoc, matdocyear: matDocYear },
            //                     { ShelfLifeExpirationDate: expiryDate } // pass the fetched expiry
            //                 );

            //                 console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: expiryDate
            //                 });

            //             } catch (itemError) {
            //                 // If fetching expiry or updating fails, still consider GR successful? 
            //                 // According to original pattern, if GR succeeded but subsequent steps fail, 
            //                 // we log warning but still count as success (since GR was created).
            //                 console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);

            //                 // Still update local row with basic GR info
            //                 originalRow.grmaterialdocnumber = materialDoc;
            //                 originalRow.grmaterialdocyear = matDocYear;
            //                 originalRow.expirydate = itemResp.Shelflifeexpirationdate
            //                     ? new Date(itemResp.Shelflifeexpirationdate)
            //                     : null;

            //                 // Add to success with warning note
            //                 aSuccessResults.push({
            //                     productionOrder: originalRow.productionorderno,
            //                     rowId: `Row ${aSortedSelectedRows.indexOf(originalRow) + 1}`,
            //                     bipllotno: originalRow.bipllotno || "",
            //                     materialDocument: materialDoc,
            //                     year: matDocYear,
            //                     expiryDate: originalRow.expirydate,
            //                     warning: "Expiry fetch failed, using GR response expiry"
            //                 });
            //             }
            //         }
            //     } catch (oError) {
            //         // Entire request failed
            //         console.error(`❌ GR failed for all items:`, oError);
            //         const sErrorMessage = this._extractErrorMessage(oError);

            //         aSortedSelectedRows.forEach((row, idx) => {
            //             aErrorResults.push({
            //                 productionOrder: row.productionorderno,
            //                 rowId: `Row ${idx + 1}`,
            //                 bipllotno: row.bipllotno || "",
            //                 error: sErrorMessage
            //             });
            //         });
            //     }

            //     // --- Update local table model and clear selection ---
            //     aSelectedRows.forEach(row => { row.__selected = false; });
            //     oTabModel.setProperty("/Samples", aRows);
            //     oTabModel.refresh();

            //     sap.ui.core.BusyIndicator.hide();

            //     // --- Show summary ---
            //     this.showGRSummaryBatch(aSuccessResults, aErrorResults);
            // },


            checkUserHasGoodsRecieptRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onGoodsReceiptPressBatch: async function () {
                const oView = this.getView();
                const oGRModel = oView.getModel("ZSB_GR_HEAD_ITEM_WTRL");         // service for posting
                const oFetchModel = oView.getModel("ZSB_GR_MATDOC_FETCH");   // service for fetching existing GR
                const oTabModel = oView.getModel("TabModel");
                const aRows = oTabModel.getProperty("/Samples");
                const aSelectedRows = aRows.filter(row => row.__selected);

                // --- Arrays to track results ---
                const aSuccessResults = [];
                const aErrorResults = [];
                const aSkippedRows = [];

                // --- 🚫 BLOCKER VALIDATION (cannot proceed) ---
                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                let aBlockerErrors = [];
                aSelectedRows.forEach((row) => {
                    let errors = [];
                    if (!row.gicnfmaterialdocnumber || row.gicnfmaterialdocnumber.trim() === "") {
                        errors.push("Missing Goods Issue Confirmation");
                    }
                    if (row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "") {
                        errors.push("Goods Receipt already exists (local)");
                    }
                    if (!row.productionorderno || row.productionorderno.trim() === "") {
                        errors.push("Missing Production Order");
                    }
                    if (errors.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aBlockerErrors.push(`Production Order ${sProdOrder}: ${errors.join(", ")}`);
                    }
                });

                if (aBlockerErrors.length > 0) {
                    sap.m.MessageBox.warning(
                        "Cannot proceed due to the following issues:\n\n" + aBlockerErrors.join("\n")
                    );
                    return;
                }

                // --- 🧪 VALIDATION (field completeness) ---
                let aValidationErrors = [];
                aSelectedRows.forEach((row) => {
                    let missingFields = [];
                    if (!row.manufacturingdate) missingFields.push("Manufacturing Date");
                    if (!row.materialcode || row.materialcode.trim() === "") missingFields.push("Material Code");
                    if (!row.plant || row.plant.trim() === "") missingFields.push("Plant");
                    // if (!row.storagelocation || row.storagelocation.trim() === "") missingFields.push("Storage Location");
                    if (!row.confirmedqty || row.confirmedqty <= 0) missingFields.push("Confirmed Quantity");
                    if (missingFields.length > 0) {
                        const sProdOrder = row.productionorderno || "(No Production Order)";
                        aValidationErrors.push(`Production Order ${sProdOrder}: ${missingFields.join(", ")}`);
                    }
                });

                if (aValidationErrors.length > 0) {
                    sap.m.MessageBox.error(
                        "Missing required fields:\n\n" + aValidationErrors.join("\n")
                    );
                    return;
                }

                // --- Remove rows that already have a GR in the UI (local) ---
                const aWithLocalGR = aSelectedRows.filter(row => row.grmaterialdocnumber && row.grmaterialdocnumber.trim() !== "");
                aWithLocalGR.forEach(row => {
                    aSkippedRows.push({
                        productionOrder: row.productionorderno,
                        reason: "Goods Receipt already exists (local)"
                    });
                });
                let aRowsToCheck = aSelectedRows.filter(row => !aWithLocalGR.includes(row));

                // --- If no rows left after local check, show summary and return ---
                if (aRowsToCheck.length === 0) {
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- 🕒 Show busy indicator before backend fetch ---
                sap.ui.core.BusyIndicator.show(0);

                // --- Fetch existing GR data from ZSB_GR_MATDOC_FETCH for remaining rows ---
                const aRowsWithExisting = [];   // { row, existing }
                let aRowsToPost = [];

                const fetchExistingPromises = aRowsToCheck.map(async (row) => {
                    try {
                        const oFilter = new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, row.productionorderno);
                        const oData = await new Promise((resolve, reject) => {
                            oFetchModel.read("/ZC_GR_MATDOC_FETCH", {
                                filters: [oFilter],
                                success: resolve,
                                error: reject
                            });
                        });

                        if (oData.results && oData.results.length > 0) {
                            // Use the first result (assuming at most one per order)
                            return { row, existing: oData.results[0] };
                        } else {
                            return { row, existing: null };
                        }
                    } catch (err) {
                        console.warn(`Error fetching existing GR for order ${row.productionorderno}:`, err);
                        // Treat as not existing; proceed with posting
                        return { row, existing: null };
                    }
                });

                const fetchExistingResults = await Promise.all(fetchExistingPromises);

                // Separate rows
                fetchExistingResults.forEach(result => {
                    if (result.existing) {
                        aRowsWithExisting.push(result);
                    } else {
                        aRowsToPost.push(result.row);
                    }
                });

                // --- Update rows that already have a goods receipt in the backend ---
                // --- Update rows that already have a goods receipt in the backend ---
                for (const { row, existing } of aRowsWithExisting) {
                    const matDoc = existing.MaterialDocument;
                    const matDocYear = existing.MaterialDocumentYear;

                    // Update local row
                    row.grmaterialdocnumber = matDoc;
                    row.grmaterialdocyear = matDocYear;

                    // Update mixing plan table
                    try {
                        await this.ToUpdateGRTabBatch(
                            row,
                            matDoc,
                            { materialdocument: matDoc, matdocyear: matDocYear },
                            { ShelfLifeExpirationDate: null }   // expiry not available from this fetch
                        );
                        console.log(`✅ Updated mixing plan for existing order ${row.productionorderno}`);
                        aSuccessResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            materialDocument: matDoc,
                            year: matDocYear,
                            existing: true
                        });
                    } catch (updateErr) {
                        console.error(`❌ Failed to update mixing plan for existing order ${row.productionorderno}:`, updateErr);
                        aErrorResults.push({
                            productionOrder: row.productionorderno,
                            rowId: "Existing",               // <-- added
                            bipllotno: row.bipllotno || "",  // <-- added
                            error: `Existing data found but update failed: ${updateErr.message || updateErr}`
                        });
                    }
                }

                // Hide busy indicator before showing confirmation
                sap.ui.core.BusyIndicator.hide();

                // --- If no rows left to post, show summary and exit ---
                if (aRowsToPost.length === 0) {
                    oTabModel.refresh();
                    this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    return;
                }

                // --- Sort rows to post (same logic as before) ---
                aRowsToPost.sort((a, b) => {
                    const dateA = new Date(a.productionordstartdate);
                    const dateB = new Date(b.productionordstartdate);
                    if (dateA < dateB) return -1;
                    if (dateA > dateB) return 1;
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                // --- Confirm with user ---
                sap.m.MessageBox.confirm(`Do you want to post goods receipt for ${aRowsToPost.length} order(s)?`, {
                    actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
                    emphasizedAction: sap.m.MessageBox.Action.YES,
                    onClose: async function (sAction) {
                        if (sAction !== sap.m.MessageBox.Action.YES) {
                            return;
                        }

                        sap.ui.core.BusyIndicator.show(0);

                        // Generate a unique request number
                        const requestNo = this.generateUUIDreqnoGR();

                        // Build payload with all rows to post
                        const oPayload = {
                            Requestno: requestNo,
                            toitem: {
                                results: aRowsToPost.map(row => ({
                                    Id: row.sap_uuid,                                 // use sap_uuid as item identifier
                                    Material: row.materialcode,
                                    Plant: row.plant,
                                    Storagelocation: row.storagelocation,
                                    Goodsmovementtype: "101",
                                    Goodsmovementcode: "02",
                                    Quantityinentryunit: String(row.confirmedqty),
                                    Manufacturingorder: row.productionorderno,
                                    // Manufacturedate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    // Postingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                                    Postingdate: row.PostingDate ? new Date(row.PostingDate.toLocaleDateString('en-CA')) : null,
                                    Goodsmovementrefdoctype: "F"
                                }))
                            }
                        };



                        console.log(`🚀 Creating GR with ${aRowsToPost.length} items in one payload`, oPayload);

                        try {
                            const oResponse = await new Promise((resolve, reject) => {
                                oGRModel.create("/header", oPayload, {
                                    success: resolve,
                                    error: reject
                                });
                            });

                            console.log(`✅ GR created for all items`, oResponse);

                            if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                                throw new Error("Invalid response: missing toitem results");
                            }

                            // Process each item in the response
                            for (let i = 0; i < oResponse.toitem.results.length; i++) {
                                const itemResp = oResponse.toitem.results[i];
                                const originalRow = aRowsToPost.find(r => r.sap_uuid === itemResp.Id);

                                if (!originalRow) {
                                    console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                    continue;
                                }

                                if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                    aErrorResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        error: itemResp.Errorresponse
                                    });
                                    continue;
                                }

                                const materialDoc = itemResp.Materialdocument;
                                const matDocYear = itemResp.Matdocyear;

                                try {
                                    // Fetch expiry date from material document item
                                    const aMatDocItemData = await this.ToFetchExpiredateGRTabbatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear }
                                    );
                                    const expiryDate = aMatDocItemData?.[0]?.ShelfLifeExpirationDate || null;

                                    // Update local row
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = expiryDate ? new Date(expiryDate) : null;

                                    // Update mixing plan table
                                    await this.ToUpdateGRTabBatch(
                                        originalRow,
                                        materialDoc,
                                        { materialdocument: materialDoc, matdocyear: matDocYear },
                                        { ShelfLifeExpirationDate: expiryDate }
                                    );

                                    console.log(`✅ Updated row ${originalRow.sap_uuid} with Material Doc: ${materialDoc}/${matDocYear}, Expiry: ${expiryDate}`);

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: expiryDate
                                    });

                                } catch (itemError) {
                                    console.error(`⚠️ Post-GR processing failed for row ${originalRow.sap_uuid}:`, itemError);
                                    // Still count as success because GR was created, but log warning
                                    originalRow.grmaterialdocnumber = materialDoc;
                                    originalRow.grmaterialdocyear = matDocYear;
                                    originalRow.expirydate = itemResp.Shelflifeexpirationdate
                                        ? new Date(itemResp.Shelflifeexpirationdate)
                                        : null;

                                    aSuccessResults.push({
                                        productionOrder: originalRow.productionorderno,
                                        rowId: `Row ${aRowsToPost.indexOf(originalRow) + 1}`,
                                        bipllotno: originalRow.bipllotno || "",
                                        materialDocument: materialDoc,
                                        year: matDocYear,
                                        expiryDate: originalRow.expirydate,
                                        warning: "Expiry fetch failed, using GR response expiry"
                                    });
                                }
                            }
                        } catch (oError) {
                            console.error(`❌ GR failed for all items:`, oError);
                            const sErrorMessage = this._extractErrorMessage(oError);
                            aRowsToPost.forEach((row, idx) => {
                                aErrorResults.push({
                                    productionOrder: row.productionorderno,
                                    rowId: `Row ${idx + 1}`,
                                    bipllotno: row.bipllotno || "",
                                    error: sErrorMessage
                                });
                            });
                        }

                        // Update table and clear selection
                        aSelectedRows.forEach(row => { row.__selected = false; });
                        oTabModel.setProperty("/Samples", aRows);
                        oTabModel.refresh();

                        sap.ui.core.BusyIndicator.hide();

                        // Show summary
                        this.showGRSummaryBatch(aSuccessResults, aErrorResults, aSkippedRows);
                    }.bind(this) // ensure 'this' context
                });
            },




            // ============================================================
            // UPDATED: Update plan table
            // ============================================================
            ToUpdateGRTabBatch: function (HeaderModel, materialdocument, resp, MatDocItemDatas) {
                return new Promise((resolve, reject) => {
                    // sap.ui.core.BusyIndicator.show();
                    var that = this;
                    var oModelGet = that.getView().getModel("ZSB_WEIGHTROLLER_PLAN");

                    var oEntry = {
                        grmaterialdocnumber: resp.materialdocument,
                        grmaterialdocyear: resp.matdocyear,
                        RejectCodes: String(HeaderModel.RejectCodes),
                        manufacturingdate: HeaderModel.manufacturingdate ? new Date(HeaderModel.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        // operator: HeaderModel.operator,
                        // inspector: HeaderModel.inspector,
                        // expirydate: MatDocItemDatas.ShelfLifeExpirationDate ? new Date(MatDocItemDatas.ShelfLifeExpirationDate.toLocaleDateString('en-CA')) : null,
                    };

                    console.log(`📝 Updating plan for ${HeaderModel.sap_uuid} with:`, oEntry);

                    oModelGet.update("/ZC_WEIGTHROLLER_PLAN('" + HeaderModel.sap_uuid + "')", oEntry, {
                        success: function (oData) {
                            console.log("✅ Internal Table Updated Successfully for", HeaderModel.sap_uuid);
                            // sap.ui.core.BusyIndicator.hide();
                            resolve(oData);
                        },
                        error: function (error) {
                            console.error("❌ Internal Table Update Failed for", HeaderModel.sap_uuid, error);
                            // sap.ui.core.BusyIndicator.hide();
                            sap.m.MessageToast.show("Goods receipt Doc No - Internal table update failed");
                            reject(error);
                        }
                    });
                });
            },

            // ============================================================
            // NEW HELPER: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // UPDATED: Summary dialog (now matches the style of showPostSummaryBatch)
            // ============================================================
            showGRSummaryBatch: function (aSuccessResults, aErrorResults) {
                const sTotal = aSuccessResults.length + aErrorResults.length;
                if (sTotal === 0) return;

                let sMessage = `Goods Receipt process completed for ${sTotal} row(s).\n\n`;
                const bHasSuccess = aSuccessResults.length > 0;
                const bHasFailed = aErrorResults.length > 0;

                if (bHasSuccess) {
                    sMessage += `✅ Successfully processed: ${aSuccessResults.length}\n`;
                    aSuccessResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}) → `;
                        if (result.materialDocument) {
                            sMessage += `Material Doc: ${result.materialDocument}/${result.year}`;
                            if (result.expiryDate) {
                                const d = new Date(result.expiryDate);
                                sMessage += `, Expiry: ${d.toLocaleDateString()}`;
                            }
                        }
                        sMessage += `\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aErrorResults.length}\n`;
                    aErrorResults.forEach(result => {
                        sMessage += `   - ${result.rowId} (Bipl: ${result.bipllotno}): ${result.error}\n`;
                    });
                }

                setTimeout(() => {
                    if (bHasFailed && !bHasSuccess) {
                        sap.m.MessageBox.error(sMessage, { title: "Goods Receipt Failed" });
                    } else if (bHasFailed && bHasSuccess) {
                        sap.m.MessageBox.warning(sMessage, {
                            title: "Goods Receipt Partial Success",
                            details: aErrorResults.map(f =>
                                `${f.rowId} (Bipl: ${f.bipllotno})\nError: ${f.error}`
                            ).join('\n\n')
                        });
                    } else {
                        sap.m.MessageBox.success(sMessage, { title: "Goods Receipt Successful" });
                    }
                }, 100);
            },



            // ============================================================
            // EXISTING: Fetch expiry date (kept for compatibility, but no longer used in new flow)
            // ============================================================
            ToFetchExpiredateGRTabbatch: function (HeaderModel, materialdocument, resp) {
                var that = this;
                return new Promise((resolve, reject) => {
                    var oView = that.getView();

                    var oModel = that.getOwnerComponent().getModel("ZSB_MAT_DOC_ITEM");
                    if (!oModel) {
                        sap.m.MessageBox.error("Model 'ZSB_MAT_DOC_ITEM' not found.");
                        return;
                    }
                    var oFilterMatDoco = new sap.ui.model.Filter("MaterialDocument", sap.ui.model.FilterOperator.EQ, resp.materialdocument);
                    var oFilterMatDocyear = new sap.ui.model.Filter("MaterialDocumentYear", sap.ui.model.FilterOperator.EQ, resp.matdocyear);
                    oModel.read("/ZC_MAT_DOC_ITEM", {
                        filters: [oFilterMatDoco, oFilterMatDocyear],
                        success: function (oData) {
                            console.log(oData)
                            resolve(oData.results)
                        },
                        error: function (oError) {
                            oView.setBusy(false);
                            sap.m.MessageBox.error("Failed to retrieve Plan data.");
                            console.error("OData read error:", oError);
                            reject(oError)
                        }
                    });
                });
            },






            // sap.ui.core.BusyIndicator.hide();
            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Update 
            // ------------------------------------------------------------------------------------------------------------------------------------------

            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);
                const aSelectedUUIDs = aSelectedRows.map(item => item.sap_uuid); // store for later

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {

                    const sKey = oODataModel.createKey("/ZC_WEIGTHROLLER_PLAN", {
                        sap_uuid: item.sap_uuid,
                    });

                    // Prepare payload with only editable fields
                    const oPayload = {
                        // confirmedqty: String(parseInt(item.confirmedqty)),
                        // scrapqty: String(parseInt(item.scrapqty)),
                        confirmedqty: String(item.confirmedqty),
                        scrapqty: String(item.scrapqty),
                        RejectCodes: String(item.RejectCodes),
                        manufacturingdate: item.manufacturingdate ? new Date(item.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        PostingDate: item.PostingDate ? new Date(item.PostingDate.toLocaleDateString('en-CA')) : null,
                        updatestatusgistatus: "GT"
                    };

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                // Promise.allSettled(aUpdatePromises).then(results => {
                //     sap.ui.core.BusyIndicator.hide();

                //     const aFailed = results.filter(r => r.status === "rejected");
                //     const aSuccess = results.filter(r => r.status === "fulfilled");

                //     let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                //     if (aFailed.length > 0) {
                //         sMsg += `\n${aFailed.length} row(s) failed to update.`;
                //     }

                //     sap.m.MessageBox.information(sMsg);
                //     oTabModel.refresh(true);
                //     this.GoWeightRollerActualfilter()
                // });
                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);

                    // Now refresh data via GoWeightRollerActualfilter and restore selection
                    this.GoWeightRollerActualfilter(function (aNewData) {
                        // Restore selection: mark __selected = true for rows whose sap_uuid is in aSelectedUUIDs
                        aNewData.forEach(item => {
                            if (aSelectedUUIDs.indexOf(item.sap_uuid) !== -1) {
                                item.__selected = true;
                            }
                        });
                        // Update the model (GoWeightRollerActualfilter already set it, but we need to reflect selection)
                        const oTabModel = this.getView().getModel("TabModel");
                        oTabModel.setProperty("/Samples", aNewData);
                        oTabModel.refresh(true);
                    }.bind(this));
                });
            },

            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Release and save 
            // ------------------------------------------------------------------------------------------------------------------------------------------
            // onReleasePress: async function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
            //     const oEeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Process rows one by one
            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sManufacturingOrder = row.productionorderno;

            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${i + 1} skipped: No production order.`);
            //             row.releasestatus = "";
            //             oTableModel.refresh();
            //             continue;
            //         }

            //         try {
            //             // Step 1: Check status from ZC_ORDER_CREATION - wait for response
            //             const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

            //             if (bStatusActive) {
            //                 console.log(`Row ${i + 1}: Status I0002 is active - already released.`);

            //                 // Update WeightRoller plan
            //                 await this.updateWeightRollerPlan(oEeightRollerPlanModel, row, true);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 oTableModel.refresh();

            //                 sap.m.MessageToast.show(`Row ${i + 1}: Already released.`);
            //                 continue; // Skip to next row
            //             }

            //             // Step 2: Create release - wait for response
            //             const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

            //             if (bReleaseSuccess) {
            //                 // Step 3: Update WeightRoller plan - wait for response
            //                 await this.updateWeightRollerPlan(oEeightRollerPlanModel, row, false);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 oTableModel.refresh();

            //                 console.log(`✅ Row ${i + 1} released successfully`);
            //                 sap.m.MessageToast.show(`Row ${i + 1}: Released successfully`);
            //             } else {
            //                 row.releasestatus = "";
            //                 oTableModel.refresh();
            //                 console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
            //             }

            //         } catch (error) {
            //             console.error(`❌ Error processing row ${i + 1}:`, error);
            //             row.releasestatus = "";
            //             oTableModel.refresh();
            //         }
            //     }

            //     // Final refresh and cleanup
            //     oTableModel.setProperty("/Samples", aRows);
            //     oTableModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();
            //     sap.m.MessageToast.show("Release process completed.");
            // },

            // // Helper function to check order status
            // checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];

            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 const bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });
            //                 resolve(bExists);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to create release
            // createRelease: function (oModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const oPayload = {
            //             ManufacturingOrder: sManufacturingOrder
            //         };

            //         oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //             success: function (oData) {
            //                 if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                     sap.m.MessageToast.show("Check material availability");
            //                     resolve(false);
            //                     return;
            //                 }
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to update WeightRoller plan
            // updateWeightRollerPlan: function (oEeightRollerPlanModel, row, bAlreadyReleased) {
            //     return new Promise((resolve, reject) => {
            //         const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //         const oUpdateEntry = {
            //             releasestatus: "RELEASED",
            //             batchweight: row.batchweight || "",
            //             operator: row.operator || "",
            //             inspector: row.inspector || "",
            //             manufacturingdate: row.manufacturingdate ?
            //                 new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
            //         };

            //         oEeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //             success: function () {
            //                 console.log(`🔄 WeightRoller Plan updated`);
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 if (!bAlreadyReleased) {
            //                     reject(oError);
            //                 } else {
            //                     // If already released, still resolve (don't fail the process)
            //                     resolve(true);
            //                 }
            //             }
            //         });
            //     });
            // },








            // onReleasePress: async function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
            //     const oEeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Arrays to track results
            //     const aSuccessRows = [];
            //     const aFailedRows = [];
            //     const aAlreadyReleasedRows = [];

            //     // Process rows one by one
            //     for (let i = 0; i < aSelectedRows.length; i++) {
            //         const row = aSelectedRows[i];
            //         const sManufacturingOrder = row.productionorderno;

            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${i + 1} skipped: No production order.`);
            //             row.releasestatus = "";
            //             aFailedRows.push({
            //                 rowNumber: i + 1,
            //                 productionOrder: "No Production Order",
            //                 error: "No production order number"
            //             });
            //             continue;
            //         }

            //         try {
            //             // Step 1: Check status from ZC_ORDER_CREATION
            //             const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

            //             if (bStatusActive) {
            //                 console.log(`Row ${i + 1}: Status I0002 is active - already released.`);
            //                 aAlreadyReleasedRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder
            //                 });

            //                 // Update WeightRoller plan updateWeightRollerPlan
            //                 await this.updateWeightRollerPlan(oEeightRollerPlanModel, row, true);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 continue;
            //             }

            //             // Step 2: Create release
            //             const bReleaseSuccess = await this.createRelease(oModel, sManufacturingOrder);

            //             if (bReleaseSuccess) {
            //                 // Step 3: Update WeightRoller plan
            //                 await this.updateWeightRollerPlan(oEeightRollerPlanModel, row, false);

            //                 // Update UI
            //                 row.releasestatus = "RELEASED";
            //                 aSuccessRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder
            //                 });
            //                 console.log(`✅ Row ${i + 1} released successfully`);
            //             } else {
            //                 row.releasestatus = "";
            //                 aFailedRows.push({
            //                     rowNumber: i + 1,
            //                     productionOrder: sManufacturingOrder,
            //                     error: "Release creation failed - check material availability"
            //                 });
            //                 console.warn(`⚠️ Row ${i + 1}: Release creation failed`);
            //             }

            //         } catch (error) {
            //             console.error(`❌ Error processing row ${i + 1}:`, error);
            //             row.releasestatus = "";
            //             aFailedRows.push({
            //                 rowNumber: i + 1,
            //                 productionOrder: sManufacturingOrder,
            //                 error: error.message || "Unknown error"
            //             });
            //         }
            //     }

            //     // Final refresh and cleanup
            //     oTableModel.setProperty("/Samples", aRows);
            //     oTableModel.refresh();
            //     sap.ui.core.BusyIndicator.hide();

            //     // Show summary message
            //     this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            // },

            // // New function to show summary
            // // showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
            // //     const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

            // //     let sMessage = `Release process completed for ${sTotal} rows.\n\n`;

            // //     if (aSuccessRows.length > 0) {
            // //         sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
            // //         aSuccessRows.forEach(row => {
            // //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            // //         });
            // //         sMessage += "\n";
            // //     }

            // //     if (aAlreadyReleasedRows.length > 0) {
            // //         sMessage += `ℹ️ Already released: ${aAlreadyReleasedRows.length}\n`;
            // //         aAlreadyReleasedRows.forEach(row => {
            // //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            // //         });
            // //         sMessage += "\n";
            // //     }

            // //     if (aFailedRows.length > 0) {
            // //         sMessage += `❌ Failed to release: ${aFailedRows.length}\n`;
            // //         aFailedRows.forEach(row => {
            // //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            // //             if (row.error) {
            // //                 sMessage += `     Error: ${row.error}\n`;
            // //             }
            // //         });

            // //         // Show failed rows in a more detailed dialog
            // //         sap.m.MessageBox.show(
            // //             sMessage,
            // //             {
            // //                 icon: sap.m.MessageBox.Icon.ERROR,
            // //                 title: "Release Process Summary",
            // //                 actions: [sap.m.MessageBox.Action.OK],
            // //                 details: aFailedRows.map(f =>
            // //                     `Row ${f.rowNumber} - Production Order: ${f.productionOrder}\nError: ${f.error}`
            // //                 ).join('\n\n')
            // //             }
            // //         );
            // //     } else {
            // //         // If no failures, show success toast
            // //         if (aSuccessRows.length > 0 || aAlreadyReleasedRows.length > 0) {
            // //             const sSuccessMsg = `${aSuccessRows.length} released successfully, ${aAlreadyReleasedRows.length} were already released.`;
            // //             sap.m.MessageToast.show(sSuccessMsg);
            // //         }
            // //     }
            // // },
            // showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
            //     const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

            //     if (sTotal === 0) {
            //         return;
            //     }

            //     let sMessage = `Release process completed for ${sTotal} rows.\n\n`;
            //     let bHasSuccess = aSuccessRows.length > 0;
            //     let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
            //     let bHasFailed = aFailedRows.length > 0;

            //     if (bHasSuccess) {
            //         sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
            //         aSuccessRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     if (bHasAlreadyReleased) {
            //         sMessage += `ℹ️ Already released: ${aAlreadyReleasedRows.length}\n`;
            //         aAlreadyReleasedRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //         });
            //         sMessage += "\n";
            //     }

            //     if (bHasFailed) {
            //         sMessage += `❌ Failed to release: ${aFailedRows.length}\n`;
            //         aFailedRows.forEach(row => {
            //             sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
            //             if (row.error) {
            //                 sMessage += `     Error: ${row.error}\n`;
            //             }
            //         });
            //     }

            //     // Always show MessageBox for all cases
            //     setTimeout(() => {
            //         if (bHasFailed) {
            //             // Show error dialog with details
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.ERROR,
            //                     title: "Release Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK],
            //                     details: aFailedRows.map(f =>
            //                         `Row ${f.rowNumber} - Production Order: ${f.productionOrder}\nError: ${f.error || "Unknown error"}`
            //                     ).join('\n\n')
            //                 }
            //             );
            //         } else {
            //             // Show success dialog (even if only already released rows)
            //             sap.m.MessageBox.show(
            //                 sMessage,
            //                 {
            //                     icon: sap.m.MessageBox.Icon.SUCCESS,
            //                     title: "Release Process Summary",
            //                     actions: [sap.m.MessageBox.Action.OK]
            //                 }
            //             );
            //         }
            //     }, 100);
            // },

            // // Helper function to check order status (unchanged)
            // checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];

            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 const bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });
            //                 resolve(bExists);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to create release (unchanged)
            // createRelease: function (oModel, sManufacturingOrder) {
            //     return new Promise((resolve, reject) => {
            //         const oPayload = {
            //             ManufacturingOrder: sManufacturingOrder
            //         };

            //         oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //             success: function (oData) {
            //                 if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                     resolve(false);
            //                     return;
            //                 }
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 reject(oError);
            //             }
            //         });
            //     });
            // },

            // // Helper function to update WeightRoller plan (unchanged)
            // updateWeightRollerPlan: function (oEeightRollerPlanModel, row, bAlreadyReleased) {
            //     return new Promise((resolve, reject) => {
            //         const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //         const oUpdateEntry = {
            //             releasestatus: "RELEASED",
            //             batchweight: row.batchweight || "",
            //             RejectCodes: String(row.RejectCodes),
            //             // operator: row.operator || "",
            //             // inspector: row.inspector || "",
            //             manufacturingdate: row.manufacturingdate ?
            //                 new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
            //         };

            //         oEeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //             success: function () {
            //                 console.log(`🔄 WeightRoller Plan updated`);
            //                 resolve(true);
            //             },
            //             error: function (oError) {
            //                 if (!bAlreadyReleased) {
            //                     reject(oError);
            //                 } else {
            //                     // If already released, still resolve (don't fail the process)
            //                     resolve(true);
            //                 }
            //             }
            //         });
            //     });
            // },


            onReleasePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oModel = oView.getModel("ZSB_PRODUCT_ORD1");
                const oWeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get ALL selected rows, regardless of UI status
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // Sort selected rows according to table sorting logic
                aAllSelectedRows.sort((a, b) => {
                    // First sort by productionordstartdate (ascending)
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;

                    // Handle date comparison
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }

                    // If dates are equal, sort by bipllotno numerically (ascending)
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;

                    // Return difference for numeric order
                    return lotA - lotB;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays to track results
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];
                const aRowsToRelease = [];

                // Phase 1: Check backend status for ALL selected rows
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);

                            // Track what we found
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update WeightRoller plan for consistency
                                await this.updateWeightRollerPlan(oWeightRollerPlanModel, row, true);
                            }
                        } else {
                            // Order is not released in backend, add to list for release
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Release rows that are not already released in backend
                for (let i = 0; i < aRowsToRelease.length; i++) {
                    const { originalIndex, row, manufacturingOrder } = aRowsToRelease[i];

                    try {
                        // Create release
                        const bReleaseSuccess = await this.createRelease(oModel, manufacturingOrder);

                        if (bReleaseSuccess) {
                            console.log(`Row ${originalIndex + 1}: Successfully released ${manufacturingOrder}`);

                            // Update WeightRoller plan
                            await this.updateWeightRollerPlan(oWeightRollerPlanModel, row, false);

                            // Update UI
                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder
                            });
                            console.log(`✅ Row ${originalIndex + 1} released successfully`);
                        } else {
                            row.releasestatus = "";
                            aFailedRows.push({
                                rowNumber: originalIndex + 1,
                                productionOrder: manufacturingOrder,
                                error: "Release creation failed - check material availability"
                            });
                            console.warn(`⚠️ Row ${originalIndex + 1}: Release creation failed`);
                        }

                    } catch (releaseError) {
                        console.error(`Row ${originalIndex + 1}: Error during release:`, releaseError);
                        row.releasestatus = "";

                        let sErrorMessage;

                        // Check EXACTLY for "Release of order not possible" or CO/118 error
                        const errorMessage = releaseError.message || "";
                        const errorCode = releaseError.code || "";

                        if (errorMessage.includes("Release of order not possible") ||
                            errorCode.includes("CO/118") ||
                            (releaseError.isMaterialAvailabilityError === true)) {
                            // ONLY for this specific error, show the material availability message
                            sErrorMessage = `Release failed: Check material availability for order ${manufacturingOrder}`;
                        } else {
                            // For ALL other errors, show the full error message
                            sErrorMessage = releaseError.message || "Unknown error";

                            // Include the error code if available
                            if (releaseError.code) {
                                sErrorMessage = `Error ${releaseError.code}: ${sErrorMessage}`;
                            }
                        }

                        aFailedRows.push({
                            rowNumber: originalIndex + 1,
                            productionOrder: manufacturingOrder,
                            error: sErrorMessage,
                            rawError: releaseError.message // Store the raw error for debugging
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message
                this.showReleaseSummary(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            showReleaseSummary: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },

            // Updated createRelease function to properly handle errors
            createRelease: function (oModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const oPayload = {
                        ManufacturingOrder: sManufacturingOrder
                    };

                    oModel.create("/ZC_PROD_STATUS1", oPayload, {
                        success: function (oData) {
                            console.log("response success:", oData);

                            // Check if there's an error in the response
                            if (oData.errorresponse) {
                                try {
                                    // Parse the error response JSON
                                    const errorObj = JSON.parse(oData.errorresponse);
                                    console.error("Error in response:", errorObj);

                                    // Check for specific error codes
                                    const errorCode = errorObj.error?.code;
                                    const errorMessage = errorObj.error?.message?.value || "Unknown error";

                                    // Reject with structured error
                                    reject({
                                        message: errorMessage,
                                        code: errorCode,
                                        details: errorObj.error?.innererror,
                                        isMaterialAvailabilityError: errorCode === "CO/118" ||
                                            errorMessage.includes("Release of order not possible")
                                    });
                                } catch (parseError) {
                                    // If JSON parsing fails, reject with the raw error
                                    reject({
                                        message: "Error processing response",
                                        rawError: oData.errorresponse
                                    });
                                }
                                return;
                            }

                            // If no error, resolve with success
                            resolve(true);
                        },
                        error: function (oError) {
                            console.error("OData call failed:", oError);
                            reject({
                                message: oError.message || "OData call failed",
                                rawError: oError
                            });
                        }
                    });
                });
            },

            // Helper function to check order status (unchanged)
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData)
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            updateWeightRollerPlan: function (oWeightRollerPlanModel, row, bAlreadyReleased) {
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        // batchweight: row.batchweight || "",
                        // operator: row.operator || "",
                        // inspector: row.inspector || "",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 WeightRoller Plan updated`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },










            // -----------------------------------------------------------------------------------------------------

            // ============================================================
            // Helper: Generate a UUID-like string for Requestno
            // ============================================================
            generateUUIDreqno: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            // ============================================================
            // Helper: Extract error message from OData error objects
            // ============================================================
            _extractErrorMessage: function (oError) {
                let sErrorMessage = oError.message || "Unknown error";
                if (oError.responseText) {
                    try {
                        const oErrorResponse = JSON.parse(oError.responseText);
                        if (oErrorResponse.error && oErrorResponse.error.message) {
                            sErrorMessage = oErrorResponse.error.message.value || oErrorResponse.error.message;
                        }
                    } catch (e) {
                        sErrorMessage = oError.responseText;
                    }
                }
                return sErrorMessage;
            },

            // ============================================================
            // Batch Release using header-item service
            // ============================================================
            checkUserHasReleaseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_RELEASE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReleasePressBatch: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // for status check
                const oWeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
                const oReleaseModel = oView.getModel("ZSB_RELEASE_HD_ITEM_WTRL");  // new service

                // Get ALL selected rows
                const aAllSelectedRows = aRows.filter(row => row.__selected);

                if (aAllSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasReleaseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_RELEASE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Sort selected rows (same logic as original)
                aAllSelectedRows.sort((a, b) => {
                    const dateA = a.productionordstartdate;
                    const dateB = b.productionordstartdate;
                    if (dateA && dateB) {
                        if (dateA < dateB) return -1;
                        if (dateA > dateB) return 1;
                    } else if (dateA && !dateB) {
                        return -1;
                    } else if (!dateA && dateB) {
                        return 1;
                    }
                    const lotA = parseInt(a.bipllotno, 10) || 0;
                    const lotB = parseInt(b.bipllotno, 10) || 0;
                    return lotA - lotB;
                });

                sap.ui.core.BusyIndicator.show(0);

                // Arrays for summary
                const aSuccessRows = [];
                const aFailedRows = [];
                const aAlreadyReleasedRows = [];

                // Phase 1: Check backend status for ALL selected rows
                const aRowsToRelease = [];
                for (let i = 0; i < aAllSelectedRows.length; i++) {
                    const row = aAllSelectedRows[i];
                    const sManufacturingOrder = row.productionorderno;

                    if (!sManufacturingOrder) {
                        console.warn(`Row ${i + 1} skipped: No production order.`);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: "No Production Order",
                            error: "No production order number"
                        });
                        continue;
                    }

                    try {
                        // Check actual backend status
                        const bStatusActive = await this.checkOrderStatus(oOrderCreationModel, sManufacturingOrder);

                        if (bStatusActive) {
                            console.log(`Row ${i + 1}: Status I0002 is active - already released in backend.`);
                            aAlreadyReleasedRows.push({
                                rowNumber: i + 1,
                                productionOrder: sManufacturingOrder,
                                uiStatus: row.releasestatus
                            });

                            // Update UI to reflect backend state if it's different
                            if (row.releasestatus !== "RELEASED") {
                                row.releasestatus = "RELEASED";
                                // Update WeightRoller plan for consistency (don't fail if this update fails)
                                try {
                                    // await this.updateMixingPlanBatch(oWeightRollerPlanModel, row, true);
                                    await this.updatePlanTableBatch(oWeightRollerPlanModel, row, true);
                                } catch (updateErr) {
                                    console.warn(`WeightRoller plan update for already released row ${row.sap_uuid} failed:`, updateErr);
                                }
                            }
                        } else {
                            // Order is not released in backend, add to list for batch release
                            aRowsToRelease.push({
                                originalIndex: i,
                                row: row,
                                manufacturingOrder: sManufacturingOrder
                            });
                        }
                    } catch (statusError) {
                        console.error(`Row ${i + 1}: Error checking order status:`, statusError);
                        row.releasestatus = "";
                        aFailedRows.push({
                            rowNumber: i + 1,
                            productionOrder: sManufacturingOrder,
                            error: `Status check failed: ${statusError.message || "Unknown error"}`
                        });
                    }
                }

                // Phase 2: Batch release rows that are not already released
                if (aRowsToRelease.length > 0) {
                    // Generate a unique request number
                    const requestNo = this.generateUUIDreqno();

                    // Build items array for the batch payload
                    const aItems = aRowsToRelease.map(item => ({
                        Id: item.row.sap_uuid,                    // unique item identifier
                        Manufacturingorder: item.manufacturingOrder
                        // No other fields needed for creation (output fields will be filled by backend)
                    }));

                    const oPayload = {
                        Requestno: requestNo,
                        toitem: { results: aItems }
                    };

                    console.log(`🚀 Posting Release batch with ${aItems.length} items`, oPayload);

                    try {
                        // Create header with all items in one call
                        const oResponse = await new Promise((resolve, reject) => {
                            oReleaseModel.create("/header", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Release batch created`, oResponse);

                        // Validate response structure
                        if (!oResponse.toitem || !oResponse.toitem.results || !Array.isArray(oResponse.toitem.results)) {
                            throw new Error("Invalid response: missing toitem results");
                        }

                        // Process each item in the response
                        for (let i = 0; i < oResponse.toitem.results.length; i++) {
                            const itemResp = oResponse.toitem.results[i];
                            const originalItem = aRowsToRelease.find(item => item.row.sap_uuid === itemResp.Id);

                            if (!originalItem) {
                                console.error(`❌ Could not find original row for Id: ${itemResp.Id}`);
                                continue;
                            }

                            const row = originalItem.row;
                            const rowNumber = originalItem.originalIndex + 1;

                            // Check if backend returned an error for this item
                            if (itemResp.Errorresponse && itemResp.Errorresponse.trim() !== "") {
                                // Parse error response if possible
                                let errorMsg = itemResp.Errorresponse;
                                try {
                                    const errObj = JSON.parse(itemResp.Errorresponse);
                                    errorMsg = errObj.error?.message?.value || errObj.message || itemResp.Errorresponse;
                                } catch (e) { /* use raw string */ }

                                aFailedRows.push({
                                    rowNumber: rowNumber,
                                    productionOrder: row.productionorderno,
                                    error: errorMsg
                                });
                                continue;
                            }

                            // Success: update WeightRoller plan and UI
                            try {
                                await this.updatePlanTableBatch(oWeightRollerPlanModel, row, false);
                            } catch (updateErr) {
                                console.error(`⚠️ WeightRoller plan update failed for row ${row.sap_uuid}`, updateErr);
                                // Still consider release successful; log warning but don't mark as failed
                            }

                            row.releasestatus = "RELEASED";

                            aSuccessRows.push({
                                rowNumber: rowNumber,
                                productionOrder: row.productionorderno
                            });
                        }
                    } catch (oError) {
                        // Entire request failed
                        console.error(`❌ Release batch failed:`, oError);
                        const sErrorMessage = this._extractErrorMessage(oError);

                        // Mark all rows that were supposed to be released as failed
                        aRowsToRelease.forEach(item => {
                            aFailedRows.push({
                                rowNumber: item.originalIndex + 1,
                                productionOrder: item.row.productionorderno,
                                error: sErrorMessage
                            });
                        });
                    }
                }

                // Final refresh and cleanup
                oTableModel.setProperty("/Samples", aRows);
                oTableModel.refresh();
                sap.ui.core.BusyIndicator.hide();

                // Show summary message (reusing the existing function)
                this.showReleaseSummarybatch(aSuccessRows, aFailedRows, aAlreadyReleasedRows);
            },

            // ============================================================
            // Helper to check order status (unchanged)
            // ============================================================
            checkOrderStatus: function (oOrderCreationModel, sManufacturingOrder) {
                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
                    ];

                    oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                        filters: aFilters,
                        success: function (oData) {
                            console.log("order status :", oData);
                            const aResults = oData.results;
                            const bExists = aResults.some(function (oItem) {
                                return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
                            });
                            resolve(bExists);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });
                });
            },

            // ============================================================
            // Update WeightRoller plan (renamed with Batch suffix for consistency)
            // ============================================================
            updatePlanTableBatch: function (oWeightRollerPlanModel, row, bAlreadyReleased) {
                return new Promise((resolve, reject) => {
                    const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
                    const oUpdateEntry = {
                        releasestatus: "RELEASED",
                        manufacturingdate: row.manufacturingdate ?
                            new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""
                    };

                    oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
                        success: function () {
                            console.log(`🔄 WeightRoller Plan updated for ${row.sap_uuid}`);
                            resolve(true);
                        },
                        error: function (oError) {
                            if (!bAlreadyReleased) {
                                reject(oError);
                            } else {
                                // If already released, still resolve (don't fail the process)
                                resolve(true);
                            }
                        }
                    });
                });
            },

            // ============================================================
            // Existing showReleaseSummarybatch function (unchanged)
            // ============================================================
            showReleaseSummarybatch: function (aSuccessRows, aFailedRows, aAlreadyReleasedRows) {
                const sTotal = aSuccessRows.length + aFailedRows.length + aAlreadyReleasedRows.length;

                if (sTotal === 0) {
                    return;
                }

                let sMessage = `Release process completed for ${sTotal} selected row(s).\n\n`;
                let bHasSuccess = aSuccessRows.length > 0;
                let bHasAlreadyReleased = aAlreadyReleasedRows.length > 0;
                let bHasFailed = aFailedRows.length > 0;

                // Check if any failures are due to material availability
                const aMaterialAvailabilityErrors = aFailedRows.filter(row =>
                    row.error && row.error.includes("Check material availability")
                );

                if (bHasSuccess) {
                    sMessage += `✅ Successfully released: ${aSuccessRows.length}\n`;
                    aSuccessRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}\n`;
                    });
                    sMessage += "\n";
                }

                if (bHasAlreadyReleased) {
                    sMessage += `ℹ️ Already released in backend: ${aAlreadyReleasedRows.length}\n`;

                    const newlySyncedRows = aAlreadyReleasedRows.filter(r => r.uiStatus !== "RELEASED");
                    if (newlySyncedRows.length > 0) {
                        sMessage += `   (${newlySyncedRows.length} were synced from backend)\n`;
                    }

                    aAlreadyReleasedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder}`;
                        if (row.uiStatus !== "RELEASED") {
                            sMessage += ` (UI updated from "${row.uiStatus}" to "RELEASED")`;
                        }
                        sMessage += "\n";
                    });
                    sMessage += "\n";
                }

                if (bHasFailed) {
                    sMessage += `❌ Failed to process: ${aFailedRows.length}\n`;

                    // Show all errors as they are (material availability or full errors)
                    aFailedRows.forEach(row => {
                        sMessage += `   - Row ${row.rowNumber}: ${row.productionOrder || "No Order"}\n`;
                        sMessage += `     Error: ${row.error}\n`;
                    });
                }

                // Always show MessageBox for all cases
                setTimeout(() => {
                    if (bHasFailed) {
                        // Special handling for material availability errors
                        if (aMaterialAvailabilityErrors.length > 0) {
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.WARNING,
                                    title: "Release Process - Material Availability Issues",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        } else {
                            // Show error dialog with details
                            sap.m.MessageBox.show(
                                sMessage,
                                {
                                    icon: sap.m.MessageBox.Icon.ERROR,
                                    title: "Release Process Summary",
                                    actions: [sap.m.MessageBox.Action.OK],
                                    details: aFailedRows.map(f =>
                                        `Row ${f.rowNumber} - Production Order: ${f.productionOrder || "No Order"}\nError: ${f.error || "Unknown error"}`
                                    ).join('\n\n')
                                }
                            );
                        }
                    } else if (bHasSuccess) {
                        // Show success dialog
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.SUCCESS,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    } else {
                        // Only already released rows (no new releases, no failures)
                        sap.m.MessageBox.show(
                            sMessage,
                            {
                                icon: sap.m.MessageBox.Icon.INFORMATION,
                                title: "Release Process Summary",
                                actions: [sap.m.MessageBox.Action.OK]
                            }
                        );
                    }
                }, 100);
            },





















            // onReleasePress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1");//ZSD_PRODUCT_ORD // OData backend
            //     const oWeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // For PATCH
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");//ZSD_PRODUCT_ORD // Using same model for read from ZC_ORDER_CREATION

            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     const that = this;
            //     let iCompleted = 0;

            //     aSelectedRows.forEach((row, index) => {
            //         const sManufacturingOrder = row.productionorderno;
            //         // debugger


            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${index + 1} skipped: No production order.`);
            //             iCompleted++;
            //             checkCompletion();
            //             return;
            //         }

            //         // Step 1: Check status from ZC_ORDER_CREATION
            //         // const sFilter = `/ZC_ORDER_CREATION?$filter=ManufacturingOrder eq '${sManufacturingOrder}'`;
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];
            //         //check
            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 // const oEntry = aResults && aResults[0];
            //                 // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

            //                 // const mapped = aResults.map(entry => {
            //                 //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
            //                 //   });

            //                 //   const oEntry = mapped.find(entry => entry !== null);
            //                 // debugger
            //                 var bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });

            //                 // const iSelectedIndex = aRows.findIndex(row => row.__selected);



            //                 if (bExists) {
            //                     console.log("Combination exists: I0002 and active.");
            //                     // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
            //                     sap.m.MessageToast.show("Rows may already be released.");

            //                     const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                     const oUpdateEntry = {
            //                         releasestatus: "RELEASED",
            //                         // releasestatus: "RELEASED",
            //                         batchweight: row.batchweight || "", // use value if filled
            //                         operator: row.operator || "",
            //                         inspector: row.inspector || "",
            //                         manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                         confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""

            //                     };
            //                     // debugger

            //                     oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                         success: function () {
            //                             console.log(`🔄 WeightRollerPlan updated for row ${index + 1}`);
            //                             // checkCompletion();
            //                             // oTableModel.refresh();
            //                             row.releasestatus = "RELEASED";
            //                             oTableModel.setProperty("/Samples", aRows);
            //                             oTableModel.refresh();


            //                             checkCompletion01()

            //                         },
            //                         error: function () {
            //                             row.releasestatus = ""; // revert
            //                             // console.warn(`⚠️ Mixing Plan update failed for row ${index + 1}`);
            //                             // checkCompletion();
            //                             // oTableModel.setProperty("/Samples", aRows);
            //                             // oTableModel.refresh();
            //                             // aRows[iSelectedIndex].releasestatus = "RELEASED";
            //                             checkCompletion01()

            //                         }
            //                     });

            //                     sap.ui.core.BusyIndicator.hide(0);
            //                     return
            //                 }


            //                 // StatusCode
            //                 //StatusIsActive
            //                 // debugger

            //                 // // Check if status should skip this row
            //                 // if (oEntry && oEntry.StatusCode === "10002" && oEntry.StatusIsActive === true) {
            //                 //     console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
            //                 //     // debugger
            //                 //     // iCompleted++;
            //                 //     // checkCompletion();
            //                 //     return;
            //                 // }

            //                 // Continue with create + update logic

            //                 const oPayload = {
            //                     ManufacturingOrder: sManufacturingOrder
            //                 };
            //                 // debugger

            //                 oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //                     success: function (oData) {
            //                         // debugger
            //                         console.log(`✅ Release POST success for row ${index + 1}`, oData);
            //                         if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                             // 🚫 Stop release and just inform user
            //                             sap.m.MessageToast.show("Check material availability");
            //                             row.releasestatus = ""; // keep as not released
            //                             sap.ui.core.BusyIndicator.hide();

            //                             // checkCompletion();
            //                             return;
            //                         }
            //                         row.releasestatus = "RELEASED";

            //                         const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                         const oUpdateEntry = {
            //                             releasestatus: "RELEASED",
            //                             // releasestatus: "RELEASED",
            //                             batchweight: row.batchweight || "", // use value if filled
            //                             operator: row.operator || "",
            //                             inspector: row.inspector || "",
            //                             manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || ""

            //                         };
            //                         // debugger


            //                         oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                             success: function () {
            //                                 console.log(`🔄 WeightRollerPlan  updated for row ${index + 1}`);
            //                                 checkCompletion();
            //                             },
            //                             error: function () {
            //                                 row.releasestatus = ""; // revert
            //                                 console.log(`⚠️ WeightRollerPlan update failed for row ${index + 1}`);
            //                                 checkCompletion();
            //                             }
            //                         });
            //                     },
            //                     error: function (oError) {
            //                         row.releasestatus = ""; // revert
            //                         console.error(`❌ Release POST failed for row ${index + 1}`, oError);
            //                         checkCompletion();
            //                     }
            //                 });
            //             },
            //             error: function (oError) {
            //                 console.error(`🔍 Status check failed for row ${index + 1}`, oError);
            //                 iCompleted++;
            //                 checkCompletion();
            //             }
            //         });
            //     });

            //     function checkCompletion() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Release process completed.");
            //         }
            //     }
            //     function checkCompletion01() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);

            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             // sap.m.MessageToast.show("Release process completed.");
            //         }
            //     }
            // },


            // ===========================================================================================================
            // ===========================================================================================================
            // ===========================================================================================================
            // onReleaseFragmentPress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     // Get selected rows from main table
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select a row first.");
            //         return;
            //     }
            //     if (aSelectedRows.length > 1) {
            //         sap.m.MessageToast.show("Please select only one row.");
            //         return;
            //     }

            //     // ✅ Save selected rows for later use
            //     oTableModel.setProperty("/SelectedRowData", aSelectedRows);

            //     sap.ui.core.BusyIndicator.show(0);

            //     // Step 1: Get Manufacturing Order (production order number)
            //     const sProdOrderNo = aSelectedRows[0].productionorderno;
            //     const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

            //     // Step 2: First fetch Reservation from ZC_RESERVATION_COMPONENT
            //     const aReservationFilter = [
            //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
            //     ];

            //     oODataModel.read("/ZC_RESERVATION_COMPONENT", {
            //         filters: aReservationFilter,
            //         success: function (oReservationData) {
            //             const aResults = oReservationData.results;

            //             if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
            //                 sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
            //                 return;
            //             }

            //             const sReservation = aResults[0].Reservation;

            //             // Step 3: Now fetch BOM data from ZC_RELEASE_BOM using Reservation
            //             // const aBomFilters = [
            //             //     new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
            //             // ];

            //             // oODataModel.read("/ZC_RELEASE_BOM", {
            //             //     filters: aBomFilters,
            //             //     success: function (oBomData) {
            //             //         oTableModel.setProperty("/BomRelease", oBomData.results || []);

            //             //         // Open fragment if not already open
            //             //         if (!this._oBomReleaseDialog) {
            //             //             this._oBomReleaseDialog = sap.ui.xmlfragment(
            //             //                 "bando.view.CommonFragments.ActualScreens.BomRelease",
            //             //                 this
            //             //                 // bando.view.CommonFragments.ActualScreens.BomRelease

            //             //             );
            //             //             oView.addDependent(this._oBomReleaseDialog);
            //             //         }
            //             //         this._oBomReleaseDialog.open();
            //             //         sap.ui.core.BusyIndicator.hide();
            //             //     }.bind(this),
            //             //     error: function (oError) {
            //             //         sap.m.MessageToast.show("Error fetching BOM Release data.");
            //             //         console.error(oError);
            //             //     }
            //             // });
            //             const aBomFilters = [
            //                 new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
            //             ];

            //             oODataModel.read("/ZC_RELEASE_BOM", {
            //                 filters: aBomFilters,
            //                 success: function (oBomData) {
            //                     // Filter out items where the Quantity (ResvnItmRequiredQtyInBaseUnit) is essentially 0
            //                     const aFilteredBomData = oBomData.results.filter(function (item) {
            //                         // Explicitly check if the quantity is not zero (allow for floating-point precision issues)
            //                         return parseFloat(item.ResvnItmRequiredQtyInBaseUnit) !== 0;
            //                     });

            //                     // If no valid data exists after filtering, show a message
            //                     if (aFilteredBomData.length === 0) {
            //                         sap.m.MessageToast.show("No valid BOM data with non-zero quantities.");
            //                     }





            //                     // Set the filtered data to the model
            //                     oTableModel.setProperty("/BomRelease", aFilteredBomData || []);

            //                     // Open the fragment dialog if it's not already open
            //                     if (!this._oBomReleaseDialog) {
            //                         this._oBomReleaseDialog = sap.ui.xmlfragment(
            //                             "bando.view.CommonFragments.ActualScreens.BomRelease",
            //                             this
            //                         );
            //                         oView.addDependent(this._oBomReleaseDialog);
            //                     }

            //                     this._oBomReleaseDialog.open();
            //                     sap.ui.core.BusyIndicator.hide();
            //                 }.bind(this),
            //                 error: function (oError) {
            //                     sap.m.MessageToast.show("Error fetching BOM Release data.");
            //                     console.error(oError);
            //                 }
            //             });

            //         }.bind(this),
            //         error: function (oError) {
            //             sap.m.MessageToast.show("Error fetching Reservation.");
            //             console.error(oError);
            //         }
            //     });
            // },


            // onReleaseCancel: function () {
            //     if (this._oBomReleaseDialog) {
            //         this._oBomReleaseDialog.close();
            //         this._oBomReleaseDialog.destroy();
            //         this._oBomReleaseDialog = null; // reset reference
            //     }
            // },


            // onReleasePress: function () {
            //     const that = this;
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");
            //     const oModel = oView.getModel("ZSB_PRODUCT_ORD1"); // OData backend for release
            //     const oWeightrollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // For PATCH
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); // Same model for status check

            //     // ✅ Use filtered selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected && row.releasestatus !== "RELEASED");

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("No eligible rows selected. Rows may already be released.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     aSelectedRows.forEach((row, index) => {
            //         const sManufacturingOrder = row.productionorderno;
            //         // debugger;

            //         if (!sManufacturingOrder) {
            //             console.warn(`Row ${index + 1} skipped: No production order.`);
            //             iCompleted++;
            //             checkCompletion();
            //             return;
            //         }

            //         // Step 1: Check status from ZC_ORDER_CREATION
            //         const aFilters = [
            //             new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sManufacturingOrder)
            //         ];

            //         oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //             filters: aFilters,
            //             success: function (oData) {
            //                 const aResults = oData.results;
            //                 // debugger;

            //                 var bExists = aResults.some(function (oItem) {
            //                     return oItem.StatusCode === "I0002" && oItem.StatusIsActive === true;
            //                 });

            //                 if (bExists) {
            //                     console.log("Combination exists: I0002 and active.");
            //                     sap.m.MessageToast.show("Rows may already be released.");

            //                     // Update Weightroller plan as RELEASED anyway
            //                     const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                     const oUpdateEntry = {
            //                         releasestatus: "RELEASED",
            //                         // batchweight: row.batchweight || "",
            //                         // operator: row.operator || "",
            //                         // inspector: row.inspector || "",
            //                         manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                         confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || "",
            //                         scrapqty:parseFloat(row.scrapqty).toFixed(3) || "",
            //                     };
            //                     // debugger;

            //                     oWeightrollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                         success: function () {
            //                             console.log(`🔄 Weightroller Plan updated for row ${index + 1}`);
            //                             row.releasestatus = "RELEASED";
            //                             oTableModel.setProperty("/Samples", aRows);
            //                             oTableModel.refresh();
            //                             checkCompletion01();
            //                         },
            //                         error: function () {
            //                             row.releasestatus = ""; // revert
            //                             checkCompletion01();
            //                         }
            //                     });

            //                     sap.ui.core.BusyIndicator.hide(0);
            //                     return;
            //                 }

            //                 // Step 2: Continue with create logic
            //                 const oPayload = { ManufacturingOrder: sManufacturingOrder };
            //                 // debugger;

            //                 oModel.create("/ZC_PROD_STATUS1", oPayload, {
            //                     success: function (oData) {
            //                         console.log(`✅ Release POST success for row ${index + 1}`, oData);

            //                         if (oData.Orderiscreated && oData.Orderiscreated.includes("Check material availability")) {
            //                             sap.m.MessageToast.show("Check material availability");
            //                             row.releasestatus = ""; // not released
            //                             sap.ui.core.BusyIndicator.hide();
            //                             return;
            //                         }

            //                         row.releasestatus = "RELEASED";

            //                         const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                         const oUpdateEntry = {
            //                             releasestatus: "RELEASED",
            //                             // batchweight: row.batchweight || "",
            //                             // operator: row.operator || "",
            //                             // inspector: row.inspector || "",
            //                             manufacturingdate: row.manufacturingdate ? new Date(row.manufacturingdate.toLocaleDateString('en-CA')) : null,
            //                             confirmedqty: parseFloat(row.confirmedqty).toFixed(3) || "",
            //                             scrapqty:parseFloat(row.scrapqty).toFixed(3) || "",
            //                         };
            //                         // debugger;

            //                         oWeightrollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                             success: function () {
            //                                 console.log(`🔄 Weightroller Plan updated for row ${index + 1}`);
            //                                 checkCompletion();
            //                             },
            //                             error: function () {
            //                                 row.releasestatus = "";
            //                                 console.log(`⚠️ Weightroller Plan update failed for row ${index + 1}`);
            //                                 checkCompletion();
            //                             }
            //                         });
            //                     },
            //                     error: function (oError) {
            //                         row.releasestatus = "";
            //                         console.error(`❌ Release POST failed for row ${index + 1}`, oError);
            //                         checkCompletion();
            //                     }
            //                 });
            //             },
            //             error: function (oError) {
            //                 console.error(`🔍 Status check failed for row ${index + 1}`, oError);
            //                 iCompleted++;
            //                 checkCompletion();
            //             }
            //         });
            //     });

            //     // function checkCompletion() {
            //     //     iCompleted++;
            //     //     if (iCompleted === aSelectedRows.length) {
            //     //         oTableModel.setProperty("/Samples", aRows);
            //     //         oTableModel.refresh();
            //     //         sap.ui.core.BusyIndicator.hide();
            //     //         sap.m.MessageToast.show("Release process completed.");
            //     //     }
            //     // }
            //     function checkCompletion() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();

            //             sap.m.MessageToast.show("Release process completed.");

            //             // 🔁 Refresh the BOM data in the fragment
            //             that._refreshBomData();
            //         }
            //     }


            //     function checkCompletion01() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             // Optional: sap.m.MessageToast.show("Release process completed.");
            //         }
            //     }
            // },

            // //refetching data after release such that batch is fetched in the bom
            // _refreshBomData: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const oODataModel = oView.getModel("ZSB_RELEASE_BOM");

            //     const aSelectedRows = oTableModel.getProperty("/SelectedRowData");
            //     if (!aSelectedRows || aSelectedRows.length === 0) return;

            //     const sProdOrderNo = aSelectedRows[0].productionorderno;

            //     const aReservationFilter = [
            //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, sProdOrderNo)
            //     ];

            //     // Step 1: Get Reservation
            //     oODataModel.read("/ZC_RESERVATION_COMPONENT", {
            //         filters: aReservationFilter,
            //         success: function (oReservationData) {
            //             const aResults = oReservationData.results;
            //             if (!aResults || aResults.length === 0 || !aResults[0].Reservation) {
            //                 sap.m.MessageToast.show("No reservation found for this Manufacturing Order.");
            //                 return;
            //             }

            //             const sReservation = aResults[0].Reservation;

            //             // Step 2: Fetch BOM
            //             const aBomFilters = [
            //                 new sap.ui.model.Filter("Reservation", sap.ui.model.FilterOperator.EQ, sReservation)
            //             ];

            //             oODataModel.read("/ZC_RELEASE_BOM", {
            //                 filters: aBomFilters,
            //                 success: function (oBomData) {
            //                     oTableModel.setProperty("/BomRelease", oBomData.results || []);
            //                     oTableModel.refresh();
            //                     sap.m.MessageToast.show("BOM data refreshed successfully.");
            //                 },
            //                 error: function (oError) {
            //                     console.error("Error fetching refreshed BOM data:", oError);
            //                 }
            //             });
            //         },
            //         error: function (oError) {
            //             console.error("Error fetching reservation:", oError);
            //         }
            //     });
            // },
            //===============================================================================================================================
            //===============================================================================================================================
            //===============================================================================================================================


            // onRowSelectionChange: async function (oEvent) {
            //     const oCheckBox = oEvent.getSource();
            //     const oView = this.getView();

            //     // Get the table model and all rows
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/BomRelease");

            //     // Get the binding context path of the checkbox
            //     const sPath = oCheckBox.getBindingContext("TabModel").getPath(); // e.g., "/BomRelease/3"
            //     const iIndex = parseInt(sPath.split("/").pop());

            //     // Get the selected row data
            //     const oSelectedRowData = aRows[iIndex];
            //     console.log("Selected Row Data:", oSelectedRowData);

            //     // --- Prepare Data for Barcode ---
            //     const barcodeData = `
            //         ManufacturingOrder: ${oSelectedRowData.ManufacturingOrder || ""}
            //         Product: ${oSelectedRowData.Product || ""}
            //         Plant: ${oSelectedRowData.Plant || ""}
            //         StorageLocation: ${oSelectedRowData.StorageLocation || ""}
            //         Batch: ${oSelectedRowData.Batch || ""}
            //         Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}
            //         UOM: ${oSelectedRowData.BaseUnit || ""}
            //     `;

            //     // --- Generate Barcode ---
            //     const canvas = document.createElement("canvas");
            //     JsBarcode(canvas, oSelectedRowData.ManufacturingOrder || "N/A", {
            //         format: "CODE128",
            //         width: 2,
            //         height: 60,
            //         displayValue: true
            //     });

            //     const barcodeBase64 = canvas.toDataURL("image/png");

            //     // --- Generate PDF with Barcode ---
            //     const { jsPDF } = window.jspdf;
            //     const doc = new jsPDF();

            //     doc.setFontSize(12);
            //     doc.text(`Manufacturing Order: ${oSelectedRowData.ManufacturingOrder || ""}`, 20, 30);
            //     doc.text(`Product: ${oSelectedRowData.Product || ""}`, 20, 40);
            //     doc.text(`Plant: ${oSelectedRowData.Plant || ""}`, 20, 50);
            //     doc.text(`Storage Location: ${oSelectedRowData.StorageLocation || ""}`, 20, 60);
            //     doc.text(`Batch: ${oSelectedRowData.Batch || ""}`, 20, 70);
            //     doc.text(`Quantity: ${oSelectedRowData.ResvnItmRequiredQtyInBaseUnit || ""}`, 20, 80);
            //     doc.text(`UOM: ${oSelectedRowData.BaseUnit || ""}`, 20, 90);

            //     // Add Barcode image to PDF
            //     doc.addImage(barcodeBase64, "PNG", 140, 20, 50, 20);

            //     // Open PDF in new tab
            //     const blob = doc.output("blob");
            //     const pdfUrl = URL.createObjectURL(blob);
            //     window.open(pdfUrl, "_blank");
            // },

            // ======================================================================================
            // ======================================================================================
            // ======================================================================================


            onBatchValueHelp: function (oEvent) {
                const oView = this.getView();
                const oSource = oEvent.getSource();
                this._oBatchInputSource = oSource; // Save for setting value later

                // Load fragment if not already created
                if (!this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog = sap.ui.xmlfragment(
                        oView.getId(),
                        "bando.view.CommonFragments.ActualScreens.bombatchselect",
                        this
                    );
                    oView.addDependent(this._oBatchValueHelpDialog);
                }

                // Get current row data (for filtering)
                const oContext = oSource.getBindingContext("TabModel");
                if (!oContext) {
                    sap.m.MessageToast.show("No row context found.");
                    return;
                }

                const oRowData = oContext.getObject();
                const sMaterial = oRowData.Product;
                const sPlant = oRowData.Plant;
                const sStorageLoc = oRowData.StorageLocation;

                // Load data before opening
                this._loadBatchData(sMaterial, sPlant, sStorageLoc);
            },

            // ===========================================================
            // Load Batch Data and Bind to Fragment Table
            // ===========================================================
            _loadBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB"); // backend OData model

                // Build filters
                const aFilters = [
                    new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                const that = this;
                oModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        console.log("✅ Batch data received:", oData);

                        // Create JSON model from results array
                        const oJSONModel = new sap.ui.model.json.JSONModel(oData.results);

                        // Get table from fragment
                        const oTable = sap.ui.core.Fragment.byId(oView.getId(), "batchTable");
                        if (oTable) {
                            oTable.setModel(oJSONModel, "BatchModel");
                            console.log("✅ Bound rows:", oJSONModel.getData());
                            that._oBatchValueHelpDialog.open();
                        } else {
                            console.error("❌ batchTable not found in fragment");
                        }
                    },

                    error: function (oError) {
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // ===========================================================
            // Handle "Select" Button - Set Batch value in Input Field
            // ===========================================================

            // onBatchRowSelect: function (oEvent) {
            //     const oTable = oEvent.getSource();
            //     const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

            //     if (!oSelectedContext) {
            //         sap.m.MessageToast.show("No row selected.");
            //         return;
            //     }

            //     const oSelectedData = oSelectedContext.getObject();

            //     if (this._oBatchInputSource) {
            //         this._oBatchInputSource.setValue(oSelectedData.Batch); // Set selected batch
            //     }

            //     // Close and destroy the dialog to avoid reuse issues
            //     if (this._oBatchValueHelpDialog) {
            //         this._oBatchValueHelpDialog.close();
            //         this._oBatchValueHelpDialog.destroy();
            //         this._oBatchValueHelpDialog = null;
            //     }
            // },
            onBatchRowSelect: function (oEvent) {
                const oTable = oEvent.getSource();
                const oSelectedContext = oTable.getContextByIndex(oEvent.getParameter("rowIndex"));

                if (!oSelectedContext) {
                    sap.m.MessageToast.show("No row selected.");
                    return;
                }

                const oSelectedData = oSelectedContext.getObject();

                if (this._oBatchInputSource) {
                    // Get the current row context in the TabModel
                    const oRowContext = this._oBatchInputSource.getBindingContext("TabModel");

                    if (oRowContext) {
                        const oTabModel = oRowContext.getModel();
                        const sRowPath = oRowContext.getPath();

                        // Set both Batch and Storage Location
                        oTabModel.setProperty(sRowPath + "/Batch", oSelectedData.Batch);
                        oTabModel.setProperty(sRowPath + "/StorageLocation", oSelectedData.StorageLocation);

                        // Optional: If you want to update the input field value as well
                        this._oBatchInputSource.setValue(oSelectedData.Batch);
                    }
                }

                // Close and destroy the dialog to avoid reuse issues
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy();
                    this._oBatchValueHelpDialog = null;
                }
            },

            // ===========================================================
            // Handle "Cancel" Button
            // ===========================================================
            onValueHelpCancel: function () {
                if (this._oBatchValueHelpDialog) {
                    this._oBatchValueHelpDialog.close();
                    this._oBatchValueHelpDialog.destroy(); // cleanup
                    this._oBatchValueHelpDialog = null; // reset reference
                }
            },






            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Release END
            // ------------------------------------------------------------------------------------------------------------------------------------------





            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse reciept start
            // ------------------------------------------------------------------------------------------------------------------------------------------













            // onReverseReceiptPress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1"); //ZSB_REVERSE_PORD    // Reverse OData model

            //     const oWeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");   // For updating internal table
            //     const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1"); //ZSD_PRODUCT_ORD

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
            //         return;
            //     }

            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
            //     if (aInvalidRows.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
            //         return;
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     const aFilters = [
            //         new sap.ui.model.Filter("ManufacturingOrder", sap.ui.model.FilterOperator.EQ, aSelectedRows[0].productionorderno)
            //     ];
            //     oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             const aResults = oData.results;
            //             // const oEntry = aResults && aResults[0];
            //             // const oEntry = aResults.find(entry => entry.StatusCode === "10002" && entry.StatusIsActive === true);

            //             // const mapped = aResults.map(entry => {
            //             //     return (entry.StatusCode === "10002" && entry.StatusIsActive === true) ? entry : null;
            //             //   });

            //             //   const oEntry = mapped.find(entry => entry !== null);
            //             var bExists = aResults.some(function (oItem) {
            //                 return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
            //             });

            //             // const iSelectedIndex = aRows.findIndex(row => row.__selected);



            //             if (bExists) {
            //                 console.log("Combination exists: I0002 and active.");
            //                 // console.warn(`⛔ Row ${index + 1} skipped: Status 10002 is active.`);
            //                 sap.m.MessageToast.show("Teco already active, cant reverse");
            //                 sap.ui.core.BusyIndicator.hide();

            //                 return;
            //             }
            //             else {
            //                 aSelectedRows.forEach((row, index) => {
            //                     const oPayload = {
            //                         Materialdocument: row.grmaterialdocnumber,
            //                         Matdocyear: row.grmaterialdocyear, // You can make this dynamic if needed
            //                         Postingdate: new Date()
            //                     };

            //                     console.log(`📤 Sending Reverse Receipt Payload for row ${index + 1}:`, oPayload);

            //                     oReverseModel.create("/ZCDS_REVERSE_PROD1", oPayload, {
            //                         success: function (oData) {
            //                             console.log(`✅ Reverse receipt success for row ${index + 1}:`, oData);

            //                             const sResponseValue = oData.Response || "";

            //                             // Update internal table field `grmaterialdocnumber`
            //                             const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                             const oUpdateEntry = {
            //                                 grmaterialdocnumber: sResponseValue,
            //                                 grmaterialdocyear: "",
            //                             };

            //                             oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                                 success: function () {
            //                                     console.log(`🔄 grmaterialdocnumber updated for row ${index + 1}`);
            //                                     row.grmaterialdocnumber = sResponseValue;
            //                                     row.grmaterialdocyear = "";
            //                                     checkCompletion();
            //                                 },
            //                                 error: function () {
            //                                     console.warn(`⚠️ Failed to update grmaterialdocnumber for row ${index + 1}`);
            //                                     checkCompletion();
            //                                 }
            //                             });
            //                         },
            //                         error: function (oError) {
            //                             console.error(`❌ Reverse receipt failed for row ${index + 1}`, oError);
            //                             checkCompletion();
            //                         }
            //                     });
            //                 });

            //                 function checkCompletion() {
            //                     iCompleted++;
            //                     if (iCompleted === aSelectedRows.length) {
            //                         oTableModel.setProperty("/Samples", aRows);
            //                         oTableModel.refresh();
            //                         sap.ui.core.BusyIndicator.hide();
            //                         sap.m.MessageToast.show("Reverse receipt process completed.");
            //                     }
            //                 }

            //             }

            //         }
            //     });

            // },


            checkUserHasGoodsRecieptReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },

            onReverseReceiptPress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_REVERSE_PROD1_WTRL");
                const oTablePlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
                const oOrderCreationModel = oView.getModel("ZSB_PRODUCT_ORD1");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse receipt.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsRecieptReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_RECIEPT_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Check missing GR fields
                const aInvalidRows = aSelectedRows.filter(row => !row.grmaterialdocnumber || !row.grmaterialdocyear);
                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse receipt: One or more selected rows are missing GR Material Document Number or Year.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    // Check TECO first
                    const aFilters = [
                        new sap.ui.model.Filter(
                            "ManufacturingOrder",
                            sap.ui.model.FilterOperator.EQ,
                            aSelectedRows[0].productionorderno
                        )
                    ];

                    const oData = await new Promise((resolve, reject) => {
                        oOrderCreationModel.read("/ZC_ORDER_CREATION1", {
                            filters: aFilters,
                            success: resolve,
                            error: reject
                        });
                    });

                    const aResults = oData.results;

                    var bExists = aResults.some(function (oItem) {
                        return oItem.StatusCode === "I0045" && oItem.StatusIsActive === true;
                    });

                    if (bExists) {
                        sap.m.MessageToast.show("Teco already active, cant reverse");
                        return;
                    }

                    // Process rows sequentially
                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Materialdocument: row.grmaterialdocnumber,
                            Matdocyear: row.grmaterialdocyear,
                            Postingdate: new Date()
                        };

                        console.log(`📤 Sending Reverse Receipt Payload for row ${i + 1}:`, oPayload);

                        // Reverse API
                        const oReverseData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZCDS_REVERSE_PROD1_WTRL", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse receipt success for row ${i + 1}:`, oReverseData);

                        const sResponseValue = oReverseData.Response || "";

                        const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            grmaterialdocnumber: sResponseValue,
                            grmaterialdocyear: ""
                        };

                        // Update API
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI
                        row.grmaterialdocnumber = sResponseValue;
                        row.grmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse receipt process completed.");

                } catch (error) {
                    console.error("❌ Reverse receipt error:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Receipt process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },










            // ------------------------------------------------------------------------------------------------------------------------------------------
            // Reverse issue start
            // ------------------------------------------------------------------------------------------------------------------------------------------





            // onReverseIssuePress: function () {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_CNFISSUEREVERSE"); // Backend OData model for reverse

            //     // 🔁 Static test payload
            //     const oPayload = {
            //         Porderno: "110000150",            // Replace with actual Production Order number
            //         ConfirmationGroup: "0000000176",     // Replace with actual Confirmation Group
            //         ConfirmationCount: "00000005"      // Replace with actual Confirmation Count
            //     };


            //     console.log("📤 Sending Reverse issue Payload:", oPayload);
            //     sap.ui.core.BusyIndicator.show(0);

            //     oModel.create("/ZDD_CNFISSUERSV", oPayload, {
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();
            //             console.log("✅ Reverse issue POST Success:", oData);
            //             sap.m.MessageToast.show("Reverse issue request posted successfully.");
            //         },
            //         error: function (oError) {
            //             sap.ui.core.BusyIndicator.hide();
            //             console.error("❌ Reverse issue POST Failed:", oError);
            //             sap.m.MessageBox.error("Reverse issue failed. Check console for details.");
            //         }
            //     });
            // },



            // onReverseIssuePress: function () {
            //     const oView = this.getView();
            //     const oTableModel = oView.getModel("TabModel");
            //     const aRows = oTableModel.getProperty("/Samples");

            //     const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1");//ZSB_CNFISSUEREVERSE // Reverse API model 
            //     const oWeightRollerPlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN"); // For PATCH

            //     // Get selected rows
            //     const aSelectedRows = aRows.filter(row => row.__selected);

            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageToast.show("Please select at least one row to reverse issue.");
            //         return;
            //     }


            //     // ✅ New Validation: Prevent if any row has grmaterialdocnumber
            //     const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
            //     if (aHasGRRows.length > 0) {
            //         sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
            //         return;
            //     }


            //     // Check for missing GR Material Document Number or Year
            //     const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
            //     if (aInvalidRows1.length > 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
            //         return;
            //     }
            //     // const aInvalidRows2 = aSelectedRows.filter(row => !row.grmaterialdocnumber);
            //     // if (aInvalidRows2.length > 0) {
            //     //     sap.ui.core.BusyIndicator.hide();
            //     //     sap.m.MessageBox.error("Cannot reverse Issue: Do Reciept reverse first.");
            //     //     return;
            //     // }





            //     sap.ui.core.BusyIndicator.show(0);
            //     let iCompleted = 0;

            //     aSelectedRows.forEach((row, index) => {
            //         const oPayload = {
            //             Porderno: row.productionorderno,
            //             ConfirmationGroup: row.gicnfconfirmationgroup,
            //             ConfirmationCount: row.gicnfconfirmationcount
            //         };

            //         console.log(`📤 Sending Reverse Issue Payload for row ${index + 1}:`, oPayload);

            //         oReverseModel.create("/ZDD_CNFISSUERSV1", oPayload, {
            //             success: function (oData) {
            //                 console.log(`✅ Reverse issue success for row ${index + 1}:`, oData);

            //                 // Get the returned material document number (assuming field is "Response")
            //                 const sResponseValue = oData.Response || "";

            //                 // Update Weightroller Plan table with returned Response
            //                 const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";
            //                 const oUpdateEntry = {
            //                     gicnfmaterialdocnumber: "",
            //                     gicnfconfirmationgroup: "",
            //                     gicnfconfirmationcount: "",
            //                     gicnfmaterialdocyear: ""
            //                 };

            //                 oWeightRollerPlanModel.update(sUpdatePath, oUpdateEntry, {
            //                     success: function () {
            //                         console.log(`🔄 gicnfmaterialdocnumber updated for row ${index + 1}`);
            //                         row.gicnfmaterialdocnumber = "";
            //                         row.gicnfconfirmationgroup = "";
            //                         row.gicnfconfirmationcount = "";
            //                         row.gicnfmaterialdocyear = "";
            //                         checkCompletion();
            //                     },
            //                     error: function () {
            //                         console.warn(`⚠️ Failed to update gicnfmaterialdocnumber for row ${index + 1}`);
            //                         checkCompletion();
            //                     }
            //                 });
            //             },
            //             error: function (oError) {
            //                 console.error(`❌ Reverse issue failed for row ${index + 1}`, oError);
            //                 checkCompletion();
            //             }
            //         });
            //     });

            //     function checkCompletion() {
            //         iCompleted++;
            //         if (iCompleted === aSelectedRows.length) {
            //             oTableModel.setProperty("/Samples", aRows);
            //             oTableModel.refresh();
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Reverse issue process completed.");
            //         }
            //     }
            // },

            checkUserHasGoodsIssueReverseRole: function () {
                return new Promise((resolve, reject) => {
                    const that = this; // Store reference for callbacks
                    const sRequiredRole = "ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON";
                    // debugger

                    // 1. Get user ID - following the same pattern as working code
                    let sUserId = this.sUserId;
                    if (!sUserId) {
                        console.log("User ID not set, trying to fetch from UserInfo service...");
                        try {
                            var oUserInfo = sap.ushell.Container.getService("UserInfo");
                            sUserId = oUserInfo ? oUserInfo.getId() : null;
                        } catch (e) {
                            console.log("Error fetching UserInfo:", e);
                            sUserId = null;
                        }
                        if (!sUserId) {
                            console.log("User ID still not available.");
                            reject(new Error("User ID not available"));
                            return;
                        }
                        this.sUserId = sUserId; // cache for future calls
                    }
                    console.log("Current User ID:", sUserId);

                    // 2. Get OData model - using getOwnerComponent() like your working code
                    console.log("Checking role assignment via OData...");
                    const oModel = this.getView().getModel("ZSB_USERBUSINESSROLE_SRB");
                    if (!oModel) {
                        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
                        reject(new Error("User Business Role model not found"));
                        return;
                    }

                    // 3. Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
                    // FIXED: Use sUserId variable, not this.sUserId
                    // FIXED: Use sRequiredRole, not sRole
                    // const oFilterUser = new Filter("UserID", FilterOperator.EQ, sUserId);
                    // const oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRequiredRole);
                    // const oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND
                    var oFilterUser = new sap.ui.model.Filter("UserID", sap.ui.model.FilterOperator.EQ, sUserId);
                    var oFilterRole = new sap.ui.model.Filter("BusinessRole", sap.ui.model.FilterOperator.EQ, sRequiredRole);
                    var oFilter = new sap.ui.model.Filter([oFilterUser, oFilterRole], true); // true = AND

                    console.log("OData filter:", "UserID =", sUserId, "AND BusinessRole =", sRequiredRole);

                    // 4. Execute read request with the combined filter
                    oModel.read("/ZCE_USERBUSINESSROLE", {
                        filters: [oFilter],
                        success: function (oData) {
                            console.log("OData read successful. Number of records returned:", oData.results.length);
                            const hasRole = oData.results && oData.results.length > 0;
                            if (hasRole) {
                                console.log("Access GRANTED - role found for user.");
                            } else {
                                console.log("Access DENIED - role not found for user.");
                            }
                            resolve(hasRole);
                        },
                        error: function (oError) {
                            console.log("OData read error:", oError);
                            reject(new Error("Error checking role: " + (oError.message || oError)));
                        }
                    });
                });
            },


            onReverseIssuePress: async function () {
                const oView = this.getView();
                const oTableModel = oView.getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples");

                const oReverseModel = oView.getModel("ZSB_CNFISSUEREVERSE1_WTRL");
                const oTablePlanModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");

                // Get selected rows
                const aSelectedRows = aRows.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to reverse issue.");
                    return;
                }

                // ---------- ROLE CHECK ----------
                try {
                    const hasRole = await this.checkUserHasGoodsIssueReverseRole();
                    if (!hasRole) {
                        sap.m.MessageBox.error("You do not have the required role (ZF_BANDO_GOODS_ISSUE_REVERSE_BUTTON) to perform this action.");
                        return;
                    }
                } catch (err) {
                    sap.m.MessageBox.error("Role check failed: " + err.message);
                    return;
                }

                // Prevent if any row has GR material doc
                const aHasGRRows = aSelectedRows.filter(row => row.grmaterialdocnumber);
                if (aHasGRRows.length > 0) {
                    sap.m.MessageBox.warning("Reverse Issue not allowed: One or more selected rows already have GR Material Document Number.");
                    return;
                }

                // Check missing GI material doc
                const aInvalidRows1 = aSelectedRows.filter(row => !row.gicnfmaterialdocnumber);
                if (aInvalidRows1.length > 0) {
                    sap.m.MessageBox.error("Cannot reverse Issue: One or more selected rows are missing GI Material Document Number.");
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                try {

                    for (let i = 0; i < aSelectedRows.length; i++) {

                        const row = aSelectedRows[i];

                        const oPayload = {
                            Porderno: row.productionorderno,
                            ConfirmationGroup: row.gicnfconfirmationgroup,
                            ConfirmationCount: row.gicnfconfirmationcount
                        };

                        console.log(`📤 Sending Reverse Issue Payload for row ${i + 1}:`, oPayload);

                        // Wait for reverse API
                        const oData = await new Promise((resolve, reject) => {
                            oReverseModel.create("/ZDD_CNFISSUERSV1_WTRL", oPayload, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`✅ Reverse issue success for row ${i + 1}:`, oData);

                        const sUpdatePath = "/ZC_WEIGTHROLLER_PLAN('" + row.sap_uuid + "')";

                        const oUpdateEntry = {
                            gicnfmaterialdocnumber: "",
                            gicnfconfirmationgroup: "",
                            gicnfconfirmationcount: "",
                            gicnfmaterialdocyear: ""
                        };

                        // Wait for update
                        await new Promise((resolve, reject) => {
                            oTablePlanModel.update(sUpdatePath, oUpdateEntry, {
                                success: resolve,
                                error: reject
                            });
                        });

                        console.log(`🔄 Updated row ${i + 1}`);

                        // Update UI row
                        row.gicnfmaterialdocnumber = "";
                        row.gicnfconfirmationgroup = "";
                        row.gicnfconfirmationcount = "";
                        row.gicnfmaterialdocyear = "";

                    }

                    oTableModel.setProperty("/Samples", aRows);
                    oTableModel.refresh();

                    sap.m.MessageToast.show("Reverse issue process completed.");

                } catch (error) {
                    console.error("❌ Error during reverse issue:", error);
                    sap.m.MessageBox.error("Error occurred during Reverse Issue process.");
                } finally {
                    sap.ui.core.BusyIndicator.hide();
                }
            },

            //srikar

            onPrintPress: async function () {
                const oModel = this.getView().getModel("TabModel").getProperty("/Samples");
                const aSelectedRows = oModel.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                const { jsPDF } = window.jspdf;

                const loadImageAsBase64 = async (url) => {
                    const response = await fetch(url);
                    const blob = await response.blob();
                    return new Promise((resolve, reject) => {
                        const reader = new FileReader();
                        reader.onloadend = () => resolve(reader.result);
                        reader.onerror = reject;
                        reader.readAsDataURL(blob);
                    });
                };

                const svgLogoBase64 = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode.png"));
                const svgLogoBase64_ = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/barcode2.png"));
                const svgLogoBase64_Bando = await loadImageAsBase64(sap.ui.require.toUrl("bando/images/Bando.png"));

                const generateSectionHTML = (data) => {
                    const isEmpty = !data;
                    const lotbatchno = data?.lotbatchno || "";
                    // const batchweight = data?.batchweight || "";
                    const manufacturingdate = data?.manufacturingdate ? new Date(data.manufacturingdate).toLocaleDateString("en-GB") : "";
                    const productionordstartdate = data?.productionordstartdate ? new Date(data.productionordstartdate).toLocaleDateString("en-GB") : "";
                    const confirmedqty = data?.confirmedqty || "";
                    const compoundcode = data?.compoundcode || "";
                    // const operator = data?.operator || "";
                    const expirydate = data?.expirydate ? new Date(data.expirydate).toLocaleDateString("en-GB") : "";
                    // const inspector = data?.inspector || "";
                    const productionorderqty = data?.productionorderqty || "";
                    const productionorderno = data?.productionorderno || "";

                    return `
        <!DOCTYPE html>
        <html>
        <head>
          <style>
            * { box-sizing: border-box; }
            .row { display: flex; margin: 0; }
            .column1 { flex: 120%; padding: 6px; }
            .column2 { flex: 110%; padding-left: 30px; padding-top: 5px; padding-right: 5px; }
            table, th, td {
              border: 1px solid black;
              border-collapse: collapse;
              text-align: left;
              padding: 5px;
            }
            .center-align { text-align: center; }
          </style>
        </head>
        <body>
        <div class="row">
          <div class="column1">
            <table style="width:106%">
              <tr>
                <td colspan="7" style="text-align:left;">
                  <img src="${svgLogoBase64_Bando}" alt="Bando Logo" width="100" style="vertical-align: middle; margin-right: 10px;">
                  Mixing Process lot Guarantee Card
                </td>
              </tr>
              <tr>
                <td colspan="2">B I P L COMPOUND FORMULA</td>
                <td colspan="2">COMPOUND CODE</td>
                <td colspan="4" class="center-align">${compoundcode}</td>
              </tr>
              <tr>
                <td>Production ord No : ${productionorderno}</td>
                <td>Production Date :<br>${manufacturingdate}</td>
                <td>Lot No.</td>
                <td>${lotbatchno}</td>
                <td>EXPIRY DATE</td>
                <td>${expirydate}</td>
              </tr>
              <tr>
                <td>
                  <table>
                    <tr><td>Batch Wt. - kgs</td></tr>
                    <tr>
                      <td>
                        <table>
                          <tr><td>Spec.</td><td>${productionorderqty}</td></tr>
                          <tr><td>Actual</td><td>${confirmedqty}</td></tr>
                          <tr><td>Difference</td><td>${productionorderqty - confirmedqty}</td></tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
                <td colspan="4">
                  ${!isEmpty ? `<img src="${svgLogoBase64_}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td>Operator</td>
              </tr>
              <tr>
                <td colspan="2">
                  ${!isEmpty ? `<img src="${svgLogoBase64}" width="180" height="100">` : `<div style="height:100px;"></div>`}
                </td>
                <td colspan="4">
                  <table style="width:100%">
                    <tr>
                      <th class="center-align">Operator</th>
                      <th class="center-align">Inspector</th>
                    </tr>
                    <tr>
                      <td class="center-align"><br><br>${operator}<br><br></td>
                      <td class="center-align">${inspector}</td>
                    </tr>
                  </table>
                </td>
              </tr>
            </table>
          </div>
          <div class="column2">
            <table style="width:118%">
              <tr><td class="center-align">Compound Code<br><br><br>${compoundcode}</td></tr>
              <tr><td class="center-align">Lot No<br><br><br>${lotbatchno}</td></tr>
              <tr><td class="center-align">Production Date<br><br><br>${manufacturingdate}</td></tr>
              <tr><td class="center-align">Operator Sign<br><br><br><br><br><br>${operator}</td></tr>
            </table>
          </div>
        </div>
        </body>
        </html>
        `;
                };

                const doc = new jsPDF('l', 'mm', [297, 148.5]); // Half A4 landscape

                const promises = aSelectedRows.map((row, idx) => {
                    return new Promise((resolve, reject) => {
                        const htmlContent = generateSectionHTML(row);

                        const iframe = document.createElement('iframe');
                        iframe.style.position = 'fixed';
                        iframe.style.top = '-100000px';
                        document.body.appendChild(iframe);

                        const iframeDoc = iframe.contentDocument || iframe.contentWindow.document;
                        iframeDoc.open();
                        iframeDoc.write(htmlContent);
                        iframeDoc.close();

                        iframe.onload = () => {
                            html2canvas(iframeDoc.body, { scale: 3 }).then(canvas => {
                                const imgData = canvas.toDataURL('image/jpeg', 0.95);
                                doc.addImage(imgData, 'JPEG', 0, 0, 297, 148.5);
                                if (idx !== aSelectedRows.length - 1) {
                                    doc.addPage();
                                }
                                document.body.removeChild(iframe);
                                resolve();
                            }).catch(error => {
                                document.body.removeChild(iframe);
                                reject(error);
                            });
                        };
                    });
                });

                await Promise.all(promises);

                const blob = doc.output('blob');
                const pdfUrl = URL.createObjectURL(blob);

                if (!this._PDFViewer) {
                    this._PDFViewer = new sap.m.PDFViewer({
                        source: pdfUrl,
                        title: "WeightRoller Guarantee Card",
                        width: "auto"
                    });
                    jQuery.sap.addUrlWhitelist("blob");
                }

                this._PDFViewer.setSource(pdfUrl);
                this._PDFViewer.open();
            },











            // ==========================================================================================
            // ========================MATERIAL FRAGMENT=================================
            // ==========================================================================================
            // onMaterialFragmentOpenSimple: function (oEvent) {
            //     this._oInputField = oEvent.getSource();
            //     var oView = this.getView();

            //     if (!this._oMaterialDialog) {
            //         this._oMaterialDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
            //             this
            //         );
            //         oView.addDependent(this._oMaterialDialog);
            //     }

            //     var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
            //     var that = this;

            //     // Only fetch materials with ProductGroup = "38"
            //     oModel.read("/ZC_MATERIALMASTER1", {
            //         filters: [
            //             new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "WEIGHT ROLLER")
            //         ],
            //         success: function (oData) {
            //             var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
            //             that._oMaterialDialog.setModel(oJSON, "VHModel");
            //             that._oMaterialDialog.open();
            //         },
            //         error: function () {
            //             sap.m.MessageToast.show("Error fetching materials");
            //         }
            //     });
            // },

            // onMaterialSelected: function (oEvent) {
            //     var oSelectedItem = oEvent.getSource();
            //     var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

            //     if (this._oInputField) {
            //         // If input is inside a table row (has a binding context)
            //         var oRowCtx = this._oInputField.getBindingContext("TabModel");
            //         if (oRowCtx) {
            //             oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialcode", oCtx.Product);
            //             oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/materialname", oCtx.ProductName);
            //         } else {
            //             // If it’s a standalone input field (like yours)
            //             this.getView().getModel("TabModel").setProperty("/materialcode", oCtx.Product);
            //             this.getView().getModel("TabModel").setProperty("/materialname", oCtx.ProductName);

            //             // Update input field value directly
            //             this._oInputField.setValue(oCtx.Product);
            //         }
            //     }

            //     // this._oMaterialDialog.close();
            //     if (this._oMaterialDialog) {
            //         this._oMaterialDialog.close();
            //         this._oMaterialDialog.destroy();
            //         this._oMaterialDialog = null; // reset reference
            //     }
            // },


            // onMaterialSearch: function (oEvent) {
            //     var sValue = oEvent.getParameter("newValue");
            //     if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

            //     var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
            //     if (!oTable) return;

            //     var oBinding = oTable.getBinding("items");
            //     if (sValue) {
            //         var oFilter = new sap.ui.model.Filter({
            //             filters: [
            //                 new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
            //                 new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
            //             ],
            //             and: false
            //         });
            //         oBinding.filter([oFilter]);
            //     } else {
            //         oBinding.filter([]);
            //     }
            // },

            // onVHClose: function () {
            //     if (this._oMaterialDialog) {
            //         this._oMaterialDialog.close();
            //         this._oMaterialDialog.destroy();
            //         this._oMaterialDialog = null; // reset reference
            //     }
            // },


            onMaterialValueHelp: function (oEvent) {
                this._oMaterialInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);

                // Create fragment if not already created
                if (!this._oMaterialDialog) {
                    this._oMaterialDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                        this
                    );
                    oView.addDependent(this._oMaterialDialog);
                }

                var oModel = this.getView().getModel("ZSB_MATERIALMASTER1");
                var that = this;

                // Only fetch materials with ProductGroup = "MIXING"
                oModel.read("/ZC_MATERIALMASTER1", {
                    filters: [
                        new sap.ui.model.Filter("ExternalProductGroup", sap.ui.model.FilterOperator.EQ, "WEIGHT ROLLER")
                    ],
                    success: function (oData) {
                        // Create the model for the dialog
                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });
                        that._oMaterialDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected materials
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.materialmaster_simple",
                            "idMaterialTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedMaterials.forEach(material => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === material.Product) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedMaterials = [];

                        // Open the dialog after all processing is done
                        that._oMaterialDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Materials");
                    }
                });
            },

            onMaterialSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oMaterialDialog || !this._oMaterialDialog.isOpen()) return;

                var oTable = this._oMaterialDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },

            onMaterialSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedMaterials = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onMaterialConfirm: function () {
                if (!this._oTempSelectedMaterials) return;

                // Store selected materials
                this._selectedMaterials = this._oTempSelectedMaterials.slice();

                // Clear old tokens first
                this._oMaterialInputField.removeAllTokens();

                // Add tokens for selected materials
                this._selectedMaterials.forEach(material => {
                    var oToken = new sap.m.Token({
                        key: material.Product,
                        text: material.Product,
                        tooltip: material.ProductName // Optional: show description on hover
                    });
                    this._oMaterialInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null;
                }
            },

            onMaterialTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedMaterials = this._selectedMaterials.filter(
                        material => material.Product !== token.getKey()
                    );
                });
            },

            onMaterialChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);

                        // Also add to selected materials array
                        if (!this._selectedMaterials.find(m => m.Product === sValue)) {
                            this._selectedMaterials.push({
                                Product: sValue,
                                ProductName: sValue // You might want to fetch the actual description if available
                            });
                        }
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },

            onMaterialVHClose: function () {
                if (this._oMaterialDialog) {
                    this._oMaterialDialog.close();
                    this._oMaterialDialog.destroy();
                    this._oMaterialDialog = null; // reset reference
                }
            },


            // ==========================================================================================
            // ========================PRODUCTION ORDER NUMBER FRAGMENT=================================
            // ==========================================================================================

            // onProductionOrderValueHelp: function (oEvent) {
            //     this._oPOInputField = oEvent.getSource();
            //     var oView = this.getView();

            //     if (!this._oProductionOrderDialog) {
            //         this._oProductionOrderDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.ActualScreens.productionorder_simple",
            //             this
            //         );
            //         oView.addDependent(this._oProductionOrderDialog);
            //     }

            //     var oModel = this.getView().getModel("ZSB_WEIGHTROLLER_PLAN");
            //     var that = this;

            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         urlParameters: {
            //             "$top": 1000 // fetch top 1000 for scrollable table; can adjust
            //         },
            //         success: function (oData) {
            //             var oJSON = new sap.ui.model.json.JSONModel({ Orders: oData.results });
            //             that._oProductionOrderDialog.setModel(oJSON, "VHModel");
            //             that._oProductionOrderDialog.open();
            //         },
            //         error: function () {
            //             sap.m.MessageToast.show("Error fetching Production Orders");
            //         }
            //     });
            // },

            // onProductionOrderSelected: function (oEvent) {
            //     var oSelectedItem = oEvent.getSource();
            //     var oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

            //     if (this._oPOInputField) {
            //         // Set the selected Production Order No directly to the input field
            //         this._oPOInputField.setValue(oCtx.productionorderno);
            //     }

            //     // this._oProductionOrderDialog.close();
            //     if (this._oProductionOrderDialog) {
            //         this._oProductionOrderDialog.close();
            //         this._oProductionOrderDialog.destroy();
            //         this._oProductionOrderDialog = null; // reset reference
            //     }
            // },


            // onProductionOrderSearch: function (oEvent) {
            //     var sValue = oEvent.getParameter("newValue");
            //     if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

            //     var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
            //     if (!oTable) return;

            //     var oBinding = oTable.getBinding("items");
            //     if (sValue) {
            //         var oFilter = new sap.ui.model.Filter({
            //             filters: [
            //                 new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
            //                 new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
            //             ],
            //             and: false
            //         });
            //         oBinding.filter([oFilter]);
            //     } else {
            //         oBinding.filter([]);
            //     }
            // },

            // onProductionOrderVHClose: function () {
            //     if (this._oProductionOrderDialog) {
            //         this._oProductionOrderDialog.close();
            //         this._oProductionOrderDialog.destroy();
            //         this._oProductionOrderDialog = null; // reset reference
            //     }
            // },

            // onProductionOrderValueHelp: function (oEvent) {
            //     this._oPOInputField = oEvent.getSource();
            //     var oView = this.getView();

            //     // Show Busy Indicator when the dialog starts loading
            //     sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

            //     // Create fragment if not already created
            //     if (!this._oProductionOrderDialog) {
            //         this._oProductionOrderDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.ActualScreens.productionorder_simple",
            //             this
            //         );
            //         oView.addDependent(this._oProductionOrderDialog);
            //     }

            //     var oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
            //     var that = this;

            //     oModel.read("/ZC_WEIGTHROLLER_PLAN", {
            //         urlParameters: { "$top": 1000 }, // fetch top 1000 records
            //         success: function (oData) {
            //             var oJSON = new sap.ui.model.json.JSONModel({ Orders: oData.results });
            //             that._oProductionOrderDialog.setModel(oJSON, "VHModel");

            //             // Pre-select already selected orders
            //             var oTable = sap.ui.core.Fragment.byId(
            //                 "bando.view.CommonFragments.ActualScreens.productionorder_simple",
            //                 "idProductionOrderTable"
            //             );

            //             if (oTable) {
            //                 oTable.removeSelections();
            //                 that._selectedProductionOrders.forEach(po => {
            //                     var aItems = oTable.getItems();
            //                     aItems.forEach(item => {
            //                         if (item.getCells()[0].getText() === po.productionorderno) {
            //                             oTable.setSelectedItem(item, true);
            //                         }
            //                     });
            //                 });
            //             }

            //             // Temporary storage for current dialog session
            //             that._oTempSelectedOrders = [];

            //             // Open the dialog after all processing is done
            //             that._oProductionOrderDialog.open();

            //             // Hide Busy Indicator after the dialog is fully loaded
            //             sap.ui.core.BusyIndicator.hide();
            //         },
            //         error: function () {
            //             // Hide the busy indicator if there was an error
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Error fetching Production Orders");
            //         }
            //     });
            // },


            onProductionOrderValueHelp: function (oEvent) {
                this._oPOInputField = oEvent.getSource();
                var oView = this.getView();

                // Show Busy Indicator when the dialog starts loading
                sap.ui.core.BusyIndicator.show(0);  // Display the busy indicator (0ms delay)

                // Create fragment if not already created
                if (!this._oProductionOrderDialog) {
                    this._oProductionOrderDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                        this
                    );
                    oView.addDependent(this._oProductionOrderDialog);
                }

                var oModel = oView.getModel("ZSB_WEIGHTROLLER_PLAN");
                var that = this;

                oModel.read("/ZC_WEIGTHROLLER_PLAN", {
                    urlParameters: { "$top": 1000 }, // fetch top 1000 records
                    success: function (oData) {
                        // Filter out production orders where productionorderno is "0"
                        var aFilteredOrders = oData.results.filter(function (item) {
                            return item.productionorderno && item.productionorderno !== "0";
                        });

                        // Create the model for the dialog with the filtered results
                        var oJSON = new sap.ui.model.json.JSONModel({ Orders: aFilteredOrders });
                        that._oProductionOrderDialog.setModel(oJSON, "VHModel");

                        // Pre-select already selected orders
                        var oTable = sap.ui.core.Fragment.byId(
                            "bando.view.CommonFragments.ActualScreens.productionorder_simple",
                            "idProductionOrderTable"
                        );

                        if (oTable) {
                            oTable.removeSelections();
                            that._selectedProductionOrders.forEach(po => {
                                var aItems = oTable.getItems();
                                aItems.forEach(item => {
                                    if (item.getCells()[0].getText() === po.productionorderno) {
                                        oTable.setSelectedItem(item, true);
                                    }
                                });
                            });
                        }

                        // Temporary storage for current dialog session
                        that._oTempSelectedOrders = [];

                        // Open the dialog after all processing is done
                        that._oProductionOrderDialog.open();

                        // Hide Busy Indicator after the dialog is fully loaded
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        // Hide the busy indicator if there was an error
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Production Orders");
                    }
                });
            },


            onProductionOrderSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                if (!this._oProductionOrderDialog || !this._oProductionOrderDialog.isOpen()) return;

                var oTable = this._oProductionOrderDialog.getContent()[0].getItems()[1];
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");
                if (sValue) {
                    var oFilter = new sap.ui.model.Filter({
                        filters: [
                            new sap.ui.model.Filter("productionorderno", sap.ui.model.FilterOperator.Contains, sValue),
                            new sap.ui.model.Filter("description", sap.ui.model.FilterOperator.Contains, sValue)
                        ],
                        and: false
                    });
                    oBinding.filter([oFilter]);
                } else {
                    oBinding.filter([]);
                }
            },
            onProductionOrderSelectionChange: function (oEvent) {
                var oTable = oEvent.getSource();
                var aSelectedItems = oTable.getSelectedItems();
                this._oTempSelectedOrders = aSelectedItems.map(item => item.getBindingContext("VHModel").getObject());
            },

            onProductionOrderConfirm: function () {
                if (!this._oTempSelectedOrders) return;

                // Store selected orders
                this._selectedProductionOrders = this._oTempSelectedOrders.slice();

                // Clear old tokens first
                this._oPOInputField.removeAllTokens();

                // Add tokens for selected production orders
                this._selectedProductionOrders.forEach(po => {
                    var oToken = new sap.m.Token({
                        key: po.productionorderno,
                        text: po.productionorderno
                    });
                    this._oPOInputField.addToken(oToken);
                });

                // Close dialog
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null;
                }
            },

            onProductionOrderTokenUpdate: function (oEvent) {
                var aRemovedTokens = oEvent.getParameter("removedTokens");

                aRemovedTokens.forEach(token => {
                    this._selectedProductionOrders = this._selectedProductionOrders.filter(
                        o => o.productionorderno !== token.getKey()
                    );
                });
            },
            onProductionOrderVHClose: function () {
                if (this._oProductionOrderDialog) {
                    this._oProductionOrderDialog.close();
                    this._oProductionOrderDialog.destroy();
                    this._oProductionOrderDialog = null; // reset reference
                }
            },

            onProductionOrderChange: function (oEvent) {
                const oInput = oEvent.getSource();  // Get the MultiInput field
                const sValue = oInput.getValue().trim();  // Get the typed value

                if (sValue) {
                    // Get current tokens in the MultiInput
                    const aTokens = oInput.getTokens().map(t => t.getKey());

                    // Only add the token if it doesn't already exist
                    if (!aTokens.includes(sValue)) {
                        const oToken = new sap.m.Token({
                            key: sValue,
                            text: sValue // Display the same value as text for now
                        });

                        // Add the token to the MultiInput field
                        oInput.addToken(oToken);
                    }
                }

                // Optionally clear the input field after adding the token
                oInput.setValue("");  // Clear the input after adding
            },

        });
    }
);