sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/export/Spreadsheet",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment"
], function (Controller, JSONModel, MessageToast, MessageBox, Spreadsheet, Filter, FilterOperator, Fragment) {
    "use strict";

    return Controller.extend("bando.controller.RejectCodeViews.RejectCodeViews", {

        // The technical name of your EntitySet in S/4HANA
        _sEntitySet: "/ZC_Reject_code",

        onInit: function () {
            // 1. Local JSON model for the main UI Table
            var oDefectModel = new JSONModel({ defects: [] });
            this.getView().setModel(oDefectModel, "defectModel");

            // 2. Initialize the NAMED OData Model from manifest.json
            this.oRejectModel = this.getOwnerComponent().getModel("ZSB_REJECT_CODE");

            if (!this.oRejectModel) {
                MessageBox.error("Model 'ZSB_REJECT_CODE' not found. Check manifest.json.");
            }
        },

        // ============================================================
        // MAIN PAGE LOGIC (GO BUTTON)
        // ============================================================

        OnGoItemPage: function () {
            var oMultiInput = this.byId("productInput");
            var aTokens = oMultiInput.getTokens();
            var aFilters = [];

            if (aTokens.length > 0) {
                var aTokenFilters = aTokens.map(function (oToken) {
                    return new Filter("reject_type", FilterOperator.EQ, oToken.getKey());
                });
                // Combine multiple tokens with OR logic
                aFilters.push(new Filter({ filters: aTokenFilters, and: false }));
            }

            this._fetchOData(aFilters);
        },

        _fetchOData: function (aFilters) {
            var oView = this.getView();
            var oJSONModel = oView.getModel("defectModel");

            oView.setBusy(true);

            this.oRejectModel.read(this._sEntitySet, {
                filters: aFilters || [],
                urlParameters: {
                    "$orderby": "reject_code asc"
                },
                success: function (oData) {
                    oView.setBusy(false);
                    var aResults = oData.results || [];

                    // Sort results logically (1, 2, 10 instead of 1, 10, 2)
                    aResults.sort(function (a, b) {
                        return a.reject_code.localeCompare(b.reject_code, undefined, {
                            numeric: true,
                            sensitivity: 'base'
                        });
                    });

                    oJSONModel.setProperty("/defects", aResults);
                }.bind(this),
                error: function (oError) {
                    oView.setBusy(false);
                    MessageBox.error("Failed to fetch data from S/4HANA.");
                }.bind(this)
            });
        },

        // ============================================================
        // VALUE HELP DIALOG (FRAGMENT)
        // ============================================================

        onValueHelpRequest: function (oEvent) {
            this._oMultiInput = oEvent.getSource();
            
            // START Busy Indicator (Global)
            sap.ui.core.BusyIndicator.show(0);

            // Fetch unique types for the selection list
            this.oRejectModel.read(this._sEntitySet, {
                urlParameters: { "$top": 1000 },
                success: function (oData) {
                    // Note: We do NOT hide the busy indicator yet!
                    var aUnique = oData.results.filter((v, i, a) =>
                        i === a.findIndex((t) => (t.reject_type === v.reject_type))
                    );

                    this._openValueHelpDialog(aUnique);
                }.bind(this),
                error: function () {
                    sap.ui.core.BusyIndicator.hide();
                    MessageToast.show("Error fetching Reject Types.");
                }
            });
        },

        _openValueHelpDialog: function (aData) {
            var oView = this.getView();
            this.oVHDModel = new JSONModel({ Datas: aData });

            // Load Fragment using Singleton pattern
            if (!this._pValueHelpDialog) {
                this._pValueHelpDialog = Fragment.load({
                    id: oView.getId(),
                    name: "bando.view.RejectCodeViews.ValueHelpDialog",
                    controller: this
                }).then(function (oDialog) {
                    oView.addDependent(oDialog);
                    return oDialog;
                });
            }

            this._pValueHelpDialog.then(function (oDialog) {
                this._oVHD = oDialog;
                oDialog.setModel(this.oVHDModel, "oJSONModelVHD");

                oDialog.getTableAsync().then(function (oTable) {
                    if (oTable.bindRows) {
                        oTable.removeAllColumns();
                        oTable.addColumn(new sap.ui.table.Column({
                            label: new sap.m.Label({ text: "Reject Type" }),
                            template: new sap.m.Text({ text: "{oJSONModelVHD>reject_type}" })
                        }));
                        oTable.bindAggregation("rows", "oJSONModelVHD>/Datas");
                    }

                    // Reset internal search field
                    var oSearchField = this.byId("idVHD_SearchField");
                    if (oSearchField) oSearchField.setValue("");

                    // OPEN DIALOG
                    oDialog.open();

                    // FINALLY HIDE Busy Indicator once fragment is ready and open
                    sap.ui.core.BusyIndicator.hide();

                }.bind(this));
            }.bind(this)).catch(function() {
                sap.ui.core.BusyIndicator.hide();
            });
        },

        onFilterBarSearch: function (oEvent) {
            var sQuery = this.byId("idVHD_SearchField").getValue();
            var aFilters = [];

            if (sQuery && sQuery.length > 0) {
                aFilters.push(new Filter("reject_type", FilterOperator.Contains, sQuery));
            }

            this._oVHD.getTableAsync().then(function (oTable) {
                var oBinding = oTable.getBinding("rows");
                if (oBinding) oBinding.filter(aFilters);
            });
        },

        onValueHelpOkPress: function (oEvent) {
            var aTokens = oEvent.getParameter("tokens");
            this._oMultiInput.setTokens(aTokens);
            this._oVHD.close();
        },

        onValueHelpCancelPress: function () { this._oVHD.close(); },
        onValueHelpAfterClose: function () { /* Fragment Cleanup */ },

        // ============================================================
        // EXCEL EXPORT
        // ============================================================

        onDownload: function () {
            var aData = this.getView().getModel("defectModel").getProperty("/defects") || [];

            if (aData.length === 0) {
                MessageToast.show("No data to export.");
                return;
            }

            var aCols = [
                { label: "Reject Code", property: "reject_code", type: "string" },
                { label: "Description", property: "reject_des", type: "string" },
                { label: "Reject Type", property: "reject_type", type: "string" }
            ];

            var oSettings = {
                workbook: { columns: aCols, context: { title: "Reject Codes Report" } },
                dataSource: aData,
                fileName: "Reject_Codes_Export.xlsx",
                worker: false
            };

            var oSheet = new Spreadsheet(oSettings);
            oSheet.build().finally(function () {
                oSheet.destroy();
            });
        }
    });
});