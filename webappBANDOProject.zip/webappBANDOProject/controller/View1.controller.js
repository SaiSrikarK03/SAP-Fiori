// sap.ui.define([
//     "sap/ui/core/mvc/Controller"
// ], (Controller) => {
//     "use strict";

//     return Controller.extend("bando.controller.View1", {
//         onInit() {
            
//         }
//     });
// });

sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
  "use strict";

  return Controller.extend("bando.controller.View1", {

    onInit: function () {
      // Set background image model
      const sBackgroundImage = sap.ui.require.toUrl("bando/images/BandoDashboard.png");
      this.getView().setModel(new JSONModel({ 
        backgroundImage: sBackgroundImage 
      }), "backgroundModel");
    },

    onAfterRendering: function () {
      // Apply background image styles after rendering
      this._applyBackgroundStyle();
    },

    _applyBackgroundStyle: function () {
      const oPage = this.getView().byId("page");
      if (oPage) {
        const oPageDom = oPage.getDomRef();
        if (oPageDom) {
          oPageDom.style.backgroundImage = "url('" + 
            this.getView().getModel("backgroundModel").getProperty("/backgroundImage") + "')";
          oPageDom.style.backgroundSize = "cover";
          oPageDom.style.backgroundPosition = "center";
          oPageDom.style.backgroundRepeat = "no-repeat";
        }
      }
    }

  });
});