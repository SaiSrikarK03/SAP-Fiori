sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/IconPool",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator"
], function (Controller, IconPool, JSONModel, MessageBox, Filter, FilterOperator) {
  "use strict";

  return Controller.extend("bando.controller.App", {

    onInit: function () {
      this.oSplitApp = this.getView().byId("splitApp");

      // Register fonts
      IconPool.registerFont({
        fontFamily: "SAP-icons-TNT",
        fontURI: sap.ui.require.toUrl("sap/tnt/themes/base/fonts/")
      });

      IconPool.registerFont({
        fontFamily: "BusinessSuiteInAppSymbols",
        fontURI: sap.ui.require.toUrl("sap/ushell/themes/base/fonts/")
      });

      // Logo model
      const sLogo = sap.ui.require.toUrl("bando/images/logo.png");
      this.getView().setModel(new JSONModel({ svgLogo: sLogo }));

      // App-level model
      this.JSonModelTransApp = new JSONModel({ Datas: [] });
      this.getView().setModel(this.JSonModelTransApp, "JSonModelTransApp");

      // Attach route match
      this.getOwnerComponent().getRouter().attachRouteMatched(this._onRouteMatched, this);


      // Properties for role handling
      this._aUserRoles = null;          // cached list of role IDs
      this._oRolesPromise = null;       // promise for ongoing fetch
    },


    // Mapping of screen keys to business role IDs
    _mRoleMapping: {
      // Home - Dashboard
      "ProductionOrdersDashboard" : "ZF_BAN_LOT_AUTO_ROLE",
      // Mixing
      "MixingPlan": "ZF_MIXING_PLAN_BANDO",
      "MixingActual": "ZF_MIXING_ACTUAL_BANDO",
      "MixingPlanReport": "ZF_MIXING_PLAN_REPORT_BANDO",
      "MixingActualReport": "ZF_MIXING_ACTUAL_REPORT_BANDO",

      // Calendering
      "CalenderingPlan": "ZF_CALENDERING_PLAN_BANDO",
      "CalenderingActual": "ZF_CALENDERING_ACTUAL_BANDO",
      "CalenderingActualReport": "ZF_CALENDERING_ACTUAL_REPORT_BANDO",
      "CalenderingPlanReport": "ZF_CALENDERING_PLAN_REPORT_BANDO",

      // Jointing
      "JointingPlan": "ZF_JOINTING_PLAN_BANDO",
      "JointingActual": "ZF_JOINTING_ACTUAL_BANDO",
      "JointingActualReport": "ZF_JOINTING_ACTUAL_REPORT_BANDO",
      "JointingPlanReport": "ZF_JOINTING_PLAN_REPORT_BANDO",


      // FG Process
      "FGProcessPlan": "ZF_FG_PROCESS_PLAN_BANDO",
      "FGProcessActual": "ZF_FG_PROCESS_ACTUAL_BANDO",
      "BeltFGActualReport": "ZF_FG_PROCESS_ACTUAL_REPORT_BANDO",
      "BeltFGPlanReport": "ZF_FG_PROCESS_PLAN_REPORT_BANDO",


      // Moulding SFG
      "MouldingPlan": "ZF_MOULDING_SFG_PLAN_BANDO",
      "MouldingActual": "ZF_MOULDING_SFG_ACTUAL_BANDO",
      "MouldingActualReport": "ZF_MOULDING_ACTUAL_REPORT_BANDO",
      "MouldingPlanReport": "ZF_MOULDING_PLAN_REPORT_BANDO",

      // Weight Roller
      "WeightRollerPlan": "ZF_WEIGHT_ROLLER_PLAN_BANDO",
      "WeightRollerActual": "ZF_WEIGHT_ROLLER_ACTUAL_BANDO",
      "WeightRollerActualReport": "ZF_WEIGHT_ROLLER_ACTUAL_REPORT_BANDO",
      "WeightRollerPlanReport": "ZF_WEIGHT_ROLLER_PLAN_REPORT_BANDO",

      // Gear Process
      "GearProcessPlan": "ZF_GEAR_PROCESS_PLAN_BANDO",
      "GearProcessActual": "ZF_GEAR_PROCESS_ACTUAL_BANDO",
      "GearProcessActualReport": "ZF_GEAR_PROCESS_ACTUAL_REPORT_BANDO",
      "GearProcessPlanReport": "ZF_GEAR_PROCESS_PLAN_REPORT_BANDO",

      // Kit Process
      "KitProcessPlan": "ZF_KIT_PROCESS_PLAN_BANDO",
      "KitProcessActual": "ZF_KIT_PROCESS_ACTUAL_BANDO",
      "KitProcessActualReport": "ZF_KIT_PROCESS_ACTUAL_REPORT_BANDO",
      "KitProcessPlanReport": "ZF_KIT_PROCESS_PLAN_REPORT_BANDO",

      // Moulding FG
      "MouldingFGPlan": "ZF_MOULDING_FG_PLAN_BANDO",
      "MouldingFGActual": "ZF_MOULDING_FG_ACTUAL_BANDO",
      "MouldingFGActualReport": "ZF_MOULDING_FG_ACTUAL_REPORT_BANDO",
      "MouldingFGPlanReport": "ZF_MOULDING_FG_PLAN_REPORT_BANDO",

      // Transfer Posting
      "stock_transfer_request": "ZF_STOCK_TRANSFER_REQUEST_BANDO_ROLE",
      "stock_transfer_post": "ZF_STOCK_TRANSFER_POST_BANDO_ROLE",

      // Direct Transfer
      "direct_stock_transfer": "ZF_DIRECT_STOCK_TRANSFER_BANDO_ROLE",

      // Production Report
      "BeltFG": "ZF_PRODUCTION_REPORT_BANDO_ROLE",

      // Reject Code
      "RejectCodeViews": "ZF_REJECT_CODE_VIEW_BANDO_ROLE"
    },


    onAfterRendering: function () {
      const oMaster = this.oSplitApp.getAggregation("_navMaster");
      oMaster.addStyleClass("masterStyleAfter");
    },

    onBeforeRendering: function () {
      var oUserInfo = sap.ushell.Container.getService("UserInfo");
      this.sUserId = oUserInfo.getId();         // e.g., "S4HANA_DEV_USER"
      console.log("user id:", this.sUserId)
    },


    onClick: function () {
      const oSideNav = this.byId("sideNavigation");
      const bExpanded = oSideNav.getExpanded();
      const oMaster = this.oSplitApp.getAggregation("_navMaster");

      oSideNav.setExpanded(!bExpanded);
      this.byId("SideBarHeaderLogo").setVisible(!bExpanded);
      this.byId("SideBarHeaderCName").setVisible(!bExpanded);

      oMaster.toggleStyleClass("masterStyleAfter", !bExpanded);
      oMaster.toggleStyleClass("masterStyle", bExpanded);
    },


    onNavBtn1: function (oEvent) {
      const sKey = oEvent.getParameter("item").getKey();
      this.getOwnerComponent().getRouter().navTo(sKey);
    },

    onNavBtn: function (oEvent) {

      var that = this;
      var sKey = oEvent.getParameter("item").getKey();

      // Ensure user ID exists
      if (!this.sUserId) {
        try {
          var oUserInfo = sap.ushell.Container.getService("UserInfo");
          this.sUserId = oUserInfo ? oUserInfo.getId() : null;
        } catch (e) {
          this.sUserId = null;
        }
      }

      console.log("Current User:", this.sUserId);

      // DEFAULT_USER bypass - grant access to all screens
      if (this.sUserId === "DEFAULT_USER") {
        console.log("DEFAULT_USER detected. Bypassing role validation.");
        this.getOwnerComponent().getRouter().navTo(sKey);
        return;
      }

      var sRole = this._mRoleMapping[sKey];

      console.log("=== Role Check Started ===");
      console.log("Screen Key:", sKey);
      console.log("Required Role:", sRole);

      function showError(msg) {
        MessageBox.error(msg);
      }

      if (!sRole) {
        showError("No access for user " + this.sUserId + " to screen " + sKey + " (no role defined)");
        return;
      }

      // Ensure user ID is available
      if (!this.sUserId) {
        console.log("User ID not set, trying to fetch from UserInfo service...");
        try {
          var oUserInfo = sap.ushell.Container.getService("UserInfo");
          this.sUserId = oUserInfo ? oUserInfo.getId() : null;
        } catch (e) {
          console.log("Error fetching UserInfo:", e);
          this.sUserId = null;
        }
        if (!this.sUserId) {
          console.log("User ID still not available.");
          showError("User ID not available");
          return;
        }
      }
      console.log("Current User ID:", this.sUserId);

      // Get the OData model
      console.log("Checking role assignment via OData...");
      var oModel = this.getOwnerComponent().getModel("ZSB_USERBUSINESSROLE_SRB");
      if (!oModel) {
        console.log("OData model 'ZSB_USERBUSINESSROLE_SRB' not found!");
        showError("User Business Role model not found. Please check the model name in manifest.json.");
        return;
      }

      // Build filter: UserID eq '<userId>' and BusinessRole eq '<role>'
      var oFilterUser = new Filter("UserID", FilterOperator.EQ, this.sUserId);
      var oFilterRole = new Filter("BusinessRole", FilterOperator.EQ, sRole);
      var oFilter = new Filter([oFilterUser, oFilterRole], true); // true = AND

      console.log("OData filter:", "UserID =", this.sUserId, "AND BusinessRole =", sRole);

      // Execute read request with the combined filter
      oModel.read("/ZCE_USERBUSINESSROLE", {
        filters: [oFilter],
        success: function (oData) {
          console.log("OData read successful. Number of records returned:", oData.results.length);
          if (oData.results.length > 0) {
            console.log("Access GRANTED - role found for user.");
            that.getOwnerComponent().getRouter().navTo(sKey);
          } else {
            console.log("Access DENIED - role not found for user.");
            showError("No access for user " + that.sUserId + " to screen " + sKey);
          }
        },
        error: function (oError) {
          console.log("OData read error:", oError);
          showError("Error checking access: " + (oError.message || oError));
        }
      });
    },


    _onRouteMatched: function (oEvent) {
      const sRouteName = oEvent.getParameter("name");
      const oNavList = this.byId("sideNavigation").getItem(); // Top-level NavigationList
      const oItem = this._findItemByKey(oNavList, sRouteName);

      if (oItem) {
        // oItem.setSelected(true);
        this.byId("sideNavigation").getItem().setSelectedKey(sRouteName);

        this._expandParentGroups(oItem);
      }
    },


    _findItemByKey: function (oNavList, sKey) {
      // Recursive search function to find item by key
      const fnSearch = function (aItems) {
        for (let i = 0; i < aItems.length; i++) {
          const oItem = aItems[i];
          if (oItem.getKey && oItem.getKey() === sKey) {
            return oItem;
          }
          if (oItem.getItems && oItem.getItems().length > 0) {
            const oFound = fnSearch(oItem.getItems());
            if (oFound) return oFound;
          }
        }
        return null;
      };

      return fnSearch(oNavList.getItems());
    },


    _expandParentGroups: function (oItem) {
      let oParent = oItem.getParent();
      while (oParent && oParent.setExpanded) {
        oParent.setExpanded(true);
        oParent = oParent.getParent();
      }
    }

  });
});
