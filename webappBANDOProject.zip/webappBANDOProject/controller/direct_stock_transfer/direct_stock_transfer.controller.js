sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/core/IconPool",
        "sap/ui/model/json/JSONModel",
        "sap/ui/core/Component",
        "sap/ui/core/UIComponent",
        "sap/m/routing/Router",
        "sap/m/MessageBox",
        "sap/ui/export/Spreadsheet",
        "sap/m/PDFViewer",

        "bando/util/importfile/importexcelfile",
        "bando/util/pdf-lib/pdf-lib.min"
    ],
    function (BaseController, IconPool, JSONModel, Component, UIComponent, Router, MessageBox, Spreadsheet, importexcelfile, PDFLibjs) {
        "use strict";

        return BaseController.extend("bando.controller.direct_stock_transfer.direct_stock_transfer", {

            onInit: function () {


                var TabModel = new sap.ui.model.json.JSONModel({
                    Samples: [

                    ]

                });

                this.getView().setModel(TabModel, "TabModel");

                var Tab_SelectAll = new sap.ui.model.json.JSONModel({
                    Samples: {
                        selectall: false
                    }

                });

                this.getView().setModel(Tab_SelectAll, "Tab_SelectAll");



                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("direct_stock_transfer").attachMatched(this._onRouteMatched, this);

            },

            _onRouteMatched: function () {


                // Optionally: clear or re-fetch table data
                this.getView().getModel("TabModel").setProperty("/Samples", []);
                this.HeaderModel = new sap.ui.model.json.JSONModel({

                    HeaderData: {
                        idPostingDate: ""

                    }
                })

                this.getView().setModel(this.HeaderModel, "HeaderModel");
            },

            onBeforeRendering: function () {
                var oUserInfo = sap.ushell.Container.getService("UserInfo");

                // User ID (e.g. "I123456")
                this.sUserId = oUserInfo.getId();

                // Full name (e.g. "John Doe")
                this.sUserFullName = oUserInfo.getFullName();

                // First name
                this.sUserFirstName = oUserInfo.getFirstName();

                // Last name
                this.sUserLastName = oUserInfo.getLastName();

                // Email address
                this.sUserEmail = oUserInfo.getEmail();

                console.log("User ID:", this.sUserId);
                console.log("Full Name:", this.sUserFullName);
            },

            onSelectAll: function (oEvent) {
                const bSelected = oEvent.getParameter("selected");
                const oTableModel = this.getView().getModel("TabModel");
                const aRows = oTableModel.getProperty("/Samples") || [];

                aRows.forEach(row => {
                    row.__selected = bSelected;
                });

                oTableModel.setProperty("/Samples", aRows);
            },


            // GoStockReqTableOpen: function (callback) {
            //     const oView = this.getView();
            //     const oModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
            //     const oTabModel = oView.getModel("TabModel");

            //     const oDateRange = oView.byId("idPostedDateRange");
            //     const oStartDate = oDateRange.getDateValue();
            //     const oEndDate = oDateRange.getSecondDateValue();

            //     if (!oStartDate && !oEndDate) {
            //         sap.m.MessageBox.error("Please select a date range.");
            //         if (callback && typeof callback === 'function') callback([]);
            //         return;
            //     }

            //     const aFilters = [];
            //     let sStartDate = null;
            //     let sEndDate = null;
            //     const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });

            //     if (oStartDate && oEndDate) {
            //         sStartDate = oDateFormat.format(oStartDate);
            //         sEndDate = oDateFormat.format(oEndDate);
            //     } else if (oStartDate) {
            //         sStartDate = oDateFormat.format(oStartDate);
            //         sEndDate = sStartDate;
            //     } else if (oEndDate) {
            //         sEndDate = oDateFormat.format(oEndDate);
            //         sStartDate = sEndDate;
            //     }

            //     aFilters.push(new sap.ui.model.Filter({
            //         path: "postingdate",
            //         operator: sap.ui.model.FilterOperator.BT,
            //         value1: sStartDate,
            //         value2: sEndDate
            //     }));

            //     const oDynamicPage = this.byId("dynamicpageDirectStockScreen");
            //     if (oDynamicPage) oDynamicPage.setShowFooter(true);

            //     sap.ui.core.BusyIndicator.show(0);

            //     oModel.read("/ZC_DIRECT_TRANSFER_POSTING", {
            //         filters: aFilters,
            //         urlParameters: { "$top": 10000 },
            //         success: function (oData) {
            //             sap.ui.core.BusyIndicator.hide();
            //             const aResults = oData.results || [];

            //             // If a callback is provided, pass the raw data back (don't update the table yet)
            //             if (callback && typeof callback === 'function') {
            //                 callback(aResults);
            //                 return;
            //             }

            //             // Otherwise, update the table directly (used for "All" or initial load)
            //             oTabModel.setProperty("/Samples", aResults);
            //             oView.byId("idDirectStockTransferTable").setVisible(true);

            //             // Re‑initialize the select‑all model
            //             const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
            //             oView.setModel(Tab_SelectAll, "Tab_SelectAll");
            //         }.bind(this),
            //         error: function (oError) {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageBox.error("Error fetching data. Please try again.");
            //             console.error("OData read error:", oError);
            //             if (callback && typeof callback === 'function') callback([]);
            //         }
            //     });
            // },

            // Store the current request numbers
            _aRequestNumbers: [],

            // Called when tokens are updated (added/removed)
            onRequestNumberTokenUpdate: function (oEvent) {
                const oMultiInput = oEvent.getSource();
                const aTokens = oMultiInput.getTokens() || [];
                this._aRequestNumbers = aTokens.map(oToken => oToken.getText().trim()).filter(s => s !== "");
            },

            // Called when the input value changes (for manual entry)
            onRequestNumberChange: function (oEvent) {
                const oMultiInput = oEvent.getSource();
                const sValue = oMultiInput.getValue().trim();

                // If user typed a value and pressed Enter, add as token
                if (sValue !== "") {
                    // Check if token already exists
                    const aExistingTokens = oMultiInput.getTokens() || [];
                    const bExists = aExistingTokens.some(oToken => oToken.getText() === sValue);

                    if (!bExists) {
                        const oToken = new sap.m.Token({ text: sValue });
                        oMultiInput.addToken(oToken);
                        oMultiInput.setValue(""); // Clear input after adding token
                    }
                }

                // Update stored array
                const aTokens = oMultiInput.getTokens() || [];
                this._aRequestNumbers = aTokens.map(oToken => oToken.getText().trim()).filter(s => s !== "");
            },

            // Helper method to clear all tokens (if needed)
            clearRequestNumberTokens: function () {
                const oMultiInput = this.getView().byId("idRequestNumberFilter");
                if (oMultiInput) {
                    oMultiInput.destroyTokens();
                    this._aRequestNumbers = [];
                }
            },
            GoStockReqTableOpen: function (callback) {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
                const oTabModel = oView.getModel("TabModel");

                // --- Get date range ---
                const oDateRange = oView.byId("idPostedDateRange");
                const oStartDate = oDateRange.getDateValue();
                const oEndDate = oDateRange.getSecondDateValue();

                // --- Get request numbers from stored array ---
                let aRequestNumbers = this._aRequestNumbers || [];

                // If stored array is empty, try to get tokens directly (as backup)
                if (aRequestNumbers.length === 0) {
                    const oMultiInput = oView.byId("idRequestNumberFilter");
                    if (oMultiInput) {
                        const aTokens = oMultiInput.getTokens() || [];
                        aRequestNumbers = aTokens.map(oToken => oToken.getText().trim()).filter(s => s !== "");
                        this._aRequestNumbers = aRequestNumbers; // Store for future use
                    }
                }

                // --- Build filters ---
                const aFilters = [];

                // 1. Date range filter (if provided)
                if (oStartDate || oEndDate) {
                    const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "yyyy-MM-dd" });
                    let sStartDate = oStartDate ? oDateFormat.format(oStartDate) : null;
                    let sEndDate = oEndDate ? oDateFormat.format(oEndDate) : null;

                    if (sStartDate && !sEndDate) sEndDate = sStartDate;
                    if (!sStartDate && sEndDate) sStartDate = sEndDate;

                    aFilters.push(new sap.ui.model.Filter({
                        path: "postingdate",
                        operator: sap.ui.model.FilterOperator.BT,
                        value1: sStartDate,
                        value2: sEndDate
                    }));
                }

                // 2. Request number filter(s) – OR logic among multiple numbers
                if (aRequestNumbers.length > 0) {
                    // Create an EQ filter for each number
                    const aRequestFilters = aRequestNumbers.map(sNumber =>
                        new sap.ui.model.Filter({
                            path: "requestnumber",
                            operator: sap.ui.model.FilterOperator.EQ,
                            value1: sNumber
                        })
                    );

                    // Combine them with OR (and: false)
                    aFilters.push(new sap.ui.model.Filter({
                        filters: aRequestFilters,
                        and: false
                    }));
                }

                // --- Validation: at least one filter must exist ---
                if (aFilters.length === 0) {
                    sap.m.MessageBox.error("Please provide at least a date range or a DP number.");
                    if (callback && typeof callback === 'function') callback([]);
                    return;
                }

                // --- UI preparation ---
                const oDynamicPage = this.byId("dynamicpageDirectStockScreen");
                if (oDynamicPage) oDynamicPage.setShowFooter(true);

                sap.ui.core.BusyIndicator.show(0);

                // --- OData read with combined filters ---
                oModel.read("/ZC_DIRECT_TRANSFER_POSTING", {
                    filters: aFilters,
                    urlParameters: { "$top": 10000 },
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();

                        const aResults = oData.results || [];

                        // Sort Material Document Number in ascending order
                        aResults.sort(function (a, b) {
                            const numA = parseInt(a.materialdocumentno, 10) || 0;
                            const numB = parseInt(b.materialdocumentno, 10) || 0;

                            return numA - numB;
                        });

                        if (callback && typeof callback === 'function') {
                            callback(aResults);
                            return;
                        }

                        // Set sorted data into TableModel
                        oTabModel.setProperty("/Samples", aResults);

                        oView.byId("idDirectStockTransferTable").setVisible(true);

                        // Re-initialize select-all model
                        const Tab_SelectAll = new sap.ui.model.json.JSONModel({
                            Samples: {
                                selectall: false
                            }
                        });

                        oView.setModel(Tab_SelectAll, "Tab_SelectAll");
                    }.bind(this),
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageBox.error("Error fetching data. Please try again.");
                        console.error("OData read error:", oError);
                        if (callback && typeof callback === 'function') callback([]);
                    }
                });
            },

            applyMatDocFilterClick: function () {
                const oView = this.getView();
                const oCombo = oView.byId("comboMatDocStatusFilter");
                const sStatus = oCombo.getSelectedKey(); // "", "COMPLETED", "NOT_COMPLETED"

                // If "All", just reload normally (no callback → direct table update)
                if (!sStatus || sStatus === "") {
                    this.GoStockReqTableOpen(); // no callback = normal refresh
                    return;
                }

                sap.ui.core.BusyIndicator.show(0);

                // Fetch fresh data with main filters, then apply status filter
                this.GoStockReqTableOpen(function (aRawData) {
                    sap.ui.core.BusyIndicator.hide();

                    if (!aRawData || aRawData.length === 0) {
                        sap.m.MessageToast.show("No data available to filter");
                        return;
                    }

                    // Apply completion filter inline
                    const aFiltered = aRawData.filter(function (item) {
                        const sMatDocNo = item.materialdocumentno;
                        let isCompleted = false;
                        if (sMatDocNo && typeof sMatDocNo === "string") {
                            const trimmed = sMatDocNo.trim();
                            if (trimmed !== "" && !/^0+$/.test(trimmed)) {
                                isCompleted = true;
                            }
                        }

                        if (sStatus === "COMPLETED") {
                            return isCompleted === true;
                        } else { // NOT_COMPLETED
                            return isCompleted === false;
                        }
                    });

                    // Update the table model with filtered data
                    const oTabModel = oView.getModel("TabModel");
                    oTabModel.setProperty("/Samples", aFiltered);

                    // Ensure the table is visible and re‑initialize select‑all model
                    oView.byId("idDirectStockTransferTable").setVisible(true);
                    const Tab_SelectAll = new sap.ui.model.json.JSONModel({ Samples: { selectall: false } });
                    oView.setModel(Tab_SelectAll, "Tab_SelectAll");

                    sap.m.MessageToast.show(`Filtered to ${aFiltered.length} records (${sStatus.toLowerCase()})`);
                });
            },

            onAddRow: function () {
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                // Create a blank row (add fields as required)
                var oNewRow = {
                    sap_uuid: "",
                    material: "",
                    description: "",
                    uom: "",
                    fromplant: "1200",
                    fromstorageloc: "",  // Changed from fromstorage
                    frombatch: "",  // Added new field
                    toplant: "1200",
                    tostoragelocation: "",  // Changed from tostorage
                    // tobatch: "",  // Added new field
                    vendorbatch: "",  // Added new field
                    qty: "",  // Added new field
                    postingdate: "",  // Added new field
                    __selected: false
                };

                aData.push(oNewRow);
                oModel.setProperty("/Samples", aData);
            },

            onRemoveRow: function () {
                var oModel = this.getView().getModel("TabModel");
                var aData = oModel.getProperty("/Samples") || [];

                var aRowsToKeep = [];
                var bAnyDeleted = false;
                var bAnyBlocked = false;

                aData.forEach(function (row) {
                    if (row.__selected) {
                        if (!row.sap_uuid || row.sap_uuid.trim() === "") {
                            // Deletable row — skip adding to keep list
                            bAnyDeleted = true;
                        } else {
                            // Selected but not deletable — keep it
                            aRowsToKeep.push(row);
                            bAnyBlocked = true;
                        }
                    } else {
                        // Not selected — keep it
                        aRowsToKeep.push(row);
                    }
                });

                oModel.setProperty("/Samples", aRowsToKeep);

                // Show appropriate message
                if (bAnyDeleted && bAnyBlocked) {
                    sap.m.MessageBox.information("Some selected rows were deleted. Others could not be deleted because they were fetched from the backend.");
                } else if (bAnyBlocked && !bAnyDeleted) {
                    sap.m.MessageBox.warning("Only unsaved rows can be removed. Rows fetched from the backend cannot be deleted.");
                } else if (bAnyDeleted) {
                    sap.m.MessageBox.success("Selected rows removed successfully.");
                } else {
                    sap.m.MessageBox.information("No rows were selected for deletion.");
                }
            },









            onNumericLiveChange: function (oEvent) {
                var sValue = oEvent.getParameter("value");

                // Allow digits, commas, and periods
                var sCleanedValue = sValue.replace(/[^\d.,]/g, "");

                // Optional (if you want to normalize double dots or commas)
                // Limit to only one dot and one comma max
                var hasDot = false;
                var hasComma = false;
                sCleanedValue = sCleanedValue
                    .split("")
                    .filter(char => {
                        if (char === "." && !hasDot) {
                            hasDot = true;
                            return true;
                        } else if (char === "," && !hasComma) {
                            hasComma = true;
                            return true;
                        } else if (/\d/.test(char)) {
                            return true;
                        }
                        return false;
                    })
                    .join("");

                // Set the cleaned value back if changed
                if (sValue !== sCleanedValue) {
                    oEvent.getSource().setValue(sCleanedValue);
                }
            },









            // onExportExl: function () {
            //     const oView = this.getView();
            //     const oTable = oView.byId("idDirectStockTransferTable");
            //     const oModel = oView.getModel("TabModel");
            //     const aData = oModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.warning("No data to export.");
            //         return;
            //     }

            //     // Filter selected rows (based on CheckBox binding)
            //     const aSelectedRows = aData.filter(row => row.__selected);

            //     // Use selected rows if available, otherwise export all
            //     const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

            //     // Define columns exactly matching your table model structure
            //     const aColumns = [
            //         { label: "Posting Date", property: "postingdate" },
            //         { label: "Material", property: "material" },
            //         { label: "UOM", property: "uom" },
            //         { label: "From Plant", property: "fromplant" },
            //         { label: "From Storage Location", property: "fromstorageloc" },
            //         { label: "From Batch", property: "frombatch" },
            //         { label: "To Plant", property: "toplant" },
            //         { label: "To Storage Location", property: "tostoragelocation" },
            //         { label: "To Batch", property: "tobatch" },
            //         { label: "Quantity", property: "qty" }
            //     ];

            //     // Create spreadsheet export
            //     const oSpreadsheet = new sap.ui.export.Spreadsheet({
            //         workbook: {
            //             columns: aColumns,
            //             context: { sheetName: "DirectStockTransferItems" }
            //         },
            //         dataSource: aExportData,
            //         fileName: "Direct_Stock_Export.xlsx"
            //     });

            //     oSpreadsheet.build()
            //         .then(() => {
            //             sap.m.MessageToast.show("Export completed successfully.");
            //         })
            //         .catch((oError) => {
            //             sap.m.MessageBox.error("Export failed: " + oError.message);
            //         });
            // },

            onExportExl: function () {
                const oView = this.getView();
                const oTable = oView.byId("idDirectStockTransferTable");
                const oModel = oView.getModel("TabModel");
                const aData = oModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.warning("No data to export.");
                    return;
                }

                // Filter selected rows (based on CheckBox binding)
                const aSelectedRows = aData.filter(row => row.__selected);

                // Use selected rows if available, otherwise export all
                const aExportData = aSelectedRows.length > 0 ? aSelectedRows : aData;

                // Function to format date to DD/MM/YYYY
                function formatDate(dateValue) {
                    if (!dateValue) return "";

                    let date;

                    // If it's already a Date object
                    if (dateValue instanceof Date) {
                        date = dateValue;
                    }
                    // If it's a string that can be parsed
                    else if (typeof dateValue === 'string') {
                        // Try to parse the string
                        date = new Date(dateValue);
                        if (isNaN(date.getTime())) {
                            return dateValue; // Return original if can't parse
                        }
                    }
                    // If it's a timestamp
                    else if (typeof dateValue === 'number') {
                        date = new Date(dateValue);
                    }
                    else {
                        return "";
                    }

                    // Format as DD/MM/YYYY
                    const day = String(date.getDate()).padStart(2, '0');
                    const month = String(date.getMonth() + 1).padStart(2, '0');
                    const year = date.getFullYear();

                    return `${day}/${month}/${year}`;
                }

                // Process the data to format dates
                const processedData = aExportData.map(row => {
                    return {
                        ...row,
                        postingdate: formatDate(row.postingdate)
                    };
                });

                // Define columns exactly matching your table model structure
                const aColumns = [
                    { label: "Posting Date", property: "postingdate" },
                    { label: "Material", property: "material" },
                    { label: "Material Description", property: "description" },
                    { label: "UOM", property: "uom" },
                    { label: "From Plant", property: "fromplant" },
                    { label: "From Storage Location", property: "fromstorageloc" },
                    { label: "From Batch", property: "frombatch" },
                    { label: "To Plant", property: "toplant" },
                    { label: "To Storage Location", property: "tostoragelocation" },
                    // { label: "To Batch", property: "tobatch" },
                    { label: "Vendor Batch", property: "vendorbatch" },
                    { label: "Quantity", property: "qty" },
                    { label: "Requested By", property: "requestedby" },
                    { label: "DP Number", property: "requestnumber" },
                    { label: "Material Document No", property: "materialdocumentno" },
                    { label: "Material Document Year", property: "matdocyear" }
                ];

                // Create spreadsheet export
                const oSpreadsheet = new sap.ui.export.Spreadsheet({
                    workbook: {
                        columns: aColumns,
                        context: { sheetName: "DirectStockTransferItems" }
                    },
                    dataSource: processedData,
                    fileName: "Direct_Stock_Export.xlsx"
                });

                oSpreadsheet.build()
                    .then(() => {
                        sap.m.MessageToast.show("Export completed successfully.");
                    })
                    .catch((oError) => {
                        sap.m.MessageBox.error("Export failed: " + oError.message);
                    });
            },


            // onImportExl: function () {
            //     const that = this;

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) return cb();

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     function doImport(file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             const data = e.target.result;
            //             const workbook = XLSX.read(data, { type: "binary" });
            //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
            //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             // Define the column mapping based on your export structure
            //             const columnMapping = {
            //                 "posting date": "postingdate",
            //                 "material": "material",
            //                 "uom": "uom",
            //                 "from plant": "fromplant",
            //                 "from storage location": "fromstorageloc", // This was "fromstoragelocation" in cleaned header
            //                 "from batch": "frombatch",
            //                 "to plant": "toplant",
            //                 "to storage location": "tostoragelocation",
            //                 "to batch": "tobatch",
            //                 "quantity": "qty" // This was "quantity" in cleaned header
            //             };

            //             // Map Excel data to model properties
            //             const mapped = jsonData.map(row => {
            //                 const obj = {};

            //                 Object.keys(row).forEach(excelHeader => {
            //                     // Clean the header for matching
            //                     const cleanedHeader = excelHeader.trim().toLowerCase();
            //                     let rawValue = row[excelHeader];

            //                     // Find the matching model property
            //                     let modelProperty = columnMapping[cleanedHeader];

            //                     // If no direct match, try removing spaces
            //                     if (!modelProperty) {
            //                         const headerWithoutSpaces = cleanedHeader.replace(/\s+/g, "");
            //                         modelProperty = columnMapping[headerWithoutSpaces];
            //                     }

            //                     if (modelProperty) {
            //                         // Convert Excel date serial numbers to JS Date
            //                         // if (modelProperty === "postingdate" && typeof rawValue === "number") {
            //                         //     const utcDays = Math.floor(rawValue - 25569);
            //                         //     const utcValue = utcDays * 86400;
            //                         //     rawValue = new Date(utcValue * 1000);
            //                         // }
            //                         if (modelProperty === "postingdate") {
            //                             if (rawValue instanceof Date) {
            //                                 // Already a JS Date → convert to ISO yyyy-MM-dd
            //                                 rawValue = rawValue.toISOString().split("T")[0];
            //                             }
            //                             else if (typeof rawValue === "number") {
            //                                 // Excel serial number
            //                                 const jsDate = new Date((rawValue - 25569) * 86400 * 1000);
            //                                 rawValue = jsDate.toISOString().split("T")[0];
            //                             }
            //                         }

            //                         // Handle quantity - ensure it's a valid number
            //                         if (modelProperty === "qty") {
            //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
            //                                 rawValue = "0";
            //                             } else {
            //                                 rawValue = String(rawValue);
            //                             }
            //                         }

            //                         obj[modelProperty] = rawValue;
            //                     }
            //                 });
            //                 return obj;
            //             });

            //             importData(mapped);
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsBinaryString(file);
            //     }

            //     function importData(mapped) {
            //         const oView = that.getView();
            //         const oModel = oView.getModel("TabModel");
            //         const existingData = oModel.getProperty("/Samples") || [];

            //         // Add default values and format data
            //         const formattedRows = mapped.map(row => {
            //             const formattedRow = {
            //                 sap_uuid: "",
            //                 __selected: true,
            //                 gtsavedstatus: "", // Add this if it exists in your model
            //                 // Ensure all fields have proper values
            //                 // postingdate: row.postingdate ? new Date(row.postingdate) : null,
            //                 postingdate: row.postingdate || null,

            //                 material: row.material || "",
            //                 uom: row.uom || "",
            //                 fromplant: row.fromplant || "1200",
            //                 fromstorageloc: row.fromstorageloc || "",
            //                 frombatch: row.frombatch || "",
            //                 toplant: row.toplant || "1200",
            //                 tostoragelocation: row.tostoragelocation || "",
            //                 tobatch: row.tobatch || "",
            //                 qty: row.qty || "0"
            //             };

            //             return formattedRow;
            //         });

            //         const updatedData = existingData.concat(formattedRows);
            //         oModel.setProperty("/Samples", updatedData);

            //         sap.m.MessageToast.show(`Successfully imported ${formattedRows.length} row(s).`);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.addEventListener("change", function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     });

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            // onImportExl: function () {
            //     const that = this;

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) return cb();

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     // ✅ NEW: Function to check if materials exist in material master
            //     async function validateMaterials(materialCodes) {
            //         return new Promise((resolve, reject) => {
            //             if (!materialCodes || materialCodes.length === 0) {
            //                 resolve({ valid: [], invalid: [] });
            //                 return;
            //             }

            //             const oView = that.getView();
            //             const oModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //             // Create filters for all material codes
            //             const filters = materialCodes.map(code => 
            //                 new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, code.trim())
            //             );

            //             oModel.read("/ZC_STOCK_TRANSFER_F4", {
            //                 filters: [new sap.ui.model.Filter({
            //                     filters: filters,
            //                     and: false
            //                 })],
            //                 urlParameters: {
            //                     "$top": 9999
            //                 },
            //                 success: function (oData) {
            //                     // Create a set of valid material codes from the response
            //                     const validMaterials = new Set();
            //                     oData.results.forEach(item => {
            //                         const code = String(item.Product || "").trim();
            //                         if (code) {
            //                             validMaterials.add(code);
            //                         }
            //                     });

            //                     // Determine which materials are invalid
            //                     const invalidMaterials = materialCodes.filter(code => 
            //                         !validMaterials.has(code.trim())
            //                     );

            //                     resolve({
            //                         valid: Array.from(validMaterials),
            //                         invalid: invalidMaterials
            //                     });
            //                 },
            //                 error: function (err) {
            //                     reject(err);
            //                 }
            //             });
            //         });
            //     }

            //     async function doImport(file) {
            //         const reader = new FileReader();

            //         reader.onload = async function (e) {
            //             const data = e.target.result;
            //             const workbook = XLSX.read(data, { type: "binary" });
            //             const sheet = workbook.Sheets[workbook.SheetNames[0]];
            //             const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             // Define the column mapping based on your export structure
            //             const columnMapping = {
            //                 "posting date": "postingdate",
            //                 "material": "material",
            //                 "uom": "uom",
            //                 "from plant": "fromplant",
            //                 "from storage location": "fromstorageloc",
            //                 "from batch": "frombatch",
            //                 "to plant": "toplant",
            //                 "to storage location": "tostoragelocation",
            //                 "to batch": "tobatch",
            //                 "quantity": "qty"
            //             };

            //             // Map Excel data to model properties
            //             const mapped = jsonData.map((row, rowIndex) => {
            //                 const obj = {};

            //                 Object.keys(row).forEach(excelHeader => {
            //                     // Clean the header for matching
            //                     const cleanedHeader = excelHeader.trim().toLowerCase();
            //                     let rawValue = row[excelHeader];

            //                     // Find the matching model property
            //                     let modelProperty = columnMapping[cleanedHeader];

            //                     // If no direct match, try removing spaces
            //                     if (!modelProperty) {
            //                         const headerWithoutSpaces = cleanedHeader.replace(/\s+/g, "");
            //                         modelProperty = columnMapping[headerWithoutSpaces];
            //                     }

            //                     if (modelProperty) {
            //                         // Convert Excel date serial numbers to JS Date
            //                         if (modelProperty === "postingdate") {
            //                             if (rawValue instanceof Date) {
            //                                 // Already a JS Date → convert to ISO yyyy-MM-dd
            //                                 rawValue = rawValue.toISOString().split("T")[0];
            //                             }
            //                             else if (typeof rawValue === "number") {
            //                                 // Excel serial number
            //                                 const jsDate = new Date((rawValue - 25569) * 86400 * 1000);
            //                                 rawValue = jsDate.toISOString().split("T")[0];
            //                             }
            //                         }

            //                         // Handle quantity - ensure it's a valid number
            //                         if (modelProperty === "qty") {
            //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
            //                                 rawValue = "0";
            //                             } else {
            //                                 rawValue = String(rawValue);
            //                             }
            //                         }

            //                         obj[modelProperty] = rawValue;
            //                     }
            //                 });

            //                 // Store the original row index for error reporting
            //                 obj.__rowIndex = rowIndex + 2; // +2 because Excel is 1-indexed and header row is 1
            //                 return obj;
            //             });

            //             // ✅ Step 1: Extract all material codes from the import
            //             const materialCodes = mapped
            //                 .map(row => String(row.material || "").trim())
            //                 .filter(Boolean);

            //             if (materialCodes.length === 0) {
            //                 sap.m.MessageBox.error("No material codes found in the imported file.");
            //                 return;
            //             }

            //             // ✅ Step 2: Validate materials
            //             try {
            //                 const validationResult = await validateMaterials(materialCodes);

            //                 // ✅ Step 3: Check for invalid materials
            //                 if (validationResult.invalid.length > 0) {
            //                     // Find which rows have invalid materials
            //                     const errorRows = [];

            //                     mapped.forEach(row => {
            //                         const materialCode = String(row.material || "").trim();
            //                         if (materialCode && validationResult.invalid.includes(materialCode)) {
            //                             errorRows.push({
            //                                 rowNumber: row.__rowIndex,
            //                                 materialCode: materialCode
            //                             });
            //                         }
            //                     });

            //                     // Prepare error message
            //                     let errorMessage = `Invalid material codes found in the following rows:\n\n`;

            //                     errorRows.forEach(errorRow => {
            //                         errorMessage += `Row ${errorRow.rowNumber}: Material "${errorRow.materialCode}" not found in material master\n`;
            //                     });

            //                     errorMessage += `\nTotal errors: ${errorRows.length}`;

            //                     sap.m.MessageBox.error(errorMessage);
            //                     return; // Don't import if there are invalid materials
            //                 }

            //                 // ✅ Step 4: All materials are valid - proceed with import
            //                 await importData(mapped);

            //             } catch (error) {
            //                 console.error("Material validation error:", error);
            //                 sap.m.MessageBox.error("Error validating materials. Please try again.");
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsBinaryString(file);
            //     }

            //     async function importData(mapped) {
            //         const oView = that.getView();
            //         const oModel = oView.getModel("TabModel");
            //         const existingData = oModel.getProperty("/Samples") || [];

            //         // Add default values and format data
            //         const formattedRows = mapped.map(row => {
            //             const formattedRow = {
            //                 sap_uuid: "",
            //                 __selected: true,
            //                 gtsavedstatus: "",
            //                 postingdate: row.postingdate || null,
            //                 material: row.material || "",
            //                 uom: row.uom || "",
            //                 fromplant: row.fromplant || "1200",
            //                 fromstorageloc: row.fromstorageloc || "",
            //                 frombatch: row.frombatch || "",
            //                 toplant: row.toplant || "1200",
            //                 tostoragelocation: row.tostoragelocation || "",
            //                 tobatch: row.tobatch || "",
            //                 qty: row.qty || "0"
            //             };

            //             return formattedRow;
            //         });

            //         const updatedData = existingData.concat(formattedRows);
            //         oModel.setProperty("/Samples", updatedData);

            //         sap.m.MessageToast.show(`Successfully imported ${formattedRows.length} row(s).`);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.addEventListener("change", function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     });

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },


            // onImportExl: function () {
            //     const that = this;

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) return cb();

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     async function validateMaterials(materialCodes) {
            //         return new Promise((resolve, reject) => {
            //             if (!materialCodes || materialCodes.length === 0) {
            //                 resolve({ valid: [], invalid: [] });
            //                 return;
            //             }

            //             const oView = that.getView();
            //             const oModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //             const filters = materialCodes.map(code =>
            //                 new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, code.trim())
            //             );

            //             oModel.read("/ZC_STOCK_TRANSFER_F4", {
            //                 filters: [new sap.ui.model.Filter({
            //                     filters: filters,
            //                     and: false
            //                 })],
            //                 urlParameters: {
            //                     "$top": 9999
            //                 },
            //                 success: function (oData) {
            //                     const validMaterials = new Set();
            //                     oData.results.forEach(item => {
            //                         const code = String(item.Product || "").trim();
            //                         if (code) validMaterials.add(code);
            //                     });

            //                     const invalidMaterials = materialCodes.filter(code =>
            //                         !validMaterials.has(code.trim())
            //                     );

            //                     resolve({ valid: Array.from(validMaterials), invalid: invalidMaterials });
            //                 },
            //                 error: function (err) {
            //                     reject(err);
            //                 }
            //             });
            //         });
            //     }


            //     function parseDateFromDDMMYYYY(dateStr) {
            //         if (!dateStr) return null;

            //         // 1. Already a Date object (e.g., from cellDates: true)
            //         if (dateStr instanceof Date) {
            //             if (isNaN(dateStr.getTime())) return null;
            //             // Convert UTC-based Date to local midnight using its UTC components
            //             const utcYear = dateStr.getUTCFullYear();
            //             const utcMonth = dateStr.getUTCMonth();
            //             const utcDay = dateStr.getUTCDate();
            //             return new Date(utcYear, utcMonth, utcDay);
            //         }

            //         // 2. String parsing
            //         if (typeof dateStr === "string") {
            //             const trimmedStr = dateStr.trim();

            //             // Match DD/MM/YYYY with / - . separators
            //             const dmyMatch = trimmedStr.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
            //             if (dmyMatch) {
            //                 const day = parseInt(dmyMatch[1], 10);
            //                 const month = parseInt(dmyMatch[2], 10) - 1;
            //                 const year = parseInt(dmyMatch[3], 10);
            //                 const date = new Date(year, month, day);
            //                 // Validate (e.g., 30/02/2026 returns invalid)
            //                 if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
            //                     return date;
            //                 }
            //                 return null;
            //             }

            //             // Match ISO YYYY-MM-DD (already local if constructed this way)
            //             const isoMatch = trimmedStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
            //             if (isoMatch) {
            //                 const year = parseInt(isoMatch[1], 10);
            //                 const month = parseInt(isoMatch[2], 10) - 1;
            //                 const day = parseInt(isoMatch[3], 10);
            //                 const date = new Date(year, month, day);
            //                 if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
            //                     return date;
            //                 }
            //                 return null;
            //             }
            //         }

            //         // 3. Excel serial number (days since 1900-01-01)
            //         if (typeof dateStr === "number") {
            //             // Convert to UTC Date using Excel epoch
            //             const utcDate = new Date((dateStr - 25569) * 86400 * 1000);
            //             if (isNaN(utcDate.getTime())) return null;
            //             // Extract UTC date parts and create a local midnight Date
            //             const utcYear = utcDate.getUTCFullYear();
            //             const utcMonth = utcDate.getUTCMonth();
            //             const utcDay = utcDate.getUTCDate();
            //             return new Date(utcYear, utcMonth, utcDay);
            //         }

            //         return null;
            //     }

            //     async function doImport(file) {
            //         const reader = new FileReader();

            //         reader.onload = async function (e) {
            //             const data = e.target.result;
            //             const workbook = XLSX.read(data, { type: "binary" });
            //             const sheet = workbook.Sheets[workbook.SheetNames[0]];

            //             // ✅ key change: ensure cellDates: true
            //             let jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const columnMapping = {
            //                 "posting date": "postingdate",
            //                 "material": "material",
            //                 "uom": "uom",
            //                 "from plant": "fromplant",
            //                 "from storage location": "fromstorageloc",
            //                 "from batch": "frombatch",
            //                 "to plant": "toplant",
            //                 "to storage location": "tostoragelocation",
            //                 // "to batch": "tobatch",
            //                 "vendor batch": "vendorbatch",
            //                 "quantity": "qty"
            //             };

            //             const mapped = jsonData.map((row, rowIndex) => {
            //                 const obj = {};

            //                 Object.keys(row).forEach(excelHeader => {
            //                     const cleanedHeader = excelHeader.trim().toLowerCase();
            //                     let rawValue = row[excelHeader];
            //                     let modelProperty = columnMapping[cleanedHeader];

            //                     if (!modelProperty) {
            //                         const headerWithoutSpaces = cleanedHeader.replace(/\s+/g, "");
            //                         modelProperty = columnMapping[headerWithoutSpaces];
            //                     }

            //                     if (modelProperty) {
            //                         if (modelProperty === "postingdate") {
            //                             rawValue = parseDateFromDDMMYYYY(rawValue);
            //                         }

            //                         if (modelProperty === "qty") {
            //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
            //                                 rawValue = "0";
            //                             } else {
            //                                 rawValue = String(rawValue).replace(/[^\d.-]/g, '') || "0";
            //                             }
            //                         }

            //                         if (modelProperty !== "postingdate" && modelProperty !== "qty") {
            //                             rawValue = String(rawValue || "");
            //                         }

            //                         obj[modelProperty] = rawValue;
            //                     }
            //                 });

            //                 obj.__rowIndex = rowIndex + 2;
            //                 return obj;
            //             });

            //             const materialCodes = mapped
            //                 .map(row => String(row.material || "").trim())
            //                 .filter(Boolean);

            //             if (materialCodes.length === 0) {
            //                 sap.m.MessageBox.error("No material codes found in the imported file.");
            //                 return;
            //             }

            //             try {
            //                 const validationResult = await validateMaterials(materialCodes);

            //                 if (validationResult.invalid.length > 0) {
            //                     const errorRows = [];
            //                     mapped.forEach(row => {
            //                         const materialCode = String(row.material || "").trim();
            //                         if (materialCode && validationResult.invalid.includes(materialCode)) {
            //                             errorRows.push({ rowNumber: row.__rowIndex, materialCode });
            //                         }
            //                     });

            //                     let errorMessage = `Invalid material codes found in the following rows:\n\n`;
            //                     errorRows.forEach(errorRow => {
            //                         errorMessage += `Row ${errorRow.rowNumber}: Material "${errorRow.materialCode}" not found in material master\n`;
            //                     });
            //                     errorMessage += `\nTotal errors: ${errorRows.length}`;
            //                     sap.m.MessageBox.error(errorMessage);
            //                     return;
            //                 }

            //                 await importData(mapped);

            //             } catch (error) {
            //                 console.error("Material validation error:", error);
            //                 sap.m.MessageBox.error("Error validating materials. Please try again.");
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsBinaryString(file);
            //     }

            //     async function importData(mapped) {
            //         const oView = that.getView();
            //         const oModel = oView.getModel("TabModel");
            //         const existingData = oModel.getProperty("/Samples") || [];

            //         const formattedRows = mapped.map(row => ({
            //             sap_uuid: "",
            //             __selected: true,
            //             gtsavedstatus: "",
            //             postingdate: row.postingdate || null,
            //             material: row.material || "",
            //             uom: row.uom || "",
            //             fromplant: row.fromplant || "1200",
            //             fromstorageloc: row.fromstorageloc || "",
            //             frombatch: row.frombatch || "",
            //             toplant: row.toplant || "1200",
            //             tostoragelocation: row.tostoragelocation || "",
            //             // tobatch: row.tobatch || "",
            //             vendorbatch: row.vendorbatch || "",
            //             qty: row.qty || "0"
            //         }));

            //         const updatedData = existingData.concat(formattedRows);
            //         oModel.setProperty("/Samples", updatedData);

            //         sap.m.MessageToast.show(`Successfully imported ${formattedRows.length} row(s).`);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.addEventListener("change", function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     });

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },



            onImportExl: function () {
                const that = this;

                // ----------------------------------------------------------------------
                // Helper: load XLSX library if not present
                // ----------------------------------------------------------------------
                function ensureXLSX(cb) {
                    if (window.XLSX) return cb();
                    const script = document.createElement("script");
                    script.src = importexcelfile;   // make sure this variable is defined globally
                    script.onload = cb;
                    script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
                    document.head.appendChild(script);
                }

                // ----------------------------------------------------------------------
                // Parse date from various formats (DD/MM/YYYY, ISO, Excel serial)
                // ----------------------------------------------------------------------
                function parseDateFromDDMMYYYY(dateStr) {
                    if (!dateStr) return null;

                    // Already a Date object (e.g., from cellDates: true)
                    if (dateStr instanceof Date) {
                        if (isNaN(dateStr.getTime())) return null;
                        const utcYear = dateStr.getUTCFullYear();
                        const utcMonth = dateStr.getUTCMonth();
                        const utcDay = dateStr.getUTCDate();
                        return new Date(utcYear, utcMonth, utcDay);
                    }

                    // String parsing
                    if (typeof dateStr === "string") {
                        const trimmedStr = dateStr.trim();

                        // DD/MM/YYYY with / - . separators
                        const dmyMatch = trimmedStr.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
                        if (dmyMatch) {
                            const day = parseInt(dmyMatch[1], 10);
                            const month = parseInt(dmyMatch[2], 10) - 1;
                            const year = parseInt(dmyMatch[3], 10);
                            const date = new Date(year, month, day);
                            if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
                                return date;
                            }
                            return null;
                        }

                        // ISO YYYY-MM-DD
                        const isoMatch = trimmedStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
                        if (isoMatch) {
                            const year = parseInt(isoMatch[1], 10);
                            const month = parseInt(isoMatch[2], 10) - 1;
                            const day = parseInt(isoMatch[3], 10);
                            const date = new Date(year, month, day);
                            if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
                                return date;
                            }
                            return null;
                        }
                    }

                    // Excel serial number (days since 1900-01-01)
                    if (typeof dateStr === "number") {
                        const utcDate = new Date((dateStr - 25569) * 86400 * 1000);
                        if (isNaN(utcDate.getTime())) return null;
                        const utcYear = utcDate.getUTCFullYear();
                        const utcMonth = utcDate.getUTCMonth();
                        const utcDay = utcDate.getUTCDate();
                        return new Date(utcYear, utcMonth, utcDay);
                    }

                    return null;
                }

                // ----------------------------------------------------------------------
                // NEW: Resolve material codes and descriptions against material master
                // ----------------------------------------------------------------------
                async function resolveMaterialsAndDescriptions(rows) {
                    // Collect distinct search terms
                    const materialCodes = new Set();
                    const descriptions = new Set();

                    rows.forEach(row => {
                        const mat = (row.material || "").trim();
                        const desc = (row.description || "").trim();
                        if (mat) materialCodes.add(mat);
                        if (desc) descriptions.add(desc);
                    });

                    if (materialCodes.size === 0 && descriptions.size === 0) {
                        throw new Error("No material codes or descriptions provided in the file.");
                    }

                    // Build OData filter: (Product eq 'code1' or ...) or (ProductName eq 'desc1' or ...)
                    const filters = [];
                    materialCodes.forEach(code => {
                        filters.push(new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, code));
                    });
                    descriptions.forEach(desc => {
                        filters.push(new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.EQ, desc));
                    });

                    const oModel = that.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                    return new Promise((resolve, reject) => {
                        oModel.read("/ZC_STOCK_TRANSFER_F4", {
                            filters: [new sap.ui.model.Filter({ filters: filters, and: false })],
                            urlParameters: { "$top": 9999 },
                            success: function (oData) {
                                // Build lookup maps
                                const materialMap = new Map();          // code -> { description, baseUnit }
                                const descToMaterials = new Map();      // description -> array of codes

                                oData.results.forEach(item => {
                                    const code = (item.Product || "").trim();
                                    const desc = (item.ProductName || "").trim();
                                    const baseUnit = (item.BaseUnit || "").trim();
                                    if (code && desc) {
                                        materialMap.set(code, { description: desc, baseUnit });
                                        if (!descToMaterials.has(desc)) descToMaterials.set(desc, []);
                                        descToMaterials.get(desc).push(code);
                                    }
                                });

                                // Resolve each row
                                const resolvedRows = [];
                                for (let idx = 0; idx < rows.length; idx++) {
                                    const row = rows[idx];
                                    const inputMat = (row.material || "").trim();
                                    const inputDesc = (row.description || "").trim();
                                    let finalMat = inputMat;
                                    let finalDesc = inputDesc;
                                    let finalUOM = "";
                                    const rowNumber = row.__rowIndex || (idx + 2);

                                    try {
                                        // Case 1: Both material and description provided
                                        if (inputMat && inputDesc) {
                                            const master = materialMap.get(inputMat);
                                            if (!master) {
                                                throw new Error(`Material code '${inputMat}' not found in master.`);
                                            }
                                            if (master.description.toLowerCase() !== inputDesc.toLowerCase()) {
                                                throw new Error(`Material '${inputMat}' has description '${master.description}', but Excel provides '${inputDesc}'.`);
                                            }
                                            finalDesc = master.description;  // use master case
                                            finalUOM = master.baseUnit;
                                        }
                                        // Case 2: Only material code
                                        else if (inputMat && !inputDesc) {
                                            const master = materialMap.get(inputMat);
                                            if (!master) {
                                                throw new Error(`Material code '${inputMat}' not found in master.`);
                                            }
                                            finalDesc = master.description;
                                            finalUOM = master.baseUnit;
                                        }
                                        // Case 3: Only description
                                        else if (!inputMat && inputDesc) {
                                            const codes = descToMaterials.get(inputDesc);
                                            if (!codes || codes.length === 0) {
                                                throw new Error(`Description '${inputDesc}' not found in master.`);
                                            }
                                            if (codes.length > 1) {
                                                throw new Error(`Description '${inputDesc}' matches multiple materials: ${codes.join(", ")}. Please provide a material code.`);
                                            }
                                            finalMat = codes[0];
                                            finalDesc = inputDesc;
                                            finalUOM = materialMap.get(finalMat).baseUnit;
                                        }
                                        // Case 4: Neither provided
                                        else {
                                            throw new Error(`Neither material code nor description provided.`);
                                        }

                                        resolvedRows.push({
                                            ...row,
                                            material: finalMat,
                                            description: finalDesc,
                                            uom: finalUOM
                                        });
                                    } catch (err) {
                                        reject(new Error(`Row ${rowNumber}: ${err.message}`));
                                        return;
                                    }
                                }
                                resolve(resolvedRows);
                            },
                            error: function (err) {
                                reject(err);
                            }
                        });
                    });
                }

                // ----------------------------------------------------------------------
                // Core import logic
                // ----------------------------------------------------------------------
                async function doImport(file) {
                    const reader = new FileReader();
                    reader.onload = async function (e) {
                        const data = e.target.result;
                        const workbook = XLSX.read(data, { type: "binary" });
                        const sheet = workbook.Sheets[workbook.SheetNames[0]];
                        let jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

                        if (!jsonData.length) {
                            sap.m.MessageToast.show("No data found in the Excel sheet.");
                            return;
                        }

                        // Column mapping (added "material description")
                        const columnMapping = {
                            "posting date": "postingdate",
                            "material": "material",
                            "material description": "description",
                            "uom": "uom",
                            "from plant": "fromplant",
                            "from storage location": "fromstorageloc",
                            "from batch": "frombatch",
                            "to plant": "toplant",
                            "to storage location": "tostoragelocation",
                            "vendor batch": "vendorbatch",
                            "quantity": "qty"
                        };

                        // Map Excel columns to internal properties
                        const mapped = jsonData.map((row, rowIndex) => {
                            const obj = {};
                            Object.keys(row).forEach(excelHeader => {
                                const cleanedHeader = excelHeader.trim().toLowerCase();
                                let rawValue = row[excelHeader];
                                let modelProperty = columnMapping[cleanedHeader];

                                if (!modelProperty) {
                                    const headerWithoutSpaces = cleanedHeader.replace(/\s+/g, "");
                                    modelProperty = columnMapping[headerWithoutSpaces];
                                }

                                if (modelProperty) {
                                    if (modelProperty === "postingdate") {
                                        rawValue = parseDateFromDDMMYYYY(rawValue);
                                    } else if (modelProperty === "qty") {
                                        if (rawValue === null || rawValue === undefined || rawValue === "") {
                                            rawValue = "0";
                                        } else {
                                            rawValue = String(rawValue).replace(/[^\d.-]/g, '') || "0";
                                        }
                                    } else {
                                        rawValue = String(rawValue || "");
                                    }
                                    obj[modelProperty] = rawValue;
                                }
                            });
                            obj.__rowIndex = rowIndex + 2;  // store original Excel row number for error messages
                            return obj;
                        });

                        if (mapped.length === 0) {
                            sap.m.MessageToast.show("No data found after mapping.");
                            return;
                        }

                        try {
                            // Resolve all materials & descriptions (throws on error)
                            const resolvedRows = await resolveMaterialsAndDescriptions(mapped);
                            // Import the resolved data into the table model
                            await importData(resolvedRows);
                        } catch (error) {
                            sap.m.MessageBox.error(error.message);
                            console.error(error);
                        }
                    };

                    reader.onerror = function () {
                        sap.m.MessageToast.show("Error reading Excel file.");
                    };
                    reader.readAsBinaryString(file);
                }

                // ----------------------------------------------------------------------
                // Append resolved rows to the table model
                // ----------------------------------------------------------------------
                async function importData(mapped) {
                    const oView = that.getView();
                    const oModel = oView.getModel("TabModel");
                    const existingData = oModel.getProperty("/Samples") || [];

                    const formattedRows = mapped.map(row => ({
                        sap_uuid: "",
                        __selected: true,
                        gtsavedstatus: "",
                        postingdate: row.postingdate || null,
                        material: row.material || "",
                        description: row.description || "",          // <-- now included
                        uom: row.uom || "",
                        fromplant: row.fromplant || "1200",
                        fromstorageloc: row.fromstorageloc || "",
                        frombatch: row.frombatch || "",
                        toplant: row.toplant || "1200",
                        tostoragelocation: row.tostoragelocation || "",
                        vendorbatch: row.vendorbatch || "",
                        qty: row.qty || "0"
                    }));

                    const updatedData = existingData.concat(formattedRows);
                    oModel.setProperty("/Samples", updatedData);

                    sap.m.MessageToast.show(`Successfully imported ${formattedRows.length} row(s).`);
                }

                // ----------------------------------------------------------------------
                // Trigger file selection dialog
                // ----------------------------------------------------------------------
                const fileInput = document.createElement("input");
                fileInput.type = "file";
                fileInput.accept = ".xlsx,.xls";
                fileInput.style.display = "none";

                fileInput.addEventListener("change", function (e) {
                    const file = e.target.files[0];
                    if (!file) return;
                    ensureXLSX(() => doImport(file));
                    document.body.removeChild(fileInput);
                });

                document.body.appendChild(fileInput);
                fileInput.click();
            },


            // onImportExl: function () {
            //     const that = this;

            //     function ensureXLSX(cb) {
            //         if (window.XLSX) return cb();

            //         const script = document.createElement("script");
            //         script.src = importexcelfile;
            //         script.onload = cb;
            //         script.onerror = () => sap.m.MessageToast.show("Failed to load Excel library.");
            //         document.head.appendChild(script);
            //     }

            //     async function validateMaterials(materialCodes) {
            //         return new Promise((resolve, reject) => {
            //             if (!materialCodes || materialCodes.length === 0) {
            //                 resolve({ validMap: {}, invalid: [] });
            //                 return;
            //             }

            //             const oView = that.getView();
            //             const oModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");

            //             const filters = materialCodes.map(code =>
            //                 new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, code.trim())
            //             );

            //             oModel.read("/ZC_STOCK_TRANSFER_F4", {
            //                 filters: [new sap.ui.model.Filter({ filters: filters, and: false })],
            //                 urlParameters: { "$top": 9999 },
            //                 success: function (oData) {
            //                     const validMap = {};          // materialCode -> baseUnit
            //                     const foundCodes = new Set();

            //                     oData.results.forEach(item => {
            //                         const code = String(item.Product || "").trim();
            //                         const baseUnit = String(item.BaseUnit || "").trim();
            //                         if (code) {
            //                             validMap[code] = baseUnit;
            //                             foundCodes.add(code);
            //                         }
            //                     });

            //                     const invalid = materialCodes.filter(code => !foundCodes.has(code.trim()));

            //                     resolve({ validMap, invalid });
            //                 },
            //                 error: function (err) {
            //                     reject(err);
            //                 }
            //             });
            //         });
            //     }

            //     function parseDateFromDDMMYYYY(dateStr) {
            //         if (!dateStr) return null;

            //         // 1. Already a Date object (e.g., from cellDates: true)
            //         if (dateStr instanceof Date) {
            //             if (isNaN(dateStr.getTime())) return null;
            //             // Convert UTC-based Date to local midnight using its UTC components
            //             const utcYear = dateStr.getUTCFullYear();
            //             const utcMonth = dateStr.getUTCMonth();
            //             const utcDay = dateStr.getUTCDate();
            //             return new Date(utcYear, utcMonth, utcDay);
            //         }

            //         // 2. String parsing
            //         if (typeof dateStr === "string") {
            //             const trimmedStr = dateStr.trim();

            //             // Match DD/MM/YYYY with / - . separators
            //             const dmyMatch = trimmedStr.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
            //             if (dmyMatch) {
            //                 const day = parseInt(dmyMatch[1], 10);
            //                 const month = parseInt(dmyMatch[2], 10) - 1;
            //                 const year = parseInt(dmyMatch[3], 10);
            //                 const date = new Date(year, month, day);
            //                 // Validate (e.g., 30/02/2026 returns invalid)
            //                 if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
            //                     return date;
            //                 }
            //                 return null;
            //             }

            //             // Match ISO YYYY-MM-DD (already local if constructed this way)
            //             const isoMatch = trimmedStr.match(/^(\d{4})-(\d{2})-(\d{2})$/);
            //             if (isoMatch) {
            //                 const year = parseInt(isoMatch[1], 10);
            //                 const month = parseInt(isoMatch[2], 10) - 1;
            //                 const day = parseInt(isoMatch[3], 10);
            //                 const date = new Date(year, month, day);
            //                 if (!isNaN(date.getTime()) && date.getDate() === day && date.getMonth() === month) {
            //                     return date;
            //                 }
            //                 return null;
            //             }
            //         }

            //         // 3. Excel serial number (days since 1900-01-01)
            //         if (typeof dateStr === "number") {
            //             // Convert to UTC Date using Excel epoch
            //             const utcDate = new Date((dateStr - 25569) * 86400 * 1000);
            //             if (isNaN(utcDate.getTime())) return null;
            //             // Extract UTC date parts and create a local midnight Date
            //             const utcYear = utcDate.getUTCFullYear();
            //             const utcMonth = utcDate.getUTCMonth();
            //             const utcDay = utcDate.getUTCDate();
            //             return new Date(utcYear, utcMonth, utcDay);
            //         }

            //         return null;
            //     }

            //     async function doImport(file) {
            //         const reader = new FileReader();

            //         reader.onload = async function (e) {
            //             const data = e.target.result;
            //             const workbook = XLSX.read(data, { type: "binary" });
            //             const sheet = workbook.Sheets[workbook.SheetNames[0]];

            //             // ✅ key change: ensure cellDates: true
            //             let jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "", cellDates: true });

            //             if (!jsonData.length) {
            //                 sap.m.MessageToast.show("No data found in the Excel sheet.");
            //                 return;
            //             }

            //             const columnMapping = {
            //                 "posting date": "postingdate",
            //                 "material": "material",
            //                 "uom": "uom",
            //                 "from plant": "fromplant",
            //                 "from storage location": "fromstorageloc",
            //                 "from batch": "frombatch",
            //                 "to plant": "toplant",
            //                 "to storage location": "tostoragelocation",
            //                 // "to batch": "tobatch",
            //                 "vendor batch": "vendorbatch",
            //                 "quantity": "qty"
            //             };

            //             const mapped = jsonData.map((row, rowIndex) => {
            //                 const obj = {};

            //                 Object.keys(row).forEach(excelHeader => {
            //                     const cleanedHeader = excelHeader.trim().toLowerCase();
            //                     let rawValue = row[excelHeader];
            //                     let modelProperty = columnMapping[cleanedHeader];

            //                     if (!modelProperty) {
            //                         const headerWithoutSpaces = cleanedHeader.replace(/\s+/g, "");
            //                         modelProperty = columnMapping[headerWithoutSpaces];
            //                     }

            //                     if (modelProperty) {
            //                         if (modelProperty === "postingdate") {
            //                             rawValue = parseDateFromDDMMYYYY(rawValue);
            //                         }

            //                         if (modelProperty === "qty") {
            //                             if (rawValue === null || rawValue === undefined || rawValue === "") {
            //                                 rawValue = "0";
            //                             } else {
            //                                 rawValue = String(rawValue).replace(/[^\d.-]/g, '') || "0";
            //                             }
            //                         }

            //                         if (modelProperty !== "postingdate" && modelProperty !== "qty") {
            //                             rawValue = String(rawValue || "");
            //                         }

            //                         obj[modelProperty] = rawValue;
            //                     }
            //                 });

            //                 obj.__rowIndex = rowIndex + 2;
            //                 return obj;
            //             });

            //             const materialCodes = mapped
            //                 .map(row => String(row.material || "").trim())
            //                 .filter(Boolean);

            //             if (materialCodes.length === 0) {
            //                 sap.m.MessageBox.error("No material codes found in the imported file.");
            //                 return;
            //             }

            //             try {
            //                 const validationResult = await validateMaterials(materialCodes);

            //                 if (validationResult.invalid.length > 0) {
            //                     const errorRows = [];
            //                     mapped.forEach(row => {
            //                         const materialCode = String(row.material || "").trim();
            //                         if (materialCode && validationResult.invalid.includes(materialCode)) {
            //                             errorRows.push({ rowNumber: row.__rowIndex, materialCode });
            //                         }
            //                     });

            //                     let errorMessage = `Invalid material codes found in the following rows:\n\n`;
            //                     errorRows.forEach(errorRow => {
            //                         errorMessage += `Row ${errorRow.rowNumber}: Material "${errorRow.materialCode}" not found in material master\n`;
            //                     });
            //                     errorMessage += `\nTotal errors: ${errorRows.length}`;
            //                     sap.m.MessageBox.error(errorMessage);
            //                     return;
            //                 }

            //                 // ✅ ALWAYS set UOM from database - override whatever was in Excel
            //                 const enhancedRows = mapped.map(row => {
            //                     const materialCode = String(row.material || "").trim();
            //                     const baseUnit = validationResult.validMap[materialCode] || "";

            //                     // Always use the base unit from database
            //                     row.uom = baseUnit;

            //                     return row;
            //                 });

            //                 await importData(enhancedRows);

            //             } catch (error) {
            //                 console.error("Material validation error:", error);
            //                 sap.m.MessageBox.error("Error validating materials. Please try again.");
            //             }
            //         };

            //         reader.onerror = function () {
            //             sap.m.MessageToast.show("Error reading Excel file.");
            //         };

            //         reader.readAsBinaryString(file);
            //     }

            //     async function importData(mapped) {
            //         const oView = that.getView();
            //         const oModel = oView.getModel("TabModel");
            //         const existingData = oModel.getProperty("/Samples") || [];

            //         const formattedRows = mapped.map(row => ({
            //             sap_uuid: "",
            //             __selected: true,
            //             gtsavedstatus: "",
            //             postingdate: row.postingdate || null,
            //             material: row.material || "",
            //             uom: row.uom || "",
            //             fromplant: row.fromplant || "1200",
            //             fromstorageloc: row.fromstorageloc || "",
            //             frombatch: row.frombatch || "",
            //             toplant: row.toplant || "1200",
            //             tostoragelocation: row.tostoragelocation || "",
            //             // tobatch: row.tobatch || "",
            //             vendorbatch: row.vendorbatch || "",
            //             qty: row.qty || "0"
            //         }));

            //         const updatedData = existingData.concat(formattedRows);
            //         oModel.setProperty("/Samples", updatedData);

            //         sap.m.MessageToast.show(`Successfully imported ${formattedRows.length} row(s).`);
            //     }

            //     const fileInput = document.createElement("input");
            //     fileInput.type = "file";
            //     fileInput.accept = ".xlsx,.xls";
            //     fileInput.style.display = "none";

            //     fileInput.addEventListener("change", function (e) {
            //         const file = e.target.files[0];
            //         if (!file) return;
            //         ensureXLSX(() => doImport(file));
            //         document.body.removeChild(fileInput);
            //     });

            //     document.body.appendChild(fileInput);
            //     fileInput.click();
            // },







            _getMaterialConversion: async function (sMaterial) {
                const oODataModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                return new Promise((resolve, reject) => {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
                    ];

                    // Set busy indicator while reading
                    sap.ui.core.BusyIndicator.show(0);

                    oODataModel.read("/ZC_STOCK_CONTAINER", {
                        filters: aFilters,
                        success: function (oData) {
                            sap.ui.core.BusyIndicator.hide();

                            const oConv = oData.results.find(
                                item => item.AlternativeUnit !== item.BaseUnit
                            );

                            if (oConv) {
                                resolve(oConv);
                            } else {
                                reject("No valid conversion row found");
                            }
                        },
                        error: function (err) {
                            sap.ui.core.BusyIndicator.hide();
                            reject(err);
                        }
                    });
                });
            },


            onContainerChange: async function (oEvent) {
                const oInput = oEvent.getSource();
                const oContext = oInput.getBindingContext("TabModel");
                const oModel = this.getView().getModel("TabModel");
                const sPath = oContext.getPath();
                const oRow = oModel.getProperty(sPath);
                const sMaterial = oRow.material;

                if (!sMaterial) {
                    sap.m.MessageToast.show("Please select a material first.");
                    return;
                }

                const iContainers = parseFloat(oInput.getValue());
                if (isNaN(iContainers)) return;

                // --- Simple 3-second delay before fetching ---
                clearTimeout(this._containerTimer);
                this._containerTimer = setTimeout(async () => {
                    try {
                        const oConv = await this._getMaterialConversion(sMaterial);
                        const num = parseFloat(oConv.QuantityNumerator);
                        const den = parseFloat(oConv.QuantityDenominator);
                        const quantity = iContainers * (num / den);

                        oModel.setProperty(sPath + "/reqqty", quantity);
                    } catch (err) {
                        console.error(err);
                        sap.m.MessageToast.show("Conversion not found for " + sMaterial);
                    }
                }, 1800);
            },

            onQuantityChange: async function (oEvent) {
                const oInput = oEvent.getSource();
                const oContext = oInput.getBindingContext("TabModel");
                const oModel = this.getView().getModel("TabModel");
                const sPath = oContext.getPath();
                const oRow = oModel.getProperty(sPath);
                const sMaterial = oRow.material;

                if (!sMaterial) {
                    sap.m.MessageToast.show("Please select a material first.");
                    return;
                }

                const iQuantity = parseFloat(oInput.getValue());
                if (isNaN(iQuantity)) return;

                // --- Simple 3-second delay before fetching ---
                clearTimeout(this._quantityTimer);
                this._quantityTimer = setTimeout(async () => {
                    try {
                        const oConv = await this._getMaterialConversion(sMaterial);
                        const num = parseFloat(oConv.QuantityNumerator);
                        const den = parseFloat(oConv.QuantityDenominator);
                        const containers = iQuantity * (den / num);

                        oModel.setProperty(sPath + "/nocontainers", containers);
                    } catch (err) {
                        console.error(err);
                        sap.m.MessageToast.show("Conversion not found for " + sMaterial);
                    }
                }, 1800);
            },



            onQtyChange: function (oEvent) {
                var oInput = oEvent.getSource();
                var oBindingContext = oInput.getBindingContext("TabModel");

                if (!oBindingContext) {
                    return;
                }

                var oModel = oInput.getModel("TabModel");
                var sPath = oBindingContext.getPath();

                // Read the hidden quantity (max allowed)
                var sHiddenQty = oModel.getProperty(sPath + "/hiddenqty");
                var nHiddenQty = parseFloat(sHiddenQty);

                // If hiddenqty is missing or not a number, we cannot validate; allow input (or show warning?)
                if (sHiddenQty === undefined || sHiddenQty === null || sHiddenQty === "" || isNaN(nHiddenQty)) {
                    // Optionally: show a message that hiddenqty is not set
                    // sap.m.MessageToast.show("Hidden quantity is not defined; please contact admin.");
                    return; // skip validation
                }

                // Get the entered quantity
                var sCurrentValue = oInput.getValue();
                var nQty = parseFloat(sCurrentValue);

                // If empty or not a number, do nothing (required validation will catch empty)
                if (sCurrentValue === "" || isNaN(nQty)) {
                    return;
                }

                // If quantity exceeds hiddenqty, correct it
                if (nQty > nHiddenQty) {
                    oInput.setValue(String(nHiddenQty));
                    oModel.setProperty(sPath + "/qty", nHiddenQty);
                    sap.m.MessageToast.show("Quantity cannot exceed the hidden quantity (" + nHiddenQty + ")");
                }
            },




            generateUUID: function () {
                return 'xxxxxxxx_xxxx_4xxx_yxxx_xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                    const r = Math.random() * 16 | 0,
                        v = c === 'x' ? r : (r & 0x3 | 0x8);
                    return v.toString(16);
                });
            },

            generateRequestNumber: function () {
                const now = new Date();
                const year = now.getFullYear();
                const month = String(now.getMonth() + 1).padStart(2, '0');
                const day = String(now.getDate()).padStart(2, '0');
                const hours = String(now.getHours()).padStart(2, '0');
                const minutes = String(now.getMinutes()).padStart(2, '0');
                const seconds = String(now.getSeconds()).padStart(2, '0');
                return `BIPLDP${year}${month}${day}${hours}${minutes}${seconds}`;
            },


            onSavePress: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
                const aData = oView.getModel("TabModel").getProperty("/Samples");

                if (!aData || !Array.isArray(aData)) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                const aAlreadySaved = aSelectedRows.filter(row => row.sap_uuid);

                if (aAlreadySaved.length > 0) {
                    sap.m.MessageBox.error("Some selected rows were already saved and cannot be saved again.");
                    return;
                }


                // ✅ Validate mandatory fields for direct stock transfer
                const aInvalidRows = [];

                aSelectedRows.forEach((row, index) => {
                    const missingFields = [];
                    const invalidFields = [];

                    // Check for missing required fields
                    if (!row.postingdate || String(row.postingdate).trim() === "") {
                        missingFields.push("Posting Date");
                    }
                    if (!row.material || String(row.material).trim() === "") {
                        missingFields.push("Material");
                    }

                    if (!row.qty || String(row.qty).trim() === "" || parseFloat(row.qty) <= 0) {
                        missingFields.push("Quantity (must be > 0)");
                    }

                    if (!row.fromplant || String(row.fromplant).trim() === "") {
                        missingFields.push("From Plant");
                    }

                    if (!row.toplant || String(row.toplant).trim() === "") {
                        missingFields.push("To Plant");
                    }

                    if (!row.fromstorageloc || String(row.fromstorageloc).trim() === "") {
                        missingFields.push("From Storage Location");
                    }

                    if (!row.tostoragelocation || String(row.tostoragelocation).trim() === "") {
                        missingFields.push("To Storage Location");
                    }
                    // if (!row.requestedby || String(row.requestedby).trim() === "") {
                    //     missingFields.push("To Requested By");
                    // }

                    // If there are missing or invalid fields, add to error list
                    if (missingFields.length > 0 || invalidFields.length > 0) {
                        const rowIndex = aData.indexOf(row) + 1; // Get actual row number from full dataset
                        const allErrors = [];

                        if (missingFields.length > 0) {
                            allErrors.push(`Missing: ${missingFields.join(", ")}`);
                        }

                        if (invalidFields.length > 0) {
                            allErrors.push(`Invalid: ${invalidFields.join(", ")}`);
                        }

                        aInvalidRows.push(`Row ${rowIndex}: ${allErrors.join("; ")}`);
                    }
                });

                if (aInvalidRows.length > 0) {
                    sap.m.MessageBox.error(
                        "The following selected row(s) have errors:\n\n" + aInvalidRows.join("\n")
                    );
                    return;
                }

                // ----- NEW: Generate a single request number for this batch -----
                const sRequestNumber = this.generateRequestNumber();
                console.log("Generated Request Number:", sRequestNumber);

                // Show busy indicator
                sap.ui.core.BusyIndicator.show(0);

                // Prepare and send all selected rows
                const aPromises = aSelectedRows.map(row => {
                    const oPayload = {
                        sap_uuid: this.generateUUID(),
                        requestnumber: sRequestNumber,
                        // Format date to 'en-CA' (YYYY-MM-DD) like in mixing example
                        postingdate: row.postingdate ? new Date(row.postingdate.toLocaleDateString('en-CA')) : null,
                        material: row.material,
                        description: row.description,
                        uom: row.uom || "",
                        fromplant: row.fromplant,
                        fromstorageloc: row.fromstorageloc,
                        frombatch: row.frombatch || "",
                        toplant: row.toplant,
                        tostoragelocation: row.tostoragelocation,
                        // tobatch: row.tobatch || "",
                        vendorbatch: String(row.vendorbatch),
                        qty: String(row.qty) || "0",
                        // hiddenqty: String(row.hiddenqty) || "0",
                        hiddenqty: row.hiddenqty != null ? String(row.hiddenqty) : "0",  // ✅ FIXED
                        gtsavedstatus: "GT",
                        screenname: "DIRECT_STOCK_TRANSFER",
                        screencode: "DST01",
                        createdat: new Date(),
                        createdby: this.sUserId,
                        requestedby: this.sUserFullName
                    };

                    return new Promise((resolve, reject) => {
                        oModel.create("/ZC_DIRECT_TRANSFER_POSTING", oPayload, {
                            success: (data) => {
                                // Update the row in local model with the saved status and any returned data
                                const rowIndex = aData.findIndex(r => r === row);
                                if (rowIndex !== -1) {
                                    const updatedRow = {
                                        ...row,
                                        gtsavedstatus: "GT",
                                        sap_uuid: data.sap_uuid || oPayload.sap_uuid
                                    };
                                    oView.getModel("TabModel").setProperty(`/Samples/${rowIndex}`, updatedRow);
                                }
                                resolve(data);
                            },
                            error: reject
                        });
                    });
                });

                const that = this;

                Promise.allSettled(aPromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    if (aFailed.length > 0) {
                        let errorMessage = `${aFailed.length} row(s) failed to save.`;

                        // Try to get more specific error messages
                        const specificErrors = aFailed.map((failed, index) => {
                            const rowIndex = aSelectedRows.findIndex((row, i) => i === index);
                            const rowNumber = rowIndex !== -1 ? `Row ${aData.indexOf(aSelectedRows[rowIndex]) + 1}` : `Row ${index + 1}`;
                            const error = failed.reason?.message || "Unknown error";
                            return `${rowNumber}: ${error}`;
                        });

                        if (specificErrors.length > 0) {
                            errorMessage += "\n\n" + specificErrors.join("\n");
                        }

                        sap.m.MessageBox.error(errorMessage);
                    }

                    if (aSuccess.length > 0) {
                        sap.m.MessageBox.success(`${aSuccess.length} row(s) saved successfully.`, {
                            onClose: () => {
                                // Refresh the model if needed
                                oModel.refresh(true);
                                that.GoStockReqTableOpen();
                            }
                        });
                    }
                }).catch(error => {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageBox.error("Save operation failed: " + (error.message || "Unknown error"));
                });
            },


            onUpdatePress: function () {
                const oView = this.getView();
                const oTabModel = oView.getModel("TabModel");
                const oODataModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
                const aSamples = oTabModel.getProperty("/Samples") || [];

                const aSelectedRows = aSamples.filter(item => item.__selected === true);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to update.");
                    return;
                }

                const aSavedRows = aSelectedRows.filter(item => item.sap_uuid);

                if (aSavedRows.length === 0) {
                    sap.m.MessageBox.warning("No saved rows selected for update.");
                    return;
                }


                sap.ui.core.BusyIndicator.show(0);

                const aUpdatePromises = aSelectedRows.map(item => {

                    const sKey = oODataModel.createKey("/ZC_DIRECT_TRANSFER_POSTING", {
                        sap_uuid: item.sap_uuid,
                    });

                    // Prepare payload with only editable fields
                    const oPayload = {
                        // confirmedqty: String(parseInt(item.confirmedqty)),
                        // scrapqty: String(parseInt(item.scrapqty)),

                        // confirmedqty: String(item.confirmedqty),
                        // scrapqty: String(item.scrapqty),
                        // manufacturingdate: item.manufacturingdate ? new Date(item.manufacturingdate.toLocaleDateString('en-CA')) : null,
                        updatestatusgistatus: "GT",
                        frombatch: item.frombatch,
                        // tobatch: item.tobatch,
                        vendorbatch: String(item.vendorbatch),
                        qty: item.qty ? String(item.qty) : null,
                        hiddenqty: item.hiddenqty ? String(item.hiddenqty) : null,
                    };

                    return new Promise((resolve, reject) => {
                        oODataModel.update(sKey, oPayload, {
                            success: resolve,
                            error: reject
                        });
                    });
                });

                Promise.allSettled(aUpdatePromises).then(results => {
                    sap.ui.core.BusyIndicator.hide();

                    const aFailed = results.filter(r => r.status === "rejected");
                    const aSuccess = results.filter(r => r.status === "fulfilled");

                    let sMsg = `${aSuccess.length} row(s) updated successfully.`;
                    if (aFailed.length > 0) {
                        sMsg += `\n${aFailed.length} row(s) failed to update.`;
                    }

                    sap.m.MessageBox.information(sMsg);
                    oTabModel.refresh(true);
                    // this.GoMixingActual()
                });
            },


            onDeletePress: function () {
                const oView = this.getView();
                const oModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
                const oTabModel = oView.getModel("TabModel");
                const aData = oTabModel.getProperty("/Samples");

                if (!aData || !Array.isArray(aData)) {
                    sap.m.MessageBox.error("No data available.");
                    return;
                }

                const aSelectedRows = aData.filter(row => row.__selected);

                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row to delete.");
                    return;
                }
                if (aSelectedRows.some(row => !row.sap_uuid)) {
                    sap.m.MessageBox.warning("Row not saved to delete.");
                    return;
                }



                sap.m.MessageBox.confirm(
                    `Are you sure you want to delete ${aSelectedRows.length} selected row(s)?`,
                    {
                        title: "Confirm Deletion",
                        actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
                        onClose: function (oAction) {
                            if (oAction !== sap.m.MessageBox.Action.OK) return;

                            sap.ui.core.BusyIndicator.show(0);

                            const aDeletePromises = aSelectedRows.map(row => {
                                return new Promise((resolve, reject) => {
                                    if (!row.sap_uuid) {
                                        reject("Missing sap_uuid for deletion.");
                                        return;
                                    }

                                    const sKeyPath = `/ZC_DIRECT_TRANSFER_POSTING(sap_uuid='${row.sap_uuid}')`;

                                    oModel.remove(sKeyPath, {
                                        success: resolve,
                                        error: reject
                                    });
                                });
                            });

                            Promise.allSettled(aDeletePromises).then(results => {
                                sap.ui.core.BusyIndicator.hide();

                                const aFailed = results.filter(r => r.status === "rejected");
                                const aSuccess = results.filter(r => r.status === "fulfilled");

                                // Remove deleted rows from TabModel local data
                                const aRemainingData = aData.filter(row => !row.__selected || !row.sap_uuid);
                                oTabModel.setProperty("/Samples", aRemainingData);

                                if (aSuccess.length > 0) {
                                    sap.m.MessageToast.show(`${aSuccess.length} row(s) deleted successfully.`);
                                }

                                if (aFailed.length > 0) {
                                    sap.m.MessageBox.error(`${aFailed.length} row(s) failed to delete.`);
                                    console.error("Deletion errors:", aFailed);
                                }
                            });
                        }
                    }
                );
            },









            onStockTransferMaterialValueHelp: function (oEvent) {
                this._oInputField = oEvent.getSource();
                var oView = this.getView();

                // Show loading
                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading materials...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                var that = this;

                // Read OData
                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    urlParameters: {
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        // Process data
                        var aAll = oData.results.map(function (item) {
                            return {
                                Product: (item.Product || "").trim(),
                                ProductName: item.ProductName || "",
                                BaseUnit: item.BaseUnit || "",
                                Plant: item.Plant || "",
                                // StorageLocation: item.StorageLocation || ""
                            };
                        });
                        console.log("Material Value Help Loaded:", aAll.length, "records");

                        // Create JSON model
                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            Products: aAll
                        });

                        // Load and configure ValueHelpDialog
                        that.loadFragment({
                            name: "bando.view.CommonFragments.Stock_transfer.StockDirect.stockTransferMaterial"
                        }).then(function (oDialog) {
                            that._oStockTransferMaterialDialog = oDialog;
                            that.getView().addDependent(oDialog);

                            // Set the model for the dialog
                            oDialog.setModel(oJSONModel, "VHModel");

                            // Configure table binding
                            that._configureValueHelpDialogTable(oDialog, aAll);

                            oDialog.open();
                        }).catch(function (oError) {
                            that._oBusyDialog.close();
                            sap.m.MessageToast.show("Error loading value help dialog");
                            console.error(oError);
                        });
                    },
                    error: function () {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Error fetching materials from OData");
                    }
                });
            },

            _configureValueHelpDialogTable: function (oDialog, aData) {
                oDialog.getTableAsync().then(function (oTable) {
                    // Set model for the table
                    var oModel = new sap.ui.model.json.JSONModel({ Products: aData });
                    oTable.setModel(oModel, "VHModel");

                    if (oTable.setGrowing) {
                        oTable.setGrowing(false);
                    }

                    // For sap.ui.table.Table (Desktop)
                    if (oTable.bindRows) {
                        oTable.bindAggregation("rows", {
                            path: "VHModel>/Products"
                        });

                        // Define columns
                        var aColumns = [
                            { label: "Material Code", template: new sap.m.Text({ text: "{VHModel>Product}" }) },
                            { label: "Description", template: new sap.m.Text({ text: "{VHModel>ProductName}" }) },
                            { label: "Base Unit", template: new sap.m.Text({ text: "{VHModel>BaseUnit}" }) },
                            { label: "Plant", template: new sap.m.Text({ text: "{VHModel>Plant}" }) },
                            // { label: "Storage Location", template: new sap.m.Text({ text: "{VHModel>StorageLocation}" }) }
                        ];

                        aColumns.forEach(function (oColConfig) {
                            var oColumn = new sap.ui.table.Column({
                                label: new sap.m.Label({ text: oColConfig.label }),
                                template: oColConfig.template
                            });
                            oTable.addColumn(oColumn);
                        });
                    }

                    // For sap.m.Table (Mobile)
                    if (oTable.bindItems) {
                        oTable.bindAggregation("items", {
                            path: "VHModel>/Products",
                            template: new sap.m.ColumnListItem({
                                cells: [
                                    new sap.m.Text({ text: "{VHModel>Product}" }),
                                    new sap.m.Text({ text: "{VHModel>ProductName}" }),
                                    new sap.m.Text({ text: "{VHModel>BaseUnit}" }),
                                    new sap.m.Text({ text: "{VHModel>Plant}" }),
                                    // new sap.m.Text({ text: "{VHModel>StorageLocation}" })
                                ]
                            })
                        });

                        // Add columns
                        var aColumnHeaders = ["Material Code", "Description", "Base Unit", "Plant"];
                        aColumnHeaders.forEach(function (sHeader) {
                            oTable.addColumn(new sap.m.Column({
                                header: new sap.m.Label({ text: sHeader })
                            }));
                        });
                    }
                });
            },

            onStockTransferMaterialFilterSearch: function (oEvent) {
                var sSearchQuery = oEvent.getParameter("searchQuery"),
                    aSelectionSet = oEvent.getParameter("selectionSet"),
                    aFilterStrings = [];

                // Filter bar values
                aSelectionSet.forEach(function (oControl) {
                    var v = oControl.getValue();
                    if (v) {
                        aFilterStrings.push(`substringof('${v}', ${oControl.getName()})`);
                    }
                });

                // Global search
                if (sSearchQuery) {
                    aFilterStrings.push(
                        "(substringof('" + sSearchQuery + "', Product) or " +
                        " substringof('" + sSearchQuery + "', ProductName) or " +
                        " substringof('" + sSearchQuery + "', Plant) or " +
                        " substringof('" + sSearchQuery + "', BaseUnit))"
                    );
                }

                var sFilterQuery = aFilterStrings.join(" and ");

                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                var that = this;

                this._oBusyDialog.open();

                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    urlParameters: {
                        "$filter": sFilterQuery,
                        "$top": 9999
                    },
                    success: function (oData) {
                        that._oBusyDialog.close();

                        var oJSON = new sap.ui.model.json.JSONModel({ Products: oData.results });

                        var oDialog = that._oStockTransferMaterialDialog;
                        oDialog.setModel(oJSON, "VHModel");

                        oDialog.getTableAsync().then(function (oTable) {
                            oTable.setModel(oJSON, "VHModel");

                            if (oTable.bindRows) {
                                oTable.bindRows("VHModel>/Products");
                            }
                            if (oTable.bindItems) {
                                oTable.bindItems({
                                    path: "VHModel>/Products",
                                    template: oTable.getBindingInfo("items").template
                                });
                            }
                        });
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        console.error(oError);
                        sap.m.MessageToast.show("Search failed.");
                    }
                });
            },

            onStockTransferMaterialOkPress: function (oEvent) {
                var aTokens = oEvent.getParameter("tokens");

                if (aTokens && aTokens.length > 0) {
                    var oSelectedItem = aTokens[0];
                    var sProduct = oSelectedItem.getKey();
                    var sProductName = oSelectedItem.getText();

                    // Extract ProductName if it's in "Description (Code)" format
                    let parts = sProductName.split("(");
                    let sDescription = parts[0].trim();

                    if (this._oInputField) {
                        var oRowCtx = this._oInputField.getBindingContext("TabModel");
                        if (oRowCtx) {
                            // Map the selected values back to your table row
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/material", sProduct);
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/description", sDescription);
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/fromstorageloc", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/fromstorageloc", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/tostoragelocation", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/frombatch", "");
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/vendorbatch", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/Batchqty", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/isbatchmanagementrequired", "");
                            // oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/tostoragelocation", "");

                            // Optional: If you need to fetch additional data like UOM, you can do it here
                            this._fetchAdditionalMaterialData(sProduct, oRowCtx);
                        }
                    }
                }

                this._oStockTransferMaterialDialog.close();
            },

            onStockTransferMaterialCancelPress: function () {
                if (this._oStockTransferMaterialDialog) {
                    this._oStockTransferMaterialDialog.close();
                }
            },

            onStockTransferMaterialAfterClose: function () {
                if (this._oStockTransferMaterialDialog) {
                    this._oStockTransferMaterialDialog.destroy();
                    this._oStockTransferMaterialDialog = null;
                }
            },

            // Optional: Method to fetch additional material data if needed
            _fetchAdditionalMaterialData: function (sMaterial, oRowCtx) {
                var oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    filters: [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial)
                    ],
                    success: function (oData) {
                        if (oData.results && oData.results.length > 0) {
                            var oMaterialData = oData.results[0];
                            oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/uom", oMaterialData.BaseUnit || "");
                            // Set other properties as needed
                        }
                    },
                    error: function () {
                        console.error("Error fetching additional material data");
                    }
                });
            },


            // plant






            onStockTransferPlantValueHelp: function (oEvent) {
                sap.ui.core.BusyIndicator.show();

                const oInput = oEvent.getSource();
                const oView = this.getView();
                const oContext = oInput.getBindingContext("TabModel");
                const that = this;

                // 🟩 Identify which field triggered (fromplant or toplant)
                this._sPlantField = oInput.getBindingInfo("value").parts[0].path;

                if (!oContext) {
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                const sRowPath = oContext.getPath();
                const oRowData = oContext.getObject();
                this._oEventModelRowPath = sRowPath;
                this._oEventModelRowData = oRowData;

                // 🟨 Require a material first
                if (!oRowData.material) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🧩 Lazy load the Plant fragment only once
                if (!this._oStockTransferPlantDialog) {
                    this._oStockTransferPlantDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferPlant",
                        this
                    );
                    oView.addDependent(this._oStockTransferPlantDialog);
                }

                const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");
                const aFilters = [
                    new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.material)
                ];

                // 🟦 Read all plant records for the selected material
                oModel.read("/ZC_STOCK_TRANSFER_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        const aPlantData = oData.results.map(function (item) {
                            return {
                                Product: (item.Product || "").trim(),
                                Plant: item.Plant || "",
                                StorageLocation: item.StorageLocation || ""
                            };
                        });

                        // 🧠 Remove duplicates (optional)
                        // const aUnique = aPlantData.filter((v, i, a) => a.findIndex(t => t.Plant === v.Plant) === i);

                        const oJSON = new sap.ui.model.json.JSONModel({ Plants: aPlantData });
                        that._oStockTransferPlantDialog.setModel(oJSON, "VHModel");

                        that._oStockTransferPlantDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Plant data from OData");
                    }
                });
            },

            // 🔍 Search inside Plant dialog
            onStockTransferPlantSearch: function (oEvent) {
                const sValue = oEvent.getParameter("newValue");
                const oTable = sap.ui.getCore().byId("idStockTransferPlantTable");
                if (!oTable) return;

                const oBinding = oTable.getBinding("items");
                if (sValue) {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            // ✅ When user selects a plant
            onStockTransferPlantSelected: function (oEvent) {
                const oSelectedItem = oEvent.getSource();
                const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

                const oModel = this.getView().getModel("TabModel");
                const oRow = oModel.getProperty(this._oEventModelRowPath);

                // 🟢 Push selected values based on triggering field
                if (this._sPlantField === "fromplant") {
                    oRow.fromplant = oCtx.Plant;
                    // oRow.fromstorageloc = oCtx.StorageLocation;
                } else if (this._sPlantField === "toplant") {
                    oRow.toplant = oCtx.Plant;
                    // oRow.tostorageloc = oCtx.StorageLocation;
                }

                oModel.refresh(true);
                this._oStockTransferPlantDialog.close();
            },

            // ❌ Close dialog
            onStockTransferPlantVHClose: function () {
                if (this._oStockTransferPlantDialog) {
                    this._oStockTransferPlantDialog.close();
                }
            },






            // onStockTransferStorageValueHelp: function (oEvent) {
            //     sap.ui.core.BusyIndicator.show();

            //     const oInput = oEvent.getSource();
            //     const oView = this.getView();
            //     const oContext = oInput.getBindingContext("TabModel");
            //     const that = this;

            //     // 🟩 Determine which input triggered (fromstorgaeloc or tostoragelocation)
            //     this._sStorageField = oInput.getBindingInfo("value").parts[0].path;

            //     if (!oContext) {
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     const sRowPath = oContext.getPath();
            //     const oRowData = oContext.getObject();
            //     this._oEventModelRowPath = sRowPath;
            //     this._oEventModelRowData = oRowData;

            //     // 🟩 Require material first
            //     if (!oRowData.material) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     // 🟩 Get relevant plant based on which input triggered
            //     const sRelevantPlant =
            //         this._sStorageField === "fromstorageloc"
            //             ? oRowData.fromplant
            //             : oRowData.toplant;

            //     if (!sRelevantPlant) {
            //         const sSide =
            //             this._sStorageField === "fromstorageloc" ? "From" : "To";
            //         sap.m.MessageBox.information(`Please select a ${sSide} Plant first.`);
            //         sap.ui.core.BusyIndicator.hide();
            //         return;
            //     }

            //     // 🟩 Define filters for OData call
            //     const oMatFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.material);
            //     const oPlantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sRelevantPlant);

            //     // 🟩 Lazy load the fragment only once
            //     if (!this._oStockTransferStorageDialog) {
            //         this._oStockTransferStorageDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage",
            //             this
            //         );
            //         oView.addDependent(this._oStockTransferStorageDialog);
            //     }

            //     const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

            //     // 🟩 Read OData with both filters
            //     oModel.read("/ZC_STOCK_STORAGE_LOC", {
            //         filters: [oMatFilter, oPlantFilter],
            //         success: function (oData) {
            //             const aStorageLocs = oData.results.map(item => ({
            //                 Product: (item.Product || "").trim(),
            //                 Plant: item.Plant || "",
            //                 StorageLocation: item.StorageLocation || ""
            //             }));

            //             const oJSON = new sap.ui.model.json.JSONModel({ StorageLocs: aStorageLocs });
            //             that._oStockTransferStorageDialog.setModel(oJSON, "VHModel");

            //             that._oStockTransferStorageDialog.open();
            //             sap.ui.core.BusyIndicator.hide();
            //         },
            //         error: function () {
            //             sap.ui.core.BusyIndicator.hide();
            //             sap.m.MessageToast.show("Error fetching Storage Location data from OData");
            //         }
            //     });
            // },
            onStockTransferStorageValueHelp: function (oEvent) {
                sap.ui.core.BusyIndicator.show();

                const oInput = oEvent.getSource();
                const oView = this.getView();
                const oContext = oInput.getBindingContext("TabModel");
                const that = this;

                // 🟩 Determine which input triggered (fromstorgaeloc or tostoragelocation)
                this._sStorageField = oInput.getBindingInfo("value").parts[0].path;

                if (!oContext) {
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                const sRowPath = oContext.getPath();
                const oRowData = oContext.getObject();
                this._oEventModelRowPath = sRowPath;
                this._oEventModelRowData = oRowData;

                // 🟩 Require material first
                if (!oRowData.material) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🟩 Get relevant plant based on which input triggered
                const sRelevantPlant =
                    this._sStorageField === "fromstorageloc"
                        ? oRowData.fromplant
                        : oRowData.toplant;

                if (!sRelevantPlant) {
                    const sSide =
                        this._sStorageField === "fromstorageloc" ? "From" : "To";
                    sap.m.MessageBox.information(`Please select a ${sSide} Plant first.`);
                    sap.ui.core.BusyIndicator.hide();
                    return;
                }

                // 🟩 Define filters for OData call
                const oMatFilter = new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, oRowData.material);
                const oPlantFilter = new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sRelevantPlant);

                // 🟩 Lazy load the fragment only once with proper cleanup
                if (!this._oStockTransferStorageDialog) {
                    // Use Fragment.load instead of sap.ui.xmlfragment for better lifecycle management
                    sap.ui.core.Fragment.load({
                        id: oView.getId(),
                        name: "bando.view.CommonFragments.Stock_transfer.StockRequest.stockTransferStorage",
                        controller: this
                    }).then(function (oDialog) {
                        that._oStockTransferStorageDialog = oDialog;
                        oView.addDependent(that._oStockTransferStorageDialog);

                        // Now proceed with data loading
                        that._loadStorageLocationData(oMatFilter, oPlantFilter);
                    }).catch(function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        console.error("Error loading fragment:", oError);
                    });
                } else {
                    // Fragment already exists, just load the data
                    this._loadStorageLocationData(oMatFilter, oPlantFilter);
                }
            },

            // 🔄 Helper function to load data
            _loadStorageLocationData: function (oMatFilter, oPlantFilter) {
                const that = this;
                const oModel = this.getView().getModel("ZSB_STOCK_TRANSFER_F4");

                // 🟩 Read OData with both filters
                oModel.read("/ZC_STOCK_STORAGE_LOC", {
                    filters: [oMatFilter, oPlantFilter],
                    success: function (oData) {
                        const aStorageLocs = oData.results.map(item => ({
                            Product: (item.Product || "").trim(),
                            Plant: item.Plant || "",
                            StorageLocation: item.StorageLocation || ""
                        }));

                        const oJSON = new sap.ui.model.json.JSONModel({ StorageLocs: aStorageLocs });
                        that._oStockTransferStorageDialog.setModel(oJSON, "VHModel");

                        that._oStockTransferStorageDialog.open();
                        sap.ui.core.BusyIndicator.hide();
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                        sap.m.MessageToast.show("Error fetching Storage Location data from OData");
                    }
                });
            },

            // 🔍 Live Search inside fragment
            onStockTransferStorageSearch: function (oEvent) {
                const sValue = oEvent.getParameter("newValue");
                const oTable = sap.ui.getCore().byId("idStockTransferStorageTable");

                if (!oTable) return;

                const oBinding = oTable.getBinding("items");

                if (sValue) {
                    const aFilters = [
                        new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            // ✅ When user selects a storage location
            // onStockTransferStorageSelected: function (oEvent) {
            //     const oSelectedItem = oEvent.getSource();
            //     const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();

            //     const oModel = this.getView().getModel("TabModel");
            //     const oRow = oModel.getProperty(this._oEventModelRowPath);

            //     // Dynamically assign based on which input triggered
            //     if (this._sStorageField === "fromstorageloc") {
            //         oRow.fromstorageloc = oCtx.StorageLocation;
            //     } else if (this._sStorageField === "tostoragelocation") {
            //         oRow.tostoragelocation = oCtx.StorageLocation;
            //     }

            //     oModel.refresh(true);
            //     this._oStockTransferStorageDialog.close();
            // },

            onStockTransferStorageSelected: function (oEvent) {
                const oSelectedItem = oEvent.getSource();
                const oCtx = oSelectedItem.getBindingContext("VHModel").getObject();
                const sSelectedStorage = oCtx.StorageLocation;

                const oModel = this.getView().getModel("TabModel");
                const oRow = oModel.getProperty(this._oEventModelRowPath);

                // Store original values for comparison
                const sOriginalFrom = oRow.fromstorageloc;
                const sOriginalTo = oRow.tostoragelocation;

                // Check which field is being updated
                if (this._sStorageField === "fromstorageloc") {
                    // If the selected value is same as current 'to' value
                    if (sSelectedStorage && sSelectedStorage === sOriginalTo) {
                        // DON'T set the new value, keep field empty or show warning
                        sap.m.MessageBox.warning(
                            "Cannot select same storage location '" + sSelectedStorage +
                            "' for both From and To fields.\n\n" +
                            "Please select a different storage location.",
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Duplicate Storage Location"
                            }
                        );
                        // Optionally clear the field to ensure it's empty
                        oRow.fromstorageloc = "";
                    } else {
                        // Only set if not a duplicate
                        oRow.fromstorageloc = sSelectedStorage;
                    }
                } else if (this._sStorageField === "tostoragelocation") {
                    // If the selected value is same as current 'from' value
                    if (sSelectedStorage && sSelectedStorage === sOriginalFrom) {
                        // DON'T set the new value, keep field empty or show warning
                        sap.m.MessageBox.warning(
                            "Cannot select same storage location '" + sSelectedStorage +
                            "' for both From and To fields.\n\n" +
                            "Please select a different storage location.",
                            {
                                icon: sap.m.MessageBox.Icon.WARNING,
                                title: "Duplicate Storage Location"
                            }
                        );
                        // Optionally clear the field to ensure it's empty
                        oRow.tostoragelocation = "";
                    } else {
                        // Only set if not a duplicate
                        oRow.tostoragelocation = sSelectedStorage;
                    }
                }

                oModel.refresh(true);
                this._oStockTransferStorageDialog.close();
            },

            // 🚪 Close handler (like Plant one)
            // onStockTransferStorageVHClose: function () {
            //     if (this._oStockTransferStorageDialog) {
            //         this._oStockTransferStorageDialog.close();
            //     }
            // },
            onStockTransferStorageVHClose: function () {
                if (this._oStockTransferStorageDialog) {
                    this._oStockTransferStorageDialog.destroy();
                    this._oStockTransferStorageDialog = null;
                }
            },




            // onTypeStorageLocationtostoragelocation: function (oEvent) {
            //     // Get the input control
            //     var oInput = oEvent.getSource();

            //     // Get the typed value
            //     var sValue = oEvent.getParameter("value");

            //     // Convert it to uppercase
            //     var sUpperCaseValue = sValue.toUpperCase();

            //     // Set the value back to the input field
            //     oInput.setValue(sUpperCaseValue);

            //     // Optional: update the model if two-way binding isn't already handling it
            //     var oContext = oInput.getBindingContext("TabModel");
            //     if (oContext) {
            //         oContext.getModel().setProperty("tostoragelocation", sUpperCaseValue, oContext);
            //     }
            // },
            // onTypeStorageLocationfromstorgaeloc: function (oEvent) {
            //     // Get the input control
            //     var oInput = oEvent.getSource();

            //     // Get the typed value
            //     var sValue = oEvent.getParameter("value");

            //     // Convert it to uppercase
            //     var sUpperCaseValue = sValue.toUpperCase();

            //     // Set the value back to the input field
            //     oInput.setValue(sUpperCaseValue);

            //     // Optional: update the model if two-way binding isn't already handling it
            //     var oContext = oInput.getBindingContext("TabModel");
            //     if (oContext) {
            //         oContext.getModel().setProperty("fromstorageloc", sUpperCaseValue, oContext);
            //     }
            // },
            onTypeStorageLocationfromstorgaeloc: function (oEvent) {
                // Get the input control
                var oInput = oEvent.getSource();

                // Get the typed value
                var sValue = oEvent.getParameter("value");

                // Convert it to uppercase
                var sUpperCaseValue = sValue.toUpperCase();

                // Set the value back to the input field
                oInput.setValue(sUpperCaseValue);

                // Get the context and row data
                var oContext = oInput.getBindingContext("TabModel");
                if (oContext) {
                    var oRow = oContext.getObject();

                    // Check if typed value matches the 'to' storage location
                    if (sUpperCaseValue && sUpperCaseValue === oRow.tostoragelocation) {
                        // Show warning message
                        sap.m.MessageToast.show("Cannot use same storage location as To Storage Location");

                        // Clear the current input field
                        sUpperCaseValue = "";
                        oInput.setValue("");
                    }

                    // Update the model with the (potentially cleared) value
                    oContext.getModel().setProperty("fromstorageloc", sUpperCaseValue, oContext);
                }
            },

            onTypeStorageLocationtostoragelocation: function (oEvent) {
                // Get the input control
                var oInput = oEvent.getSource();

                // Get the typed value
                var sValue = oEvent.getParameter("value");

                // Convert it to uppercase
                var sUpperCaseValue = sValue.toUpperCase();

                // Set the value back to the input field
                oInput.setValue(sUpperCaseValue);

                // Get the context and row data
                var oContext = oInput.getBindingContext("TabModel");
                if (oContext) {
                    var oRow = oContext.getObject();

                    // Check if typed value matches the 'from' storage location
                    if (sUpperCaseValue && sUpperCaseValue === oRow.fromstorageloc) {
                        // Show warning message
                        sap.m.MessageToast.show("Cannot use same storage location as From Storage Location");

                        // Clear the current input field
                        sUpperCaseValue = "";
                        oInput.setValue("");
                    }

                    // Update the model with the (potentially cleared) value
                    oContext.getModel().setProperty("tostoragelocation", sUpperCaseValue, oContext);
                }
            },





            // onBatchFragmentOpen: function (oEvent) {
            //     this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
            //     var oView = this.getView();
            //     var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
            //     var oRow = oCtx.getObject();

            //     // 🟩 Ensure material is selected first
            //     if (!oRow.material) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         return;
            //     }

            //     // 🟩 Ensure Plant is selected if required
            //     if (!oRow.fromplant && !oRow.toplant) {
            //         sap.m.MessageBox.information("Please select a Plant first.");
            //         return;
            //     }
            //     // 🟩 Ensure Storage Location is selected if available
            //     if (!oRow.fromstorageloc) {
            //         sap.m.MessageBox.information("Please select a Storage Location first.");
            //         return;
            //     }

            //     // Lazy-load fragment
            //     if (!this._oStockTransferBatchDialog) {
            //         this._oStockTransferBatchDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
            //             this
            //         );
            //         oView.addDependent(this._oStockTransferBatchDialog);
            //     }

            //     // Load data before opening - using material, plant and storage location from current row
            //     this._loadStockTransferBatchData(oRow.material, oRow.fromplant || oRow.toplant, oRow.fromstorageloc);
            // },





            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     const oBatchModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB");
            //     const oStockModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }

            //     this._oBusyDialog.open();

            //     // Build filters for both services
            //     const aBatchFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];
            //     debugger

            //     const aStockFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant)
            //     ];

            //     // Read from both OData services
            //     Promise.all([
            //         new Promise((resolve, reject) => {
            //             oBatchModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
            //                 filters: aBatchFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         }),
            //         new Promise((resolve, reject) => {
            //             oStockModel.read("/ZC_STOCK_BATCH", {
            //                 filters: aStockFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         })
            //     ]).then(function (results) {
            //         that._oBusyDialog.close();

            //         const oBatchData = results[0];
            //         const oStockData = results[1];

            //         console.log("✅ Batch data received:", oBatchData);
            //         console.log("✅ Stock data received:", oStockData);

            //         // Create a map of batch numbers to shelf life expiration dates
            //         const oShelfLifeMap = {};
            //         oStockData.results.forEach(function (item) {
            //             if (item.Batch) {
            //                 oShelfLifeMap[item.Batch] = item.ShelfLifeExpirationDate ?
            //                     new Date(item.ShelfLifeExpirationDate) : null;
            //             }
            //         });

            //         // Merge batch data with shelf life information
            //         const aMergedBatches = oBatchData.results.map(function (batchItem) {
            //             return {
            //                 ...batchItem,
            //                 ShelfLifeExpirationDate: oShelfLifeMap[batchItem.Batch] || null
            //             };
            //         });

            //         // Create JSON model from merged data
            //         const oJSONModel = new sap.ui.model.json.JSONModel({
            //             Batches: aMergedBatches
            //         });

            //         // Set model to the fragment dialog
            //         that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //         console.log("✅ Bound rows with shelf life data:", oJSONModel.getData());

            //         // Open the dialog
            //         that._oStockTransferBatchDialog.open();
            //     }).catch(function (oError) {
            //         that._oBusyDialog.close();
            //         sap.m.MessageToast.show("Failed to load batch data.");
            //         console.error("❌ OData Error:", oError);
            //     });
            // },

            // ==================================================================
            // ===============BATCH FRAGMENT BEGIN===============================
            // ==================================================================

            // onBatchFragmentOpen: function (oEvent) {
            //     this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
            //     var oView = this.getView();
            //     var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
            //     var oRow = oCtx.getObject();

            //     // 🟩 Ensure material is selected first
            //     if (!oRow.material) {
            //         sap.m.MessageBox.information("Please select a Material first.");
            //         return;
            //     }

            //     // Get the binding path to determine if it's frombatch or tobatch
            //     var sBindingPath = this._oBatchInputSource.getBindingPath("value");

            //     // Determine which batch field was clicked
            //     var isFromBatch = false;
            //     var isToBatch = false;

            //     // Check by looking at the parent column tooltip
            //     var oParent = this._oBatchInputSource.getParent();
            //     while (oParent) {
            //         if (oParent.getTooltip) {
            //             var sTooltip = oParent.getTooltip();
            //             if (sTooltip && sTooltip.includes("From Batch")) {
            //                 isFromBatch = true;
            //                 break;
            //             } else if (sTooltip && sTooltip.includes("To Batch")) {
            //                 isToBatch = true;
            //                 break;
            //             }
            //         }
            //         oParent = oParent.getParent();
            //     }

            //     // If we couldn't determine by tooltip, try by binding context
            //     if (!isFromBatch && !isToBatch) {
            //         // Check the actual value in the row to see which field is empty
            //         // This is a fallback method
            //         var sCurrentValue = this._oBatchInputSource.getValue();
            //         if (!sCurrentValue) {
            //             // If both fields are empty, we need another way
            //             // Let's check which column this input is in based on its position
            //             // For now, let's use a simple approach
            //             if (sBindingPath === "frombatch" || (oRow.frombatch === "" || oRow.frombatch === undefined)) {
            //                 isFromBatch = true;
            //             } else if (sBindingPath === "tobatch" || (oRow.tobatch === "" || oRow.tobatch === undefined)) {
            //                 isToBatch = true;
            //             }
            //         }
            //     }

            //     var sPlant, sStorageLoc;

            //     if (isFromBatch) {
            //         // For From Batch: use fromplant and fromstorageloc
            //         if (!oRow.fromplant) {
            //             sap.m.MessageBox.information("Please select a From Plant first.");
            //             return;
            //         }
            //         if (!oRow.fromstorageloc) {
            //             sap.m.MessageBox.information("Please select a From Storage Location first.");
            //             return;
            //         }
            //         sPlant = oRow.fromplant;
            //         sStorageLoc = oRow.fromstorageloc;
            //     } else if (isToBatch) {
            //         // For To Batch: use toplant and tostoragelocation
            //         if (!oRow.toplant) {
            //             sap.m.MessageBox.information("Please select a To Plant first.");
            //             return;
            //         }
            //         if (!oRow.tostoragelocation) {
            //             sap.m.MessageBox.information("Please select a To Storage Location first.");
            //             return;
            //         }
            //         sPlant = oRow.toplant;
            //         sStorageLoc = oRow.tostoragelocation;
            //     } else {
            //         // If we still can't determine, show a better error
            //         console.error("Cannot determine batch field type. Binding path:", sBindingPath);
            //         sap.m.MessageBox.information("Please ensure you have selected the correct Plant and Storage Location first.");
            //         return;
            //     }

            //     // Lazy-load fragment
            //     if (!this._oStockTransferBatchDialog) {
            //         this._oStockTransferBatchDialog = sap.ui.xmlfragment(
            //             "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
            //             this
            //         );
            //         oView.addDependent(this._oStockTransferBatchDialog);
            //     }

            //     // Load data before opening - using material, plant and storage location from current row
            //     this._loadStockTransferBatchData(oRow.material, sPlant, sStorageLoc);
            // },


            onBatchFragmentOpen: function (oEvent) {
                this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
                var oView = this.getView();
                var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
                var oRow = oCtx.getObject();

                // 🟩 Ensure material is selected first
                if (!oRow.material) {
                    sap.m.MessageBox.information("Please select a Material first.");
                    return;
                }

                // 🟩 Ensure Plant is selected if required
                if (!oRow.fromplant) {
                    sap.m.MessageBox.information("Please select a Plant first.");
                    return;
                }
                // 🟩 Ensure Storage Location is selected if available
                if (!oRow.fromstorageloc) {
                    sap.m.MessageBox.information("Please select a Storage Location first.");
                    return;
                }
                // debugger

                // Lazy-load fragment
                if (!this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog = sap.ui.xmlfragment(
                        "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
                        this
                    );
                    oView.addDependent(this._oStockTransferBatchDialog);
                }
                // debugger
                // Load data before opening - using material, plant and storage location from current row
                this._loadStockTransferBatchData(oRow.material, oRow.fromplant, oRow.fromstorageloc);
                // debugger
            },

            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     const oBatchModel = oView.getModel("ZCE_BATCH_MATNR_F4_SRVB");
            //     const oStockModel = oView.getModel("ZSB_STOCK_TRANSFER_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }

            //     this._oBusyDialog.open();

            //     // Build filters for both services
            //     const aBatchFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     const aStockFilters = [
            //         new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant)
            //     ];
            //     // debugger

            //     // Read from both OData services
            //     Promise.all([
            //         new Promise((resolve, reject) => {
            //             oBatchModel.read("/ZCE_BATCH_BASE_MATNR_F4", {
            //                 filters: aBatchFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         }),
            //         new Promise((resolve, reject) => {
            //             oStockModel.read("/ZC_STOCK_BATCH", {
            //                 filters: aStockFilters,
            //                 success: resolve,
            //                 error: reject
            //             });
            //         })
            //     ]).then(function (results) {
            //         that._oBusyDialog.close();

            //         const oBatchData = results[0];
            //         const oStockData = results[1];

            //         console.log("✅ Batch data received:", oBatchData);
            //         console.log("✅ Stock data received:", oStockData);

            //         // Create a map of ALL properties from stock data keyed by Batch
            //         const oStockDataMap = {};
            //         oStockData.results.forEach(function (item) {
            //             if (item.Batch) {
            //                 // Store all properties from stock data for this batch
            //                 oStockDataMap[item.Batch] = {
            //                     ...item, // Spread all properties from stock data item
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             }
            //         });

            //         // 🛠 FILTER MANUALLY BY STORAGE LOCATION (Backend not filtering)
            //         const aFilteredBatchData = oBatchData.results.filter(function (batchItem) {
            //             return batchItem.StorageLocation === sStorageLoc;
            //         });

            //         console.log("🔍 Filtered batch data (Frontend Filter Applied):", aFilteredBatchData);

            //         // Merge batch data with ALL stock data properties
            //         const aMergedBatches = aFilteredBatchData.map(function (batchItem) {
            //             const stockItem = oStockDataMap[batchItem.Batch] || {};
            //             return {
            //                 ...batchItem,  // Batch data properties
            //                 ...stockItem   // Stock data properties (will override batch data if same property names)
            //             };
            //         });

            //         // Create JSON model from merged data
            //         const oJSONModel = new sap.ui.model.json.JSONModel({
            //             Batches: aMergedBatches
            //         });

            //         // Set model to the fragment dialog
            //         that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //         console.log("✅ Bound rows with merged data:", oJSONModel.getData());

            //         // Debug: Check if BatchBySupplier is in the merged data
            //         console.log("🔍 Sample merged item:", aMergedBatches.length > 0 ? aMergedBatches[0] : "No data");
            //         if (aMergedBatches.length > 0) {
            //             console.log("🔍 BatchBySupplier value in merged data:", aMergedBatches[0].BatchBySupplier);
            //         }

            //         // Open the dialog
            //         that._oStockTransferBatchDialog.open();

            //     }).catch(function (oError) {
            //         that._oBusyDialog.close();
            //         sap.m.MessageToast.show("Failed to load batch data.");
            //         console.error("❌ OData Error:", oError);
            //     });
            // },
            // _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
            //     const oView = this.getView();
            //     // Use the new single OData model
            //     const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
            //     const that = this;

            //     // Busy Dialog
            //     if (!this._oBusyDialog) {
            //         this._oBusyDialog = new sap.m.BusyDialog({
            //             text: "Loading batches...",
            //             title: "Please wait"
            //         });
            //     }
            //     this._oBusyDialog.open();

            //     // Build filters for the new service (property names: Product, Plant, StorageLocation)
            //     const aFilters = [
            //         new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
            //         new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
            //         new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
            //     ];

            //     // Read from the new entity set "/ZC_STOCK_BATCH_F4"
            //     oBatchModel.read("/ZC_STOCK_BATCH_F4", {
            //         filters: aFilters,
            //         success: function (oData) {
            //             that._oBusyDialog.close();

            //             console.log("✅ Batch/Stock data received:", oData);

            //             const aRawData = oData.results || [];

            //             // Map fields to match fragment expectations:
            //             // - Product -> Material (fragment uses BatchModel>Material)
            //             // - Supplier -> BatchBySupplier (fragment uses BatchModel>BatchBySupplier)
            //             // - Keep all other fields as they are
            //             const aMappedBatches = aRawData.map(function (item) {
            //                 return {
            //                     ...item,                                    // keep all original fields
            //                     Material: item.Product || "",               // map Product to Material
            //                     BatchBySupplier: item.Supplier || "",       // map Supplier to BatchBySupplier
            //                     ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
            //                         new Date(item.ShelfLifeExpirationDate) : null
            //                 };
            //             });

            //             // Create JSON model for the fragment table
            //             const oJSONModel = new sap.ui.model.json.JSONModel({
            //                 Batches: aMappedBatches
            //             });

            //             that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
            //             console.log("✅ Bound rows with mapped data:", oJSONModel.getData());

            //             // Open the dialog
            //             that._oStockTransferBatchDialog.open();
            //         },
            //         error: function (oError) {
            //             that._oBusyDialog.close();
            //             sap.m.MessageToast.show("Failed to load batch data.");
            //             console.error("❌ OData Error:", oError);
            //         }
            //     });
            // },
            _loadStockTransferBatchData: function (sMaterial, sPlant, sStorageLoc) {
                const oView = this.getView();
                const oBatchModel = oView.getModel("ZSB_STOCK_BATCH_F4");
                const that = this;

                if (!this._oBusyDialog) {
                    this._oBusyDialog = new sap.m.BusyDialog({
                        text: "Loading batches...",
                        title: "Please wait"
                    });
                }
                this._oBusyDialog.open();

                const aFilters = [
                    new sap.ui.model.Filter("Product", sap.ui.model.FilterOperator.EQ, sMaterial),
                    new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.EQ, sPlant),
                    new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.EQ, sStorageLoc)
                ];

                oBatchModel.read("/ZC_STOCK_BATCH_F4", {
                    filters: aFilters,
                    success: function (oData) {
                        that._oBusyDialog.close();

                        console.log("✅ Batch/Stock data received:", oData);

                        const aRawData = oData.results || [];

                        // 🔁 Deduplicate by Batch (keep first occurrence)
                        const uniqueMap = new Map();
                        for (const item of aRawData) {
                            if (!uniqueMap.has(item.Batch)) {
                                // Map fields for fragment compatibility
                                const mappedItem = {
                                    ...item,
                                    Material: item.Product || "",               // for column "Material"
                                    BatchBySupplier: item.Supplier || "",       // for column "BatchBySupplier"
                                    ShelfLifeExpirationDate: item.ShelfLifeExpirationDate ?
                                        new Date(item.ShelfLifeExpirationDate) : null
                                };
                                uniqueMap.set(item.Batch, mappedItem);
                            }
                        }

                        const aUniqueBatches = Array.from(uniqueMap.values());
                        console.log(`✅ Deduplicated: ${aRawData.length} → ${aUniqueBatches.length} unique batches`);

                        const oJSONModel = new sap.ui.model.json.JSONModel({
                            Batches: aUniqueBatches
                        });

                        that._oStockTransferBatchDialog.setModel(oJSONModel, "BatchModel");
                        console.log("✅ Bound rows with unique batches:", oJSONModel.getData());

                        that._oStockTransferBatchDialog.open();
                    },
                    error: function (oError) {
                        that._oBusyDialog.close();
                        sap.m.MessageToast.show("Failed to load batch data.");
                        console.error("❌ OData Error:", oError);
                    }
                });
            },

            // Optional: Add search function for the new field
            onStockTransferBatchSearch: function (oEvent) {
                var sValue = oEvent.getParameter("newValue");
                var oTable = sap.ui.getCore().byId("idStockTransferBatchTable");
                if (!oTable) return;

                var oBinding = oTable.getBinding("items");

                if (sValue) {
                    var aFilters = [
                        new sap.ui.model.Filter("Material", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Batch", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("Plant", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("StorageLocation", sap.ui.model.FilterOperator.Contains, sValue),
                        new sap.ui.model.Filter("ShelfLifeExpirationDate", sap.ui.model.FilterOperator.Contains, sValue)
                    ];
                    oBinding.filter([new sap.ui.model.Filter({ filters: aFilters, and: false })]);
                } else {
                    oBinding.filter([]);
                }
            },

            onStockTransferBatchSelected: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oCtx = oSelectedItem.getBindingContext("BatchModel").getObject();

                console.log("✅ Selected batch data:", oCtx);

                // FIX: use the correct source input field variable
                if (this._oBatchInputSource) {
                    var oRowCtx = this._oBatchInputSource.getBindingContext("TabModel");

                    // Update TabModel values
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/batch", oCtx.Batch);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/storagelocation", oCtx.StorageLocation);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/hiddenqty", oCtx.MatlWrhsStkQtyInMatlBaseUnit);
                    oRowCtx.getModel().setProperty(oRowCtx.getPath() + "/vendorbatch", oCtx.BatchBySupplier || "");

                    // Update the input field UI value
                    this._oBatchInputSource.setValue(oCtx.Batch);

                    console.log("✅ Updated TabModel with batch:", oCtx.Batch, "and storage location:", oCtx.StorageLocation, "and quantity:", oCtx.MatlWrhsStkQtyInMatlBaseUnit);
                }

                // Close dialog
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },



            onStockTransferBatchVHClose: function () {
                if (this._oStockTransferBatchDialog) {
                    this._oStockTransferBatchDialog.close();
                    this._oStockTransferBatchDialog.destroy();
                    this._oStockTransferBatchDialog = null;
                }
            },


            // onBatchFragmentOpen: function (oEvent) {
            //                 this._oBatchInputSource = oEvent.getSource(); // Save for setting value later
            //                 var oView = this.getView();
            //                 var oCtx = this._oBatchInputSource.getBindingContext("TabModel");
            //                 var oRow = oCtx.getObject();

            //                 // 🟩 Ensure material is selected first
            //                 if (!oRow.material) {
            //                     sap.m.MessageBox.information("Please select a Material first.");
            //                     return;
            //                 }

            //                 // Get the binding path to determine if it's frombatch or tobatch
            //                 var sBindingPath = this._oBatchInputSource.getBindingPath("value");

            //                 // Determine which batch field was clicked
            //                 var isFromBatch = false;
            //                 var isToBatch = false;

            //                 // Check by looking at the parent column tooltip
            //                 var oParent = this._oBatchInputSource.getParent();
            //                 while (oParent) {
            //                     if (oParent.getTooltip) {
            //                         var sTooltip = oParent.getTooltip();
            //                         if (sTooltip && sTooltip.includes("From Batch")) {
            //                             isFromBatch = true;
            //                             break;
            //                         } else if (sTooltip && sTooltip.includes("To Batch")) {
            //                             isToBatch = true;
            //                             break;
            //                         }
            //                     }
            //                     oParent = oParent.getParent();
            //                 }

            //                 // If we couldn't determine by tooltip, try by binding context
            //                 if (!isFromBatch && !isToBatch) {
            //                     // Check the actual value in the row to see which field is empty
            //                     // This is a fallback method
            //                     var sCurrentValue = this._oBatchInputSource.getValue();
            //                     if (!sCurrentValue) {
            //                         // If both fields are empty, we need another way
            //                         // Let's check which column this input is in based on its position
            //                         // For now, let's use a simple approach
            //                         if (sBindingPath === "frombatch" || (oRow.frombatch === "" || oRow.frombatch === undefined)) {
            //                             isFromBatch = true;
            //                         } else if (sBindingPath === "tobatch" || (oRow.tobatch === "" || oRow.tobatch === undefined)) {
            //                             isToBatch = true;
            //                         }
            //                     }
            //                 }

            //                 var sPlant, sStorageLoc;

            //                 if (isFromBatch) {
            //                     // For From Batch: use fromplant and fromstorageloc
            //                     if (!oRow.fromplant) {
            //                         sap.m.MessageBox.information("Please select a From Plant first.");
            //                         return;
            //                     }
            //                     if (!oRow.fromstorageloc) {
            //                         sap.m.MessageBox.information("Please select a From Storage Location first.");
            //                         return;
            //                     }
            //                     sPlant = oRow.fromplant;
            //                     sStorageLoc = oRow.fromstorageloc;
            //                 } else if (isToBatch) {
            //                     // For To Batch: use toplant and tostoragelocation
            //                     if (!oRow.toplant) {
            //                         sap.m.MessageBox.information("Please select a To Plant first.");
            //                         return;
            //                     }
            //                     if (!oRow.tostoragelocation) {
            //                         sap.m.MessageBox.information("Please select a To Storage Location first.");
            //                         return;
            //                     }
            //                     sPlant = oRow.toplant;
            //                     sStorageLoc = oRow.tostoragelocation;
            //                 } else {
            //                     // If we still can't determine, show a better error
            //                     console.error("Cannot determine batch field type. Binding path:", sBindingPath);
            //                     sap.m.MessageBox.information("Please ensure you have selected the correct Plant and Storage Location first.");
            //                     return;
            //                 }

            //                 // Save which field was clicked for later use
            //                 this._batchFieldType = {
            //                     isFromBatch: isFromBatch,
            //                     isToBatch: isToBatch
            //                 };

            //                 // Lazy-load fragment
            //                 if (!this._oStockTransferBatchDialog) {
            //                     this._oStockTransferBatchDialog = sap.ui.xmlfragment(
            //                         "bando.view.CommonFragments.Stock_transfer.StockPost.stockTransferBatch",
            //                         this
            //                     );
            //                     oView.addDependent(this._oStockTransferBatchDialog);
            //                 }

            //                 // Load data before opening - using material, plant and storage location from current row
            //                 this._loadStockTransferBatchData(oRow.material, sPlant, sStorageLoc);
            //             },
            // onStockTransferBatchSelected: function (oEvent) {
            //     var oSelectedItem = oEvent.getSource();
            //     var oCtx = oSelectedItem.getBindingContext("BatchModel").getObject();

            //     console.log("✅ Selected batch data:", oCtx);

            //     // FIX: use the correct source input field variable
            //     if (this._oBatchInputSource) {
            //         var oRowCtx = this._oBatchInputSource.getBindingContext("TabModel");
            //         var oRowPath = oRowCtx.getPath();
            //         var oModel = oRowCtx.getModel();
            //         var sBatch = oCtx.Batch;

            //         // Update BOTH frombatch and tobatch fields with the selected batch
            //         oModel.setProperty(oRowPath + "/frombatch", sBatch);
            //         oModel.setProperty(oRowPath + "/tobatch", sBatch);

            //         // Also update storage locations if needed
            //         // Note: You might want to consider if you need to update storage locations for both fields
            //         // This depends on your business logic

            //         // Update the input field UI value (the one that was clicked)
            //         this._oBatchInputSource.setValue(sBatch);

            //         console.log("✅ Updated BOTH frombatch and tobatch with batch:", sBatch);
            //     }

            //     // Close dialog
            //     if (this._oStockTransferBatchDialog) {
            //         this._oStockTransferBatchDialog.close();
            //     }

            //     // Clear the batch field type
            //     delete this._batchFieldType;
            // },

            // ==================================================================
            // ==================BATCH FRAGMENT ENDS=============================
            // ==================================================================




























            // onDirectTransfer: async function () {
            //     const oView = this.getView();
            //     const oDataModel = oView.getModel("ZSB_DIRECT_TRAN_HD_ITM_API");
            //     const oUpdateModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
            //     const oTabModel = oView.getModel("TabModel");
            //     const aData = oTabModel.getProperty("/Samples");

            //     if (!aData || aData.length === 0) {
            //         sap.m.MessageBox.error("No data available in the table.");
            //         return;
            //     }

            //     const aSelectedRows = aData.filter(row => row.__selected);
            //     if (aSelectedRows.length === 0) {
            //         sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
            //         return;
            //     }

            //     const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
            //     if (aAlreadyPosted.length > 0) {
            //         const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
            //         sap.m.MessageBox.warning(
            //             `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
            //         );
            //         return;
            //     }

            //     const invalid = [];
            //     aSelectedRows.forEach((row, idx) => {
            //         const missing = [];
            //         if (!row.material) missing.push("Material");
            //         if (row.qty === "" || row.qty == null || row.qty == "0.000") missing.push("Quantity");
            //         if (!row.uom) missing.push("Unit");
            //         if (!row.fromplant) missing.push("Plant");
            //         if (!row.fromstorageloc) missing.push("From Storage Location");
            //         if (!row.tostoragelocation) missing.push("To Storage Location");
            //         if (missing.length > 0) invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
            //     });

            //     if (invalid.length > 0) {
            //         sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
            //         return;
            //     }

            //     // const aUniqueRequestNos = [...new Set(aSelectedRows.map(r => r.requestno))];
            //     // if (aUniqueRequestNos.length !== 1) {
            //     //     sap.m.MessageBox.error("All selected rows must have the same Request No to post together.");
            //     //     return;
            //     // }
            //     // const sRequestNo = aUniqueRequestNos[0];

            //     const sGoodsMovementCode = "04";
            //     const sGoodsMovementType = "311";

            //     // const firstRow = aSelectedRows[0];
            //     // const sPostingDate = firstRow.postingdate
            //     //     ? new Date(firstRow.postingdate.toLocaleDateString('en-CA'))
            //     //     : new Date(); // Default to current date if not provided
            //     const sPostingDate = new Date(new Date().toLocaleDateString('en-CA'));

            //     const oHeaderPayload = {
            //         Postingdate: sPostingDate,
            //         Goodsmovementcode: sGoodsMovementCode,
            //         // MaterialDocumentHeaderText: sRequestNo, // Added this based on entity structure
            //         Response: "",
            //         Errorresponse: "",
            //         toitem: aSelectedRows.map(row => ({
            //             Material: row.material,
            //             Quantityinentryunit: row.qty,
            //             Entryunit: row.uom,
            //             Uom: row.uom,
            //             Plant: row.fromplant,
            //             Storagelocation: row.fromstorageloc,
            //             Issuingorreceivingstorageloc: row.tostoragelocation,
            //             Batch: row.frombatch || "", // Handle empty batch
            //             Goodsmovementtype: sGoodsMovementType,
            //             postingdate: sPostingDate,
            //             // postingdate: sPostingDate
            //             //     ? new Date(sPostingDate.toLocaleDateString('en-CA'))
            //             //     : sPostingDate,
            //             goodsmovementcode: sGoodsMovementCode,
            //             // MaterialDocumentHeaderText: sRequestNo // Add this if needed in items
            //         }))
            //     };

            //     console.log("📦 Final Deep Payload:", JSON.stringify(oHeaderPayload, null, 2));

            //     sap.ui.core.BusyIndicator.show(0);

            //     oDataModel.create("/ZC_DIRECT_TRANSFER_HEADER", oHeaderPayload, {
            //         success: (oResponse) => {
            //             console.log("✅ Stock Transfer Success:", oResponse);
            //             sap.ui.core.BusyIndicator.hide();

            //             const sMatDoc = oResponse.Materialdocument;
            //             const sMatYear = oResponse.Matdocyear;

            //             // if (!sMatDoc || !sMatYear) {
            //             //     sap.m.MessageBox.error("No Material Document returned from backend.");
            //             //     return;
            //             // }


            //             if (!sMatDoc || !sMatYear) {
            //                 // Check if there's an error response from backend
            //                 if (oResponse.Errorresponse) {
            //                     try {
            //                         const oError = JSON.parse(oResponse.Errorresponse);
            //                         let sErrorMessage = "Stock Transfer failed: ";

            //                         // Extract the error message from the nested structure
            //                         if (oError.error && oError.error.message) {
            //                             if (typeof oError.error.message === 'object' && oError.error.message.value) {
            //                                 sErrorMessage += oError.error.message.value;
            //                             } else if (typeof oError.error.message === 'string') {
            //                                 sErrorMessage += oError.error.message;
            //                             }
            //                         } else {
            //                             sErrorMessage += "Unknown error occurred.";
            //                         }

            //                         sap.m.MessageBox.error(sErrorMessage);
            //                     } catch (e) {
            //                         // If parsing fails, show generic message
            //                         sap.m.MessageBox.error("No Material Document returned from backend.");
            //                     }
            //                 } else {
            //                     sap.m.MessageBox.error("No Material Document returned from backend.");
            //                 }
            //                 return;
            //             }


            //             const aSamples = oTabModel.getProperty("/Samples");
            //             aSelectedRows.forEach(row => {
            //                 const iIndex = aSamples.findIndex(item => item.sap_uuid === row.sap_uuid);
            //                 if (iIndex !== -1) {
            //                     aSamples[iIndex].materialdocumentno = sMatDoc;
            //                     aSamples[iIndex].matdocyear = sMatYear;

            //                     const oUpdatePayload = {
            //                         materialdocumentno: sMatDoc,
            //                         matdocyear: sMatYear,
            //                         // batch: row.batch || "",
            //                         // issueqty: row.issueqty || row.qty // Use issueqty if exists, otherwise qty
            //                     };

            //                     oUpdateModel.update(`/ZC_DIRECT_TRANSFER_POSTING(sap_uuid='${row.sap_uuid}')`, oUpdatePayload, {
            //                         success: () => console.log(`✅ GT Updated for ${row.sap_uuid}`),
            //                         error: (err) => console.error("❌ GT Update Error:", err)
            //                     });
            //                 }
            //             });

            //             oTabModel.refresh(true);

            //             sap.m.MessageBox.success(
            //                 `All selected line items posted successfully.\n\nMaterial Document: ${sMatDoc}\nYear: ${sMatYear}`
            //             );
            //         },
            //         error: (oError) => {
            //             console.error("❌ Stock Transfer Error:", oError);
            //             sap.ui.core.BusyIndicator.hide();

            //             let sErrorMsg = "Unknown error";
            //             try {
            //                 const oErr = JSON.parse(oError.responseText);
            //                 sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
            //             } catch (e) { }
            //             sap.m.MessageBox.error("Stock transfer posting failed:\n\n" + sErrorMsg);
            //         }
            //     });
            // },



            onDirectTransfer: async function () {
                const oView = this.getView();
                const oDataModel = oView.getModel("ZSB_DIRECT_TRAN_HD_ITM_API");
                const oUpdateModel = oView.getModel("ZSB_DIRECT_TRANSFER_POST");
                const oTabModel = oView.getModel("TabModel");
                const aData = oTabModel.getProperty("/Samples");

                if (!aData || aData.length === 0) {
                    sap.m.MessageBox.error("No data available in the table.");
                    return;
                }

                const aSelectedRows = aData.filter(row => row.__selected);
                if (aSelectedRows.length === 0) {
                    sap.m.MessageBox.warning("Please select at least one row using the checkbox.");
                    return;
                }

                // Store the original selected rows with their indices for updating later
                const aSelectedRowsWithIndices = aSelectedRows.map(row => {
                    const iIndex = aData.findIndex(item => item.sap_uuid === row.sap_uuid);
                    return {
                        ...row,
                        originalIndex: iIndex
                    };
                });

                const aAlreadyPosted = aSelectedRows.filter(row => row.materialdocumentno && row.materialdocumentno.trim() !== "");
                if (aAlreadyPosted.length > 0) {
                    const aDocNos = aAlreadyPosted.map(r => r.materialdocumentno).join(", ");
                    sap.m.MessageBox.warning(
                        `The following rows are already posted with material document(s): ${aDocNos}\n\nPlease deselect them to continue.`
                    );
                    return;
                }

                const invalid = [];
                aSelectedRows.forEach((row, idx) => {
                    const missing = [];
                    if (!row.material) missing.push("Material");
                    if (row.qty === "" || row.qty == null || row.qty == "0.000") missing.push("Quantity");
                    if (!row.uom) missing.push("Unit");
                    if (!row.fromplant) missing.push("Plant");
                    if (!row.fromstorageloc) missing.push("From Storage Location");
                    if (!row.tostoragelocation) missing.push("To Storage Location");
                    if (missing.length > 0) invalid.push(`Row ${idx + 1}: ${missing.join(", ")}`);
                });

                if (invalid.length > 0) {
                    sap.m.MessageBox.error("Please fill mandatory fields:\n\n" + invalid.join("\n"));
                    return;
                }

                const sGoodsMovementCode = "04";
                const sGoodsMovementType = "311";
                // const sPostingDate = new Date(new Date().toLocaleDateString('en-CA'));


                const firstRow = aSelectedRows[0];
                const sPostingDate = firstRow.postingdate
                    ? new Date(firstRow.postingdate.toLocaleDateString('en-CA'))
                    : new Date(); // Default to current date if not provided
                // const sPostingDate = new Date(new Date().toLocaleDateString('en-CA'));
                // debugger
                const oHeaderPayload = {
                    Postingdate: sPostingDate,
                    Goodsmovementcode: sGoodsMovementCode,
                    toitem: aSelectedRows.map(row => ({
                        Material: row.material,
                        Quantityinentryunit: row.qty,
                        Entryunit: row.uom,
                        Uom: row.uom,
                        Plant: row.fromplant,
                        Storagelocation: row.fromstorageloc,
                        Issuingorreceivingstorageloc: row.tostoragelocation,
                        Batch: row.frombatch || "",
                        Issgorrcvgbatch: row.frombatch || "",
                        Goodsmovementtype: sGoodsMovementType,
                        // postingdate: sPostingDate,
                        goodsmovementcode: sGoodsMovementCode
                    }))
                };

                console.log("📦 Final Deep Payload:", JSON.stringify(oHeaderPayload, null, 2));

                sap.ui.core.BusyIndicator.show(0);

                oDataModel.create("/ZC_DIRECT_TRANSFER_HEADER", oHeaderPayload, {
                    success: (oResponse) => {
                        console.log("✅ Stock Transfer Success:", oResponse);
                        sap.ui.core.BusyIndicator.hide();

                        const sMatDoc = oResponse.Materialdocument;
                        const sMatYear = oResponse.Matdocyear;

                        if (!sMatDoc || !sMatYear) {
                            if (oResponse.Errorresponse) {
                                try {
                                    const oError = JSON.parse(oResponse.Errorresponse);
                                    let sErrorMessage = "Stock Transfer failed: ";
                                    if (oError.error && oError.error.message) {
                                        if (typeof oError.error.message === 'object' && oError.error.message.value) {
                                            sErrorMessage += oError.error.message.value;
                                        } else if (typeof oError.error.message === 'string') {
                                            sErrorMessage += oError.error.message;
                                        }
                                    } else {
                                        sErrorMessage += "Unknown error occurred.";
                                    }
                                    sap.m.MessageBox.error(sErrorMessage);
                                } catch (e) {
                                    sap.m.MessageBox.error("No Material Document returned from backend.");
                                }
                            } else {
                                sap.m.MessageBox.error("No Material Document returned from backend.");
                            }
                            return;
                        }

                        // Update the table model with the material document info for each selected row
                        const aSamples = oTabModel.getProperty("/Samples");

                        // Update each selected row in the table model
                        aSelectedRowsWithIndices.forEach(selectedRow => {
                            if (selectedRow.originalIndex !== -1) {
                                // Create a copy of the row to avoid direct mutation if needed
                                const updatedRow = {
                                    ...aSamples[selectedRow.originalIndex],
                                    materialdocumentno: sMatDoc,
                                    matdocyear: sMatYear,
                                    __selected: false // Optionally deselect after posting
                                };

                                // Update in the array
                                aSamples[selectedRow.originalIndex] = updatedRow;

                                // Also update the backend model for this specific row
                                const oUpdatePayload = {
                                    materialdocumentno: sMatDoc,
                                    matdocyear: sMatYear
                                };

                                oUpdateModel.update(`/ZC_DIRECT_TRANSFER_POSTING(sap_uuid='${selectedRow.sap_uuid}')`, oUpdatePayload, {
                                    success: () => console.log(`✅ GT Updated for ${selectedRow.sap_uuid}`),
                                    error: (err) => console.error("❌ GT Update Error:", err)
                                });
                            }
                        });

                        // Set the updated array back to the model
                        oTabModel.setProperty("/Samples", aSamples);

                        // Optional: refresh the binding to ensure UI updates
                        const oTable = oView.byId("idTransferTable"); // Make sure this ID matches your table
                        if (oTable) {
                            oTable.getBinding("items").refresh();
                        }

                        sap.m.MessageBox.success(
                            `All selected line items posted successfully.\n\nMaterial Document: ${sMatDoc}\nYear: ${sMatYear}`
                        );
                    },
                    error: (oError) => {
                        console.error("❌ Stock Transfer Error:", oError);
                        sap.ui.core.BusyIndicator.hide();

                        let sErrorMsg = "Unknown error";
                        try {
                            const oErr = JSON.parse(oError.responseText);
                            sErrorMsg = oErr?.error?.message?.value || sErrorMsg;
                        } catch (e) { }
                        sap.m.MessageBox.error("Stock transfer posting failed:\n\n" + sErrorMsg);
                    }
                });
            },





            // onPrintPressAdobeform: async function () {
            //     console.log("hi");
            //     const oTable = this.byId("idDirectStockTransferTable");

            //     // Get all selected rows
            //     const aAllContexts = oTable.getBinding("rows").getContexts();
            //     const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

            //     if (!aSelectedRows.length) {
            //         sap.m.MessageToast.show("Please select at least one row to print.");
            //         return;
            //     }

            //     // Load pdf-lib if not already loaded
            //     if (!window.PDFLib) {
            //         await new Promise((resolve, reject) => {
            //             const script = document.createElement("script");
            //             script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
            //             script.onload = resolve;
            //             script.onerror = () => reject(new Error("Failed to load PDF library."));
            //             document.head.appendChild(script);
            //         });
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     const { PDFDocument } = window.PDFLib;
            //     const mergedPdf = await PDFDocument.create();

            //     let successCount = 0;
            //     let errorCount = 0;

            //     for (const ctx of aSelectedRows) {
            //         const material = ctx.getObject().material;
            //         if (!material) {
            //             console.warn("Skipping row without material:", ctx.getObject());
            //             errorCount++;
            //             continue;
            //         }

            //         const sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ1?material=" + encodeURIComponent(material);
            //         console.log("url:", sUrl)

            //         try {
            //             const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });
            //             const base64Data = await response.text();

            //             if (base64Data.startsWith("<!DOCTYPE html>")) {
            //                 console.error("Backend error for material:", material);
            //                 errorCount++;
            //                 continue;
            //             }

            //             // Convert base64 → Uint8Array
            //             const pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
            //             const pdfToMerge = await PDFDocument.load(pdfBytes);
            //             const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
            //             copiedPages.forEach(page => mergedPdf.addPage(page));
            //             successCount++;

            //         } catch (err) {
            //             console.error("Error fetching/merging PDF for material:", material, err);
            //             errorCount++;
            //         }
            //     }

            //     sap.ui.core.BusyIndicator.hide(0);

            //     if (successCount === 0) {
            //         sap.m.MessageToast.show("No valid PDF could be retrieved. Check console for errors.");
            //         return;
            //     }

            //     // Save and open the merged PDF
            //     const mergedPdfBytes = await mergedPdf.save();
            //     const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
            //     const pdfUrl = URL.createObjectURL(blob);
            //     window.open(pdfUrl, "_blank");

            //     if (errorCount > 0) {
            //         sap.m.MessageToast.show(`Merged ${successCount} PDF(s). ${errorCount} failed.`);
            //     } else {
            //         sap.m.MessageToast.show(`Successfully merged ${successCount} PDF(s).`);
            //     }
            // },
            // onPrintPressAdobeform: async function () {
            //     console.log("hi");
            //     const oTable = this.byId("idDirectStockTransferTable");

            //     // Get all selected rows
            //     const aAllContexts = oTable.getBinding("rows").getContexts();
            //     const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

            //     if (!aSelectedRows.length) {
            //         sap.m.MessageToast.show("Please select at least one row to print.");
            //         return;
            //     }

            //     // Make sure pdf-lib global is available
            //     if (!window.PDFLib) {
            //         await new Promise((resolve, reject) => {
            //             const script = document.createElement("script");
            //             script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
            //             script.onload = resolve;
            //             script.onerror = () => reject(new Error("Failed to load PDF library."));
            //             document.head.appendChild(script);
            //         });
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     const { PDFDocument } = window.PDFLib;
            //     const mergedPdf = await PDFDocument.create();

            //     let successCount = 0;
            //     let errorCount = 0;

            //     for (const ctx of aSelectedRows) {
            //         const sap_uuid = ctx.getObject().sap_uuid;
            //         const requestedBy = ctx.getObject().requestedby;

            //         if (!sap_uuid) {
            //             console.warn("Skipping row without sap_uuid:", ctx.getObject());
            //             errorCount++;
            //             continue;
            //         }
            //         if (!requestedBy) {
            //             console.warn("Skipping row without requestedby:", ctx.getObject());
            //             errorCount++;
            //             continue;
            //         }

            //         // Build URL with both parameters
            //         const sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ1?sap_uuid=" 
            //                      + encodeURIComponent(sap_uuid) 
            //                      + "&requestedby=" + encodeURIComponent(requestedBy);
            //         console.log("url:", sUrl);

            //         try {
            //             const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });
            //             const base64Data = await response.text();

            //             // Skip if backend returned HTML (error)
            //             if (base64Data.startsWith("<!DOCTYPE html>")) {
            //                 console.error("Backend error for sap_uuid:", sap_uuid, "requestedby:", requestedBy);
            //                 errorCount++;
            //                 continue;
            //             }

            //             // Convert Base64 → PDF (as in working reference)
            //             const pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
            //             const pdfToMerge = await PDFDocument.load(pdfBytes);
            //             const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
            //             copiedPages.forEach(page => mergedPdf.addPage(page));
            //             successCount++;
            //         } catch (err) {
            //             console.error("Error fetching/merging PDF for sap_uuid:", sap_uuid, "requestedby:", requestedBy, err);
            //             errorCount++;
            //             sap.m.MessageToast.show("Error merging PDF for sap_uuid: " + sap_uuid);
            //         }
            //     }

            //     sap.ui.core.BusyIndicator.hide(0);

            //     if (successCount === 0) {
            //         sap.m.MessageToast.show("No valid PDF could be retrieved. Check console for errors.");
            //         return;
            //     }

            //     // Save the merged PDF
            //     const mergedPdfBytes = await mergedPdf.save();
            //     const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
            //     const pdfUrl = URL.createObjectURL(blob);
            //     window.open(pdfUrl, "_blank");

            //     if (errorCount > 0) {
            //         sap.m.MessageToast.show(`Merged ${successCount} PDF(s). ${errorCount} failed.`);
            //     } else {
            //         sap.m.MessageToast.show(`Successfully merged ${successCount} PDF(s).`);
            //     }
            // },


            // onPrintPressAdobeform: async function () {
            //     // console.log("hi");
            //     const oTable = this.byId("idDirectStockTransferTable");

            //     // Get all selected rows
            //     const aAllContexts = oTable.getBinding("rows").getContexts();
            //     const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

            //     if (!aSelectedRows.length) {
            //         sap.m.MessageToast.show("Please select at least one row to print.");
            //         return;
            //     }

            //     const missingUuidRows = [];
            //     const missingRequestedByRows = [];

            //     for (const ctx of aSelectedRows) {
            //         const row = ctx.getObject();
            //         const sap_uuid = row.sap_uuid;
            //         const requestedBy = row.requestedby;

            //         if (!sap_uuid) {
            //             missingUuidRows.push(row);
            //         } else if (!requestedBy) {
            //             missingRequestedByRows.push(row);
            //         }
            //     }

            //     // Show error and abort if any rows are invalid
            //     if (missingUuidRows.length > 0) {
            //         const rowNumbers = missingUuidRows.map((row, idx) => idx + 1).join(", ");
            //         sap.m.MessageBox.error(`The following selected row(s) do not have a saved UUID. Please save them first.\nRows: ${rowNumbers}`);
            //         return;
            //     }

            //     if (missingRequestedByRows.length > 0) {
            //         const rowNumbers = missingRequestedByRows.map((row, idx) => idx + 1).join(", ");
            //         sap.m.MessageBox.error(`The following selected row(s) are missing the "Requested By" field.\nRows: ${rowNumbers}\nPlease fill the field before printing.`);
            //         return;
            //     }


            //     // Make sure pdf-lib global is available
            //     if (!window.PDFLib) {
            //         await new Promise((resolve, reject) => {
            //             const script = document.createElement("script");
            //             script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
            //             script.onload = resolve;
            //             script.onerror = () => reject(new Error("Failed to load PDF library."));
            //             document.head.appendChild(script);
            //         });
            //     }

            //     sap.ui.core.BusyIndicator.show(0);
            //     const { PDFDocument } = window.PDFLib;
            //     const mergedPdf = await PDFDocument.create();

            //     // --- Group rows by "requestedby" ---
            //     const groups = new Map(); // key: requestedby, value: array of sap_uuid
            //     for (const ctx of aSelectedRows) {
            //         const sap_uuid = ctx.getObject().sap_uuid;
            //         const requestedBy = ctx.getObject().requestedby;
            //         if (!sap_uuid) {
            //             console.warn("Skipping row without sap_uuid:", ctx.getObject());
            //             continue;
            //         }
            //         if (!requestedBy) {
            //             console.warn("Skipping row without requestedby:", ctx.getObject());
            //             continue;
            //         }
            //         if (!groups.has(requestedBy)) {
            //             groups.set(requestedBy, []);
            //         }
            //         groups.get(requestedBy).push(sap_uuid);
            //     }

            //     if (groups.size === 0) {
            //         sap.ui.core.BusyIndicator.hide();
            //         sap.m.MessageToast.show("No valid rows (missing sap_uuid or requestedby).");
            //         return;
            //     }

            //     let successCount = 0;
            //     let errorCount = 0;

            //     // Process each group (one HTTP request per distinct requestedby)
            //     for (const [requestedBy, sapUuidList] of groups.entries()) {
            //         // Build URL with multiple sap_uuid parameters
            //         // let sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ1?";
            //         // for (const uuid of sapUuidList) {
            //         //     sUrl += "sap_uuid=" + encodeURIComponent(uuid) + "&";
            //         // }
            //         const joinedUuids = sapUuidList.join("^");
            //         let sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ1?";
            //         sUrl += "sap_uuid=" + encodeURIComponent(joinedUuids);
            //         sUrl += "&requestedby=" + encodeURIComponent(requestedBy);
            //         // sUrl += "requestedby=" + encodeURIComponent(requestedBy);
            //         console.log("Group URL:", sUrl);

            //         try {
            //             const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });
            //             const base64Data = await response.text();

            //             // Skip if backend returned HTML (error)
            //             if (base64Data.startsWith("<!DOCTYPE html>")) {
            //                 console.error("Backend error for requestedby:", requestedBy, "uuids:", sapUuidList);
            //                 errorCount++;
            //                 continue;
            //             }

            //             // Convert Base64 → PDF
            //             const pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
            //             const pdfToMerge = await PDFDocument.load(pdfBytes);
            //             const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
            //             copiedPages.forEach(page => mergedPdf.addPage(page));
            //             successCount++;
            //         } catch (err) {
            //             console.error("Error fetching/merging PDF for requestedby:", requestedBy, "uuids:", sapUuidList, err);
            //             errorCount++;
            //             sap.m.MessageToast.show("Error merging PDF for group: " + requestedBy);
            //         }
            //     }

            //     sap.ui.core.BusyIndicator.hide();

            //     if (successCount === 0) {
            //         sap.m.MessageToast.show("No valid PDF could be retrieved. Check console for errors.");
            //         return;
            //     }

            //     // Save the merged PDF
            //     const mergedPdfBytes = await mergedPdf.save();
            //     const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
            //     const pdfUrl = URL.createObjectURL(blob);
            //     window.open(pdfUrl, "_blank");

            //     if (errorCount > 0) {
            //         sap.m.MessageToast.show(`Merged ${successCount} group(s). ${errorCount} group(s) failed.`);
            //     } else {
            //         sap.m.MessageToast.show(`Successfully merged ${successCount} group(s).`);
            //     }
            // },


            onPrintPressAdobeFormBeforePost: async function () {
                const oTable = this.byId("idDirectStockTransferTable");

                // Get all selected rows
                const aAllContexts = oTable.getBinding("rows").getContexts();
                const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

                if (!aSelectedRows.length) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                const missingUuidRows = [];
                const missingRequestedByRows = [];
                const materialDocExistsRows = [];

                for (const ctx of aSelectedRows) {
                    const row = ctx.getObject();
                    const sap_uuid = row.sap_uuid;
                    const requestedBy = row.requestedby;
                    const materialDocumentNo = row.materialdocumentno; // Change this if your property name is different

                    // Check UUID
                    if (!sap_uuid) {
                        missingUuidRows.push(row);
                    }

                    // Check Requested By
                    if (!requestedBy) {
                        missingRequestedByRows.push(row);
                    }

                    // Material Document No should be blank for printing
                    if (materialDocumentNo) {
                        materialDocExistsRows.push(row);
                    }
                }

                if (missingUuidRows.length > 0) {
                    const rowNumbers = missingUuidRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(
                        `The following selected row(s) do not have a saved UUID. Please save them first.\nRows: ${rowNumbers}`
                    );
                    return;
                }

                if (missingRequestedByRows.length > 0) {
                    const rowNumbers = missingRequestedByRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(
                        `The following selected row(s) are missing the "Requested By" field.\nRows: ${rowNumbers}\nPlease fill the field before printing.`
                    );
                    return;
                }

                if (materialDocExistsRows.length > 0) {
                    const rowNumbers = materialDocExistsRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(
                        `The following selected row(s) already have a "Material Document No".\nRows: ${rowNumbers}\nPrinting is only allowed when the Material Document No is blank.`
                    );
                    return;
                }

                // Make sure pdf-lib global is available
                if (!window.PDFLib) {
                    await new Promise((resolve, reject) => {
                        const script = document.createElement("script");
                        script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
                        script.onload = resolve;
                        script.onerror = () => reject(new Error("Failed to load PDF library."));
                        document.head.appendChild(script);
                    });
                }

                sap.ui.core.BusyIndicator.show(0);
                const { PDFDocument } = window.PDFLib;
                const mergedPdf = await PDFDocument.create();

                // --- Group rows by "requestedby" ---
                const groups = new Map();
                for (const ctx of aSelectedRows) {
                    const sap_uuid = ctx.getObject().sap_uuid;
                    const requestedBy = ctx.getObject().requestedby;
                    if (!sap_uuid || !requestedBy) continue;
                    if (!groups.has(requestedBy)) groups.set(requestedBy, []);
                    groups.get(requestedBy).push(sap_uuid);
                }

                if (groups.size === 0) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageToast.show("No valid rows (missing sap_uuid or requestedby).");
                    return;
                }

                let successCount = 0;
                let errorCount = 0;


                // Process each group
                for (const [requestedBy, sapUuidList] of groups.entries()) {
                    const joinedUuids = sapUuidList.join("^");
                    const sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ1?sap_uuid=" + encodeURIComponent(joinedUuids) + "&requestedby=" + encodeURIComponent(requestedBy);
                    console.log("Group URL:", sUrl);

                    console.log("Requested By:", requestedBy);


                    try {
                        const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });

                        // ✅ Check HTTP status (critical fix)
                        if (!response.ok) {
                            console.error(`HTTP ${response.status} for requestedby: ${requestedBy}`, await response.text());
                            sap.m.MessageToast.show(`Failed for group "${requestedBy}" – HTTP ${response.status}`);
                            errorCount++;
                            continue;
                        }

                        const base64Data = await response.text();

                        // ✅ Skip if backend returned HTML (error page)
                        if (base64Data.trim().startsWith("<")) {
                            console.error("Backend returned HTML (likely error) for requestedby:", requestedBy, "uuids:", sapUuidList);
                            errorCount++;
                            continue;
                        }

                        // ✅ Safely decode base64 (could still fail if response is corrupted)
                        let pdfBytes;
                        try {
                            pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
                        } catch (e) {
                            console.error("Invalid base64 data for requestedby:", requestedBy, e);
                            errorCount++;
                            continue;
                        }

                        // Load and merge PDF
                        const pdfToMerge = await PDFDocument.load(pdfBytes);
                        const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
                        copiedPages.forEach(page => mergedPdf.addPage(page));
                        successCount++;
                    } catch (err) {
                        console.error("Error fetching/merging PDF for requestedby:", requestedBy, "uuids:", sapUuidList, err);
                        sap.m.MessageToast.show("Error merging PDF for group: " + requestedBy);
                        errorCount++;
                    }
                }

                sap.ui.core.BusyIndicator.hide();

                if (successCount === 0) {
                    sap.m.MessageToast.show("No valid PDF could be retrieved. Check console for errors.");
                    return;
                }

                // Save the merged PDF
                const mergedPdfBytes = await mergedPdf.save();
                const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
                const pdfUrl = URL.createObjectURL(blob);
                window.open(pdfUrl, "_blank");

                if (errorCount > 0) {
                    sap.m.MessageToast.show(`Merged ${successCount} group(s). ${errorCount} group(s) failed.`);
                } else {
                    sap.m.MessageToast.show(`Successfully merged ${successCount} group(s).`);
                }
            },



            onPrintPressAdobeformAfterPost: async function () {
                const oTable = this.byId("idDirectStockTransferTable");

                // Get all selected rows
                const aAllContexts = oTable.getBinding("rows").getContexts();
                const aSelectedRows = aAllContexts.filter(ctx => ctx.getObject().__selected);

                if (!aSelectedRows.length) {
                    sap.m.MessageToast.show("Please select at least one row to print.");
                    return;
                }

                const missingUuidRows = [];
                const missingRequestedByRows = [];
                const missingMatDocRows = [];

                for (const ctx of aSelectedRows) {
                    const row = ctx.getObject();
                    const sap_uuid = row.sap_uuid;
                    const requestedBy = row.requestedby;
                    const matDocNo = row.materialdocumentno;

                    if (!sap_uuid) {
                        missingUuidRows.push(row);
                    } else if (!requestedBy) {
                        missingRequestedByRows.push(row);
                    } else if (!matDocNo) {                   // <-- check if material document number is empty
                        missingMatDocRows.push(row);
                    }
                }

                if (missingUuidRows.length > 0) {
                    const rowNumbers = missingUuidRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(`The following selected row(s) do not have a saved UUID. Please save them first.\nRows: ${rowNumbers}`);
                    return;
                }

                if (missingRequestedByRows.length > 0) {
                    const rowNumbers = missingRequestedByRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(`The following selected row(s) are missing the "Requested By" field.\nRows: ${rowNumbers}\nPlease fill the field before printing.`);
                    return;
                }

                // New check for Material Document No
                if (missingMatDocRows.length > 0) {
                    const rowNumbers = missingMatDocRows.map((_, idx) => idx + 1).join(", ");
                    sap.m.MessageBox.error(`The following selected row(s) are missing the "Material Document No" field.\nRows: ${rowNumbers}\nPlease enter a value before printing.`);
                    return;
                }

                // Make sure pdf-lib global is available
                if (!window.PDFLib) {
                    await new Promise((resolve, reject) => {
                        const script = document.createElement("script");
                        script.src = sap.ui.require.toUrl("bando/util/pdf-lib/pdf-lib.min.js");
                        script.onload = resolve;
                        script.onerror = () => reject(new Error("Failed to load PDF library."));
                        document.head.appendChild(script);
                    });
                }

                sap.ui.core.BusyIndicator.show(0);
                const { PDFDocument } = window.PDFLib;
                const mergedPdf = await PDFDocument.create();

                // --- Group rows by "requestedby" ---
                const groups = new Map();
                for (const ctx of aSelectedRows) {
                    const sap_uuid = ctx.getObject().sap_uuid;
                    const requestedBy = ctx.getObject().requestedby;
                    if (!sap_uuid || !requestedBy) continue;
                    if (!groups.has(requestedBy)) groups.set(requestedBy, []);
                    groups.get(requestedBy).push(sap_uuid);
                }

                if (groups.size === 0) {
                    sap.ui.core.BusyIndicator.hide();
                    sap.m.MessageToast.show("No valid rows (missing sap_uuid or requestedby).");
                    return;
                }

                let successCount = 0;
                let errorCount = 0;


                // Process each group
                for (const [requestedBy, sapUuidList] of groups.entries()) {
                    const joinedUuids = sapUuidList.join("^");
                    const sUrl = "/sap/bc/http/sap/Z_DIR_MAT_REQ2?sap_uuid=" + encodeURIComponent(joinedUuids) + "&requestedby=" + encodeURIComponent(requestedBy);
                    console.log("Group URL:", sUrl);
                    console.log("Requested By:", requestedBy);


                    // https://my425853.s4hana.cloud.sap/sap/bc/http/sap/Z_DIR_MAT_REQ2?sap-client=080

                    try {
                        const response = await fetch(sUrl, { headers: { "Accept": "application/pdf" } });

                        // ✅ Check HTTP status (critical fix)
                        if (!response.ok) {
                            console.error(`HTTP ${response.status} for requestedby: ${requestedBy}`, await response.text());
                            sap.m.MessageToast.show(`Failed for group "${requestedBy}" – HTTP ${response.status}`);
                            errorCount++;
                            continue;
                        }

                        const base64Data = await response.text();

                        // ✅ Skip if backend returned HTML (error page)
                        if (base64Data.trim().startsWith("<")) {
                            console.error("Backend returned HTML (likely error) for requestedby:", requestedBy, "uuids:", sapUuidList);
                            errorCount++;
                            continue;
                        }

                        // ✅ Safely decode base64 (could still fail if response is corrupted)
                        let pdfBytes;
                        try {
                            pdfBytes = Uint8Array.from(atob(base64Data), c => c.charCodeAt(0));
                        } catch (e) {
                            console.error("Invalid base64 data for requestedby:", requestedBy, e);
                            errorCount++;
                            continue;
                        }

                        // Load and merge PDF
                        const pdfToMerge = await PDFDocument.load(pdfBytes);
                        const copiedPages = await mergedPdf.copyPages(pdfToMerge, pdfToMerge.getPageIndices());
                        copiedPages.forEach(page => mergedPdf.addPage(page));
                        successCount++;
                    } catch (err) {
                        console.error("Error fetching/merging PDF for requestedby:", requestedBy, "uuids:", sapUuidList, err);
                        sap.m.MessageToast.show("Error merging PDF for group: " + requestedBy);
                        errorCount++;
                    }
                }

                sap.ui.core.BusyIndicator.hide();

                if (successCount === 0) {
                    sap.m.MessageToast.show("No valid PDF could be retrieved. Check console for errors.");
                    return;
                }

                // Save the merged PDF
                const mergedPdfBytes = await mergedPdf.save();
                const blob = new Blob([mergedPdfBytes], { type: "application/pdf" });
                const pdfUrl = URL.createObjectURL(blob);
                window.open(pdfUrl, "_blank");

                if (errorCount > 0) {
                    sap.m.MessageToast.show(`Merged ${successCount} group(s). ${errorCount} group(s) failed.`);
                } else {
                    sap.m.MessageToast.show(`Successfully merged ${successCount} group(s).`);
                }
            },

            // onFilterRequestedBy: function (oEvent) {
            //     var sQuery = oEvent.getParameter("query") ||
            //                  oEvent.getParameter("newValue");

            //     var oTable = this.byId("idDirectStockTransferTable");
            //     var oBinding = oTable.getBinding("rows");

            //     var aFilters = [];

            //     if (sQuery) {
            //         aFilters.push(
            //             new sap.ui.model.Filter(
            //                 "requestedby",
            //                 sap.ui.model.FilterOperator.Contains,
            //                 sQuery
            //             )
            //         );
            //     }

            //     oBinding.filter(aFilters);
            // }

        });
    });