sap.ui.define([
	"bando/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
