/* global QUnit */

sap.ui.require(["bando/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
